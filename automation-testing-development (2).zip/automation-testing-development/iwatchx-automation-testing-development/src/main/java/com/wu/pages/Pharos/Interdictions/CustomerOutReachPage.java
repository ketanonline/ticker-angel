package com.wu.pages.Pharos.Interdictions;

import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;

public class CustomerOutReachPage extends BasePage {

    public WebElement getCaseRefClipboardIcon(){
        return browserElementLocator.findElementByXpath("(//mat-icon[text()='file_copy'])[1]");
    }

    public WebElement getCOPanel(){
        return browserElementLocator.findElementByXpath("//fuse-sidebar[@class='w-400 fuse-sidebar right-positioned animations-enabled open']");
    }

    public WebElement getURLClipboardIcon(){
        return browserElementLocator.findElementByXpath("(//mat-icon[text()='file_copy'])[2]");
    }

    public WebElement getCustomerPanelTitle(String title) {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'" + title + "')]");
    }

    public WebElement getCustomerOutReachButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'perm_phone_msg')]");
    }

    public WebElement getCaseRefValueField() {
        return browserElementLocator.findElementByXpath("(//mat-label[contains(text(),'Case reference No.:')]//following::mat-label)[1]");
    }

    public WebElement getUploadValueField() {
        return browserElementLocator.findElementByXpath("//mat-label[contains(text(),'www.id.wu.com')]");
    }

    public String getClipboardItem() throws IOException, UnsupportedFlavorException {

        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        Transferable contents = clipboard.getContents(null);
        String content = (String) contents.getTransferData(DataFlavor.stringFlavor);
        Logger.info("Successfully retreived the clipboard content as : " + content);
        return content;
    }

    public String getClipboardItemFromOpenDUTURL() throws IOException, UnsupportedFlavorException {
        getURLClipboardIcon().click();
        String text=getClipboardItem();
        System.out.println("The Open DUT clipboard content Fetched is "+text);
        return  text;
    }

    public String validateCaseRefValue() throws InterruptedException {
        System.out.println("Case Reference values fetched from Panel is :"+getCaseRefValueField().getText());
        return getCaseRefValueField().getText();
    }

    public void validateUploadLinkValue() throws InterruptedException {
        System.out.println("Open DUT Link fetched from Panel is :"+getUploadValueField().getText());
    }

    public void verifyCOPanelTitle(String title) throws InterruptedException {
        Thread.sleep(2000);
        if (getCustomerPanelTitle(title).isEnabled()) {
            System.out.println("Customer Out reach title is displayed");
        }
    }

    public void clickCustomerOutreachIcon()throws InterruptedException {
        if(getCustomerOutReachButton().isEnabled()){
            getCustomerOutReachButton().click();
        }
    }
    public WebElement closeCustomerOutreachBtn() throws Exception {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'close')]");
    }

    public void verifyPanelShouldOpen() throws InterruptedException {
        if (getCOPanel()!=null) {
            System.out.println("Customer outreach Panel is opened");
        }
        else{
            System.out.println("Customer outreach Panel is not opened");
        }
    }

    public void getClipboardItemFromCaseReference() throws IOException, UnsupportedFlavorException, ParseException, InterruptedException {
        getCaseRefClipboardIcon().click();
        Logger.info("Analyst clicked on case reference clipboard icon");
        String jsonText;
        jsonText=getClipboardItem();
//        JSONObject obj = new JSONObject(jsonText);
        String caserefUI=validateCaseRefValue();
        Assert.assertEquals(jsonText,caserefUI,"Case reference number has been verified with Case details");

//        if(isJSONValid(jsonText)){
//            Logger.info("Retreived clipboard content has been verified as a valid JSON");
//            Logger.info("The JSON retrived is : "+obj);
//        }
//        Map<String, Object> jsonDocument = new ObjectMapper()
//                .readValue(jsonText, new TypeReference<Map<String, Object>>() {});
//        String caselist=null;
//        for (Map.Entry<String, Object> entry : jsonDocument.entrySet()) {
//            Logger.info("Successfully retreived JSON node as "+entry.getKey() + " : " + entry.getValue().toString());
//            if(entry.getKey()=="case"){
//                caselist=entry.getValue().toString();
//                String final_caseref= caselist.substring(120,(caselist.length()-1));
//                Logger.info("Case reference extracted from the retreived JSON is "+final_caseref);
//                String caserefUI=validateCaseRefValue();
//                Assert.assertEquals(final_caseref,caserefUI,"Case reference number has been verified with Case details");
//                String final_case1= caselist.substring(4,(caselist.length()-86));
//                Logger.info("Case ID retreived from JSON is "+final_case1);
//                Logger.info("Scenario passed : JSON content has been validated for SBT tool");
//            }
//        }
    }
    public boolean isJSONValid(String test) {
        try {
            new JSONObject(test);
        } catch (JSONException ex) {
            try {
                new JSONArray(test);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }
    public void ValidateCaseRefnofromDB(String caseRefNo) throws InterruptedException {
        Thread.sleep(2000);
        if (caseRefNo.contains("$")) {
            caseRefNo = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
        }
        String actWorkFlow = getCaserefnumber().getText().trim();

        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();
//        actWorkFlow=actWorkFlow.replaceAll(" ","");

        String expWorkFlow = ""+caseRefNo+"";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
        assertThat("WorkFlow is validated", actWorkFlow.equals(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);
    }

    private WebElement getCaserefnumber() {
        return browserElementLocator.findElementByXpath("(//mat-label[contains(text(),'Case reference No.:')]//following::mat-label)[1]");
    }
}
