package com.wu.pages;

import com.wu.base.logger.Logger;
import com.wu.base.selenium.*;

public class BasePage {

    public static String PAYMENT_ID;
    public static String CASE_ID;
    public static String ORDER_ID;
    public static String Confirmation_Number;
    public static String Customer_ID;
    protected WindowsElements windowsElements;
    protected WindowsTextBox windowsTextBox;
    protected WindowsElementLocator windowsElementLocator;

    protected BrowserElements browserElements;
    protected BrowserElementLocator browserElementLocator;
    protected BrowserCheckBox browserCheckBox;
    protected BrowserTextBox browserTextBox;
    protected BrowserWindows browserWindows;
    protected JavaScriptExecutor javaScriptExecutor;
    protected BrowserPage browserPage;


    public BasePage() {
        windowsElements = new WindowsElements();
        windowsElementLocator = new WindowsElementLocator();
        windowsTextBox = new WindowsTextBox();
        browserElements = new BrowserElements();

        browserElementLocator = new BrowserElementLocator();
        browserCheckBox = new BrowserCheckBox();
        browserTextBox = new BrowserTextBox();
        browserWindows = new BrowserWindows();
        javaScriptExecutor = new JavaScriptExecutor();
        browserPage = new BrowserPage();
    }

    protected void wait(int miliSec) {
        try {
            Thread.sleep(miliSec);
        } catch (InterruptedException ie) {
            Logger.error("wait() interrupted!");
        }
    }

}
