package com.wu.pages.Pharos.Interdictions;

import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;

public class PartyActivityInformationPage extends BasePage {

    public WebElement getIssueID() {
        return browserElementLocator.findElementByXpath("(//div//*[contains(text(),'GEO')]//following::div[contains(@class,'mt')]//span[contains(@class,'wu-align-right wu-text-truncate')])[1]");
    }

    public String getIDCountry() {
        return getIssueID().getText();
    }

    public WebElement getEmailElement() {
        return browserElementLocator.findElementByXpath("(//div//*[contains(text(),'GEO')]//following::div[contains(@class,'mt')]//span[contains(@class,'wu-align-right wu-text-truncate')])[2]");
    }

    public WebElement getMoreBtnGEO() {
        return browserElementLocator.findElementByXpath("//p/span[contains(.,'Address')]//following::a[contains(text(),'more')][1]");
    }

    public WebElement getAddressLineText() {
        return browserElementLocator.findElementByXpath("(//span[contains(text(),'Address')]//following::span[contains(@class,'wu-align-right')])[1]");
    }

    public WebElement getZipCode() {
        return browserElementLocator.findElementByXpath("//p/span[contains(.,'Address')]//following::span[contains(@class,'wu-align-right ng-star-inserted')][3]");
    }

    public WebElement getAccountNumberSender(){
        return browserElementLocator.findElementByXpath("(//div[@class='wu-subject-card-content']//div[3]//following::p)[1]");
    }

    public void clickMore() {
        getMoreBtnGEO().click();
    }

    public String getZipCodeText() {
        return getZipCode().getText();
    }

    public String getEmail() {
        return getEmailElement().getText();
    }

    public String getAddressLine() {
        return getAddressLineText().getText();
    }

    public String getZipcodetext() {
        return getZipCode().getText();
    }

}
