package com.wu.pages.Pharos.Interdictions;

import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;

public class ConversationPage extends BasePage{

    public WebElement getConversationInputBox() {
        return browserElementLocator.findElementByXpath("//textarea[@placeholder='Start Conversation']");
    }

    public void verifyConversationFooter() {
        browserElements.isElementDisplayed(getConversationInputBox());
    }

    public WebElement getConversationCloseButton(){
        return browserElementLocator.findElementByXpath("//div[@class='app-sidebar']/div/div[2]/button[2]/span/mat-icon");
    }

    public WebElement getViewAllLink() {
        return browserElementLocator.findElementByXpath("//a[contains(text(),'View All')]");
    }

    public WebElement getArrowMarkSubmitButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'send')]");
    }

    public WebElement getToaster() {
        return browserElementLocator.findElementByXpath("//*[text()='Conversation Saved Successfully!']");
    }

    public WebElement getPopupMenu() {
        return browserElementLocator.findElementByXpath("//ul[@class='wu-dropdown-menu ng-star-inserted']");
    }

    public WebElement getConversationPanel() {
        return browserElementLocator.findElementByXpath("//span[@class='wu-sidebar-title']");
    }

    public WebElement getPartyIdLabel() {
        return browserElementLocator.findElementByXpath("//ul[@class='wu-dropdown-menu ng-star-inserted']/li[1]/a[2]");
    }

    public WebElement getPartyIDLink() {
        return browserElementLocator.findElementByXpath("//ul[@class='wu-dropdown-menu ng-star-inserted']/li[1]");
    }

    public WebElement getMTCNLabel() {
        return browserElementLocator.findElementByXpath("//ul[@class='wu-dropdown-menu ng-star-inserted']/li[2]/a[2]");
    }

    public void clickOnViewAllLink() {
        getViewAllLink().click();
    }

    public void enterTextInConversationBox(String inputText) {
        browserElements.clickElementAfterFocus(getConversationInputBox());
        browserTextBox.sendKeys(getConversationInputBox(),inputText);
    }

    public WebElement getConversations() {
//        return browserElementLocator.findElementByXpath("//div[@class='wu-comments-container']/div[2]/mat-card/mat-card-content");
        return browserElementLocator.findElementByXpath("(//mat-card-content/p)[1]");
    }

    public String getConversationComment()
    {
        return getConversations().getText();
    }

    public void closeConversationPanel(){
        getConversationCloseButton().click();
    }

    public WebElement getLevel() {
        return browserElementLocator.findElementByXpath("//mat-icon[@class='mat-icon notranslate mat-menu-trigger wu-dropdown material-icons-outlined mat-icon-no-color']");
    }

    public WebElement getPrivacyDropdown(String btnName) {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'"+btnName+"')]");
    }

    public String getMTCNValue() {
        return browserElementLocator.findElementByXpath("(//div[contains(@class,'wu-text-input-highlight-container')]/ul/li[2]/div/a[1])[1]").getText();
    }

    public String getPartyIDValue() {
        return browserElementLocator.findElementByXpath("(//div[contains(@class,'wu-text-input-highlight-container')]/ul/li[1]/div/a[1])[1]").getText();
    }

    public WebElement getFilterIcon() {
        return browserElementLocator.findElementByXpath("//*[text()='filter_list_alt ']");
    }

    public WebElement getMTCNFilter() {
        return browserElementLocator.findElementByXpath("//mat-action-list[@class='mat-list mat-list-base mat-action-list']/button[3]");
    }

    public WebElement getFilterCheckBox() {
        return browserElementLocator.findElementByXpath("//mat-pseudo-checkbox[contains(@class,'mat-pseudo-checkbox')]");
    }

    public WebElement getApplyButton() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Apply')]");
    }

    public WebElement getSubjectFilter() {
        return browserElementLocator.findElementByXpath("//mat-action-list[@class='mat-list mat-list-base mat-action-list']/button[2]");
    }

    public WebElement getCaseFilter() {
        return browserElementLocator.findElementByXpath("//mat-action-list[@class='mat-list mat-list-base mat-action-list']/button[1]");
    }

    public WebElement getMTCN_ConversationPanel() {
        return browserElementLocator.findElementByXpath("//div[@class='mat-list-item-content']");
    }

    public WebElement getMessage() {
        return browserElementLocator.findElementByXpath("//div[@class='wu-result-txt text-center']");
    }

    public String getTextInConversationBox()  {
        return getConversationInputBox().getAttribute("value");
    }

    public WebElement getCancelButton() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Cancel')]");
    }

    public WebElement getClearFilter() {
        return browserElementLocator.findElementByXpath("//div[contains(text(),'Clear Filter')]");
    }


    public WebElement getSubject_ConversationPanel() {
        return browserElementLocator.findElementByXpath("//div[@class='mat-list-text']");
    }

    public String getPartyIDLabel() {
        return browserElementLocator.findElementByXpath("(//div[@class='wu-heading'][1])[1]").getText();
    }

    public WebElement getAnalyst() {
        return browserElementLocator.findElementByXpath("//div[@class='h3 username']");
    }

    public WebElement getConversationAnalyst() {
        return browserElementLocator.findElementsByXpath("//mat-card[@class='mat-card mat-focus-indicator wu-card-primary ng-star-inserted']/span").get(0);
    }

    public WebElement getDateAndTime() {
        return  browserElementLocator.findElementsByXpath("//mat-card[@class='mat-card mat-focus-indicator wu-card-primary ng-star-inserted']/div").get(0);
    }

    public WebElement getCharacterCounter() {
        return browserElementLocator.findElementByXpath("//span[@class='wu-hint']");
    }

    public void verifyCharacterCounter(String num) {
        String actValue = getCharacterCounter().getText();
        Logger.info("Expected text: "+num);
        Logger.info("Actual text: "+actValue);
        assertThat("Character Counter is updated", actValue.equals(num));
        Logger.info("Character Counter is updated correctly");
    }

    public String getConversationDateAndTime()
    {
        return getDateAndTime().getText();
    }

    public String getConversationAnalystName()
    {
        return getConversationAnalyst().getText();
    }

    public String getAnalystName()
    {
        return getAnalyst().getText();
    }

    public void clickOnCancelButton() {
        getCancelButton().click();
    }

    public String getComment()
    {
        return getMessage().getText();
    }

    public void clickOnClearFilter() {
        getClearFilter().click();
    }

    public void clickOnCaseIdFilter() {
        getCaseFilter().click();
        getFilterCheckBox().click();
    }

    public void clickOnSubjectFilter() {
        getSubjectFilter().click();
        getFilterCheckBox().click();
    }

    public void clickOnApplyButton() {
        getApplyButton().click();
    }

    public void clickOnFilter() {
        getFilterIcon().click();
    }

    public void clickOnMTCNFilter() {
        getMTCNFilter().click();
        getFilterCheckBox().click();
    }
    public void clickOnArrowMarkButton() {
        getArrowMarkSubmitButton().click();
    }

    public void verifyConfirmationMsg() {
        String tstValue = getToaster().getAttribute("innerHTML");
        System.out.println(tstValue);
        if (tstValue.contains("Mail"))
            Logger.info("Saved successfully message appeared");
    }

    public void verifyConversationPanelShouldOpen() {
        if (getConversationPanel().getText().contains("Conversation"))
        {
            Logger.info("Conversation Panel opened");
        }
        else
            Logger.info("Conversation Panel not opened");

    }
    public void clickOnPrivacyLevel(String level) {
        getLevel().click();
        getPrivacyDropdown(level).click();
    }

    public void verifyPopupMenu() {
        browserElements.isElementDisplayed(getPopupMenu());
        Logger.info("Analyst sees Auto suggest Popup menu for MTCN And Party ID");
        String partyIDAct = getPartyIdLabel().getText().trim();
        Assert.assertEquals(partyIDAct,"Party ID"," Party ID  field is not displayed in Conversation Footer Auto suggest Popup menu");
        String mtcnAct = getMTCNLabel().getText().trim();
        Assert.assertEquals(mtcnAct,"MTCN"," MTCN  field is not displayed in Conversation Footer Auto suggest Popup menu");
    }

    public String getHashTaggedConversationComment()
    {
        return getConversations().getAttribute("innerHTML");
    }

    public WebElement VerifySubjectId() {
        return browserElementLocator.findElementByXpath("//*[@id=\"container-3\"]/content/app-gsi-sanction-case-management/app-case-management/div/div[2]/div[1]/div/app-transaction-hit-details/div/div[1]/div[3]");
    }

}

