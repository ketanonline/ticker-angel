package com.wu.api.util.common;

import com.jayway.jsonpath.JsonPath;
import com.wu.base.logger.Logger;
import com.wu.utils.AutProperties;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import java.io.*;
import java.security.SecureRandom;
import java.util.*;
import static java.lang.Boolean.TRUE;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class CommonFunctions {

    public static Response apiCall(String apiURL, String apiName, String methodType, String jsonString, Map<String, Object> headerMap, Map<String, Object> params) throws NullPointerException {

        Response apiResponse = null;

        Logger.info("API URL : '" + apiURL + "'");
        Allure.addAttachment("API_Request", "URL : " + apiURL +  "\nParams : " + params + "\nHeader : "  +headerMap + "\nBody : " + jsonString);
        EncoderConfig ec = new EncoderConfig();
        ec.appendDefaultContentCharsetToContentTypeIfUndefined(false);
        System.out.println(apiURL +""+params);
        switch (methodType) {
            case "POST":
                apiResponse = SerenityRest.given().urlEncodingEnabled(false)
                        .relaxedHTTPSValidation().contentType("application/json")
                        .log().all()
                        .pathParams(params)
                        .headers(headerMap)
                        .when().body(jsonString)
                        .post(apiURL)
                        .then().log().all().extract().response();
                break;

            case "PUT":
                apiResponse = SerenityRest.given().urlEncodingEnabled(false)
                        .relaxedHTTPSValidation().contentType("application/json")
                        .log().all()
                        .pathParams(params)
                        .headers(headerMap)
                        .when().body(jsonString)
                        .put(apiURL)
                        .then().log().all().extract().response();
                break;

            case "GET":
                apiResponse = SerenityRest.given().urlEncodingEnabled(false)
                        .relaxedHTTPSValidation().contentType("application/json")
                        .log().all()
                        .pathParams(params)
                        .headers(headerMap)
                        .when().body(jsonString)
                        .get(apiURL)
                        .then().log().all().extract().response();
                break;
        }

        assert apiResponse != null;
        String body = apiResponse.body().asString();
        Logger.info("API response : '" + body + "'");
        Allure.addAttachment("API_Response", body);
        return apiResponse;
    }

    public static Response apiCallWithQueryParams(String apiURL, String apiName, String methodType, String jsonString, Map<String, Object> headerMap, Map<String, Object> params) throws NullPointerException {

        Response apiResponse = null;

        Logger.info("API URL : '" + apiURL + "'");
        Allure.addAttachment("API_Request", "URL : " + apiURL +  "\nParams : " + params + "\nHeader : "  +headerMap + "\nBody : " + jsonString);
        EncoderConfig ec = new EncoderConfig();
        ec.appendDefaultContentCharsetToContentTypeIfUndefined(false);
        System.out.println(apiURL +""+params);
        switch (methodType) {
            case "POST":
                apiResponse = SerenityRest.given().urlEncodingEnabled(false)
                        .relaxedHTTPSValidation().contentType("application/json")
                        .log().all()
                        .queryParams(params)
                        .headers(headerMap)
                        .when().body(jsonString)
                        .post(apiURL)
                        .then().log().all().extract().response();
                break;

            case "PUT":
                apiResponse = SerenityRest.given().urlEncodingEnabled(false)
                        .relaxedHTTPSValidation().contentType("application/json")
                        .log().all()
                        .queryParams(params)
                        .headers(headerMap)
                        .when().body(jsonString)
                        .put(apiURL)
                        .then().log().all().extract().response();
                break;

            case "GET":
                apiResponse = SerenityRest.given().urlEncodingEnabled(false)
                        .relaxedHTTPSValidation().contentType("application/json")
                        .log().all()
                        .queryParams(params)
                        .headers(headerMap)
                        .when().body(jsonString)
                        .get(apiURL)
                        .then().log().all().extract().response();
                break;
        }

        assert apiResponse != null;
        String body = apiResponse.body().asString();
        Logger.info("API response : '" + body + "'");
        Allure.addAttachment("API_Response", body);
        return apiResponse;
    }


    public static Response apiCallWithFile(String apiURL, String apiName, String methodType, String jsonString, String filePath, String mimeType, Map<String, Object> headerMap, Map<String, Object> params) throws NullPointerException {
//        apiURL = apiURL.replaceAll("[\\p{Ps}\\p{Pe}]", "");
        Response apiResponse = null;
        Logger.info("API URL : '" + apiURL + "'");
        Allure.addAttachment("API_Request", "URL : " + apiURL +  "\nParams : " + params + "\nHeader : "  +headerMap + "\nBody : " + jsonString);
        EncoderConfig ec = new EncoderConfig();
        ec.appendDefaultContentCharsetToContentTypeIfUndefined(false);

        switch (methodType) {
            case "POST":
                if (apiName.contains("BulkUpload_FileInput"))
                {
                    apiResponse = SerenityRest.given().filter(new ResponseLoggingFilter()).header("Content-type", "multipart/form-data")
                            .headers(headerMap)
                            .multiPart("data", jsonString)
                            .log().all()
                            .multiPart("uploadFile", new File(filePath), mimeType).when()
                            .config(RestAssured.config().encoderConfig(ec.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                            .when().post(apiURL).then().log().all().extract().response();
                }
                else
                {
                    apiResponse = SerenityRest.given().filter(new ResponseLoggingFilter()).header("Content-type", "multipart/form-data")
                            .headers(headerMap)
                            .multiPart("data", jsonString)
                            .log().all()
                            .multiPart("files", new File(filePath), mimeType).when()
                            .config(RestAssured.config().encoderConfig(ec.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                            .when().post(apiURL).then().log().all().extract().response();}
                break;
            case "PUT":
                apiResponse = SerenityRest.given().filter(new ResponseLoggingFilter()).header("Content-type", "multipart/form-data")
                        .headers(headerMap)
                        .multiPart("data", jsonString)
                        .log().all()
                        .multiPart("files", new File(filePath), mimeType).when()
                        .config(RestAssured.config().encoderConfig(ec.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                        .when().put(apiURL).then().log().all().extract().response();
                break;

            case "GET":
                apiResponse = SerenityRest.given().filter(new ResponseLoggingFilter()).header("Content-type", "multipart/form-data")
                        .headers(headerMap)
                        .multiPart("data", jsonString)
                        .log().all()
                        .multiPart("files", new File(filePath), mimeType).when()
                        .config(RestAssured.config().encoderConfig(ec.appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                        .when().get(apiURL).then().log().all().extract().response();
                break;
        }
        assert apiResponse != null;
        String body = apiResponse.body().asString();
        Logger.info("API response : '" + body + "'");
        Allure.addAttachment("API_Response", body);
        return apiResponse;
    }

    public static String getApiURL(String apiName, String caseId) {
        String fileName = getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String apiURL;
        switch (apiName) {
            case "caseDisposition":
                apiURL = readFile(fileName, "caseDisposition");
                apiURL = apiURL.replaceAll("caseId", caseId);
                break;
            case "getConversation":
                apiURL = readFile(fileName, "conversation");
                break;
            case "startWFM":
                apiURL = readFile(fileName, "WorkFlowManager");
                apiURL = apiURL + "start";
                break;
            case "assignToAnalystWFM":
                apiURL = readFile(fileName, "WorkFlowManager");
                apiURL = apiURL + "ready";
                break;
            case "evaluateEntitiesWFM":
            case "reEvaluationWFM":
                apiURL = readFile(fileName, "WorkFlowManager");
                apiURL = apiURL + "dispose";
                break;
            case "inforamtionReceivedWFM":
                apiURL = readFile(fileName, "WorkFlowManager");
                apiURL = apiURL + "notifyupload   ";
                break;
            case "skipEvaluationWFM":
                apiURL = readFile(fileName, "WorkFlowManager");
                apiURL = apiURL + "skip-evaluation";
                break;
            case "skipDocUploadWFM":
                apiURL = readFile(fileName, "WorkFlowManager");
                apiURL = apiURL + "skipupload";
                break;
            case "skipTxnVerificationWFM":
                apiURL = readFile(fileName, "WorkFlowManager");
                apiURL = apiURL + "skiptransactioncheck";
                break;
            case "caseDispositionForComplianceVisibility":
                apiURL = readFile(fileName, "caseDispositionForComplianceVisibility");
                apiURL = apiURL.replaceAll("caseId", caseId);
                break;
            case "startWFE":
                apiURL = readFile(fileName, "WorkFlowEngineAPI");
                apiURL = apiURL + "start";
                break;
            case "assignToAnalystWFE":
                apiURL = readFile(fileName, "WorkFlowEngineAPI");
                apiURL = apiURL + "ready";
                break;
            case "evaluateEntitiesWFE":
                apiURL = readFile(fileName, "WorkFlowEngineAPI");
                apiURL = apiURL + "dispose";
                break;
            case "informationReceivedWFE":
            case "reEvaluationWFE":
                apiURL = readFile(fileName, "WorkFlowEngineAPI");
                apiURL = apiURL + "notifyupload";
                break;
            case "skipEvaluationWFE":
                apiURL = readFile(fileName, "WorkFlowEngineAPI");
                apiURL = apiURL + "skip-evaluation";
                break;
            case "skipDocUploadWFE":
                apiURL = readFile(fileName, "WorkFlowEngineAPI");
                apiURL = apiURL + "skipupload";
                break;
            case "skipTxnVerificationWFE":
                apiURL = readFile(fileName, "WorkFlowEngineAPI");
                apiURL = apiURL + "skiptransactioncheck";
                break;
            case "caseDispositionHierarchy":
                apiURL = readFile(fileName, "caseDispositionHierarchy");
                apiURL = apiURL.replaceAll("caseId", caseId);
                break;
            default:
                apiURL = readFile(fileName, apiName);
                break;
        }
        return apiURL;
    }


    public static String getApiURL(String apiName) {
        String fileName = getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String apiURL,apiPath,fullURL;
        String apiFile = getFullPath("apiEndPoints.properties");
        if (apiName.substring(0,3).equalsIgnoreCase("GW_")){
            fullURL=readFile(fileName, "F5URL")+readFile(apiFile, apiName);
        }
        else{
            fullURL=readFile(fileName, "baseURL")+readFile(apiFile, apiName);
        }
        return fullURL;
    }


    public static String getFullPath(String filename) {
        String userHome = System.getProperty("user.dir");
        String fullPath = userHome + System.getProperty("file.separator") + "config";
        return fullPath + System.getProperty("file.separator") + filename;
    }

    public static String readFile(String fileName, String paramName) {
        FileInputStream fileInput = null;
        try {
            fileInput = new FileInputStream(fileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            Logger.assertFail("Exception while reading file: " + fileName);
        }
        Properties prop = new Properties();
        try {
            prop.load(fileInput);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return prop.getProperty(paramName);
    }

    public static List readColumnValuesFromBulkExcel(int columnIndex, int sheetIndexNo){
        String filePath = CommonFunctions.getFullPath("uploadFiles",  "BulkActionInputTemplate.xlsx");

        List<String> columnValues = new ArrayList<String>();

        try{
            FileInputStream file = new FileInputStream(new File(filePath));//place path of your excel file
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet sheet = workbook.getSheetAt(sheetIndexNo);//which sheet you want to read

            Iterator<Row> rowIterator = sheet.iterator();
            while(rowIterator.hasNext()){
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while(row.getRowNum() > 0 && cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();
                    if (cell.getColumnIndex() == columnIndex) {
                        {
                            columnValues.add(cell.getStringCellValue());
                        }

                    }
                }
            }
            file.close();
//            Logger.info("Closing the excel file");
        }catch (Exception e){
            e.printStackTrace();
        }
        return columnValues;

    }

    public static List readBooleanColumnValuesFromBulkExcel(int columnIndex, int sheetIndexNo){
        String filePath = CommonFunctions.getFullPath("uploadFiles",  "BulkActionInputTemplate.xlsx");

        List<Boolean> columnValues = new ArrayList<Boolean>();

        try{
            FileInputStream file = new FileInputStream(new File(filePath));//place path of your excel file
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet sheet = workbook.getSheetAt(sheetIndexNo);//which sheet you want to read

            Iterator<Row> rowIterator = sheet.iterator();
            while(rowIterator.hasNext()){
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                while(row.getRowNum() > 0 && cellIterator.hasNext()) {

                    Cell cell = cellIterator.next();
                    if (cell.getColumnIndex() == columnIndex) {
                        {
                            columnValues.add(cell.getBooleanCellValue());
                        }

                    }
                }
            }
            file.close();
//            Logger.info("Closing the excel file");
        }catch (Exception e){
            e.printStackTrace();
        }
        return columnValues;

    }

    public static String getFullPath_GSI_INTR(String folderName, String filename) {
        String userHome = System.getProperty("user.dir");
        String fullPath = userHome + System.getProperty("file.separator") +
                "config" + System.getProperty("file.separator") +
                "GSI_INTR" + System.getProperty("file.separator") +
                folderName;
        return fullPath + System.getProperty("file.separator") + filename;
    }

    public static String getFullPath_GSI_Deferred(String folderName, String filename) {
        String userHome = System.getProperty("user.dir");
        String fullPath = userHome + System.getProperty("file.separator") +
                "config" + System.getProperty("file.separator") +
                "GSI_Deferred" + System.getProperty("file.separator") +
                folderName;
        return fullPath + System.getProperty("file.separator") + filename;
    }

    public static String getFullPath(String folderName, String filename) {
        String userHome = System.getProperty("user.dir");
        String fullPath = userHome + System.getProperty("file.separator") + "config" + System
                .getProperty("file.separator") + folderName;
        return fullPath + System.getProperty("file.separator") + filename;
    }

    public static Integer getStatusCode(Response apiResponse) {
        return apiResponse.then().extract().statusCode();
    }

    public static Object getTagVal(Response apiResponse, String jsonPath) {
        return apiResponse.body().jsonPath().get(jsonPath);
    }

    public static Object getValueFromJSON(String jsonFieldPath, String inputJSON) {
        return JsonPath.read(inputJSON, jsonFieldPath);
    }

    public static String getTagValue(Response apiResponse, String jsonPath) {
        try {
            return apiResponse.body().jsonPath().get(jsonPath).toString();
        } catch (Exception e) {
            return null;
        }
    }

    public static JSONObject getResponseAsJSONObject(Response apiResponse) {
        return new JSONObject(apiResponse.body().asString());
    }

    public static Boolean verifyJSONObjectHasTag(String jsonPath, JSONObject jsonObject) {
        Logger.info("Verifying" + jsonPath + " in " + jsonObject);
        if (jsonPath.contains(".")) {
            String[] node = jsonPath.split("\\.");
            String parentNode = node[0];
            StringBuilder childNode = new StringBuilder();
            for (int i = 1; i < node.length; i++) {
                childNode.append(node[i]);
            }
            assertThat("Verify " + parentNode + "is present ", verifyJSONObjectHasTag(parentNode, jsonObject), equalTo(TRUE));
            return verifyJSONObjectHasTag(childNode.toString(), jsonObject.getJSONObject(parentNode));
        } else {
            return jsonObject.has(jsonPath);
        }
    }

    public static Object getResponseSize(Response apiResponse, String jsonPath) {
        return apiResponse.jsonPath().getList(jsonPath).size();
    }

    public static List<String> readFileData(String fileName) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            List<String> fileRecords = new ArrayList<>();
            String line = br.readLine();
            while (line != null) {
                fileRecords.add(line);
                line = br.readLine();
            }
            return fileRecords;
        }
    }

    public static String randomString(int length) {
        SecureRandom secureRnd = new SecureRandom();
        final String SOURCE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++)
            sb.append(SOURCE.charAt(secureRnd.nextInt(SOURCE.length())));
        return sb.toString();
    }
    public static String getFullPath_SANCTIONS(String folderName, String filename) {
        String userHome = System.getProperty("user.dir");
        String fullPath = userHome + System.getProperty("file.separator") +
                "config" + System.getProperty("file.separator") +
                "Sanctions" + System.getProperty("file.separator") +
                folderName;
        return fullPath + System.getProperty("file.separator") + filename;
    }
    public static String getSwaggerApiURL(String apiName) {
        String fileName = getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String apiURL,apiPath,fullURL;
        String apiFile = getFullPath("swagger_config.properties");

        fullURL=readFile(fileName, "baseURL")+readFile(apiFile, apiName);

        return fullURL;
    }

    public static Object getIntValueFromJSON(String jsonFieldPath, String inputJSON) {
                return JsonPath.parse(inputJSON).read(jsonFieldPath, int.class);
    }
}