package com.wu.pages.Pharos.Interdictions;

import com.wu.api.util.common.CommonFunctions;
import com.wu.api.util.common.CouchBaseUtility;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import com.wu.utils.AutProperties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import java.awt.*;
import java.awt.event.KeyEvent;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.WebDriver;


import java.util.List;

import static com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps.getCaseData;
import static org.hamcrest.MatcherAssert.assertThat;

public class DashboardPage extends BasePage {
    static String dbResult = null;
    public WebElement getInfoText() {
        return browserElementLocator.findElementByXpath("//div/app-transaction-hit-details");
    }

    public WebElement getDisplayCheckbox(String reason) {
        String listOfCheckbox = "//span[text()=' reason ']/ancestor::span//input[@type='checkbox']";
        return browserElementLocator.findElementByXpath(listOfCheckbox.replace("reason", reason));
    }

    public WebElement getDisplayDropdown() {
        return browserElementLocator.findElementByXpath("//app-section-display[@class='wu-section-container']");
    }

    public WebElement getCaseRefNum() {
        return browserElementLocator.findElementByXpath("//td[contains(@class,'cdk-cell cdk-column-caseRefNo mat-column-caseRefNo')]");
    }

    public WebElement getTimeStamp() {
        return browserElementLocator.findElementByXpath("//td[contains(@class,'cdk-column-creationDate mat-column-creationDate')]");
    }

    public WebElement getMTCN() {
        return browserElementLocator.findElementByXpath("//td[contains(@class,'cdk-column-refId mat-column-refId')]");
    }

    public WebElement getResetButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'refresh')]");
    }

    public WebElement getButton(String btnName) {
        return browserElementLocator.findElementsByXpath("//span[contains(text(),'" + btnName + "')]").get(0);
    }

    public WebElement getEmpId() {
        return browserElementLocator.findElementByXpath("//div[contains(@class,'userid')]");
    }

    public WebElement getEmpName() {
        return browserElementLocator.findElementByXpath("//div[contains(@class,'username')]");
    }

    public WebElement getPharosLogoIcon() {
        return browserElementLocator.findElementByXpath("//div[@class='logo']//img[@alt='WU branding logo']");
    }

    public WebElement getCaseIDInputBox() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='caseId']");
    }

    public WebElement getSearchPanelCaseRefField() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='caseRefNo']");
    }

    public WebElement getSearchPanelCaseID() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='caseId']");
    }

    public WebElement getSearchPanelMTCN() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='refId']");
    }

    public WebElement getViewButton() {
        return browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'remove_red_eye')])[1]");
    }

    public WebElement getSearchGridDisposition() {
        return browserElementLocator.findElementByXpath("//th[@id='disposition']");
    }

    public WebElement getSearchGridTier() {
        return browserElementLocator.findElementByXpath("//th[@id='tier']");
    }

    public WebElement getSearchGridStage() {
        return browserElementLocator.findElementByXpath("//th[@id='stage']");
    }

    public WebElement getSearchGridmtcn() {
        return browserElementLocator.findElementByXpath("//th[@id='refId']");
    }

    public WebElement getSearchGridCaseref() {
        return browserElementLocator.findElementByXpath("//th[@id='caseRefNo']");
    }

    public WebElement getSearchGridCaseParty() {
        return browserElementLocator.findElementByXpath("//th[@id='partyName']");
    }

    public List getGridLabelsAfterReset() {
        return browserElementLocator.findElementsByXpath("//input[@formcontrolname='caseRefNo']//following::mat-label");
    }

    public WebElement getSearchGridAnalyst() {
        return browserElementLocator.findElementByXpath("//th[@id='analystName']");
    }

    public WebElement getSearchGridCreationDate() {
        return browserElementLocator.findElementByXpath("//th[@id='creationDate']");
    }

    public WebElement getSearchGridCaseID() {
        return browserElementLocator.findElementByXpath("//th[@id='caseId']");
    }

    public WebElement getSearchGridAction() {
        return browserElementLocator.findElementByXpath("//th[@id='action']");
    }

    public WebElement getAnalystValueForWorkIcon() {
        return browserElementLocator.findElementByXpath("(//td[contains(@class,'mat-column-analystName')])[1]");
    }

    public WebElement getCaseInfo(String caseId) {
        return browserElementLocator.findElementByXpath("//td[contains(text(),'" + caseId + "')]");
    }

    public WebElement getCaseIdInputBox() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='caseId']");
    }

    public WebElement getSearchButton() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Search')]");
    }

    public WebElement getStage(String stage) {
        return browserElementLocator.findElementByXpath("//table//td[contains(text(),'"+stage+"')]");
    }

    public WebElement getCaseTier(String tier) {
        return browserElementLocator.findElementByXpath("//table//td[contains(text(),'"+tier+"')]");
    }

    public WebElement getCaseDisposition(String disposition) {
        return browserElementLocator.findElementByXpath("//table//td[contains(text(),'"+disposition+"')]");
    }

    public WebElement getWorkButton() {
        return browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'work_outline')])[1]");
    }

    public WebElement getLink(String linkName) {
        return browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'" + linkName + "')])[1]");
    }

    public WebElement getDashboardLink() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Dashboard')]");
    }

    public WebElement getCaseIdError() {
        return browserElementLocator.findElementByXpath("//mat-error[contains(text(),'Please enter valid Case ID. Maximum 37 characters.')]");
    }

    public WebElement getSelectGenreDropDown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='genreId']/div/div[2]");
    }

    public WebElement getGenreOption(String option) {
        return browserElementLocator.findElementByXpath("//mat-option/span[contains(text(),'" + option + "')]");
    }

    public WebElement getSelectCaseTypeDropDown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='investigativeGroup']");
    }

    public WebElement getMTCNError() {
        return browserElementLocator.findElementByXpath("//mat-error[contains(text(),'Please enter valid Activity Ref No. Maximum 10 digits.')]");
    }

    public WebElement getViewOnly() {
        return browserElementLocator.findElementByXpath("//mat-chip//span[contains(.,'View Only')]");
    }

    public WebElement getPanelTitle(String title) {
        return browserElementLocator.findElementByXpath("//form//mat-card-title[contains(text(),'Get Case')]");
    }

    public WebElement getMyQueueButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(.,'assignment')]");
    }

    public WebElement getDashboard() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Dashboard')]");
    }

    public WebElement getGetCaseButton() {
        return browserElementLocator.findElementByXpath("//button/span[contains(text(),'Get Case')]");
    }

    public WebElement getCaseId() {
        return browserElementLocator.findElementByXpath("//td[contains(@class,'cdk-column-caseId mat-column-caseId ng-star-inserted')]");
    }

    public WebElement getSearchPanel() {
        return browserElementLocator.findElementByXpath("//div[@class='mat-card-header-text']/mat-card-title[text()='Case Retrieval']");
    }
    public WebElement getActionFailureWidget() {
        return browserElementLocator.findElementByXpath("//mat-card-title[text()='Action Failures']");
    }

    public void enterCaseIdInSearchTextBox(String inputText) {
        browserTextBox.sendKeys(getCaseIdInputBox(), inputText);
    }

    public WebElement getCaseRefError1() {
        return browserElementLocator.findElementByXpath("//mat-error[contains(text(),'Please enter valid Case Ref No.')]");
    }

    public WebElement getCaseRefError2() {
        return browserElementLocator.findElementByXpath("(//mat-error//span[contains(text(),'Maximum 12 characters')])[1]");
    }

    public WebElement getCaseRefError3() {
        return browserElementLocator.findElementByXpath("(//mat-error//span[contains(text(),'Only alphanumeric characters are allowed.')])[1]");
    }

    public WebElement getToaster() {
        return browserElementLocator.findElementByXpath("//*[@id='cdk-describedby-message-container']");
    }

    public void clickOnSearchButton() {
        getSearchButton().click();
    }

    public void validateCaseStage(String stage) {
        String actStage = getStage(stage).getText().trim();
        assertThat("Case stage is validated", actStage.equals(stage));
    }

    public void validateCaseDisposition(String disposition) {
        String actDisposition = getCaseDisposition(disposition).getText().trim();
        assertThat("Disposition is validated", actDisposition.equals(disposition));
    }

    public void validateCaseTier(String tier) {
        String actTier = getCaseTier(tier).getText().trim();
        assertThat("Tier is validated", actTier.equals(tier));
    }

    public void clickOnCaseActionButton(String mode) {
        if (mode.equals("View Case"))
            getLink("remove_red_eye").click();
        else if (mode.equals("Work Case"))
            getLink("work_outline").click();
        else
            getLink(mode).click();
    }

    public void selectGenreDropdown(String option) {
        getSelectGenreDropDown().click();
        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//span[contains(text(),'"+option+"')]"));
        drpdwnValue.click();
    }

    public void selectGenreOption(String option) {
        getGenreOption(option).click();
    }

    public void selectCaseTypeDropdown(String option) {
        getSelectCaseTypeDropDown().click();
        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//mat-option/span[contains(text(),'"+option+"')]"));
        drpdwnValue.click();
    }

    public void clickOnLink(String btnName) {
        getDashboardLink().click();
    }

    public WebElement getCaseDispositionFromCase(){
        return browserElementLocator.findElementByXpath("(//mat-select/div/div/span/span)[1]");
    }

    public void verifyViewOnlyLabel() {
        if (getViewOnly().isDisplayed()) {
            Logger.info("Search Panel with Case ref Number,Case ID and MTCN fields verified");
        }
    }

    public void clickMyQueue() {
        getMyQueueButton().click();
    }

    public String analystGetCaseIDSearchResults(String case_id) {
        try {
            return getCaseInfo(case_id).getText();
        } catch (Exception e) {
            Logger.info("No case found with case id : " + case_id);
            return null;
        }
    }

    public void verifyAnalystVisibilityForWorkIcon() {
        if ((getAnalystValueForWorkIcon().getText().equalsIgnoreCase("Divya Jayakumar"))) {
            System.out.println("All the search grid components verified");
        }
    }

    public boolean getWorkCaseIcons() {
        boolean isPresent = false;
        List<WebElement> rows = BaseTestSetup.webDriver.findElements(By.xpath("//tr[contains(@class,'mat-row')]"));
        for (WebElement ele : rows) {
            if (ele.findElement(By.xpath("//following::mat-icon[contains(text(),'work_outline')]")).isDisplayed()) {
                isPresent = true;
            }
        }
        return isPresent;
    }

    public void verifySearchGridFields() {
        if ((getSearchGridAction().isDisplayed()) && (getSearchGridCaseID().isDisplayed()) &&
                (getSearchGridAnalyst().isDisplayed()) && (getSearchGridCaseParty().isDisplayed()) && (getSearchGridCaseref().isDisplayed())
                && (getSearchGridCreationDate().isDisplayed()) && (getSearchGridTier().isDisplayed()) && (getSearchGridStage().isDisplayed())
                && (getSearchGridmtcn().isDisplayed()) && (getSearchGridDisposition().isDisplayed())) {
            System.out.println("All the search grid components verified");
        }
    }

    public void clickResetBtn() {
        getResetButton().click();
    }

    public void entersCaseId(String caseId) {
        getCaseIDInputBox().click();
        browserTextBox.sendKeys(getCaseIDInputBox(), caseId);
    }

    public void entersMTCN(String mtcn) throws InterruptedException {
        clickResetBtn();
        getSearchPanelMTCN().sendKeys(mtcn);
    }

    public void enterMTCNWithoutClearing(String mtcn) throws InterruptedException {
        getSearchPanelMTCN().sendKeys(mtcn);
    }

    public void clickViewBtn() throws InterruptedException {
        if (getViewButton().isEnabled()) {
            getViewButton().click();
        }
    }

    public void verifySearchPanel() {
        if (getSearchPanel().isDisplayed()) {
            if ((getSearchPanelCaseID().isEnabled()) && (getSearchPanelCaseRefField().isEnabled()) && (getSearchPanelMTCN().isEnabled()))
                System.out.println("Search Panel with Case ref Number,Case ID and MTCN fields verified");
        }
        if (getSearchButton().isEnabled()) {
            System.out.println("Search Button is displayed");
        }
    }
    public void verifyActionFailureWidget() {
        Assert.assertTrue(getActionFailureWidget().isDisplayed(),"Action Failure Widget is present");

    }

    public void verifyResetOptionFunctionality() {
        clickResetBtn();
        List<WebElement> labels = getGridLabelsAfterReset();
        if (labels.size() == 3) {
            Logger.info("Reset option has been clicked and verified");
        } else {
            Logger.info("Reset option validation failed.No data has been reset");
        }
    }

    public void clickGetCaseBtn() {
        getGetCaseButton().click();
    }

    public void validateErrorMessageMTCN(String message) throws InterruptedException {
        Assert.assertEquals(getMTCNError().getText(), message, "MTCN Error message validated successfully");
        Thread.sleep(2000);
    }

    public void validateErrorMessageCaseId(String message) throws InterruptedException {
        Assert.assertEquals(getCaseIdError().getText(), message, "Case Id error message validated successfully");
    }

    public void validateErrorMessageCaseRef1(String message) throws InterruptedException {
        Assert.assertEquals(getCaseRefError1().getText(), message, "Case Ref Error message verfied: Only alphanumeric characters are allowed");
    }

    public void validateErrorMessageCaseRef2(String message) throws InterruptedException {
        Assert.assertEquals(getCaseRefError2().getText(), message, "Case Ref Error message verfied: Only alphanumeric characters are allowed");
    }

    public void validateErrorMessageCaseRef3(String message) throws InterruptedException {
        Assert.assertEquals(getCaseRefError3().getText(), message, "Case Ref Error message verfied: Only alphanumeric characters are allowed");
    }

    public void verifiesAutoRedactioCaseIDField(String caseid) {
        getCaseIDInputBox().sendKeys(" " + caseid + " ");
        Logger.info("Analyst enters a case id which have leading and trailing spaces");
        getSearchButton().click();
        Logger.info("Analyst clicked on search button for case id for validating case id field validation");
        if (spaceCount(getCaseIDInputBox().getText()) == 0) {
            Logger.info("No spaces found after Auto-redaction check in case id field : Scenario passed");
        } else {
            Logger.info("Auto-redaction functionality failed.Since retreived data contains spaces in case id field");
        }
    }

    public int spaceCount(String s) {
        int i;
        int c;
        for (i = 0, c = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == ' ')
                c++;
        }
        return c;
    }

    public void verifyHamburgerMenuDashboardOption() {
        getDashboard().isDisplayed();
    }

    public void verifyGetCasePanelTitle(String title) throws InterruptedException {
        Thread.sleep(2000);
        if (getPanelTitle(title).isEnabled()) {
            System.out.println("Get Case Panel title is displayed");
        }
    }

    public String getCaseReferenceNumAndTimeStamp() {
        String caseREfNum = getCaseRefNum().getText().trim();
        Logger.info("Case Reference Number is captured: " + caseREfNum);
        String timeStamp = getTimeStamp().getText().trim();
        Logger.info("Created TimeStamp is captured: " + timeStamp);
        String mtcn = getMTCN().getText().trim();
        Logger.info("MTCN is captured: " + mtcn);
        return caseREfNum + "&" + timeStamp + "&" + mtcn;
    }

    public void selectInvestigationFocusDropdown() {
        getselectInvestigationFocusDropdown().click();


        //Select select = new Select(getselectInvestigationFocusDropdown());
        //select.selectByVisibleText(option);
        //select.selectByValue(option);
    }

    public void selectInvestigationFocus(String option) {
        getselectInvestigationFocus(option).click();

    }

    public WebElement getselectInvestigationFocus(String option) {
        return browserElementLocator.findElementByXpath("(//span[contains(text(),'" + option + "')])[2]");

    }

        public void selectTierDropdown(String option) throws InterruptedException {
        Thread.sleep(2000);
//        getSelectTierDropDown().click();
            WebElement drpdwnValue1 = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='mat-select-arrow ng-tns-c104-8']"));
            drpdwnValue1.click();
        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//mat-option/span[contains(text(),'"+option+"')]"));
        drpdwnValue.click();
    }
    public WebElement getSelectTierDropDown(){
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='tierId']");
    }
//    public void selectTierDropdown(String option) throws InterruptedException {
//        Thread.sleep(2000);
////        getSelectTierDropDown().click();
//        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//mat-option/span[contains(text(),'"+option+"')]"));
//        drpdwnValue.click();
//    }
//    public WebElement getSelectTierDropDown(){
//        return browserElementLocator.findElementByXpath("(//mat-select[@role='combobox'])[3]");
//    }
//    public void selectTier(String option) throws InterruptedException {
//        getselectTier(option).click();
//        Thread.sleep(2000);
//        System.out.println("Tier option selected");
//    }
//
//    public WebElement getselectTier(String option) {
//        return browserElementLocator.findElementByXpath("//mat-option//span[contains(text(),'" + option + "')]");
//    }


    public void verifyRFWtitle(String title) throws InterruptedException {
        Thread.sleep(2000);
        if (getRFWTitle(title).isEnabled())
        //if (getRFWTitle(title).equals("Ready For Work"))
        {
            System.out.println("RFW Widget title is displayed");
        }
    }

    public void verifyStandardInvestigationtitle(String title) throws InterruptedException {
        Thread.sleep(2000);
        if (getStandardInvestigationTitle(title).isEnabled()) {
            System.out.println("Standard Investigation title is displayed on RFW widget");
        }
    }

    public void verifyEnhancedInvestigationtitle(String title) throws InterruptedException {
        Thread.sleep(2000);
        if (getEnhancedInvestigationTitle(title).isEnabled()) {
            System.out.println("Enhanced Investigation title is displayed on RFW widget");
        }
    }

    public void verifyAdvancedInvestigationtitle(String title) throws InterruptedException {
        Thread.sleep(2000);
        if (getAdvancedInvestigationTitle(title).isEnabled()) {
            System.out.println("Advanced Investigation title is displayed on RFW widget");
        }
    }

    public WebElement getRFWTitle(String title) {
        return browserElementLocator.findElementByXpath("//app-dashboard-widget//mat-card-title[contains(text(),'Ready For Work')]");

    }

    public WebElement getStandardInvestigationTitle(String title) {
        return browserElementLocator.findElementByXpath("//p[contains(text(),'Standard Investigation')]");
    }

    public WebElement getEnhancedInvestigationTitle(String title) {
        return browserElementLocator.findElementByXpath("//p[contains(text(),'Enhanced Investigation')]");
    }

    public WebElement getAdvancedInvestigationTitle(String title) {
        return browserElementLocator.findElementByXpath("//p[contains(text(),'Advanced Investigation')]");
    }

    public WebElement getselectInvestigationFocusDropdown() {
        return browserElementLocator.findElementByXpath("//div[contains(@class,'ng-tns-c102-5')]/mat-select/div/div[2]");
    }

    public WebElement getStandardInvestigationCasePullButton() {
        return browserElementLocator.findElementByXpath("(//p[contains(text(),'Standard Investigation')]//following::button)[1]");
    }

    public WebElement getselectTierDropdown() {
        return browserElementLocator.findElementByXpath("//mat-select[@id='mat-select-4']");
    }

    public String getmtcn() {
        System.out.println("mtcn=" + browserElementLocator.findElementByXpath("//mat-card-content[@class='mat-card-content']/div/div[7]/div/p").getText());
        return browserElementLocator.findElementByXpath("//mat-card-content[@class='mat-card-content']/div/div[7]/div/p").getText();
    }

    public String getCaseID() {
        System.out.println("CaseId=" + browserElementLocator.findElementByXpath("//mat-expansion-panel-header/span[1]/mat-panel-title[1]/div[2]/div[1]").getText());
        return browserElementLocator.findElementByXpath("//mat-expansion-panel-header/span[1]/mat-panel-title[1]/div[2]/div[1]").getText().trim();

    }

    public java.util.List<WebElement> getInvestigationDrpDownValues() {
        return browserElementLocator.findElementsByXpath("//mat-select[@formcontrolname='investigativeGroup']//following::mat-option/span");
    }

    public boolean invsFocusDropDownValidation(java.util.List<String> details) {


        java.util.List<WebElement> investigativefocus = getInvestigationDrpDownValues();
        String[] actualDrpDownValues = new String[details.size()];

        for (int i = 0; i < investigativefocus.size(); i++) {

            String drpdownValue = investigativefocus.get(i).getText();
            System.out.println("Dropdown values :" + drpdownValue);
            actualDrpDownValues[i] = drpdownValue;

        }

        //Creating a string Array to Story the input values given in the Feature File. Dynamically the String array is created.
        String inputValues[] = new String[details.size()];
        for (int j = 0; j < details.size(); j++) {
            inputValues[j] = details.get(j);
            System.out.println("Given input Values:" + inputValues[j]);
        }
        Logger.info("All the input Values are stored in the input Values Array");

        //This for loop is to check if both the inputValues & actual values are matching.
        for (int i = 0; i < inputValues.length; i++) {
            if (!inputValues[i].equals(actualDrpDownValues[i]))

                return false;
        }

        return true;
    }

    public void verifyStandardInvestigationCasepullButton() throws InterruptedException {
        Thread.sleep(2000);
        if (getStandardInvestigationCasePullButton().isEnabled()) {
            System.out.println("Standard Investigation case pull button is enabled on RFW widget");
        }
    }

    public void ctrlF() {
        //Actions action = new Actions(BaseTestSetup.webDriver);
        //action.keyDown(Keys.CONTROL).sendKeys("f").keyUp(Keys.CONTROL).build().perform();
        try {
            //Create Robot class
            Robot rb = new Robot();
            rb.keyPress(KeyEvent.VK_CONTROL);
            //Thread.sleep(1000);
            rb.keyPress(KeyEvent.VK_F);
            rb.keyRelease(KeyEvent.VK_F);
            rb.keyRelease(KeyEvent.VK_CONTROL);
            Thread.sleep(1000);
            rb.keyPress(KeyEvent.VK_I);
            rb.keyRelease(KeyEvent.VK_I);
            rb.keyPress(KeyEvent.VK_D);
            rb.keyRelease(KeyEvent.VK_D);
            javaScriptExecutor.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void getinfotext() {
        String infoText = getInfoText().getText();
        System.out.println("Extracted info text: " + infoText);
    }

    public void clickdisplaydropdrown(String reason) throws InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        getDisplayDropdown().click();
        Thread.sleep(3000);
        String[] reasons = reason.split(",");
        for (String token : reasons) {
            action.moveToElement(getDisplayCheckbox(token)).click().build().perform();
            Thread.sleep(3000);
        }
    }

    public void isReasonDisplayed() {
        boolean isDisplayed = BaseTestSetup.webDriver.findElement(By.xpath("//mat-icon[text()=' phone ']")).isDisplayed();
        System.out.println(isDisplayed);
        //isReasonDisplayed().click();
    }

    public static void ClickOnIcon(String action) {
        Actions actions = new Actions(BaseTestSetup.webDriver);
        actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("//mat-icon[text()=' keyboard_arrow_down']"))).click().build().perform();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
        System.out.println(actions);
    }

    public static void clicksTierLink(String tier) {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
        WebElement tierLink = BaseTestSetup.webDriver.findElement(By.xpath("//p[contains(text(),'" + tier + "')]"));
        ((JavascriptExecutor) BaseTestSetup.webDriver).executeScript("arguments[0].scrollIntoView(true);", tierLink);
        tierLink.click();
        Logger.info("Clicked on the " + tier + " tier link");
    }

    public static void ClicksOnFilters() throws InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
        System.out.println(action);
        WebDriver BaseSetUp;
        List<WebElement> filters = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class = 'wu-filter-header-placement ng-star-inserted']"));
        WebElement q;
        for (int i = 0; i < filters.size(); i++) {
            {
                q = filters.get(i);
                q.click();
                action.moveToElement(q).click().build().perform();
            }
        }
    }

    public static void verifySideColumnTitle(String expTitleName){
         WebElement title = BaseTestSetup.webDriver.findElement(By.xpath("(//th[@role = 'columnheader']/div[2])[7]"));
         String actualTitleName = title.getText();
        Assert.assertEquals(actualTitleName, expTitleName, "Title of the column is not - 'Review type'");
         Logger.info("Title of the side column in UI is :"+actualTitleName);

    }

    public static void clickOnReviewTypeFilter(){
        BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class = 'wu-filter-header-placement ng-star-inserted']/mat-icon)[7]")).click();
        Logger.info("Analyst clicked on Review type filter");
    }

    public void verifyAllFilterOptionsOfReviewType() throws InterruptedException {
        List <WebElement> filterOptions = BaseTestSetup.webDriver.findElements(By.xpath("//mat-option"));
        for(int i =1; i<=filterOptions.size();i++){
            WebElement checkboxEle = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-option)["+ i +"]"));
            browserCheckBox.selectCheckboxButton(checkboxEle);
            String filterName = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-option/span)["+ i + "]")).getText();
            Logger.info("Analyst checked the filter option : "+filterName);
            Thread.sleep(1000);

        }
        Logger.info("Analyst is able to click on all filter options of review type column");

    }


    public static void ClickOnSorting() {
        Actions actions = new Actions(BaseTestSetup.webDriver);
        actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("//div[contains(@class,'mat-sort-header-arrow')]"))).click().build().perform();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
    }

    public static void ClickOnSortings() {
        Actions actions = new Actions(BaseTestSetup.webDriver);
        actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("//div[contains(@class,'mat-sort-header-arrow')]"))).click().build().perform();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
    }

    public static void ClickOnClose() {
        Actions actions = new Actions(BaseTestSetup.webDriver);
        actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("//mat-icon[text() = 'close']"))).click().build().perform();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
        }
    }
    public WebElement getGridHeader(String headers) {
        return browserElementLocator.findElementByXpath("//thead/tr[1]/th[@id='"+headers+"']");
    }
    public List<WebElement> getGridHeaderSize(String headers) {
        return BaseTestSetup.webDriver.findElements(By.xpath("//thead/tr[1]/th[@id='"+headers+"']" ));
    }
    public static void ClickOnTotalCountInRFW() {
        Actions actions = new Actions(BaseTestSetup.webDriver);
        actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget/div/mat-card/mat-card-header/div/mat-card-title[2]")));
    }

    public void selectTierbox(String option) throws InterruptedException {
        Thread.sleep(2000);
        boolean b1 = browserElementLocator.findElementByXpath("(//mat-select[@role='combobox'])[3]").isSelected();
        System.out.println(b1);
        if (b1 = true) {
//is selected method is applciable only for radio buttons, check buttons and dropdowns. It means if radiobutton/dropdown is selected,it will return true or else it will give falses
            System.out.println("Tierdropdown is disabled.Scenario Passed");
        } else {
            System.out.println("Tierdropdown is enabled.Scenario Failed");
        }
    }


    public void selectTierbox() throws InterruptedException {
        Thread.sleep(2000);
        boolean b1 = browserElementLocator.findElementByXpath("(//mat-select[@role='combobox'])[3]").isSelected();
        System.out.println(b1);
        if (b1 = true) {
//is selected method is applciable only for radio buttons, check buttons and dropdowns. It means if radiobutton/dropdown is selected,it will return true or else it will give falses
            System.out.println("Tierdropdown is disabled.Scenario Passed");
        } else {
            System.out.println("Tierdropdown is enabled.Scenario Failed");
        }

    }

    public void enterMTCNInSearchTextBox(String inputText) {
        browserTextBox.sendKeys(getMTCNInputBox(), inputText);
    }
    private WebElement getMTCNInputBox() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='refId']");
    }


    public void enterCaseRefNoInSearchTextBox(String inputText) {
        browserTextBox.sendKeys(getCaseRefNoInputBox(), inputText);
    }

    private WebElement getCaseRefNoInputBox() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='caseRefNo']");
    }
    public void verifyGetCaseBtn() {
        boolean b1 = browserElementLocator.findElementByXpath("//button/span[contains(text(),'Get Case')]").isEnabled();
        System.out.println(b1);
        if (b1 = true) {
            System.out.println("GetCase button is disabled.Scenario Passed");
        } else {
            System.out.println("GetCase button is enabled.Scenario Failed");
        }
    }
    public WebElement getmyqueueToaster() {
        return browserElementLocator.findElementByXpath("//*[@class='cdk-overlay-container']");
    }
    public void verifyAnalystVisibilityForviewIcon() {
        if (getAnalystValueForviewIcon().isDisplayed()) {
            System.out.println("View icon is visible");
        } else {
            System.out.println("view icon is not visible");
        }
    }
    public WebElement getAnalystValueForviewIcon() {
        return browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'remove_red_eye')])[1]");
    }
    public void selectanalystclicksonRemittance() {
        getselectanalystclicksonRemittance().click();
    }

    private WebElement getselectanalystclicksonRemittance() {
        return browserElementLocator.findElementByXpath("//app-dashboard[1]/div[1]/app-case-retrieval[1]/div[1]/form[1]/mat-card[1]/mat-card-content[1]/div[1]/mat-form-field[2]/div[1]/div[1]/div[3]/select[1]");
    }

    public void selectanalystclicksonRemittancedropdown() {
        getselectanalystclicksonRemittancedropdown().click();
    }

    private WebElement getselectanalystclicksonRemittancedropdown() {
        return browserElementLocator.findElementByXpath("//mat-form-field[2]/div[1]/div[1]/div[3]/select[1]/option[contains(text(),'Remittance')]");
    }


    public void selectActivityTypeDropdown(String option) throws InterruptedException {
        getSelectActivityTypeDropDown().click();
        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/app-case-retrieval/div/form/mat-card/mat-card-content/div/mat-form-field[2]"));
        drpdwnValue.click();
        WebElement Remittancevalue = BaseTestSetup.webDriver.findElement(By.xpath("//mat-form-field[2]/div[1]/div[1]/div[3]/select[1]/option[contains(text(),'Remittance')]"));
        Remittancevalue.click();
        Thread.sleep(2000);
    }
    private WebElement getSelectActivityTypeDropDown() {
        return browserElementLocator.findElementByXpath("//*[@id=\"container-3\"]/content/app-dashboard/div/app-case-retrieval/div/form/mat-card/mat-card-content/div/mat-form-field[2]");
    }

    public void clickOnDashboardActionButton() {
        getanalystclickonDashboardbutton().click();
    }

    private WebElement getanalystclickonDashboardbutton() {
        return BaseTestSetup.webDriver.findElement(By.xpath("//tbody/tr[1]/td/span/button[2]/span/mat-icon[contains(text(),'work_outline')]"));
    }
    public void ValidatesAnalystname(String analyst, String role) throws Exception {
        WebDriver webDriver = BaseTestSetup.webDriver;
        WebElement Actanalyst = webDriver.findElement(By.xpath("//span[@class='ng-star-inserted'][contains(text(),'"+analyst+"')]"));
        WebElement Expanalyst = webDriver.findElement(By.xpath("//div[@class='h3 username']"));
        String Actual = Actanalyst.getText();
        String expect = Expanalyst.getText();
        String query;
        String id;
        String invGroup;
        String tier;
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserName;
        oktaUserName = CommonFunctions.readFile(fileName, "oktaUserName_" + role);
        if (Actual.equals(expect)) {
            if (analyst.equals("Sushmitha Ramesh")) {
                invGroup = "SANC";
                tier = "Standard Investigation";
                id = "'SI.RFW.CA','SI.RFW.AP'";

            } else {
                if (analyst.equals("Sriram Sarma")) {
                    invGroup = "SANC";
                    tier = "Enhanced Investigation";
                    id = "'EI.RFWA.AP','EI.RFW.AP','EI.INV.TO'";
                } else {
                    if (analyst.equals("Phalguni Raghava desamsetty")) {
                        invGroup = "SANC";
                        tier = "Advanced Investigation";
                        id = "'AI.RFW.AP', 'AI.INV.PE', 'AI.INV.TO'";
                    } else {
                        invGroup = "Sushmitha Ramesh";
                        tier = "Standard Investigation";
                        id = "'SI.RFW.CA','SI.INV.PE','SI.INV.TO'";

                    }
                }
            }
            query = "SELECT RAW META(docRetrieve).id\n" +
                    "FROM iWatchXCustomerJourney docRetrieve\n" +
                    "WHERE docRetrieve.docType='gsiCase'\n" +
                    "    AND docRetrieve.tenant.sId = 'CMT'\n" +
                    "    AND docRetrieve.tenant.pId = 'WU'\n" +
                    "    AND docRetrieve.classification.businessGroup = 'GSI'\n" +
                    "    AND docRetrieve.classification.invGroup IN [\"" + invGroup + "\"]\n" +
                    "    AND docRetrieve.genreId ='CJ'\n" +
                    "    AND docRetrieve.workflow.status.tier = \"" + tier + "\"\n" +
                    "    AND docRetrieve.workflow.status.id IN [" + id + "]\n" +
                    "    AND (docRetrieve.analyst.id is missing OR docRetrieve.analyst.id <> [" + oktaUserName + "])\n" +
                    "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                    "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                    "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                    "    AND docRetrieve.createdTimestamp <> ''\n" +
                    "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                    "    AND docRetrieve.hitSide.`index` <> ''\n" +
                    "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                    "    AND docRetrieve.caseRefNo <> ''\n" +
                    "ORDER BY docRetrieve.workflow.targetTimestamp  DESC LIMIT 1";
            String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
            String caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
            dbResult = queryResult;
            if (caseIdVal.contains("$")) {
                caseIdVal = caseIdVal.substring(caseIdVal.indexOf("$") + 1);
                caseIdVal = getCaseData(caseIdVal).toString();
            }
            clickResetBtn();

        } else {
            Logger.info("Analyst verifies " + analyst + " as analystname in Case Retrieval page for Role " + role + "");
        }

    }
    public WebElement getInvestigativeFocus() {
        return browserElementLocator.findElementByXpath("//td[contains(@class,'cdk-column-investigationFocus')]");

    }



    public void analystclickonsettingsubmitbutton1() {
        getAnalystclicksubmitsetbutton().click();
    }

    private WebElement getAnalystclicksubmitsetbutton() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Submit')]");
    }

    public void clickonSettingPage() {
        getanalytclickonsettingpage().click();
    }

    private WebElement getanalytclickonsettingpage() {
        return browserElementLocator.findElementByXpath("//a/span[contains(text(),'Settings')]");
    }

    public void ValidatesToaster(String toaster) throws InterruptedException {
        try {

            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            webDriver.navigate().refresh();
            JavascriptExecutor je = (JavascriptExecutor) webDriver;
            WebElement Dashboarddft = webDriver.findElement(By.xpath("//div/simple-snack-bar/span[contains(text(),'" + toaster + "')]"));
            je.executeScript("arguments[0].style.border='3px solid red'", Dashboarddft);
            Thread.sleep(500);
            String errormsg = Dashboarddft.getText();
            Assert.assertEquals(errormsg, toaster);
        } catch (Exception e) {

        }
    }

    public void validateEmptyRfwWidget() {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        List<WebElement> Rfwwidget = webDriver.findElements(By.xpath("//mat-card-content[@class='mat-card-content ng-star-inserted']/div"));
        for (int i = 1; i <= 3; i++) {
            String Widget = Rfwwidget.get(i).getText();
            System.out.println(Widget);
            if (Widget.contains("SI") && Widget.contains("EI") && Widget.contains("AI")) {
                Logger.info("Analyst Validate RFW Widget is not empty for not set value");
            } else {
                System.out.println(Widget);
                Logger.info("Analyst Validate RFW Widget is empty for not set value");
            }
        }
    }

    public void ValidatesNotToaster() throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        webDriver.navigate().refresh();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        try {
            List<WebElement> Dashboarddft = webDriver.findElements(By.xpath("//div[@class='cdk-overlay-container']"));
            for (int i = 1; i <= Dashboarddft.size(); i++) {
                String ActError = Dashboarddft.get(i).getText();
                if (ActError.isEmpty()) {
                    Logger.info("Analyst validate Dashboard page doesnt contain error message");

                } else {
                    Logger.info("Analyst validate Dashboard page does contain error message");
                }
                Assert.assertTrue(ActError.isEmpty());


            }
        } catch (Exception ex) {

        }

    }

    public void analystSelectsBusinessGrp(String businessgroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        webDriver.manage().window().maximize();
        webDriver.findElement(By.xpath("//*[@id='mat-select-0']/div")).click();
        Thread.sleep(2000);
        WebElement bggroup;
        if(businessgroup.equalsIgnoreCase("KYC")){
            bggroup = webDriver.findElement(By.xpath("(//span[@class='mat-option-text'][contains(text(),'" + businessgroup + "')])[2]"));
        }
        else {
            bggroup = webDriver.findElement(By.xpath("//span[@class='mat-option-text'][contains(text(),'" + businessgroup + "')]"));
        }
        je.executeScript("arguments[0].style.border='5px solid red'", bggroup);
        Thread.sleep(2000);
        bggroup.click();
        String actbg = bggroup.getText();
        Assert.assertEquals(businessgroup, actbg);

    }

    public void analystvalidatesBgDatafromRfwWidget(String businessgroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        for (int i = 1; i <= 3; i++) {
            WebElement RfwWidget = webDriver.findElement(By.xpath("//div/mat-card/mat-card-content/div[" + i + "]/div[1]/div[1]/div/div"));
            act.moveToElement(RfwWidget).click().build().perform();
            Thread.sleep(2000);
            WebElement actWidget = webDriver.findElement(By.xpath("//table/tbody/tr[1]/td[2]"));
            String actBg = actWidget.getText().trim();
            if (actBg.startsWith(businessgroup)) {
                Logger.info("Businessgroup as " + businessgroup + " Rfw Widget data as " + actBg + "");
            } else {
                Logger.info("Businessgroup as " + businessgroup + " is different from Rfw Widget data as " + actBg + "");
            }
        }

    }

    public void analystvalidatesBgDataonRfwWidget(String businessgroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        for (int i = 1; i <= 3; i++) {
            WebElement RfwWidget1 = webDriver.findElement(By.xpath("//div/mat-card/mat-card-content/div[" + i + "]/div[1]/div[1]/div/div"));
            act.moveToElement(RfwWidget1).click().build().perform();
            Thread.sleep(2000);
            WebElement actWidget = webDriver.findElement(By.xpath("//table/tbody/tr[1]/td[2]"));
            String actBg = actWidget.getText().trim();
            if (actBg.startsWith(businessgroup)) {
                Logger.info("Businessgroup as " + businessgroup + " Rfw Widget data as " + actBg + "");
            } else {
                Logger.info("Businessgroup as " + businessgroup + " is different from Rfw Widget data as " + actBg + "");
            }
        }

    }

    public WebElement analystvalidatesPendinginfoWidget(String businessgroup) throws InterruptedException {
        return browserElementLocator.findElementByXpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[2]/div/mat-card/mat-card-header/div/mat-card-title[1]\n");
    }

    public WebElement analystValidatesInProgressWidget(){
        return browserElementLocator.findElementByXpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[3]/div/mat-card/mat-card-header/div/mat-card-title[1]");

    }

    public String getSIInProgCountFromUI(){
        return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[1]").getText();

    }

    public String getEIInProgCountFromUI(){
        return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[2]").getText();

    }

    public String getAIInProgCountFromUI(){
        return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[3]").getText();

    }

    public String getIAInProgCountFromUI(){
        return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[4]").getText();

    }



    public void analystValidatesInProgressCountIncrement( String tier) throws InterruptedException {
        //(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[1]
        int j;
        if (tier.equalsIgnoreCase("Standard Investigation")) {
            j = 1;
            validateCountIncrement(tier, j);
        } else if (tier.equalsIgnoreCase("Enhanced Investigation")) {
            j = 2;
            validateCountIncrement(tier, j);
        } else if (tier.equalsIgnoreCase("Advanced Investigation")) {
            j = 3;
            validateCountIncrement(tier, j);
        } else if (tier.equalsIgnoreCase("Investigation Approver")) {
            j = 4;
            validateCountIncrement(tier, j);
        }
        else {Logger.error("Given Tier name is invalid");}
        Logger.info("Analyst validated increment in the inprogress panel");
    }

    public void validateCountIncrement (String tier, int j) throws InterruptedException {
        int beforeCount = Integer.parseInt(browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])["+ j +"]").getText());
        Logger.info("Count of "+tier+ "in In-progress is " +beforeCount);
        Thread.sleep(5000);

        browserElementLocator.findElementByXpath("(//app-dashboard-widget[1]/div/mat-card/mat-card-content/div/div/div[2])["+j+"]").click();
        Logger.info("Clicked on total count of the " +tier+" in RFW Widget");
        Thread.sleep(3000);
        browserElementLocator.findElementByXpath("(//th[@id = 'targetTimestamp']/div/div[2]/div)[1]").click();
        Thread.sleep(1000);
        Logger.info("Clicked on due date sort to get the latest case to the top ");


        //Clicks on work case button
        browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'work_outline')])["+j+"]").click();
        Thread.sleep(7000);
        Logger.info("Analyst has clicked on work case button");
        browserPage.refreshPage();
        Logger.info(("Refreshed the page"));

        Thread.sleep(3000);
        int afterCount = Integer.parseInt(browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])["+j+"]").getText());
        Logger.info("Count after working on a case is : "+afterCount);
        Assert.assertEquals(beforeCount+1,afterCount, "Count is being incremented");
    }
        public void analystvalidatesBgDatafromRfwWidgetSupervisor(String businessgroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        for (int i = 1; i <= 2; i++) {
            WebElement RfwWidget = webDriver.findElement(By.xpath("//div/mat-card/mat-card-content/div[" + i + "]/div[1]/div[1]/div/div"));
            act.moveToElement(RfwWidget).click().build().perform();
            WebElement errormsg = webDriver.findElement(By.xpath("//div/simple-snack-bar/span[contains(text(),'Unable to retrieve cases by tier. Please retry.')]"));
            je.executeScript("arguments[0].style.border='5px solid red'", errormsg);
            String actual = errormsg.getText().trim();
            System.out.println(actual);
        }
    }

    public void analystValidatesRfwCasecount() {
        try {
            WebDriver webDriver = BaseTestSetup.webDriver;
            Actions act = new Actions(webDriver);
            JavascriptExecutor je = (JavascriptExecutor) webDriver;
            WebElement Totalcount = webDriver.findElement(By.xpath("//mat-card-header[@class='mat-card-header ng-star-inserted']//div[@class='mat-card-header-text']/mat-card-title[2]"));
            int Total = 0;
            Total = Integer.parseInt(Totalcount.getText());
            int sum = 0;
            for (int i = 1; i <= 4; i++) {
                WebElement RfwWidget = webDriver.findElement(By.xpath("//mat-card-content[1]/div[" + i + "]/div[1]/div[@class='ml-12 wu-btn-clickable wu-case-count']"));
                act.moveToElement(RfwWidget).click().build().perform();
                je.executeScript("arguments[0].style.border='5px solid red'", RfwWidget);
                sum = sum + Integer.parseInt(RfwWidget.getText());
            }

            Logger.info("calculated Total number case are " + sum + " actually displayed count " + Total + "");
            Assert.assertEquals(Total, sum, "totalcount" + Total + " and sum count" + sum + "not matchs");
        } catch (Exception ex) {

        }

    }

    public void analystValidatesPendingInfoCasecount() {
        try {
            WebDriver webDriver = BaseTestSetup.webDriver;
            Actions act = new Actions(webDriver);
            JavascriptExecutor je = (JavascriptExecutor) webDriver;
            WebElement Totalcount = webDriver.findElement(By.xpath("//mat-card-header[@class='mat-card-header ng-star-inserted']//div[@class='mat-card-header-text']/mat-card-title[2]"));
            int Total = 0;
            Total = Integer.parseInt(Totalcount.getText());
            int sum = 0;
            for (int i = 1; i <= 4; i++) {
                WebElement RfwWidget = webDriver.findElement(By.xpath("//mat-card-content[1]/div[" + i + "]/div[1]/div[@class='ml-12 wu-btn-clickable wu-case-count']"));
                act.moveToElement(RfwWidget).click().build().perform();
                je.executeScript("arguments[0].style.border='5px solid red'", RfwWidget);
                sum = sum + Integer.parseInt(RfwWidget.getText());
            }

            Logger.info("calculated Total number case are " + sum + " actually displayed count " + Total + "");
            Assert.assertEquals(Total, sum, "totalcount" + Total + " and sum count" + sum + "not matchs");
        } catch (Exception ex) {

        }

    }
    public void getErrorTextforCRN(String errormsg) {
        String error=geterrortesxt().getText();
        Assert.assertEquals(error,errormsg);
        Logger.info("Error message"+ error );

    }

    public WebElement geterrortesxt() {
        return browserElementLocator.findElementByXpath("//*[@class='ng-tns-c102-11 ng-trigger ng-trigger-transitionMessages ng-star-inserted']");
    }


    public void openFirstCaseInViewMode(){
        browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'remove_red_eye')])[1]").click();
    }

    public void openSecondCaseInViewMode(){
        browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'remove_red_eye')])[2]").click();

    }

    public String getHitText(){
        return browserElementLocator.findElementByXpath("(//div[contains(@class,'wu-transaction-hit-card')]/div/div[2])[1]").getText();
    }

    public WebElement getLinkIcon(){
        return browserElementLocator.findElementByXpath("//button/span/mat-icon[contains(text(),'link')]");
    }

    public WebElement getCaseScreenTitle(){
        return browserElementLocator.findElementByXpath("//span[text()='Related Cases']");
    }

    public WebElement getDispositionCasescreen(){
        return browserElementLocator.findElementByXpath("//span[@id='dispSummary']");
    }

    public WebElement getActionCasescreen(){
        return browserElementLocator.findElementByXpath("//td[contains(@class,'cdk-column-dispositionAction')]");
    }

    public WebElement getActionStatus(){
        return browserElementLocator.findElementByXpath("//div[contains(@class,'wu-action-status')]");
    }

    public WebElement getTriggeringPurpose(String expectedTrgPurpose) {
        return browserElementLocator.findElementByXpath("(//td[contains(text(),'"+expectedTrgPurpose+"')])");
    }

    public int getGetCaseWidgetCount() {
      return BaseTestSetup.webDriver.findElements(By.tagName("app-get-case-form")).size();

    }

    public void analystSelectsBusinessGrpDropdown(String BG) throws InterruptedException {
        getBussinessGroupDropdown().click();
        Thread.sleep(3000);
WebElement ele =        BaseTestSetup.webDriver.findElement(By.xpath("(//span[text()=' " + BG + " '])"));
        Actions action = new Actions(BaseTestSetup.webDriver);

        action.moveToElement(ele).click().perform();
            }
    public void analystSelectsReviewTypeDropdown(String ReviewType) throws InterruptedException {
        getReviewTypeDropdown().click();
        Thread.sleep(3000);
        WebElement ele =        BaseTestSetup.webDriver.findElement(By.xpath("(//span[contains(text(),'" + ReviewType + "')])"));
        Actions action = new Actions(BaseTestSetup.webDriver);

        action.moveToElement(ele).click().perform();
    }

    private WebElement getBussinessGroupDropdown() {
        return browserElementLocator.findElementByXpath("//*[@formcontrolname='businessGroupId']");
    }
    private WebElement getReviewTypeDropdown() {
        return browserElementLocator.findElementByXpath("//*[@formcontrolname='reviewType']");
    }

    public void analystSelectsInvestigationFocusDropdown(String IF) {
        getInvestigativeFocusDropdown().click();
        WebElement ele = null;
        if(IF.equals("GSI")){
            ele =BaseTestSetup.webDriver.findElement(By.xpath("(//span[contains(text(),'" + IF + "')])[2]"));
        }
        else {
            ele = BaseTestSetup.webDriver.findElement(By.xpath("(//span[contains(text(),'" + IF + "')])[1]"));
        }
        Actions action = new Actions(BaseTestSetup.webDriver);

        action.moveToElement(ele).click().perform();
    }

    private WebElement getInvestigativeFocusDropdown() {
        return browserElementLocator.findElementByXpath("//*[@formcontrolname='investigativeGroup']");
    }

    public String getSearchGridTitleText() {
        return getSearchGridTitle().getText();
    }

    private WebElement getSearchGridTitle() {
        return browserElementLocator.findElementByXpath("(//mat-card-title[@class='mat-card-title'])[5]");
    }

    public WebElement getStopButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'pan_tool')]//parent::span//parent::button");
    }

    public WebElement getReviewType(String var) {
        return browserElementLocator.findElementByXpath("(//td[contains(text(),'"+var+"')])");
    }

    public WebElement getActionFailureTypeCasesCount(String fieldName) {
        String xPath ="(//span[text()='"+fieldName+"']//parent::div//parent::div)[1]//div[@class='mat-chip-ripple']//parent::mat-chip";
        return browserElementLocator.findElementByXpath("(//span[text()='"+fieldName+"']//parent::div//parent::div)[1]//div[@class='mat-chip-ripple']//parent::mat-chip");
    }
    public WebElement getRFWTypeCasesCount(String fieldName, String type) {
        if(type.equals("SLAB")) {
            return browserElementLocator.findElementByXpath("(//p[text()='" + fieldName + "'])[1]//parent::div//preceding-sibling::div//div[contains(@class,'wu-rfw-cases-sla-breached')]");
        }
        else{
            return browserElementLocator.findElementByXpath("(//p[text()='" + fieldName + "'])[1]//parent::div//preceding-sibling::div//div[contains(@class,'wu-rfw-cases-sla ')]");
        }
    }
    public WebElement getPendingInfoTypeCasesCount(String fieldName, String type) {
        if(type.equals("SLAB")) {
            return browserElementLocator.findElementByXpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'wu-rfw-cases-sla-breached')]");
        }
        else{
            return browserElementLocator.findElementByXpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'mat-tooltip-trigger wu-rfw-cases-sla wu-btn-clickable wu-flex-grow-shirk wu-bar-graph-border-radius ng-star-inserted')]");
        }
    }
    public WebElement getInProgressTypeCasesCount(String fieldName, String type) {
        if(type.equals("SLAB")) {
            return browserElementLocator.findElementByXpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'wu-rfw-cases-sla-breached')]");
        }
        else{
            return browserElementLocator.findElementByXpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'mat-tooltip-trigger wu-rfw-cases-sla wu-btn-clickable wu-flex-grow-shirk wu-bar-graph-border-radius ng-star-inserted')]");
        }
    }
    public List<WebElement> getActionFailureTypeCasesCountSize(String fieldName) {
        return browserElementLocator.findElementsByXpath("(//span[text()='"+fieldName+"']//parent::div//parent::div)[1]//div[@class='mat-chip-ripple']//parent::mat-chip");
    }

    public WebElement saveTriggeringPurpose() {
        return browserElementLocator.findElementByXpath("//td[contains(@class,'cdk-column-trgPrps mat-column-trgPrps')]");
    }
}


