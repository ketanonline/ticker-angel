package com.wu.pages.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;

public class EntityDispositionPage extends BasePage {


    public WebElement getEntity() {
        return browserElementLocator.findElementByXpath("//app-hit-entity[@class='ng-star-inserted'][1]");
    }

    public WebElement getPosMatchBucket() {
        return browserElementLocator.findElementByXpath("//button[@id='Possible Match-button']");
    }

    public WebElement getMatchBucket() {
        return browserElementLocator.findElementByXpath("//button[@id='Match-button']");
    }

    public WebElement getFalMatchBucket() {
        return browserElementLocator.findElementByXpath("//button[@id='False Match-button']");
    }

    public WebElement getNotDisBucket() {
        return browserElementLocator.findElementByXpath("//button[@id='NotDispositioned-button']");
    }

    public WebElement getPendingInfoBucket() {
        return browserElementLocator.findElementByXpath("//button[@id='Pending Info-button']");
    }

    public WebElement getActionWorkFlowText() {
        return browserElementLocator.findElementByXpath("//div[contains(@class,'wu-action-workflow-div')]");
    }

    public WebElement getActionDropdown() {
        return browserElementLocator.findElementById("dispositionAction");
    }

    public WebElement getSubmitLink() {
        return browserElementLocator.findElementByXpath("//div[contains(text(),'Submit')]");
    }

    public WebElement getDispositionDropdown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='disposition']");
    }

    public WebElement getReasonDropdown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='reason']");
    }

    public void clickOnSubmitTab() {
        getSubmitLink().click();
    }

    public List<WebElement> getEntities() {
        return browserElementLocator.findElementsByXpath("//app-hit-entity[@class='ng-star-inserted']");
    }

    public void clickOnAllEntities() {
        List<WebElement> entities = getEntities();
        int rows_count = entities.size();

        for (int i = 1; i <= rows_count; i++) {
            WebElement eleExp = browserElementLocator.findElementByXpath("//app-hit-entity[@class='ng-star-inserted'][" + i + "]");
            eleExp.click();
        }
    }

    public void clickOnNotDispositionBucket() {
        getNotDisBucket().click();
    }

    public void selectDisposition(String dis) {

        WebElement option = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='disposition']"));
        String defaultItem = option.getText().trim();
        //System.out.println(defaultItem );
        if (defaultItem.equalsIgnoreCase(dis)) {
            Logger.info("Expected disposition is already selected : " + defaultItem);
        } else {
            getDispositionDropdown().sendKeys(dis);
            Logger.info("Expected disposition is selected in UI : " + dis);
        }
    }

    public void selectReason(String reason) throws java.lang.Exception {

        WebElement option = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='reason']"));
        String defaultItem = option.getText().trim();
        //System.out.println(defaultItem );
        if (defaultItem.equalsIgnoreCase(reason)) {
            Logger.info("Expected Reason is already selected : " + defaultItem);
        } else {
            getReasonDropdown().sendKeys(reason);
            Logger.info("Expected Reason is selected in UI : " + reason);
        }

    }

    public void validateCTMAck_WithoutCheck(String ackWF) {
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String expAckWF = ackWF;
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("ActionWorkFlow displayed in UI is validated :" + ackWF);
        else
            Logger.error("ActionWorkFlow displayed in UI is not correct :" + actActionWF);

        assertThat("ActionWorkFlow displayed is validated", expAckWF.equals(actActionWF));
    }

    public void validateCTMAckEntClearingBulk(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();
//        System.out.println("Actual : " + actActionWF);

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
//        System.out.println("Actual after \\R : " + actActionWF);
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        //    System.out.println("Actual : after replace space" + actActionWF);
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "close" + ackWFArr[0];
        ackWFArr[1] = "close" + ackWFArr[1];
        ackWFArr[2] = "check" + ackWFArr[2];
        System.out.println("3rd value:"+ackWFArr[2]);

        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1]+ ">" + ackWFArr[2];
        expAckWF = expAckWF.replaceAll(" ", "").trim();
        System.out.println("Actual : " + actActionWF);


        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }

    public void validateCTMAckCrossEntClearing(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();
//        System.out.println("Actual : " + actActionWF);

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
//        System.out.println("Actual after \\R : " + actActionWF);
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        //    System.out.println("Actual : after replace space" + actActionWF);
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "close" + ackWFArr[0];
        ackWFArr[1] = "close" + ackWFArr[1];
        ackWFArr[2] = "close" + ackWFArr[2];

        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1] +">" + ackWFArr[2];
        expAckWF = expAckWF.replaceAll(" ", "").trim();
        System.out.println("Actual : " + actActionWF);


        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }

    public void validateCTMAckCross(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();
//        System.out.println("Actual : " + actActionWF);

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
//        System.out.println("Actual after \\R : " + actActionWF);
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        //    System.out.println("Actual : after replace space" + actActionWF);
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "close" + ackWFArr[0];
        ackWFArr[1] = "close" + ackWFArr[1];

        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1];
        expAckWF = expAckWF.replaceAll(" ", "").trim();
        System.out.println("Actual : " + actActionWF);


        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }

    public void validateCTMAckNoAction(String ackWF) throws Exception{
        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String[] ackWFArr = ackWF.split(">");
//        ackWFArr[0] = "check" + ackWFArr[0];
//        ackWFArr[1] = "check" + ackWFArr[1];
        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1];
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }


    public void selectAction(String action) throws java.lang.Exception {

        WebElement option = BaseTestSetup.webDriver.findElement(By.id("dispositionAction"));
        String defaultItem = option.getText().trim();
        //System.out.println(defaultItem );
        if (defaultItem.equalsIgnoreCase(action)) {
            Logger.info("Expected Action is already selected : " + defaultItem);
        } else {
            getActionDropdown().sendKeys(action);
            Logger.info("Expected Action is selected in UI : " + action);
        }
    }

    public void clickOnPendingInfoBucket() {
        getPendingInfoBucket().click();
    }

    public void clickOnPosMatchBucket() {
        getPosMatchBucket().click();
    }

    public void clickOnFalseMatchBucket() {
        getFalMatchBucket().click();
    }

    public void clickOnMatchBucket() {
        getMatchBucket().click();
    }

    public void clickOnEntity() {
        getEntity().click();
    }

    public void selectEnhancedmovetoadvAction(String action) {
        getselectEnhancedmovetoadvAction().click();
    }

    public void selectEnhancedhoptoadvAction(String action) {
        getselectEnhancedhoptoadvAction().click();
    }

    public WebElement getselectEnhancedmovetoadvAction() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), ' Move to Advanced Investigation ')]");
    }

    public WebElement getselectEnhancedhoptoadvAction() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), ' Hop to Advanced Investigation ')]");
    }

    public void selectEnhancedCustomerChangedReason(String action) {
        getselectEnhancedCustomerChangedReason().click();
    }

    public WebElement getselectEnhancedCustomerChangedReason() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), 'Customer Changed Mind (CCM)')]");
    }

    public void selectEnhancedMoneyNotCollectedReason(String action) {
        getselectEnhancedMoneyNotCollectedReason().click();
    }

    public WebElement getselectEnhancedMoneyNotCollectedReason() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), 'Money Not Collected (MNC)')]");
    }

    public void selectEnhancedSentwithWrongInfoWIRReason(String action) {
        getselectEnhancedSentwithWrongInfoWIRReason().click();
    }

    public WebElement getselectEnhancedSentwithWrongInfoWIRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[3]/span[contains(text(), 'Sent with Wrong Info (WIR)')]");
    }

    public void selectEnhancedConsumerFraudCFRReason(String action) {
        getselectEnhancedConsumerFraudCFRReason().click();
    }

    public WebElement getselectEnhancedConsumerFraudCFRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[4]/span[contains(text(), 'Consumer Fraud (CFR)')]");
    }

    public void selectEnhancedTestTransactionRefundTTRReason(String action) {
        getselectEnhancedTestTransactionRefundTTRReason().click();
    }

    public WebElement getselectEnhancedTestTransactionRefundTTRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[5]/span[contains(text(), 'Test Transaction Refund (TTR)')]");
    }

    public void selectEnhancedTestTransactionCancelReason(String action) {
        getselectEnhancedTestTransactionCancelReason().click();
    }

    public WebElement getselectEnhancedTestTransactionCancelReason() {
        return browserElementLocator.findElementByXpath("//mat-option[6]/span[contains(text(), 'Test Transaction Cancel (TTC)')]");
    }

    public void selectEnhancedInsufficientSourceDetailsReason(String action) {
        getselectEnhancedInsufficientSourceDetailsReason().click();
    }

    public WebElement getselectEnhancedInsufficientSourceDetailsReason() {
        return browserElementLocator.findElementByXpath("//mat-option[7]/span[contains(text(), 'Insufficient Source Details (ISD)')]");
    }

    public void selectEnhancedSimilarInformationReason(String action) {
        getselectEnhancedSimilarInformationReason().click();
    }

    private WebElement getselectEnhancedSimilarInformationReason() {
        return browserElementLocator.findElementByXpath("//mat-option[8]/span[contains(text(), 'Similar Information (SIM)')]");
    }

    public void selectEnhancedReleaseFundsAction(String action) {
        getselectEnhancedReleaseFundsAction().click();
    }

    private WebElement getselectEnhancedReleaseFundsAction() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), ' Release Funds ')]");
    }

    public void selectEnhancedReturnFundsAction(String action) {
        getselectEnhancedReturnFundsAction().click();
    }

    private WebElement getselectEnhancedReturnFundsAction() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), ' Return Funds ')]");
    }

    public void selectEnhancedCancelFundsAction(String action) {
        getselectEnhancedCancelFundsAction().click();
    }

    private WebElement getselectEnhancedCancelFundsAction() {
        return browserElementLocator.findElementByXpath("//mat-option[3]/span[contains(text(), 'Cancel Funds ')]");
    }

    public void selectEnhancedReturnFundsOwnedAction(String action) {
        getselectEnhancedReturnFundsOwnedAction().click();
    }

    private WebElement getselectEnhancedReturnFundsOwnedAction() {
        return browserElementLocator.findElementByXpath("//mat-option[4]/span[contains(text(), 'Return Funds (Owned) ')]");
    }

    public void selectEnhancedApprovedCustomerAllowedOKCReason(String action) {
        getselectEnhancedApprovedCustomerAllowedOKCReason().click();
    }

    private WebElement getselectEnhancedApprovedCustomerAllowedOKCReason() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), 'Customer Allowed (OKC)')]");
    }

    public void selectAdvancedApproveCustomerChangedReason(String reason) {
        getselectAdvancedApproveCustomerChangedReason().click();
    }

    public WebElement getselectAdvancedApproveCustomerChangedReason() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), 'Customer Changed Mind (CCM)')]");
    }

    public void selectAdvancedApproveMoneyNotCollectedReason(String reason) {
        getselectAdvancedApproveMoneyNotCollectedReason().click();
    }

    public WebElement getselectAdvancedApproveMoneyNotCollectedReason() {
        return browserElementLocator.findElementByXpath("//mat-option[3]/span[contains(text(), 'Money Not Collected (MNC)')]");
    }

    public void selectAdvancedApproveSentwithWrongInfoWIRReason(String reason) {
        getselectAdvancedApproveSentwithWrongInfoWIRReason().click();
    }

    public WebElement getselectAdvancedApproveSentwithWrongInfoWIRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[4]/span[contains(text(), 'Sent with Wrong Info (WIR)')]");
    }

    public void selectAdvancedApproveConsumerFraudCFRReason(String reason) {
        getselectAdvancedApproveConsumerFraudCFRReason().click();
    }

    private WebElement getselectAdvancedApproveConsumerFraudCFRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[5]/span[contains(text(), 'Consumer Fraud (CFR)')]");
    }

    public void selectAdvancedApproveTestTransactionRefundTTRReason(String reason) {
        getselectAdvancedApproveTestTransactionRefundTTRReason().click();
    }

    private WebElement getselectAdvancedApproveTestTransactionRefundTTRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[6]/span[contains(text(), 'Test Transaction Refund (TTR)')]");
    }

    public void selectAdvancedApproveInternalPolicyCancelReason(String reason) {
        getselectAdvancedApproveInternalPolicyCancelReason().click();
    }

    private WebElement getselectAdvancedApproveInternalPolicyCancelReason() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), 'Internal Policy (LVL)')]");
    }

    public void selectsAdvancedBlockFundsAction(String action) {
        getselectsAdvancedBlockFundsAction().click();
    }

    private WebElement getselectsAdvancedBlockFundsAction() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), 'Block Funds')]");
    }

    public void selectsAdvancedBlockFundsOwnedAction(String action) {
        getselectsAdvancedBlockFundsOwnedAction().click();
    }

    private WebElement getselectsAdvancedBlockFundsOwnedAction() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), ' Block Funds (Owned) ')]");
    }

    public void selectsAdvancedReturnFundsAction(String action) {
        getselectsAdvancedReturnFundsAction().click();
    }

    private WebElement getselectsAdvancedReturnFundsAction() {
        return browserElementLocator.findElementByXpath("//mat-option[3]/span[contains(text(), ' Return Funds ')]");
    }

    public void selectsAdvancedReturnFundsOwnedAction(String action) {
        getselectsAdvancedReturnFundsOwnedAction().click();
    }

    private WebElement getselectsAdvancedReturnFundsOwnedAction() {
        return browserElementLocator.findElementByXpath("//mat-option[5]/span[contains(text(), 'Return Funds (Owned)')]");
    }

    public void selectAdvancedDeclinedCustomerChangedReason(String reason) {
        getselectAdvancedDeclinedCustomerChangedReason().click();
    }

    private WebElement getselectAdvancedDeclinedCustomerChangedReason() {
        return browserElementLocator.findElementByXpath("//mat-option[3]/span[contains(text(), 'Customer Changed Mind (CCM)')]");
    }

    public void selectAdvancedDeclinedMoneyNotCollectedReason(String reason) {
        getselectAdvancedDeclinedMoneyNotCollectedReason().click();
    }

    private WebElement getselectAdvancedDeclinedMoneyNotCollectedReason() {
        return browserElementLocator.findElementByXpath("//mat-option[4]/span[contains(text(), 'Money Not Collected (MNC)')]");
    }

    public void selectAdvancedDeclinedSentwithWrongInfoWIRReason(String reason) {
        getselectAdvancedDeclinedSentwithWrongInfoWIRReason().click();
    }

    private WebElement getselectAdvancedDeclinedSentwithWrongInfoWIRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[5]/span[contains(text(), 'Sent with Wrong Info (WIR)')]");
    }

    public void selectAdvancedDeclinedConsumerFraudCFRReason(String reason) {
        getselectAdvancedDeclinedConsumerFraudCFRReason().click();
    }

    private WebElement getselectAdvancedDeclinedConsumerFraudCFRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[6]/span[contains(text(), 'Consumer Fraud (CFR)')]");
    }

    public void selectAdvancedDeclinedTestTransactionRefundTTRReason(String reason) {
        getselectAdvancedDeclinedTestTransactionRefundTTRReason().click();
    }

    private WebElement getselectAdvancedDeclinedTestTransactionRefundTTRReason() {
        return browserElementLocator.findElementByXpath("//mat-option[7]/span[contains(text(), 'Test Transaction Refund (TTR)')]");
    }

    public void selectAdvancedDeclinedInternalPolicyCancelReason(String reason) {
        getselectAdvancedDeclinedInternalPolicyCancelReason().click();
    }

    private WebElement getselectAdvancedDeclinedInternalPolicyCancelReason() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), 'Internal Policy (LVL)')]");
    }

    public void selectAdvancedDeclinedPerRegulationLVLReason(String reason) {
        getselectAdvancedDeclinedPerRegulationLVLReason().click();
    }

    private WebElement getselectAdvancedDeclinedPerRegulationLVLReason() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), 'Per Regulation (LVL)')]");
    }

    public void selectInvestigationApproverApproveEntityAction(String action) {
        getselectInvestigationApproverApproveEntityAction().click();
    }

    private WebElement getselectInvestigationApproverApproveEntityAction() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), ' Approve Entity-(ies) ')]");
    }

    public void selectInvestigationApproverApproveEntityCoachAction(String action) {
        getselectInvestigationApproverApproveEntityCoachAction().click();
    }

    private WebElement getselectInvestigationApproverApproveEntityCoachAction() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), ' Approve Entity-(ies) & Coach ')]");
    }

    public void selectInvestigationApproverApproveCriticalCoachingAction(String action) {
        getselectInvestigationApproverApproveCriticalCoachingAction().click();
    }

    private WebElement getselectInvestigationApproverApproveCriticalCoachingAction() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), 'Critical Coaching ')]");
    }

    public void selectInvestigationApproverApproveElevatedCoachingAction(String action) {
        getselectInvestigationApproverApproveElevatedCoachingAction().click();
    }

    private WebElement getselectInvestigationApproverApproveElevatedCoachingAction() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), 'Elevated Coaching ')]");
    }

    public void selectInvestigationInterimSuspensionReason(String reason) {
        getselectInvestigationInterimSuspensionReason().click();
    }

    private WebElement getselectInvestigationInterimSuspensionReason() {
        return browserElementLocator.findElementByXpath("//mat-option[2]/span[contains(text(), 'Interim Suspension (SUS)')]");
    }

    public void selectInvestigationRecoveredinQueueReason(String reason) {
        getselectInvestigationRecoveredinQueueReason().click();
    }

    private WebElement getselectInvestigationRecoveredinQueueReason() {
        return browserElementLocator.findElementByXpath("//mat-option[1]/span[contains(text(), 'Recovered in Queue (QUE)')]");
    }

    public void selectInvestigationAllowedinErrorReason(String reason) {
        getselectInvestigationAllowedinErrorReason().click();
    }

    private WebElement getselectInvestigationAllowedinErrorReason() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Allowed in Error (ERR)')]");
    }

    public void selectInvestigationApproverDecisionOKCoachingAction(String reason) {
        getselectInvestigationApproverDecisionOKCoachingAction().click();
    }

    private WebElement getselectInvestigationApproverDecisionOKCoachingAction() {

        return browserElementLocator.findElementByXpath("//span[contains(text(),'Decision OK (OKD)')]");
    }



    public WebElement analystClickOnTotalNumber(String invgrp) {
        return browserElementLocator.findElementByXpath("//app-dashboard-widget/div/mat-card/mat-card-content/div[1]/div[1]/div[2]");

    }

    public void analystClickOnTotalNumberGRID(String invgrp) {
          getanalystClickOnTotalNumberGRID().click();
    }
    public void analystClickOnTotalNumberGRIDInProg(){
        getanalystClickOnTotalNumberGRIDInProg().click();
    }


    public WebElement getanalystClickOnTotalNumberGRID() {
        return browserElementLocator.findElementByXpath("//div[@class='wu-flex-width-15 ml-12 wu-btn-clickable wu-case-count']");
    }

    public WebElement getanalystClickOnTotalNumberGRIDInProg(){
        return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[1]");
    }

    public void analystClickOnTotalNumberGRIDEH(String invgrp) {

            getanalystClickOnTotalNumberGRIDEH().click();
    }

    public void analystClickOnTotalNumberGRIDEHInProg(){
        getanalystClickOnTotalNumberGRIDEHInProg().click();
    }

    public WebElement getanalystClickOnTotalNumberGRIDEH() {
        return browserElementLocator.findElementByXpath("//mat-card/mat-card-content/div[2]/div[1]/div[2]");
    }

    public WebElement getanalystClickOnTotalNumberGRIDEHInProg(){
        return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[2]");
    }

    public void analystClickOnTotalNumberGRIDAD(String invgrp) {
        getanalystClickOnTotalNumberGRIDAD().click();
    }

    public void analystClickOnTotalNumberGRIDADInProg(){
        getanalystClickOnTotalNumberGRIDADInProg().click();
    }

    private WebElement getanalystClickOnTotalNumberGRIDAD() {
        return browserElementLocator.findElementByXpath("//mat-card/mat-card-content/div[3]/div[1]/div[2]");
    }

    public WebElement getanalystClickOnTotalNumberGRIDADInProg(){
     return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[3]");
    }

    public void analystClickOnTotalNumberGRIDIA(String invgrp) {
        getanalystClickOnTotalNumberGRIDIA().click();
    }

    public void analystClickOnTotalNumberGRIDIAInProg(String invgrp, String BusinessGrp){
        getanalystClickOnTotalNumberGRIDIAInProg(BusinessGrp).click();
    }

    private WebElement getanalystClickOnTotalNumberGRIDIA() {
        return browserElementLocator.findElementByXpath("//mat-card/mat-card-content/div[4]/div[1]/div[2]");
    }

    public WebElement getanalystClickOnTotalNumberGRIDIAInProg(String BusinessGrp) {
        if (BusinessGrp.equalsIgnoreCase("BKYC")) {
            return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[3]");

        } else {
            return browserElementLocator.findElementByXpath("(//app-dashboard-widget[3]/div/mat-card/mat-card-content/div/div/div[2])[4]");
        }
    }

    public WebElement getFilterCheckboxes(String InvFocus) {
        return browserElementLocator.findElementByXpath("//label[@class='mat-checkbox-layout']/span[contains(text(),'"+InvFocus+"')]");
    }

    public WebElement getMatchEntities() {
        return browserElementLocator.findElementByXpath("(//button[@id='Match-button']//span)[3]");
    }

    public WebElement getErrorToasterMsg() {
        return browserElementLocator.findElementByXpath("//snack-bar-container//span[contains(text(),'Sanctions')]");
    }


    public void clickOnAllEntityCards()
    {
        List<WebElement> entities = getEntities();
        int rows_count = entities.size();
        for (int i = 1; i <= rows_count; i++) {
            WebElement eleExp = browserElementLocator.findElementByXpath("//app-hit-entity[@class='ng-star-inserted'][" + i + "]");
            eleExp.click();

            String Entitycard = browserElementLocator.findElementByXpath("(//mat-card-title[@class='mat-card-title'])[" + i + "]").getText();
            //mat-card-title[contains(text(),'SANC')])
            if(Entitycard.contains("SANC")) {
                Logger.info("Original Source is displayed for Sanctions entity card'" + Entitycard + "'");
            }
            else
                Logger.info("Original Source is not displayed for Interdiction entity cards");

        }
    }

}

