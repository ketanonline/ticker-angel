package com.wu.pages.Pharos.Interdictions;

import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.pages.BasePage;
import com.wu.utils.AutProperties;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;

public class UICommonPage extends BasePage {
    BaseTestSetup baseTestSetup=new BaseTestSetup();

    public WebElement getOktaId() {
        return browserElementLocator.findElementByXpath("//input[@id='idp-discovery-username']");
    }

    public WebElement getOktaSubmit() {
        return browserElementLocator.findElementByXpath("//input[@id='idp-discovery-submit']");
    }

    public WebElement getOktaUserNameTextbox() {
        return browserElementLocator.findElementByXpath("//input[@id='okta-signin-username']");
    }
    public WebElement getOktaPasswordTextbox() {
        return browserElementLocator.findElementByXpath("//input[@id='okta-signin-password']");
    }
    public WebElement getOKTASubmitButton() {
        return browserElementLocator.findElementByXpath("//input[@id='okta-signin-submit']");
    }

    public void entersUIdAndSubmit(String inputText) {
        browserTextBox.sendKeys(getOktaId(),inputText);
        getOktaSubmit().click();
    }
    public void entersUidAndPwdForOktaSignIn() throws InterruptedException {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserName = CommonFunctions.readFile(fileName, "oktaUserName");
        String oktaPassword = CommonFunctions.readFile(fileName, "oktaPassword");
        getOktaUserNameTextbox().clear();
        getOktaUserNameTextbox().sendKeys(oktaUserName);
        getOktaPasswordTextbox().sendKeys(oktaPassword);
        getOKTASubmitButton().click();
        Thread.sleep(9000);
    }
    public void entersUidAndPwdForOktaSignInRole(String role) throws InterruptedException {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserName = CommonFunctions.readFile(fileName, "oktaUserName_" + role);
        String oktaPassword = CommonFunctions.readFile(fileName, "oktaPassword_" + role);
//        System.out.println("*********" + oktaPassword);
        getOktaUserNameTextbox().clear();
        getOktaUserNameTextbox().sendKeys(oktaUserName);
        getOktaPasswordTextbox().sendKeys(oktaPassword);
        getOKTASubmitButton().click();
        Thread.sleep(9000);
    }


}
