package com.wu.pages.Pharos.Interdictions;

import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class UnisysPage extends BasePage {


    public WebElement getOperatorIDbox() {
        return browserElementLocator.findElementByXpath("//input[@name='optId']");
    }

    public WebElement getPasswordBox() {
        return browserElementLocator.findElementByXpath("//input[@name='passwd']");
    }

    public WebElement getSiteBox() {
        return browserElementLocator.findElementByXpath("//input[@name='site']");
    }

    public WebElement getOkButton() {
        return browserElementLocator.findElementByXpath("//input[@name='okBtn']");
    }

    public WebElement getMTUtilityLink() {
        return browserElementLocator.findElementByXpath("//a[text()='MONEY TRANSFER UTILITY']");
    }

    public WebElement getControlnumberBox() {
        return browserElementLocator.findElementByXpath("//input[@name='mtcn']");
    }

    public WebElement getSearchBtn() {
        return browserElementLocator.findElementByXpath("//input[@name='srchBtn']");
    }

    public WebElement getMTCNDataBtn() {
        return browserElementLocator.findElementByXpath("//input[@value='COMMENT']");

    }

    public WebElement getCommentBtn() {
        return browserElementLocator.findElementByXpath("//input[@value='COMMENT']");

    }

    public WebElement getMTCNDetailsBtn() {
        return browserElementLocator.findElementByXpath("//input[@value='MTCN Details']");

    }

    public WebElement getQueueBtn() {
        return browserElementLocator.findElementByXpath(" //input[@value='QUEUE'][@name='but077']");
    }

    public WebElement getQueueName() {
        return browserElementLocator.findElementByXpath("//table[@class='ESAtextMain']/tbody/tr[2]/td[2]");
    }

    public WebElement getTranStatus() {
        return browserElementLocator.findElementByXpath("//table[@class='ESAtextMain']/tbody/tr/td[14]");
    }

    public WebElement getTranStatus_Cancel() {
        return browserElementLocator.findElementByXpath("//table[@class='ESAtextMain']/tbody/tr/td[16]");
    }

    public List<WebElement> getAllCommentsRows() {
        return browserElementLocator.findElementsByXpath("(//tbody)[4]//tr");
    }

    public List<String> getAllComments() {
        List<String> commentList=new ArrayList<String>();
        for(int i=3 ; i<=getAllCommentsRows().size();i=i+2){
            String xpathOfComment = "(//tbody)[4]//tr[" + String.valueOf(i) + "]//td";
            String commentFull = browserElementLocator.findElementByXpath(xpathOfComment).getAttribute("innerHTML");
            commentList.add(commentFull.substring(0,commentFull.indexOf("&nbsp")));
        }
        return commentList;
    }

    public int getNoOfComments() {
        return (getAllCommentsRows().size()-1)/2;
    }

    public String getLatestComment() {
        int indexOfLatestComment=getAllCommentsRows().size();
        String xpathOfLatestComment = "(//tbody)[4]//tr[" + String.valueOf(indexOfLatestComment) + "]//td";
        String latestCommentFull = browserElementLocator.findElementByXpath(xpathOfLatestComment).getAttribute("innerHTML");
        return latestCommentFull.substring(0,latestCommentFull.indexOf("&nbsp"));

    }

    public List<WebElement> getCommentsTable() {
        return browserElementLocator.findElementsByXpath("//table[@class='ESAtable' and @id='results']/tbody/tr");
    }

}
