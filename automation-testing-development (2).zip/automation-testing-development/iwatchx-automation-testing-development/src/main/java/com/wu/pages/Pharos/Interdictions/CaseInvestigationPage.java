package com.wu.pages.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;


import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;

public class CaseInvestigationPage extends BasePage {

    public String getMTCN() {
        System.out.println("mtcn=" + browserElementLocator.findElementByXpath("//mat-card-content[@class='mat-card-content']/div/div[8]/div/p").getText());
        return browserElementLocator.findElementByXpath("//mat-card-content[@class='mat-card-content']/div/div[8]/div/p").getText();
    }

    public WebElement getMatchBucketButton() {
        return browserElementLocator.findElementByXpath("//button[@id='Match-button']");
    }

    public List<WebElement> getEntities() {
        return browserElementLocator.findElementsByXpath("//app-hit-entity[@class='ng-star-inserted']");
    }

    public WebElement getDispositionSubmitButton() {
        return  browserElementLocator.findElementByXpath("//span[contains(text(),'Submit')]");
    }

    public WebElement getToaster() {
        return browserElementLocator.findElementByXpath("//*[text()='Case action successful. Please navigate to next case.']");
    }


    public WebElement getPlusSymbol() {
        return browserElementLocator.findElementByXpath("//wu-fab-menu[contains(@class,'wu-fab-menu ng-tns')]/div/div/button");
    }

    public WebElement getAuditLogButton() {
        return browserElementLocator.findElementByXpath("//span[text()='Audit Log']");
    }

    public WebElement getAuditTable() {
        return browserElementLocator.findElementByXpath("//table[@class='mat-table cdk-table mat-sort wu-table-gray']");
    }

    public List<WebElement> getAuditTabletr() {
        return browserElementLocator.findElementsByXpath("//table[@class='mat-table cdk-table mat-sort wu-table-gray']/tbody/tr");
    }
    public List<WebElement> getexpansionBtn() {
        return browserElementLocator.findElementsByXpath("//p[@class='wu-info-container']//mat-icon");
    }

    public WebElement getConstrainExpandBtn() {
        return browserElementLocator.findElementByXpath("//p[contains(.,'Constraints')]//mat-icon");
    }

    public WebElement getDisplayFilterDropdown() {
        return browserElementLocator.findElementByXpath("//mat-select[contains(@panelclass,'wu-display-filter-button')]");
    }

    public WebElement getDisplayFilterInfoCheckbox() {
        return browserElementLocator.findElementByXpath("(//mat-checkbox//span[contains(text(),'Info')])[2]");
    }

    public WebElement getDisplayFilterConstraintsCheckbox() {
        return browserElementLocator.findElementByXpath("//mat-checkbox//span[contains(text(),'Constraints')]");
    }

    public WebElement getEntityCardNameSection() {
        return browserElementLocator.findElementByXpath("//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-name')]");
    }

    public WebElement getEntityCardInfoSection() {
        return browserElementLocator.findElementByXpath("//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-msg')]");
    }

    public WebElement getEntityCardIdSection() {
        return browserElementLocator.findElementByXpath("//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-id')]");
    }

    public WebElement getEntityCardDobSection() {
        return browserElementLocator.findElementByXpath("//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-dob')]");
    }

    public WebElement getEntityCardGeoSection() {
        return browserElementLocator.findElementByXpath("//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-geo')]");
    }

    public WebElement getEntityCardContactSection() {
        return browserElementLocator.findElementByXpath("//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-contact')]");
    }

    public WebElement getEntityCardConstraintsSection() {
        return browserElementLocator.findElementByXpath("//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-constraints')]");
    }

    public void clickOnAllEntities() {
        List<WebElement> entities = getEntities();
        int rows_count = entities.size();

        for (int i = 1; i <= rows_count; i++) {
            WebElement eleExp = browserElementLocator.findElementByXpath("(//app-hit-entity[@class='ng-star-inserted']/mat-card/mat-card-header)[" + i + "]");
//            eleExp.click();
            Actions action = new Actions(BaseTestSetup.webDriver);
            action.moveToElement(eleExp).click().perform();
        }
    }

    public void clickOnFirstEntity() {
        List<WebElement> entities = getEntities();
        int rows_count = entities.size();

        for (int i = 1; i <= rows_count; i++) {
            WebElement eleExp = browserElementLocator.findElementByXpath("//app-hit-entity[@class='ng-star-inserted'][" + i + "]");
            eleExp.click();
            break;
        }
    }

    public WebElement getReasonsButton() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Reasons')]");
    }

    public void clickOnReasonsButton() {
        getReasonsButton().click();
    }

    public List<WebElement> getReasons() {
        return browserElementLocator.findElementsByXpath("//*[@id='mat-menu-panel-1']/div/button");
    }
    public WebElement getNotificationButton(){
        return browserElementLocator.findElementByXpath("//mat-expansion-panel-header[1]/span[last()]");
    }
    public boolean listOfReasonsDisplayed(java.util.List<String> details) {
        List<WebElement> reasons = getReasons();
        int rows_count = reasons.size();
        String[] actualReasons = new String[details.size()];
        String[] expectedReasons = new String[details.size()];

        for (int i = 1; i < rows_count; i++) {
            WebElement reasonText = browserElementLocator.findElementByXpath("//*[@id='mat-menu-panel-1']/div/button[" + i + "]/span[1]");
            actualReasons[i - 1] = reasonText.getText().trim();
            System.out.println("Reasons Displayed:" + actualReasons[i - 1]);
        }

        for (int j = 0; j < details.size(); j++) {
            expectedReasons[j] = details.get(j);
            System.out.println("Expected Reasons:" + expectedReasons[j]);
        }

        int l1= actualReasons.length;
        System.out.println("Size of actual reasons= "+l1);
        int l2= expectedReasons.length;
        System.out.println("Size of expected reasons= "+l2);

        System.out.println("Actual reasons: ");
        for(int x = 0; x < l1; x++)
        {
            System.out.print(actualReasons[x] + " ");
        }
        System.out.println();

        System.out.println("Expected reasons: ");
        for(int x = 0; x < l2; x++)
        {
            System.out.print(expectedReasons[x] + " ");
        }
        System.out.println();

        Object [] act = {actualReasons};
        Object [] exp = {expectedReasons};

        boolean result = Arrays.deepEquals(act, exp);
        System.out.println(result);
        if (result) {
            Logger.info("Expected Reasons displayed");

        }
        else {
            Logger.info("Expected Reasons are not displayed");

        }
        return result;
        /*
        //This for loop is to check if both the inputValues & actual values are matching.
        for (int i = 0; i < expectedReasons.length; i++) {
            if (!expectedReasons[i].equals(actualReasons[i]))
                return false;
        }
        return true;
*/
    }

    public void validateDisposition(String disposition) throws java.lang.InterruptedException {

        Thread.sleep(2000);
        WebElement option = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='disposition']"));
        String defaultItem = option.getText().trim();
        if (defaultItem.equalsIgnoreCase(disposition)) {
            Logger.info("Expected Disposition is displayed : " + disposition);
        } else
            Logger.info("Expected Disposition is not displayed.Disposition in UI : " + defaultItem);
        Assert.assertEquals(defaultItem, disposition, "Expected Disposition is not displayed in UI");
    }

    public void clickOnDispositionSubmit() {
        getDispositionSubmitButton().click();
    }

    public void verifyConfirmationMsg() {
        String tstValue = getToaster().getAttribute("innerHTML");

        if (tstValue.contains("Mail"))
            Logger.info("Case action successfull message appeared");
        else
            Assert.assertTrue(false,"Case successfully toaster didn't display");

        Logger.info("Case action successfull message not appeared.Displayed Error msg :" + tstValue);
    }

    public void clickOnPlusSymbol() {
        getPlusSymbol().click();
    }

    public void clickOnAuditLogSymbol() throws java.lang.InterruptedException {
        Thread.sleep(2000);
        getAuditLogButton().click();
    }
    public void closeAuditLog() throws InterruptedException {
        Thread.sleep(2000);
        browserElementLocator.findElementByXpath("(//mat-icon[contains(text(),'close')])[1]").click();
    }

    public void validateAuditLog(String expAuditDEsc) throws Exception {
        browserElements.waitForWebElementIsDisplayed(getAuditTable(),5000);
        List<WebElement> auditRows = getAuditTabletr();
        int rows_count = auditRows.size();

        boolean bflag=false;
        for (int i =1;i<=rows_count;i++) {
            WebElement ele =browserElementLocator.findElementByXpath("//table[@class='mat-table cdk-table mat-sort wu-table-gray']/tbody/tr["+i+"]/td[3]");
            String actDEsc = ele.getText().trim();
//            Logger.info("Actual log: "+actDEsc);
//            Logger.info("Expected log: "+expAuditDEsc);
            if (actDEsc.contains(expAuditDEsc))
            {
                bflag=true;
                break;
            }
        }
        Assert.assertTrue(bflag,"Expected audit message is not displayed.");
    }


    public void validateAuditLogActionFailure(String expAuditDEsc) throws Exception {
        browserElements.waitForWebElementIsDisplayed(getAuditTable(),5000);
        List<WebElement> auditRows = getAuditTabletr();
        int rows_count = auditRows.size();

        boolean bflag=false;
        for (int i =1;i<=rows_count;i++) {
            WebElement ele =browserElementLocator.findElementByXpath("//table[@class='mat-table cdk-table mat-sort wu-table-gray']/tbody/tr["+i+"]/td[3]");
            String actDEsc = ele.getText().trim();
            if (actDEsc.contains(expAuditDEsc))
            {
                bflag=true;
                break;
            }
        }
        Assert.assertTrue(bflag,"Expected audit message is not displayed.");
        Logger.info("Audit log verified for : "+expAuditDEsc);
    }

    public List verifyInfoConstraintExpansionbutton() {
        List<WebElement> expansionButton = getexpansionBtn();
        for (WebElement button : expansionButton) {
            browserElements.isElementDisplayed(button);
        }
        Logger.info("Verified presence of expansion button");
        return expansionButton;
    }

    public void clickOnInfoExpansion() {
        List<WebElement> expBtn = verifyInfoConstraintExpansionbutton();
        for (WebElement button : expBtn) {
            button.click();
            break;
        }
        Logger.info("Clicked on info expansion button");
    }

    public void clickOnConstraintsExpansion() throws InterruptedException {
        getConstrainExpandBtn().click();
        Logger.info("Clicked on constraints expansion button");
    }

    public void verifyDefaultExpansion() {
        List<WebElement> expBtn = verifyInfoConstraintExpansionbutton();
        for (WebElement button : expBtn) {
            Logger.info(button.getText());
            Assert.assertEquals(button.getText(), "keyboard_arrow_up");
        }
        Logger.info("Verified that info constraints sections are expanded by default");
    }

    public void verifyInfoConstarintsFromDisplayFilter() throws InterruptedException {
        if (browserElements.isElementDisplayed(getEntityCardConstraintsSection()) && browserElements.isElementDisplayed(getEntityCardContactSection()) && browserElements.isElementDisplayed(getEntityCardNameSection()) && browserElements.isElementDisplayed(getEntityCardInfoSection()) && browserElements.isElementDisplayed(getEntityCardIdSection()) && browserElements.isElementDisplayed(getEntityCardDobSection()) && browserElements.isElementDisplayed(getEntityCardGeoSection())) {
            Logger.info("Before applying Display filter, All the entity card details are displayed");
        }
        getDisplayFilterDropdown().click();
        Logger.info("Clicked on Display Filter");
        getDisplayFilterInfoCheckbox().click();
        Logger.info("Checked on info checkbox option");
        getDisplayFilterConstraintsCheckbox().click();
        Logger.info("Checked on Constraints checkbox option");
        Thread.sleep(2000);
        try {
            if (browserElements.isElementDisplayed(getEntityCardGeoSection()) || browserElements.isElementDisplayed(getEntityCardDobSection())) {
                Logger.info("Display filter didnot work.Other entity details displayed in entity card");
            }
        } catch (Exception e) {
            if (browserElements.isElementDisplayed(getEntityCardInfoSection()) || browserElements.isElementDisplayed(getEntityCardConstraintsSection()))
                Logger.info("Verified Info and Constraints section is displayed after applying Display filter");
            Logger.info("Info : " + BaseTestSetup.webDriver.findElement(By.xpath("(//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-msg')]//following::p//span)[1]")).getText());
            Logger.info("Constraints : " + BaseTestSetup.webDriver.findElement(By.xpath("(//mat-card[contains(@class,'entity')]//following::div[contains(@class,'hit-entity-msg')]//following::p//span)[2]")).getText());
        }
    }

    public void VerifyMatchBtnSanctionCase() {
        try {
            if (browserElements.isElementDisplayed(getMatchBucketButton())) {
                Logger.info("Scenario failed : Match bucket displayed in Sanction flow");

                Assert.assertTrue(false);
            }
        } catch (Exception e) {
            Assert.assertTrue(true);
            Logger.info("Scenario passed : Match bucket disabled in Sanction flow");

        }

    }
    public void clickonNotificationButton(){
        getNotificationButton().click();
    }

    public void VerifyMatchBtnINTRCase() {

        if (browserElements.isElementDisplayed(getMatchBucketButton())) {
            Logger.info("Scenario passed : Match bucket enabled in INTR flow");
            Assert.assertTrue(true);
        } else {
            Assert.assertTrue(false);
            Logger.info("Scenario failed : Match bucket disabled in INTR flow");
        }
    }
    public void validateAuditLogNotPresent(String expAuditDEsc) throws Exception {
        browserElements.waitForWebElementIsDisplayed(getAuditTable(), 5000);
        List<WebElement> auditRows = getAuditTabletr();
        int rows_count = auditRows.size();

        boolean bflag = false;
        for (int i = 1; i <= rows_count; i++) {
            WebElement ele = browserElementLocator.findElementByXpath("//table[@class='mat-table cdk-table mat-sort']/tbody/tr[" + i + "]/td[3]");
            String actDEsc = ele.getText().trim();
            if (expAuditDEsc.equalsIgnoreCase(actDEsc)) {
                bflag = true;
                break;
            }
        }
        if (bflag)
            Logger.info("Audit message is displayed : " + expAuditDEsc);
        else
            Logger.error("Audit message is not displayed.");

        Assert.assertFalse(bflag, "Audit Log Not Present");
    }
    public void clickOnActionArrow(){
        getclickOnActionArrow().click();
    }
    public void clickOnReasonArrow(){
        getclickOnReasonArrow().click();
    }
    public WebElement getclickOnActionArrow(){
        return browserElementLocator.findElementByXpath("//app-case-disposition[1]/form[1]/div[1]/mat-form-field[2]/div[1]/div[1]/div[3]/mat-select[1]/div[1]/div[1]/span[1]/span[1]");
    }
    public WebElement getclickOnReasonArrow(){
        return browserElementLocator.findElementByXpath("//app-case-disposition[1]/form[1]/div[1]/mat-form-field[3]/div[1]/div[1]/div[3]/mat-select[1]/div[1]");
    }
    public void clickOnCriticalArrow() {
        getclickOnCriticalArrow().click();
    }

    private WebElement getclickOnCriticalArrow() {
        return browserElementLocator.findElementByXpath("//app-case-disposition[1]/form[1]/div[1]/mat-form-field[2]/div[1]/div[1]/div[3]//span[contains(text(),'Critical Coaching')]");
    }

    public void clickOnIAReasonArrow() {
        getclickOnIAReasonArrow().click();
    }

    private WebElement getclickOnIAReasonArrow() {
        return browserElementLocator.findElementByXpath("//*[@id='mat-select-value-15']/span/span");
    }
    public void clickOnSummarySubmit() {
        getclickOnSummarySubmit().click();
    }

    private WebElement getclickOnSummarySubmit() {
        return browserElementLocator.findElementByXpath("//div[contains(text(),'Submit')]");
    }
    public void validateactAuditlog() throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        List<WebElement> Auditcount = webDriver.findElements(By.xpath("//table/tbody/tr/td[3]"));
        for (int i = 1; i <= Auditcount.size(); i++) {
            WebElement Auditreason = webDriver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[3]"));
            je.executeScript("arguments[0].style.border='3px solid red'", Auditreason);
            Thread.sleep(2000);
            String actAuditreason = Auditreason.getText();
            Logger.info("Analyst validates " + actAuditreason + " description in Audit Log");
        }
    }

    public void unselectCheckbox(String name) {
        if (caseTypeCheckboxiSselected(name) == true) {
            getCasesCheckboxClickable(name).click();
        }
    }
    public boolean caseTypeCheckboxiSselected(String caseTypename) {
        if (getCasesCheckbox(caseTypename).isSelected()) {
            return true;
        } else {
            return false;
        }
    }

    public WebElement getCasesCheckbox(String caseType) {
        return browserElementLocator.findElementByXpath("//label[contains(@class,'checkbox')]//span[contains(text(),'" + caseType + "')]/preceding-sibling::span//input[@type='checkbox']");
    }

    public WebElement getCasesCheckboxClickable(String caseType) {
        return browserElementLocator.findElementByXpath("//label[contains(@class,'checkbox')]//span[contains(text(),'" + caseType + "')]/preceding-sibling::span");
    }

    public void selectCheckbox(String name) {
        if (caseTypeCheckboxiSselected(name) == false) {
            getCasesCheckboxClickable(name).click();
        }
    }

    public List<WebElement> getAllActionFailure() {

        return browserElementLocator.findElementsByXpath("//mat-icon[@class='mat-icon notranslate lh-20 wu-action-workflow-icon material-icons-outlined wu-cursor-pointer wu-anchor-link mat-icon-no-color ng-star-inserted']");
    }

    public List<WebElement> getAllActionFailureResolved() {
        return browserElementLocator.findElementsByXpath("//mat-icon[@class='mat-icon notranslate lh-20 wu-action-workflow-icon material-icons-outlined wu-overrideSuccess-text mat-icon-no-color ng-star-inserted']");
    }

    public WebElement getHeaderCaseId() {
        return browserElementLocator.findElementByXpath("//*[contains(@id,'cdk-accordion-child')]/div/div/div[1]");
    }

    public WebElement getCaseRefNo() {
        return browserElementLocator.findElementByXpath("//*[contains(@id,'mat-expansion-panel-header')]/span/mat-panel-title/div[2]/div/div");
    }
    public WebElement getTrgInfo() {
        return browserElementLocator.findElementByXpath("//*[contains(@id,'cdk-accordion-child')]/div/div/div[2]/div/span");
    }
}
