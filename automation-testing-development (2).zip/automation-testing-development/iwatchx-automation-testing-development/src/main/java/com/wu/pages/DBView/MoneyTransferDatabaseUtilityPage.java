package com.wu.pages.DBView;

import com.wu.base.BaseTestSetup;
import com.wu.pages.BasePage;
import com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import static com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps.getCaseData;

public class MoneyTransferDatabaseUtilityPage extends BasePage {

    JavascriptExecutor jse = (JavascriptExecutor)BaseTestSetup.webDriver;
    public WebElement getSearchButton() throws InterruptedException {
        Thread.sleep(10000);
        return browserElementLocator.findElementByXpath("//button[@type='button']");
    }
    public WebElement getMTCNDetailsButton() {

        jse.executeScript("window.scrollBy(0,350)", "");
        return browserElementLocator.findElementByXpath("//button[@data-test='MTCNDetails-button-back']");
    }
    public WebElement getQueueButton() {

        return browserElementLocator.findElementByXpath("//button[@data-test='button-queue']");
    }
    public WebElement getCommentButton() {

        return browserElementLocator.findElementByXpath("//button[@data-test='button-comment']");
    }
    public void setControlNumber() {

        String str1 =getCaseData("mtcn");
//        jse.executeScript("document.getElementsByName('controlNumber')[0].value= '"+ str1 +"'");
        WebElement controlNumber = browserElementLocator.findElementByName("controlNumber");
        Actions performAct = new Actions(BaseTestSetup.webDriver);
        performAct.sendKeys(controlNumber, str1).build().perform();

    }

    public WebElement getStatus() {

        return browserElementLocator.findElementByXpath("//*[@id='root']/div/div/div[2]/div/div/div[2]/div[5]");
    }
    public WebElement getNotification() {

        return browserElementLocator.findElementByCssSelector(".notification");
    }
    public WebElement getAAOIDValueCARERGSI() {


        return browserElementLocator.findElementByXpath("//*[@id='root']/div/div/div[2]/div/div[2]/div/div[2]/div[1]/div[2]/div/div[3]");
    }
}
