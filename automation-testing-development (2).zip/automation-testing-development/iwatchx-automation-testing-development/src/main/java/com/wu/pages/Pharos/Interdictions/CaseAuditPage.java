package com.wu.pages.Pharos.Interdictions;

import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;

public class CaseAuditPage extends BasePage {

    public WebElement getAuditLogPhase() {
        return browserElementLocator.findElementByXpath("//tbody[@role='rowgroup']/tr[1]/td[3]");
    }

    public String getPhaseInAuditLog()
    {
        return getAuditLogPhase().getText().trim();
    }
}
