package com.wu.pages.DBView;

import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;

public class LandingPage extends BasePage {
    public WebElement getButton(String btnName) {
        return browserElementLocator.findElementByXpath("//a[contains(text(),'" + btnName + "')]");
    }
}
