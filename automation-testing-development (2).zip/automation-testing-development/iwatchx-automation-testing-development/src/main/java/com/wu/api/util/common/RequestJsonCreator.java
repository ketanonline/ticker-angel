package com.wu.api.util.common;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.internal.JsonContext;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.wu.base.logger.Logger;
import net.serenitybdd.core.Serenity;
import org.json.JSONObject;

import java.io.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class RequestJsonCreator {

    public static JSONObject GetCaseDetailsByCaseKeyAPI(String caseKey, String mode, String queueId, String investigativeGroup,
                                                        String loggedInAnalystUserId, String loggedInAnalystName,
                                                        String assignedToAnalystLevel,  String AnalystWorkGroup,String assignedToAnalystWorkLevel)
    {
        JSONObject caseWorkViewModeJSON = new JSONObject();
        caseWorkViewModeJSON.put("caseKey", caseKey);
        caseWorkViewModeJSON.put("mode", mode);
        caseWorkViewModeJSON.put("queueId", queueId);
        caseWorkViewModeJSON.put("investigativeGroup",investigativeGroup);
        JSONObject analystDetailsJSON = new JSONObject();
        analystDetailsJSON.put("analystUserId", loggedInAnalystUserId);
        analystDetailsJSON.put("analystName", loggedInAnalystName);
        analystDetailsJSON.put("analystLevel", assignedToAnalystLevel);
        analystDetailsJSON.put("analystWorkGroup", AnalystWorkGroup);
        analystDetailsJSON.put("analystWorkLevel", assignedToAnalystWorkLevel);
        caseWorkViewModeJSON.put("analystDetails", analystDetailsJSON);

        return caseWorkViewModeJSON;
    }

    public static JSONObject GetCaseDispositionInputJSON(int dispositionID, String dispositionValue, String dispositionReason,
                                                         String analystName,String analystID, String workflowCaseLevel,
                                                         String workflowStepID, String workflowStepName)
    {
        JSONObject caseDispositionJSON = new JSONObject();

        JSONObject disposition = new JSONObject();
        disposition.put("id", dispositionID);
        disposition.put("value", dispositionValue);
        disposition.put("reason", dispositionReason);
        caseDispositionJSON.put("disposition", disposition);

        JSONObject analyst = new JSONObject();
        analyst.put("name", analystName);
        analyst.put("id", analystID);
        caseDispositionJSON.put("analyst", analyst);

        JSONObject workflow = new JSONObject();
        workflow.put("caseLevel", workflowCaseLevel);
        workflow.put("stepId", workflowStepID);
        workflow.put("stepName", workflowStepName);
        caseDispositionJSON.put("workflow", workflow);

        return caseDispositionJSON;
    }

    public static JSONObject GetCaseHitDispositionInputJSON(String entityId, String analystName, String analystID,
                                                            String caseLevel,String comment, String reason,String type)
    {
        JSONObject caseHitDispositionJSON = new JSONObject();
        caseHitDispositionJSON.put("entityId", entityId);

        JSONObject disposition = new JSONObject();

        JSONObject analyst = new JSONObject();
        analyst.put("name", analystName);
        analyst.put("id", analystID);
        disposition.put("analyst", analyst);

        disposition.put("caseLevel", caseLevel);
        disposition.put("comment", comment);
        disposition.put("reason", reason);
        disposition.put("createdTimestamp", "2020-07-11T21:57:29.339Z");
        disposition.put("type", type);

        caseHitDispositionJSON.put("disposition", disposition);

        return caseHitDispositionJSON;
    }


    public String updateTheGivenNodeInJson(String jsonTemplateFileName, String nodeToBeUpdated, String valueToBeUpdated) throws Exception {

        String[] inputJSONFields = nodeToBeUpdated.split(";");
        String[] suspiciousValues = valueToBeUpdated.split(";");
        int i =0;
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        long mtcnNumber = timestamp.getTime();
        DocumentContext newJson = null;
        Configuration config = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
                .mappingProvider(new JacksonMappingProvider()).build();

        String filePath = CommonFunctions.getFullPath("json-api", jsonTemplateFileName);
        newJson = JsonPath.using(config).parse(new File(filePath)).set("{", "{");
        try {
            newJson = JsonPath.using(config).parse(new File(filePath)).set("activity.refId", mtcnNumber);
        }
        catch (Exception ex)
        {

        }
        Serenity.getCurrentSession().put("mtcnNumber", mtcnNumber);
        for (String jsonField : inputJSONFields) {

            newJson = JsonPath.using(config).parse(newJson.jsonString()).set(jsonField,suspiciousValues[i]);
            i++;
        }
        Serenity.getCurrentSession().put("inputPayloadJSON", ((JsonContext) newJson).json().toString());
        return newJson.toString();
    }
}
