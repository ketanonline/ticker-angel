package com.wu.api.util.common;

import com.wu.base.logger.Logger;
import com.wu.utils.AutProperties;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import static com.wu.api.util.common.CommonFunctions.*;

public class CreateCase {
    public static String gatewayURL;
    public static HashMap<String, String> ValidateResponseXMLHM = new HashMap<String, String>();
    public static HashMap<String, String> StoreResponseXMLHM = new HashMap<String, String>();
    public String sndrFName = "", sndrLName = "", sndrStreetName = "", sndrStreetName1 = "", localArea = "", sndrPhoneNum = "", sndrIdAlphaNum = "", sndr2ndIdAlphaNum = "", sndrMobileNum = "", sndrMobileCountryCode = "", sndrMail = "";
    public String rcvrFName = "", rcvrLName = "", rcvrStreetName = "", rcvrStreetName1 = "", rcvrPhoneNum = "", rcvrIdAlphaNum = "", rcvr2ndIdAlphaNum = "", rcvrMobileNum = "", rcvrMobileCountryCode = "", rcvrMail = "";
    public static HashMap<String, String> FeeResponseXMLHM = new HashMap<String, String>();
    public static int principalAmount = 0;
    public static int deliveryServicePosition;
    public static String sMethodName;
    private String entityType;
    String sendEntityType = "";
    String payEntityType = "";
    public String queueNameExcel = "";
    private boolean validateRequestStatus;
    private int iterationCount = 1;
    private boolean storeRequestStatus;
    public static String sScenarioName;
    private boolean scenarioStatus = false;
    private String errorCodeMessage = "";
    private boolean counterPartyFlag = false;

    public static HashMap<String, String> AISFeeResponseXMLHM = new HashMap<String, String>();
    public static HashMap<String, String> AISValidateResponseXMLHM = new HashMap<String, String>();
    public static HashMap<String, String> AISStoreResponseXMLHM = new HashMap<String, String>();

    public CreateCase(){
        String fileName = getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        gatewayURL= CommonFunctions.readFile(fileName, "GatewayURL");
//        System.out.println("gatewayURL=" + gatewayURL);
    }


    public String getRandomRcvrFName(){
        int leftLimit = 97; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 7;
        Random random = new Random();

        String RandomReceiverfirstname = random.ints(leftLimit, rightLimit + 1)
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        Logger.info("Random receiver first name generated : "+RandomReceiverfirstname);
        return RandomReceiverfirstname;
    }

    public String getRandomRcvrLName(){
        int leftLimit = 97; // letter 'a'
        int rightLimit = 122; // letter 'z'
        int targetStringLength = 5;
        Random random = new Random();

        String RandomReceiverLastname = random.ints(leftLimit, rightLimit + 1)
                .limit(targetStringLength)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        Logger.info("Random receiver Last name generated : "+RandomReceiverLastname);
        return RandomReceiverLastname;
    }


    String RandomRcvrFirstname = getRandomRcvrFName();
    String RandomRcvrLastname = getRandomRcvrLName();

    public String createDigitalMTCNUsingGWforSenderCase(String entityFileName,int entityNo, int totalNoOfEntities) throws ClassNotFoundException, InterruptedException, SQLException, Exception {
        String mtcn16 = "";
        HashMap<String, Object> map=new HashMap<String,Object>();
        switch(entityFileName){
            case "Digital_GSI_SingleEntity":
                map=getDataForMTCN_WUDigital_GSIsingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "L1_Digital_WU_Sanctions_SingleEntity":
                map=getDataForMTCN_WUDigital_SanctionssingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "L2_Digital_WU_Sanctions_SingleEntity":
                map=getDataForMTCN_WUDigital_L2_SanctionssingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
        }
        mtcn16 = ListProcessingSendSide(map);
        return mtcn16;
    }

    public HashMap<String, Object> getDataForMTCN_WUDigital_GSIsingleEntity(String fileName, int entityNo,int totalNoOfEntities)  {
        int n;
        String filePath = CommonFunctions.getFullPath_GSI_INTR("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);

        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Sndr_addr_line1", CommonFunctions.readFile(filePath, "Sndr_addr_line1"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2_"+n));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity_"+n));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState_"+n));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip_"+n));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry_"+n));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name_"+n));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode"));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName_"+n));
        map.put("SenderStreetName1", CommonFunctions.readFile(filePath, "SenderStreetName1"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber_"+n));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email_"+n));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type_"+n));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue_"+n));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue_"+n));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number_"+n));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date_"+n));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth_"+n));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth_"+n));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality_"+n));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Mobile_override_flag", CommonFunctions.readFile(filePath, "Mobile_override_flag"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("Credit_debit_card_number", CommonFunctions.readFile(filePath, "Credit_debit_card_number"));
        map.put("Cvvii_code", CommonFunctions.readFile(filePath, "Cvvii_code"));
        map.put("Expiration_date", CommonFunctions.readFile(filePath, "Expiration_date"));
        map.put("Cub_source", CommonFunctions.readFile(filePath, "Cub_source"));
        map.put("Store_validate_flag", CommonFunctions.readFile(filePath, "Store_validate_flag"));
        map.put("Auto_aprv_id", CommonFunctions.readFile(filePath, "Auto_aprv_id"));
        map.put("Host_based_taxes", CommonFunctions.readFile(filePath, "Host_based_taxes"));
        map.put("Account_nbr", CommonFunctions.readFile(filePath, "Account_nbr"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Ip_address", CommonFunctions.readFile(filePath, "Ip_address"));
        map.put("Mobile_city_code", CommonFunctions.readFile(filePath, "Mobile_city_code"));
        map.put("RWC_flag", CommonFunctions.readFile(filePath, "RWC_flag"));
        map.put("Receiver_mobile_override_flag", CommonFunctions.readFile(filePath, "Receiver_mobile_override_flag"));
        return map;
    }

    public String ListProcessingSendSide(HashMap<String, Object> map) throws ClassNotFoundException {
        String mtcn, mtcn16;
        Logger.info("HashMap: " + map);
        mtcn = "";
        mtcn16 = "";
            String newMtcnPay = "";
            readAndAssignTestCasePrerequisites(map);
            for (int i = 1; i <= iterationCount; i++) {
                //FeeInquiry Request
                GenerateTestDataForDynamicFields(map, entityType);
                boolean feeInquiryStatus = FeeEnquiry(map);

                if (!feeInquiryStatus) {
                    Logger.info("Fee Enquiry request failed" + FeeResponseXMLHM.get("Error Message"));
                    break;
                } else {
                    //validate request
                    validateRequestStatus = ValidateRequest(map);

                    if (!validateRequestStatus) {
                        Logger.info("Validation request failed" + ValidateResponseXMLHM.get("Error Message"));
                        break;
                    } else {
                        //Store Request
                        mtcn16 = ValidateResponseXMLHM.get("new_mtcn");
                        storeRequestStatus = StoreRequest(map);
                        if (!storeRequestStatus) {
                            Logger.info("Store request failed" + StoreResponseXMLHM.get("Error Message"));
                            break;
                        } else {
                            mtcn = ValidateResponseXMLHM.get("mtcn");
                            Logger.info("MTCN: " + mtcn);
                        }
                        Logger.info("Store Request Status for Cycle" + i + ": " + storeRequestStatus);
                    }
                }
            }
            return mtcn16;
    }

    public static boolean FeeEnquiry(HashMap<String, Object> map) {
        boolean Status = true;

        int principalAmount = 10180;
        try {
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(gatewayURL);
            String xmlvalue = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xrsi=\"http://www.westernunion.com/schema/xrsi\">\r\n" +
                    "   <soapenv:Header/>\r\n" +
                    "   <soapenv:Body>\r\n" +
                    "      <xrsi:fee-survey-request>\r\n" +
                    "         <device>\r\n" +
                    "            <id>" + map.get("Device_id") + "</id>\r\n" +
                    "            <type>" + map.get("Device_type") + "</type>\r\n" +
                    "         </device>\r\n" +
                    "         <channel>\r\n" +
                    "            <type>" + map.get("Channel_type") + "</type>\r\n" +
                    "            <name>" + map.get("Channel_name") + "</name>\r\n" +
                    "            <version>" + map.get("Channel_version") + "</version>\r\n" +
                    "         </channel>\r\n" +
                    "         <security>\r\n" +
                    "            <session>\r\n" +
                    "               <id>web-8c8c3b0a-569a-48bd-a3f3-b800133348b6</id>\r\n" +
                    "            </session>\r\n" +
                    "         </security>\r\n" +
                    "         <terminal>\r\n" +
                    "            <ip_address>17203109212</ip_address>\r\n" +
                    "         </terminal>\r\n" +
                    "         <sender>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + map.get("Sndr_addr_line1") + "</addr_line1>\r\n" +
//                    "               <addr_line2>"+map.get("Sndr_addr_line2")+"</addr_line2>\r\n" +
                    "               <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "               <state>" + map.get("SenderState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("SenderCountry") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "                  <country_name>" + map.get("Sender_country_name") + "</country_name>\r\n" +
                    "               </country_code>\r\n" +
                    "            </address>\r\n" +
                    "         </sender>\r\n" +
                    "         <financials>\r\n" +
                    "            <originators_principal_amount>" + principalAmount + "</originators_principal_amount>\r\n" +
                    "            <!--<destination_principal_amount>50000</destination_principal_amount>-->\r\n" +
                    "         </financials>\r\n" +
                    "         <payment_details>\r\n" +
                    "            <origination>\r\n" +
                    "               <currency_iso_code>" + map.get("OriginatingCurrencyCode") + "</currency_iso_code>\r\n" +
                    "               <country_iso_code>" + map.get("OriginatingCountry") + "</country_iso_code>\r\n" +
                    "            </origination>\r\n" +
                    "            <destination>\r\n" +
                    "               <currency_iso_code>" + map.get("DestinationCurrencyCode") + "</currency_iso_code>\r\n" +
                    "               <country_iso_code>" + map.get("DestinationCountry") + "</country_iso_code>\r\n" +
                    "            </destination>\r\n" +
                    "            <payment_type>" + map.get("Payment_type") + "</payment_type>\r\n" +
                    "         </payment_details>\r\n" +
                    "         <!--<transaction_type>WMF</transaction_type>-->\r\n" +
                    "         <foreign_remote_system>\r\n" +
                    "            <identifier>" + map.get("ForeignSystemIdentifier") + "</identifier>\r\n" +
                    "            <reference_no>" + map.get("ForeignSystemReferenceNo") + "</reference_no>\r\n" +
                    "            <counter_id>" + map.get("ForeignSystemCounterID") + "</counter_id>\r\n" +
                    "         </foreign_remote_system>\r\n" +
                    "      </xrsi:fee-survey-request>\r\n" +
                    "   </soapenv:Body>\r\n" +
                    "</soapenv:Envelope>\r\n" +
                    "";
            //System.out.println("Fee request:"+ xmlvalue);
            InputStream xmlInput = new ByteArrayInputStream(xmlvalue.getBytes(StandardCharsets.UTF_8));
            post.setEntity(new InputStreamEntity(new DataInputStream(xmlInput)));
            post.setHeader("Content-Type", "text/xml;charset=UTF-8");
            post.setHeader("Accept-Encoding", "gzip,deflate");
            post.setHeader("SOAPAction", "FeeSurveyAction");
            post.setHeader("Connection", "Keep-Alive");
            post.setHeader("Credential", "World!!");
            post.setHeader("User_id", "Hello");
            post.setHeader("Auth_token", "cc4d43df1f5ef0bb0dc6fa857a15ce8348a2bc5f0f0b7a206e040bfe1a0867c2bd76dd3b50de9a177bbaa56c391d6189b8d2fc858c742b1b7279f8fe35ece986");
            HttpResponse response = client.execute(post);
            int ResponseCode = response.getStatusLine().getStatusCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = "";
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            Logger.info("Fee Enquiry Response " + sb);
            String abc = sb.toString();
            if (ResponseCode == 200) {
                Logger.info("*********** Start FeeEnquiry ************");
                Logger.info("Successfully hit Fee request with status code :" + ResponseCode);
                FeeResponseHMFiedlMapping(abc);
            } else {
                Logger.info("Failed to hit Fee request due to status code :" + ResponseCode);
                FeeResponseXMLHM.put("Error Message", GetNodeValue(abc, "error"));
                Status = false;
            }
        } catch (Exception e) {
            Logger.info("Unable to get response from Fee Enquiry due to : " + e.getMessage());
            Status = false;
        }
        return Status;

    }

    public boolean ValidateRequest(HashMap<String, Object> map) {
        boolean Status = true;
        try {
            //String URL= "https://wugatewaysoap.qawesternunion.com";
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(gatewayURL);
            String xmlvalue = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xrsi=\"http://www.westernunion.com/schema/xrsi\">\r\n" +
                    "   <soapenv:Header/>\r\n" +
                    "   <soapenv:Body>\r\n" +
                    "      <xrsi:send-money-digital-validation-request>\r\n" +
                    "         <device>\r\n" +
                    "            <id>" + map.get("Device_id") + "</id>\r\n" +
                    "            <type>" + map.get("Device_type") + "</type>\r\n" +
                    "         </device>\r\n" +
                    "         <!--Optional:-->\r\n" +
                    "         <channel>\r\n" +
                    "            <type>" + map.get("Channel_type") + "</type>\r\n" +
                    "            <name>" + map.get("Channel_name") + "</name>\r\n" +
                    "            <version>" + map.get("Channel_version") + "</version>\r\n" +
                    "         </channel>\r\n" +
                    "\r\n" +
                    "         <security>\r\n" +
                    "            <session>\r\n" +
                    "               <id>web-2c9f88fa-44fb569c-0145-19ba4828-005e</id>\r\n" +
                    "            </session>\r\n" +
                    "         </security>\r\n" +
                    "        \r\n" +
                    "         <sender>\r\n" +
                    "            <user_id></user_id>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + sndrFName + "</first_name>\r\n" +
                    "               <last_name>" + sndrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + sndrStreetName + "</addr_line1>\r\n" +
                    "               <addr_line2>" + sndrStreetName1 + "</addr_line2>\r\n" +
                    "               <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "               <state>" + map.get("SenderState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("SenderCountry") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "                  <country_name>" + map.get("SenderCountry") + "</country_name>\r\n" +
                    "               </country_code>\r\n" +
                    "               <local_area>Local</local_area>\r\n" +
                    "            </address>\r\n" +
                    "            <preferred_customer>\r\n" +
                    "               <account_nbr>" + map.get("Account_nbr") + "</account_nbr>\r\n" +
                    "               <level_code>" + map.get("Level_code") + "</level_code>\r\n" +
                    "               <original_card_type></original_card_type>\r\n" +
                    "               <card_class/>\r\n" +
                    "               <name_altkey></name_altkey>\r\n" +
                    "               <last_use_date/>\r\n" +
                    "               <issue_date>04042011</issue_date>\r\n" +
                    "              <first_use_date/>\r\n" +
                    "               <max_number_receivers_allowed></max_number_receivers_allowed>\r\n" +
                    "               <last_modification_time/>\r\n" +
                    "               <last_change_source/>\r\n" +
                    "               <expiration_date/>\r\n" +
                    "               <card_replaced_count></card_replaced_count>\r\n" +
                    "               <card_changes_count>0</card_changes_count>\r\n" +
                    "               <update/>\r\n" +
                    "            </preferred_customer>\r\n" +
                    "            <compliance_details>\r\n" +
                    "               <id_details>\r\n" +
                    "                  <id_type>" + map.get("Id_type") + "</id_type>\r\n" +
                    "                  <id_country_of_issue>" + map.get("Id_country_of_issue") + "</id_country_of_issue>\r\n" +
                    "                  <id_place_of_issue>" + map.get("Id_place_of_issue") + "</id_place_of_issue>\r\n" +
                    "                  <id_number>" + map.get("Id_number") + "</id_number>\r\n" +
                    "               </id_details>\r\n" +
                    "               <third_party_details>\r\n" +
                    "                  <flag_pay>" + map.get("Third_party_flag_pay") + "</flag_pay>\r\n" +
				/*"					<address>\r\n" +
				"						<city>Lodi</city>\r\n" +
				"					</address>\r\n" + */
                    "               </third_party_details>\r\n" +
                    "               <id_expiration_date>" + map.get("Id_expiration_date") + "</id_expiration_date>\r\n" +
                    "               <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "				<occupation>" + map.get("Occupation") + "</occupation>\r\n" +
                    "               <transaction_reason>" + map.get("Transaction_reason") + "</transaction_reason>\r\n" +
                    "               <Country_of_Birth>" + map.get("Country_of_Birth") + "</Country_of_Birth>\r\n" +
                    "               <nationality>" + map.get("Nationality") + "</nationality>\r\n" +
                    "               <Source_of_Funds>" + map.get("Source_of_Funds") + "</Source_of_Funds>\r\n" +
                    "               <Name_of_Employer_Business>" + map.get("Name_of_Employer_Business") + "</Name_of_Employer_Business>\r\n" +
                    "               <Nature_of_Work_Business>" + map.get("Nature_of_Work_Business") + "</Nature_of_Work_Business>\r\n" +
                    "				<Relationship_to_Receiver_Sender>" + map.get("Relationship_to_Receiver_Sender") + "</Relationship_to_Receiver_Sender>\r\n" +
                    "               <I_act_on_My_Behalf>" + map.get("I_act_on_My_Behalf") + "</I_act_on_My_Behalf>\r\n" +
                    "               <WU_COM_Electronic_Validation>" + map.get("WU_COM_Electronic_Validation") + "</WU_COM_Electronic_Validation>\r\n" +
                    "             <are_you_a_PEP_relative_or_friend>" + map.get("Are_you_a_PEP_relative_or_friend") + "</are_you_a_PEP_relative_or_friend>\r\n" +
                    "\r\n" +
                    "               <employer_status>" + map.get("Employer_status") + "</employer_status>\r\n" +
                    "               <Employment_position_level>" + map.get("Employment_position_level") + "</Employment_position_level>\r\n" +
                    "               \r\n" +
                    "            </compliance_details>\r\n" +
                    "            <email>" + sndrMail + "</email>\r\n" +
                    "            <contact_phone>" + sndrPhoneNum + "</contact_phone>\r\n" +
                    "            <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "            <ip_address>" + map.get("Ip_address") + "</ip_address>\r\n" +
                    "            <mobile_details>\r\n" +
                    "               <city_code>" + map.get("Mobile_city_code") + "</city_code>\r\n" +
                    "               <number>" + sndrPhoneNum + "</number>\r\n" +
                    "               <override_flag>" + map.get("Mobile_override_flag") + "</override_flag>\r\n" +
                    "            </mobile_details>\r\n" +
                    "            <bank_details>\r\n" +
                    "               <name>" + map.get("Bank_name") + "</name>\r\n" +
                    "               <account_number>" + map.get("Bank_account_number") + "</account_number>\r\n" +
                    "               <state_country/> " +
                    "              <bank_code>" + map.get("Bank_code") + "</bank_code>\r\n" +
                    "            </bank_details>\r\n" +
                    "         </sender>\r\n" +
                    "         <receiver>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + rcvrFName + "</first_name>\r\n" +
                    "               <last_name>" + rcvrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + rcvrStreetName + "</addr_line1>\r\n" +
                    "               <addr_line2>" + rcvrStreetName1 + "</addr_line2>\r\n" +
                    "               <city>" + map.get("ReceiverCity") + "</city>\r\n" +
                    "               <state>" + map.get("ReceiverState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("ReceiverZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("ReceiverCountryCode") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("DestinationCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "                  <country_name>" + map.get("Receivercountry_name") + "</country_name>\r\n" +
                    "               </country_code>\r\n" +
                    "               <local_area>" + map.get("ReceiverLocalDeliveryArea") + "</local_area>\r\n" +
                    "               <street>" + map.get("ReceiverLocalStreet") + "</street>\r\n" +
                    "            </address>\r\n" +
                    "			 <compliance_details>\r\n" +
                    "				<third_party_details>\r\n" +
				/*"					<address>\r\n" +
				"						<city>Lodi</city>\r\n"+
				"					 </address>\r\n" + */
                    "				</third_party_details>\r\n" +
                    "			</compliance_details>\r\n" +
                    "            <email>" + rcvrMail + "</email>\r\n" +
                    "            <contact_phone>" + rcvrPhoneNum + "</contact_phone>\r\n" +
                    "            <date_of_birth>" + map.get("Receiver_date_of_birth") + "</date_of_birth>\r\n" +
                    "            <mobile_details>\r\n" +
                    "               <city_code>" + map.get("Receiver_mobile_city_code") + "</city_code>\r\n" +
                    "               <number>" + rcvrPhoneNum + "</number>\r\n" +
                    "               <override_flag>" + map.get("Receiver_mobile_override_flag") + "</override_flag>\r\n" +
                    "            </mobile_details>\r\n" +
                    "            <bank_details>\r\n" +
                    "               <name>" + map.get("Receiver_bank_name") + "</name>\r\n" +
                    "               <account_number>" + map.get("Receiver_account_number") + "</account_number>\r\n" +
                    "               <routing_number>" + map.get("Receiver_routing_number") + "</routing_number>\r\n" +
                    "               <account_type>" + map.get("Receiver_account_type") + "</account_type>\r\n" +
                    "               <rcv_financial_id>" + map.get("Receiver_rcv_financial_id") + "</rcv_financial_id>\r\n" +
                    "               <bank_number>" + map.get("Receiver_bank_number") + "</bank_number>\r\n" +
                    "               <branch_number>" + map.get("Receiver_branch_number") + "</branch_number>\r\n" +
                    "               <bank_location>" + map.get("Receiver_bank_location") + "</bank_location>\r\n" +
                    "               <bic>" + map.get("Receiver_bic") + "</bic>\r\n" +
                    "               <bank_code>" + map.get("Receiver_bank_code") + "</bank_code>\r\n" +
                    "               <sort_code>" + map.get("Receiver_sort_code") + "</sort_code>\r\n" +
                    "               <account_prefix>" + map.get("Receiver_account_prefix") + "</account_prefix>\r\n" +
                    "               <account_suffix>" + map.get("Receiver_account_suffix") + "</account_suffix>\r\n" +
                    "               <bank_area>" + map.get("Receiver_bank_area") + "</bank_area>\r\n" +
                    "               <bank_account_holder>" + map.get("Receiver_bank_account_holder") + "</bank_account_holder>\r\n" +
                    "            </bank_details>\r\n" +
                    "         </receiver>\r\n" +
                    "         <billing_details>\r\n" +
                    "            <name name_type=\"M\">\r\n" +
                    "               <first_name>TEST1</first_name>\r\n" +
                    "               <middle_name/>\r\n" +
                    "               <last_name>WEST1</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>calle Inocencio Fernandez,61</addr_line1>\r\n" +
                    "               <addr_line2/>\r\n" +
                    "               <city>MADRID</city>\r\n" +
                    "               <state>MADRID</state>\r\n" +
                    "               <postal_code>01234</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <cpc_code/>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>IN</country_code>\r\n" +
                    "                     <currency_code>INR</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "                  <country_name>IND</country_name>\r\n" +
                    "               </country_code>\r\n" +
                    "            </address>\r\n" +
                    "            <home_phone/>\r\n" +
                    "            <contact_phone>71234567891</contact_phone>\r\n" +
                    "            <email_address></email_address>\r\n" +
                    "            <company_name/>\r\n" +
                    "         </billing_details>\r\n" +
                    "         <service_options>\r\n" +
                    "            <service_option>\r\n" +
                    "               <channel>\r\n" +
                    "                  <type>WEB</type>\r\n" +
                    "                  <name/>\r\n" +
                    "               </channel>\r\n" +
                    "               <wu_product>\r\n" +
                    "                  <name>" + map.get("WU_product_name") + "</name>\r\n" +
                    "                  <code>" + FeeResponseXMLHM.get("wu_productcode") + "</code>\r\n" +
                    "                  <routing_code>" + FeeResponseXMLHM.get("wu_productrouting_code") + "</routing_code>\r\n" +
                    "               </wu_product>\r\n" +
                    "               <payment_details>\r\n" +
                    "                  <origination>\r\n" +
                    "                     <principal_amount>" + principalAmount + "</principal_amount>\r\n" +
                    "                     <gross_amount>" + FeeResponseXMLHM.get("origination:gross_amount") + "</gross_amount>\r\n" +
                    "                     <currency_iso_code>" + map.get("OriginatingCurrencyCode") + "</currency_iso_code>\r\n" +
                    "                     <country_iso_code>" + map.get("OriginatingCountry") + "</country_iso_code>\r\n" +
                    "                  </origination>\r\n" +
                    "                <destination>\r\n" +
                    "                     <expected_payout_amount>" + FeeResponseXMLHM.get("destination:expected_payout_amount") + "</expected_payout_amount>\r\n" +
                    "                     <currency_iso_code>" + map.get("DestinationCurrencyCode") + "</currency_iso_code>\r\n" +
                    "                     <country_iso_code>" + map.get("DestinationCountry") + "</country_iso_code>\r\n" +
                    "                </destination>\r\n" +
                    "                  <promotion>\r\n" +
                    "                     <code/>\r\n" +
                    "                     <discount>" + FeeResponseXMLHM.get("promotion:discount") + "</discount>\r\n" +
                    "                     <message>CAT 4</message>\r\n" +
                    "                  </promotion>\r\n" +
                    "                  <taxes>\r\n" +
                    "                     <tax_amount>" + FeeResponseXMLHM.get("taxes:tax_amount") + "</tax_amount>\r\n" +
                    "                  </taxes>\r\n" +
                    "                  <fees>\r\n" +
                    "                     <charges>" + FeeResponseXMLHM.get("fees:charges") + "</charges>\r\n" +
                    "                  </fees>\r\n" +
                    "                  <exchange_rate>" + FeeResponseXMLHM.get("exchange_rate") + "</exchange_rate>\r\n" +
                    "                 <min_amount>" + FeeResponseXMLHM.get("min_amount") + "</min_amount>\r\n" +
                    "                  <max_amount>" + FeeResponseXMLHM.get("max_amount") + "</max_amount>\r\n" +
                    "                  <payment_type>CreditCard</payment_type>\r\n" +
                    "               <payment_digest>" + FeeResponseXMLHM.get("payment_digest") + "</payment_digest>\r\n" +
                    "                  <credit_debit_card_details>\r\n" +
                    "                     <card_number>" + map.get("Credit_debit_card_number") + "</card_number>\r\n" +
                    "                     <cvvii_code>" + map.get("Cvvii_code") + "</cvvii_code>\r\n" +
                    "                     <expiration_date>" + map.get("Expiration_date") + "</expiration_date>\r\n" +
                    "                  </credit_debit_card_details>\r\n" +
                    "               </payment_details>\r\n" +
                    "               <additional_service_options>\r\n" +
                    "                  <additional_service_option>\r\n" +
                    "                     <name>NOTIFICATION</name>\r\n" +
                    "                     <code>051</code>\r\n" +
                    "                     <discounted_surcharge>0</discounted_surcharge>\r\n" +
                    "                     <taxes>\r\n" +
                    "                        <tax_amount>0</tax_amount>\r\n" +
                    "                     </taxes>\r\n" +
                    "                  </additional_service_option>\r\n" +
                    "               </additional_service_options>\r\n" +
                    "            </service_option>\r\n" +
                    "         </service_options>\r\n" +
                    "         <new_mtcn/>\r\n" +
                    "        <foreign_remote_system>\r\n" +
                    "            <identifier>" + map.get("ForeignSystemIdentifier") + "</identifier>\r\n" +
                    "            <reference_no>" + map.get("ForeignSystemReferenceNo") + "</reference_no>\r\n" +
                    "            <counter_id>" + map.get("ForeignSystemCounterID") + "</counter_id>\r\n" +
                    "            <operator_id>" + map.get("ForeignSystemOperatorID") + "</operator_id>\r\n" +
                    "         </foreign_remote_system>\r\n" +
                    "\r\n" +
                    "         <cub>\r\n" +
                    "            <web_cub>\r\n" +
                    "               <cub_source>" + map.get("Cub_source") + "</cub_source>\r\n" +
                    "               <fid_acculynk_language>en</fid_acculynk_language>\r\n" +
                    "               <card_type></card_type>\r\n" +
                    "               <cub_exp_date></cub_exp_date>\r\n" +
                    "               <principal_amount>1000</principal_amount>\r\n" +
                    "               <base_charge>490</base_charge>\r\n" +
                    "               <total_amount>1100</total_amount>\r\n" +
                    "               <environment>B</environment>\r\n" +
                    "               <rwc_flag>" + map.get("RWC_flag") + "</rwc_flag>\r\n" +
                    "<!--               <send_delay_hours></send_delay_hours>\r\n" +
                    "-->\r\n" +
                    "		            <di_thirdparty_identifier/>" +
                    "	              	<di_txn_channel>" + map.get("Di_txn_channel") + "</di_txn_channel>\r\n" +
                    "		            <di_partner_name>" + map.get("Di_partner_name") + "</di_partner_name>\r\n" +
                    "	                <additional_data/>" +
                    "<!--               <txn_identifier>ABMT</txn_identifier>\r\n" +
                    "-->\r\n" +
                    "<!--               <merchant_id>Retail3456</merchant_id>\r\n" +
                    "-->\r\n" +
                    "            </web_cub>\r\n" +
                    "         </cub>\r\n" +
                    "         <store_validate_flag>" + map.get("Store_validate_flag") + "</store_validate_flag>\r\n" +
                    "         <auto_aprv_id>" + map.get("Auto_aprv_id") + "</auto_aprv_id>\r\n" +
                    "         <host_based_taxes>" + map.get("Host_based_taxes") + "</host_based_taxes>\r\n" +
                    "      </xrsi:send-money-digital-validation-request>\r\n" +
                    "   </soapenv:Body>\r\n" +
                    "</soapenv:Envelope>\r\n" +
                    "";
            //System.out.println("validate request "+xmlvalue);
            InputStream xmlInput = new ByteArrayInputStream(xmlvalue.getBytes(StandardCharsets.UTF_8));
            post.setEntity(new InputStreamEntity(new DataInputStream(xmlInput)));
            post.setHeader("Content-Type", "text/xml;charset=UTF-8");
            post.setHeader("Accept-Encoding", "gzip,deflate");
            post.setHeader("SOAPAction", "FeeSurveyAction");
            post.setHeader("Connection", "Keep-Alive");
            post.setHeader("Credential", "World!!");
            post.setHeader("User_id", "Hello");
            post.setHeader("Auth_token", "cc4d43df1f5ef0bb0dc6fa857a15ce8348a2bc5f0f0b7a206e040bfe1a0867c2bd76dd3b50de9a177bbaa56c391d6189b8d2fc858c742b1b7279f8fe35ece986");
            HttpResponse response = client.execute(post);
            int ResponseCode = response.getStatusLine().getStatusCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = "";
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            Logger.info("Response after validate request " + sb);
            String abc = sb.toString();
            if (ResponseCode == 200) {
                Logger.info("*********** Start Validate Request ************");
                Logger.info("Successfully hit validate request with status code :" + ResponseCode);
                ValidateResponseHMFiedlMapping(abc);
            } else {
                Logger.info("Failed to hit validate request due to status code :" + ResponseCode);
                ValidateResponseXMLHM.put("Error Message", GetNodeValue(abc, "error"));
                Status = false;
            }
        } catch (Exception e) {
            Logger.info("Unable to get response from Validate request due to : " + e.getMessage());
            Status = false;
        }
        return Status;

    }

    public boolean StoreRequest(HashMap<String, Object> map) {
        boolean Status = true;
        try {
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(gatewayURL);
            String xmlvalue = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\r\n" +
                    "   <soap:Body>\r\n" +
                    "      <ns2:send-money-digital-store-request xmlns:ns2=\"http://www.westernunion.com/schema/xrsi\">\r\n" +
                    "         <device>\r\n" +
                    "            <id>" + map.get("Device_id") + "</id>\r\n" +
                    "            <type>" + map.get("Device_type") + "</type>\r\n" +
                    "         </device>\r\n" +
                    "          <channel>\r\n" +
                    "            <type>" + map.get("Channel_type") + "</type>\r\n" +
                    "            <name>" + map.get("Channel_name") + "</name>\r\n" +
                    "            <version>" + map.get("Channel_version") + "</version>\r\n" +
                    "         </channel>\r\n" +
                    "\r\n" +
                    "          <instant_notification>\r\n" +
                    "            <addl_service_charges>" + ValidateResponseXMLHM.get("addl_service_charges") + "</addl_service_charges>\r\n" +
                    "         </instant_notification>\r\n" +
                    "         <terminal>\r\n" +
                    "            <id>" + ValidateResponseXMLHM.get("terminal_id") + "</id>\r\n" +
                    "         </terminal>\r\n" +
                    "         <sender>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + sndrFName + "</first_name>\r\n" +
                    "               <last_name>" + sndrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + sndrStreetName + "</addr_line1>\r\n" +
                    "               <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "               <state>" + map.get("SenderState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("SenderCountry") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "                  <country_name>" + map.get("SenderCountry") + "</country_name>\r\n" +
                    "               </country_code>\r\n" +
                    "            </address>\r\n" +
                    "            <preferred_customer>\r\n" +
                    "               <account_nbr>" + map.get("Account_nbr") + "</account_nbr>\r\n" +
                    "               <level_code>" + map.get("Level_code") + "</level_code>\r\n" +
                    "               <original_card_type></original_card_type>\r\n" +
                    "               <card_class/>\r\n" +
                    "               <name_altkey></name_altkey>\r\n" +
                    "               <last_use_date/>\r\n" +
                    "               <issue_date>04042011</issue_date>\r\n" +
                    "              <first_use_date/>\r\n" +
                    "               <max_number_receivers_allowed></max_number_receivers_allowed>\r\n" +
                    "               <last_modification_time/>\r\n" +
                    "               <last_change_source/>\r\n" +
                    "               <expiration_date/>\r\n" +
                    "               <card_replaced_count></card_replaced_count>\r\n" +
                    "               <card_changes_count>0</card_changes_count>\r\n" +
                    "               <update/>\r\n" +
                    "            </preferred_customer>\r\n" +
                    "            <compliance_details>\r\n" +
                    "               <id_details>\r\n" +
                    "                  <id_type>" + map.get("Id_type") + "</id_type>\r\n" +
                    "                  <id_country_of_issue>" + map.get("Id_country_of_issue") + "</id_country_of_issue>\r\n" +
                    "                  <id_place_of_issue>" + map.get("Id_place_of_issue") + "</id_place_of_issue>\r\n" +
                    "                  <id_number>" + map.get("Id_number") + "</id_number>\r\n" +
                    "               </id_details>\r\n" +
                    "               <third_party_details>\r\n" +
                    "                  <flag_pay>" + map.get("Third_party_flag_pay") + "</flag_pay>\r\n" +
                    "               </third_party_details>\r\n" +
                    "               <id_expiration_date>" + map.get("Id_expiration_date") + "</id_expiration_date>\r\n" +
                    "               <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "				<occupation>" + map.get("Occupation") + "</occupation>\r\n" +
                    "               <transaction_reason>" + map.get("Transaction_reason") + "</transaction_reason>\r\n" +
                    "               <Country_of_Birth>" + map.get("Country_of_Birth") + "</Country_of_Birth>\r\n" +
                    "               <nationality>" + map.get("Nationality") + "</nationality>\r\n" +
                    "               <Source_of_Funds>" + map.get("Source_of_Funds") + "</Source_of_Funds>\r\n" +
                    "               <Name_of_Employer_Business>" + map.get("Name_of_Employer_Business") + "</Name_of_Employer_Business>\r\n" +
                    "               <Nature_of_Work_Business>" + map.get("Nature_of_Work_Business") + "</Nature_of_Work_Business>\r\n" +
                    "				<Relationship_to_Receiver_Sender>" + map.get("Relationship_to_Receiver_Sender") + "</Relationship_to_Receiver_Sender>\r\n" +
                    "               <I_act_on_My_Behalf>" + map.get("I_act_on_My_Behalf") + "</I_act_on_My_Behalf>\r\n" +
                    "               <WU_COM_Electronic_Validation>" + map.get("WU_COM_Electronic_Validation") + "</WU_COM_Electronic_Validation>\r\n" +
                    "             <are_you_a_PEP_relative_or_friend>" + map.get("Are_you_a_PEP_relative_or_friend") + "</are_you_a_PEP_relative_or_friend>\r\n" +
                    "\r\n" +
                    "               <employer_status>" + map.get("Employer_status") + "</employer_status>\r\n" +
                    "               <Employment_position_level>" + map.get("Employment_position_level") + "</Employment_position_level>\r\n" +
                    "               \r\n" +
                    "            </compliance_details>\r\n" +
                    "            <email>" + sndrMail + "</email>\r\n" +
                    "            <contact_phone>" + sndrPhoneNum + "</contact_phone>\r\n" +
                    "            <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "			 <mobile_details>\r\n" +
                    "               <city_code>1</city_code>\r\n" +
                    "               <number>" + sndrPhoneNum + "</number>\r\n" +
                    "               <override_flag>N</override_flag>\r\n" +
                    "            </mobile_details>\r\n" +
                    "         </sender>\r\n" +
                    "         <receiver>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + rcvrFName + "</first_name>\r\n" +
                    "               <last_name>" + rcvrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + rcvrStreetName + "</addr_line1>\r\n" +
                    "               <city>" + map.get("ReceiverCity") + "</city>\r\n" +
                    "               <state>" + map.get("ReceiverState") + "</state>\r\n" +
                    "				<postal_code>" + map.get("ReceiverZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("ReceiverCountryCode") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("DestinationCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "               </country_code>\r\n" +
                    "            </address>\r\n" +
                    "            <email>" + rcvrMail + "</email>\r\n" +
                    "            <contact_phone>" + rcvrPhoneNum + "</contact_phone>\r\n" +
                    "            <date_of_birth>" + map.get("Receiver_date_of_birth") + "</date_of_birth>\r\n" +
                    "			 <mobile_phone>\r\n" +
                    "               <phone_number>\r\n" +
                    "                  <country_code>1</country_code>\r\n" +
                    "                  <national_number>" + rcvrPhoneNum + "</national_number>\r\n" +
                    "               </phone_number>\r\n" +
                    "               <identity>\r\n" +
                    "                  <type>IMEI</type>\r\n" +
                    "                  <data>" + rcvrPhoneNum + "</data>\r\n" +
                    "               </identity>\r\n" +
                    "            </mobile_phone>\r\n" +
                    "            <mobile_details>\r\n" +
                    "               <city_code>973</city_code>\r\n" +
                    "               <number>8793724</number>\r\n" +
                    "               <sms_flag>1</sms_flag>\r\n" +
                    "            </mobile_details>\r\n" +
                    "            <bank_details>\r\n" +
                    "               <name>" + map.get("Receiver_bank_name") + "</name>\r\n" +
                    "               <account_number>" + map.get("Receiver_account_number") + "</account_number>\r\n" +
                    "				<routing_number>" + map.get("Receiver_routing_number") + "</routing_number>\r\n" +
                    "            </bank_details>\r\n" +
                    "         </receiver>\r\n" +
                    "         <service_options>\r\n" +
                    "            <service_option>\r\n" +
                    "               <wu_product>\r\n" +
                    "                  <name>" + map.get("WU_product_name") + "</name>\r\n" +
                    "                  <code>" + FeeResponseXMLHM.get("wu_productcode") + "</code>\r\n" +
                    "                  <routing_code>" + FeeResponseXMLHM.get("wu_productrouting_code") + "</routing_code>\r\n" +
                    "               </wu_product>\r\n" +
                    "               <payment_details>\r\n" +
                    "                  <origination>\r\n" +
                    "                     <principal_amount>" + principalAmount + "</principal_amount>\r\n" +
                    "                     <gross_amount>" + ValidateResponseXMLHM.get("origination:gross_amount") + "</gross_amount>\r\n" +
                    "                     <currency_iso_code>" + map.get("OriginatingCurrencyCode") + "</currency_iso_code>\r\n" +
                    "                     <country_iso_code>" + map.get("OriginatingCountry") + "</country_iso_code>\r\n" +
                    "                  </origination>\r\n" +
                    "                  <destination>\r\n" +
                    "                     <expected_payout_amount>" + ValidateResponseXMLHM.get("destination:expected_payout_amount") + "</expected_payout_amount>\r\n" +
                    "                     <currency_iso_code>" + map.get("DestinationCurrencyCode") + "</currency_iso_code>\r\n" +
                    "                     <country_iso_code>" + map.get("DestinationCountry") + "</country_iso_code>\r\n" +
                    "                  </destination>\r\n" +
                    "                  <promotion>\r\n" +
                    "                     <discount>" + ValidateResponseXMLHM.get("promotion:discount") + "</discount>\r\n" +
                    "                  </promotion>\r\n" +
                    "                  <taxes>\r\n" +
                    "                    <municipal_tax>" + ValidateResponseXMLHM.get("municipal_tax") + "</municipal_tax>\r\n" +
                    "                     <state_tax>" + ValidateResponseXMLHM.get("state_tax") + "</state_tax>\r\n" +
                    "                     <county_tax>" + ValidateResponseXMLHM.get("county_tax") + "</county_tax>\r\n" +
                    "                  </taxes>\r\n" +
                    "                  <fees>\r\n" +
                    "                     <delivery_charges>" + ValidateResponseXMLHM.get("delivery_charges") + "</delivery_charges>\r\n" +
                    "                     <charges>" + ValidateResponseXMLHM.get("charges") + "</charges>\r\n" +
                    "                  </fees>\r\n" +
                    "                  <exchange_rate>" + FeeResponseXMLHM.get("exchange_rate") + "</exchange_rate>\r\n" +
                    "\r\n" +
                    "                  <min_amount>" + FeeResponseXMLHM.get("min_amount") + "</min_amount>\r\n" +
                    "                  <max_amount>" + FeeResponseXMLHM.get("max_amount") + "</max_amount>\r\n" +
                    "\r\n" +
                    "                  <payment_type>" + map.get("Payment_type") + "</payment_type>\r\n" +
                    "               <payment_digest>" + FeeResponseXMLHM.get("payment_digest") + "</payment_digest>\r\n" +
                    "              <credit_debit_card_details>\r\n" +
                    "                     <card_number>" + map.get("Credit_debit_card_number") + "</card_number>\r\n" +
                    "                     <cvvii_code>" + map.get("Cvvii_code") + "</cvvii_code>\r\n" +
                    "                     <expiration_date>" + map.get("Expiration_date") + "</expiration_date>\r\n" +
                    "                     <authorization_code/>\r\n" +
                    "                     <card_type></card_type>\r\n" +
                    "                     <card_indicator></card_indicator>\r\n" +
                    "                  </credit_debit_card_details>\r\n" +
                    "                  <fix_on_send>N</fix_on_send>\r\n" +
                    "               </payment_details>\r\n" +
                    "\r\n" +
                    "            </service_option>\r\n" +
                    "         </service_options>\r\n" +
                    "         <mtcn>" + ValidateResponseXMLHM.get("mtcn") + "</mtcn>\r\n" +
                    "         <new_mtcn>" + ValidateResponseXMLHM.get("new_mtcn") + "</new_mtcn>\r\n" +
                    "\r\n" +
                    "         <foreign_remote_system>\r\n" +
                    "            <identifier>" + map.get("ForeignSystemIdentifier") + "</identifier>\r\n" +
                    "            <reference_no>" + map.get("ForeignSystemReferenceNo") + "</reference_no>\r\n" +
                    "            <counter_id>" + map.get("ForeignSystemCounterID") + "</counter_id>\r\n" +
                    "            <operator_id>" + map.get("ForeignSystemOperatorID") + "</operator_id>\r\n" +
                    "         </foreign_remote_system>\r\n" +
                    "         <saturn_fields>\r\n" +
                    "            <saturn_exception_flag>" + ValidateResponseXMLHM.get("saturn_exception_flag") + "</saturn_exception_flag>\r\n" +
                    "            <saturn_rate_code>" + ValidateResponseXMLHM.get("saturn_rate_code") + "</saturn_rate_code>\r\n" +
                    "            <saturn_rate_date>" + ValidateResponseXMLHM.get("saturn_rate_date") + "</saturn_rate_date>\r\n" +
                    "            <saturn_create_date_account>" + ValidateResponseXMLHM.get("saturn_create_date_account") + "</saturn_create_date_account>\r\n" +
                    "            <saturn_create_date_customer>" + ValidateResponseXMLHM.get("saturn_create_date_customer") + "</saturn_create_date_customer>\r\n" +
                    "            <saturn_channel_product>" + ValidateResponseXMLHM.get("saturn_channel_product") + "</saturn_channel_product>\r\n" +
                    "            <saturn_score>" + ValidateResponseXMLHM.get("saturn_score") + "</saturn_score>\r\n" +
                    "            <saturn_s_packet_flag>" + ValidateResponseXMLHM.get("saturn_s_packet_flag") + "</saturn_s_packet_flag>\r\n" +
                    "            <saturn_pre_auth_timestamp>" + ValidateResponseXMLHM.get("saturn_pre_auth_timestamp") + "</saturn_pre_auth_timestamp>\r\n" +
                    "            <sender_main_phone_number>" + ValidateResponseXMLHM.get("sender_main_phone_number") + "</sender_main_phone_number>\r\n" +
                    "\r\n" +
                    "            <saturn_blaze_response_code>000083</saturn_blaze_response_code>\r\n" +
                    "            <saturn_resp_post_auth>000083</saturn_resp_post_auth>\r\n" +
                    "         </saturn_fields>\r\n" +
                    "          <cub>\r\n" +
                    "            <web_cub>\r\n" +
                    "               <cub_source>" + map.get("Cub_source") + "</cub_source>\r\n" +
                    "               <fid_acculynk_language>en</fid_acculynk_language>\r\n" +
                    "               <card_type></card_type>\r\n" +
                    "               <cub_exp_date></cub_exp_date>\r\n" +
                    "               <principal_amount>1000</principal_amount>\r\n" +
                    "               <base_charge>490</base_charge>\r\n" +
                    "               <total_amount>1100</total_amount>\r\n" +
                    "               <environment>B</environment>\r\n" +
                    "               <rwc_flag>" + map.get("RWC_flag") + "</rwc_flag>\r\n" +
                    "<!--               <send_delay_hours></send_delay_hours>\r\n" +
                    "-->\r\n" +
                    "	                <di_thirdparty_identifier/>" +
                    "		            <di_txn_channel>" + map.get("Di_txn_channel") + "</di_txn_channel>\r\n" +
                    "	                <di_partner_name>" + map.get("Di_partner_name") + "</di_partner_name>\r\n" +
                    "	                <additional_data/>" +
                    "<!--               <txn_identifier>ABMT</txn_identifier>\r\n" +
                    "-->\r\n" +
                    "<!--               <merchant_id>Retail3456</merchant_id>\r\n" +
                    "-->\r\n" +
                    "            </web_cub>\r\n" +
                    "         </cub>\r\n" +
                    "\r\n" +
                    "         <store_validate_flag>" + map.get("Store_validate_flag") + "</store_validate_flag>\r\n" +
                    "         <auto_aprv_id>" + map.get("Auto_aprv_id") + "</auto_aprv_id>\r\n" +
                    "         <!--<host_based_taxes>Y</host_based_taxes>-->\r\n" +
                    "      </ns2:send-money-digital-store-request>\r\n" +
                    "   </soap:Body>\r\n" +
                    "</soap:Envelope>\r\n";
            //System.out.println("Store Request "+xmlvalue);
            InputStream xmlInput = new ByteArrayInputStream(xmlvalue.getBytes(StandardCharsets.UTF_8));
            post.setEntity(new InputStreamEntity(new DataInputStream(xmlInput)));
            post.setHeader("Content-Type", "text/xml;charset=UTF-8");
            post.setHeader("Accept-Encoding", "gzip,deflate");
            post.setHeader("SOAPAction", "FeeSurveyAction");
            post.setHeader("Connection", "Keep-Alive");
            post.setHeader("Credential", "World!!");
            post.setHeader("User_id", "Hello");
            post.setHeader("Auth_token", "cc4d43df1f5ef0bb0dc6fa857a15ce8348a2bc5f0f0b7a206e040bfe1a0867c2bd76dd3b50de9a177bbaa56c391d6189b8d2fc858c742b1b7279f8fe35ece986");
            HttpResponse response = client.execute(post);
            int ResponseCode = response.getStatusLine().getStatusCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = "";
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            Logger.info("Store Response " + sb);
            String abc = sb.toString();
            if (ResponseCode == 200) {
                Logger.info("*********** Start Store Request ************");
                Logger.info("Successfully hit store request with status code :" + ResponseCode);
                StoreResponseHMFiedlMapping(abc);
            } else {
                Logger.info("Failed to hit store request due to status code :" + ResponseCode);
                StoreResponseXMLHM.put("Error Message", GetNodeValue(abc, "error"));
                Status = false;
            }
        } catch (Exception e) {
            Logger.info("Unable to get response from Store request due to : " + e.getMessage());
            Status = false;
        }
        return Status;

    }

    public static HashMap<String, String> FeeResponseHMFiedlMapping(String sDocumentxml) throws Exception {
        try {
            FeeResponseXMLHM.put("wu_productname", GetChildNodeValue(sDocumentxml, "wu_product", deliveryServicePosition, "name"));
            FeeResponseXMLHM.put("wu_productcode", GetChildNodeValue(sDocumentxml, "wu_product", deliveryServicePosition, "code"));
            FeeResponseXMLHM.put("wu_productrouting_code", GetChildNodeValue(sDocumentxml, "wu_product", deliveryServicePosition, "routing_code"));
            FeeResponseXMLHM.put("origination:principal_amount", GetChildNodeValue(sDocumentxml, "origination", deliveryServicePosition, "principal_amount"));
            FeeResponseXMLHM.put("origination:gross_amount", GetChildNodeValue(sDocumentxml, "origination", deliveryServicePosition, "gross_amount"));
            FeeResponseXMLHM.put("destination:expected_payout_amount", GetChildNodeValue(sDocumentxml, "destination", deliveryServicePosition, "expected_payout_amount"));
            FeeResponseXMLHM.put("destination:currency_iso_code", GetChildNodeValue(sDocumentxml, "destination", deliveryServicePosition, "currency_iso_code"));
            FeeResponseXMLHM.put("destination:country_iso_code", GetChildNodeValue(sDocumentxml, "destination", deliveryServicePosition, "country_iso_code"));
            FeeResponseXMLHM.put("promotion:code", GetChildNodeValue(sDocumentxml, "promotion", deliveryServicePosition, "code"));
            FeeResponseXMLHM.put("promotion:discount", GetChildNodeValue(sDocumentxml, "promotion", deliveryServicePosition, "discount"));
            FeeResponseXMLHM.put("promotion:message", GetChildNodeValue(sDocumentxml, "promotion", deliveryServicePosition, "message"));
            FeeResponseXMLHM.put("taxes:tax_amount", GetChildNodeValue(sDocumentxml, "taxes", deliveryServicePosition, "tax_amount"));
            FeeResponseXMLHM.put("fees:charges", GetChildNodeValue(sDocumentxml, "fees", deliveryServicePosition, "charges"));
            FeeResponseXMLHM.put("exchange_rate", GetChildNodeValue(sDocumentxml, "payment_details", deliveryServicePosition, "exchange_rate"));
            FeeResponseXMLHM.put("min_amount", GetChildNodeValue(sDocumentxml, "payment_details", deliveryServicePosition, "min_amount"));
            FeeResponseXMLHM.put("max_amount", GetChildNodeValue(sDocumentxml, "payment_details", deliveryServicePosition, "max_amount"));
            FeeResponseXMLHM.put("payment_digest", GetChildNodeValue(sDocumentxml, "payment_details", deliveryServicePosition, "payment_digest"));
        } catch (Exception e) {
            Logger.info("Failed to read input from Fee enquiry :" + e.getMessage());
        }
        return FeeResponseXMLHM;

    }

    public static HashMap<String, String> ValidateResponseHMFiedlMapping(String sDocumentxml) throws Exception {
        try {
            ValidateResponseXMLHM.put("addl_service_charges", GetNodeValue(sDocumentxml, "addl_service_charges"));
            ValidateResponseXMLHM.put("terminal_id", GetChildNodeValue(sDocumentxml, "terminal", 0, "id"));
            ValidateResponseXMLHM.put("sender_account_nbr", GetChildNodeValue(sDocumentxml, "wu_product", 0, "routing_code"));
            ValidateResponseXMLHM.put("municipal_tax", GetNodeValue(sDocumentxml, "municipal_tax"));
            ValidateResponseXMLHM.put("state_tax", GetNodeValue(sDocumentxml, "state_tax"));
            ValidateResponseXMLHM.put("county_tax", GetNodeValue(sDocumentxml, "county_tax"));
            ValidateResponseXMLHM.put("delivery_charges", GetNodeValue(sDocumentxml, "delivery_charges"));
            ValidateResponseXMLHM.put("charges", GetNodeValue(sDocumentxml, "charges"));
            ValidateResponseXMLHM.put("total_undiscounted_charges", GetNodeValue(sDocumentxml, "total_undiscounted_charges"));
            ValidateResponseXMLHM.put("total_discount", GetNodeValue(sDocumentxml, "total_discount"));
            ValidateResponseXMLHM.put("total_discounted_charges", GetNodeValue(sDocumentxml, "total_discounted_charges"));
            ValidateResponseXMLHM.put("fix_on_send", GetNodeValue(sDocumentxml, "fix_on_send"));
            ValidateResponseXMLHM.put("mtcn", GetNodeValue(sDocumentxml, "mtcn"));
            ValidateResponseXMLHM.put("new_mtcn", GetNodeValue(sDocumentxml, "new_mtcn"));
            ValidateResponseXMLHM.put("pds_required_flag", GetNodeValue(sDocumentxml, "pds_required_flag"));
            ValidateResponseXMLHM.put("df_transaction_flag", GetNodeValue(sDocumentxml, "df_transaction_flag"));
            ValidateResponseXMLHM.put("partner_marketing_languages_locale", GetChildNodeValue(sDocumentxml, "partner_marketing_languages", 0, "locale"));
            ValidateResponseXMLHM.put("amount_to_receiver", GetNodeValue(sDocumentxml, "amount_to_receiver"));
            ValidateResponseXMLHM.put("delay_hours", GetNodeValue(sDocumentxml, "delay_hours"));
            ValidateResponseXMLHM.put("delivery_service_name", GetNodeValue(sDocumentxml, "delivery_service_name"));
            ValidateResponseXMLHM.put("saturn_exception_flag", GetNodeValue(sDocumentxml, "saturn_exception_flag"));
            ValidateResponseXMLHM.put("saturn_rate_code", GetNodeValue(sDocumentxml, "saturn_rate_code"));
            ValidateResponseXMLHM.put("saturn_rate_date", GetNodeValue(sDocumentxml, "saturn_rate_date"));
            ValidateResponseXMLHM.put("saturn_create_date_account", GetNodeValue(sDocumentxml, "saturn_create_date_account"));
            ValidateResponseXMLHM.put("saturn_create_date_customer", GetNodeValue(sDocumentxml, "saturn_create_date_customer"));
            ValidateResponseXMLHM.put("saturn_channel_product", GetNodeValue(sDocumentxml, "saturn_channel_product"));
            ValidateResponseXMLHM.put("saturn_score", GetNodeValue(sDocumentxml, "saturn_score"));
            ValidateResponseXMLHM.put("saturn_s_packet_flag", GetNodeValue(sDocumentxml, "saturn_s_packet_flag"));
            ValidateResponseXMLHM.put("saturn_pre_auth_timestamp", GetNodeValue(sDocumentxml, "saturn_pre_auth_timestamp"));
            ValidateResponseXMLHM.put("sender_main_phone_number", GetNodeValue(sDocumentxml, "sender_main_phone_number"));
            ValidateResponseXMLHM.put("saturn_blaze_response_code", GetNodeValue(sDocumentxml, "saturn_blaze_response_code"));
            ValidateResponseXMLHM.put("cub_source", GetNodeValue(sDocumentxml, "cub_source"));
            ValidateResponseXMLHM.put("di_txn_channel", GetNodeValue(sDocumentxml, "di_txn_channel"));
            ValidateResponseXMLHM.put("di_partner_name", GetNodeValue(sDocumentxml, "di_partner_name"));
            ValidateResponseXMLHM.put("origination:gross_amount", GetNodeValue(sDocumentxml, "gross_amount"));
            ValidateResponseXMLHM.put("destination:expected_payout_amount", GetNodeValue(sDocumentxml, "expected_payout_amount"));
            ValidateResponseXMLHM.put("promotion:discount", GetNodeValue(sDocumentxml, "discount"));
            ValidateResponseXMLHM.put("promotion:discount", GetNodeValue(sDocumentxml, "discount"));
        } catch (Exception e) {
            Logger.info("Failed to read input from validate request :" + e.getMessage());
        }

        return ValidateResponseXMLHM;

    }

    public static HashMap<String, String> StoreResponseHMFiedlMapping(String sDocumentxml) throws Exception {
        try {
            StoreResponseXMLHM.put("Error Message", GetNodeValue(sDocumentxml, "error"));

        } catch (Exception e) {
            Logger.info("Failed to read input from Store response :" + e.getMessage());
        }
        return StoreResponseXMLHM;

    }


    /* --------------------------------------------------------
     * ---------------  AIS Case creation  ---------------------
     * ---------------------------------------------------------*/

    public String createAISRetailMTCNUsingGWforGSISenderSide(String entityFileName,int entityNo, int totalNoOfEntities) throws ClassNotFoundException, InterruptedException, SQLException, Exception {
        String mtcn16 = "";
        HashMap<String, Object> map=new HashMap<String,Object>();
        switch(entityFileName){
            case "WU_GSI_SingleEntity":
                map=getDataForMTCN_WURetail_GSIsingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "L1_WU_Sanctions_SingleEntity":
                map=getDataForMTCN_WURetail_SanctionssingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "L2_WU_Sanctions_SingleEntity":
                map=getDataForMTCN_WURetail_L2_SanctionssingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "L3_WU_Sanctions_SingleEntity":
                map=getDataForMTCN_WURetail_L3_SanctionssingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "DualHitCases":
                map=getDataForMTCN_WURetail_L1_DualHitsingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "L2_DualHitCases":
                map=getDataForMTCN_WURetail_L2_DualHitsingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "L3_DualHitCases":
                map=getDataForMTCN_WURetail_L3_DualHitsingleEntity(entityFileName, entityNo,totalNoOfEntities);
                break;
            case "Deferred_WU_Intr_Intr":
                map=getDataForMTCN_WUDeferredSenderPotentialReceiver(entityFileName, entityNo,totalNoOfEntities);
                break;

        }
        mtcn16 = AISTrnscountSendSide(map);
        return mtcn16;
    }

    public HashMap<String, Object> getDataForMTCN_WURetail_GSIsingleEntity(String fileName, int entityNo,int totalNoOfEntities) {
        int n;
        String rcvrFName = getRandomRcvrFName();
        String rcvrLName = getRandomRcvrLName();
        String filePath = CommonFunctions.getFullPath_GSI_INTR("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth_" + n));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date_" + n));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue_" + n));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue_" + n));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type_" + n));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry_" + n));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name_" + n));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality_" + n));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode_" + n));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_" + n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_" + n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName_" + n));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber_" + n));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum_" + n));
        map.put("Email", CommonFunctions.readFile(filePath, "Email_" + n));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity_" + n));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2_" + n));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState_" + n));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip_" + n));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", rcvrFName);
        map.put("ReceiverLastName", rcvrLName);
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number_" + n));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date_" + n));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth_" + n));
        return map;
    }



    public HashMap<String, Object> getDataForMTCN_WURetail_GSIDeferredEntity(String fileName, int entityNo,int totalNoOfEntities) {
        int n;
        String filePath = CommonFunctions.getFullPath_GSI_Deferred("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth_" + n));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date_" + n));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue_" + n));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue_" + n));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type_" + n));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry_" + n));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name_" + n));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality_" + n));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode_" + n));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_" + n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_" + n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName_" + n));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber_" + n));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum_" + n));
        map.put("Email", CommonFunctions.readFile(filePath, "Email_" + n));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity_" + n));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2_" + n));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState_" + n));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip_" + n));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number_" + n));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date_" + n));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth_" + n));
        return map;
    }

    public String AISTrnscountSendSide(HashMap<String, Object> map) throws ClassNotFoundException, InterruptedException, IOException, SQLException {
        String mtcn = "", mtcn16 = "";
        for (int z = 0; z < 1; z++) {
            try {
                deliveryServicePosition = Integer.parseInt(map.get("ReqDeliveryServicePositionforAgent").toString());
                readAndAssignTestCasePrerequisites(map);
                for (int i = 1; i <= 1; i++) {
//                    GenerateTestDataForDynamicFieldsAIS(map,i,entityType);
                    GenerateTestDataForDynamicFields(map, entityType);
                    boolean feeInquiryStatus = AISFeeEnquiry(map);
                    Logger.info("AIS FeeInquiry Status for Cycle" + i + ": " + feeInquiryStatus);
                    if (feeInquiryStatus == false && AISFeeResponseXMLHM.get("Error Message").contains("C7000")) {
                        Logger.info("ErrorMessage: " + AISFeeResponseXMLHM.get("Error Message"));

                        for (int j = 0; j <= 2; j++) {
                            Logger.info("Retrying the request..");
                            feeInquiryStatus = AISFeeEnquiry(map);
                            Logger.info("AIS FeeInquiry Status for Cycle" + i + ": " + feeInquiryStatus);
                            if (feeInquiryStatus)
                                break;
                            else if (!feeInquiryStatus && AISFeeResponseXMLHM.get("Error Message").contains("C7000")) {
                                Logger.info("ErrorMessage: " + AISFeeResponseXMLHM.get("Error Message"));
                            } else {
                                errorCodeMessage = AISFeeResponseXMLHM.get("Error Message");
                                break;
                            }
                        }
                        if (feeInquiryStatus == false && AISFeeResponseXMLHM.get("Error Message").contains("C7000")) {
                            errorCodeMessage = AISFeeResponseXMLHM.get("Error Message");
                            break;
                        }
                    } else if (feeInquiryStatus == false) {
                        errorCodeMessage = AISFeeResponseXMLHM.get("Error Message");
                        break;
                    }
                    if (feeInquiryStatus) {
                        validateRequestStatus = AISValidateRequest(map);
                        Logger.info("AIS Validate Request Status for Cycle" + i + ": " + validateRequestStatus);
                        mtcn = AISValidateResponseXMLHM.get("mtcn");
                        if (validateRequestStatus == false) {
                            errorCodeMessage = AISValidateResponseXMLHM.get("Error Message");
                        }
                        if (validateRequestStatus == false && errorCodeMessage.contains("C7000")) {
                            Logger.info("ErrorMessage: " + errorCodeMessage);
                            for (int j = 0; j <= 2; j++) {
                                Logger.info("Retrying the request..");
                                validateRequestStatus = AISValidateRequest(map);
                                Logger.info("AIS Validate Request Status for Cycle" + i + ": " + validateRequestStatus);
                                if (validateRequestStatus)
                                    break;
                                else if (!validateRequestStatus && AISValidateResponseXMLHM.get("Error Message").contains("C7000")) {
                                    Logger.info("ErrorMessage: " + AISValidateResponseXMLHM.get("Error Message"));
                                } else {
                                    errorCodeMessage = AISValidateResponseXMLHM.get("Error Message");
                                    break;
                                }
                            }
                            if (validateRequestStatus == false && AISValidateResponseXMLHM.get("Error Message").contains("C7000")) {
                                errorCodeMessage = AISValidateResponseXMLHM.get("Error Message");
                                break;
                            }
                        } else if (!validateRequestStatus && i != iterationCount) {
                            String otherRuleStatus = otherRuleHitHandling(errorCodeMessage, "AIS Validate Request", "AIS Validate request should be successful", "AIS Validate request Failed with ", mtcn, i);
                            if (otherRuleStatus.equals("ExitLoop")) {
                                break;
                            } else if (otherRuleStatus.equals("Iterate")) {
                                iterationCount++;
                            }
                        } else if (i == iterationCount && !validateRequestStatus && map.containsKey("Expected Result") && errorCodeMessage.equalsIgnoreCase(map.get("Expected Result").toString())) {
                            Logger.info("Message: " + errorCodeMessage);

                        } else if (i == iterationCount && !validateRequestStatus && map.containsKey("Expected Result") && !(errorCodeMessage.equalsIgnoreCase(map.get("Expected Result").toString()))) {
                            String otherRuleStatus = otherRuleHitHandling(errorCodeMessage, "AIS Validate Request", "AIS Validate request should be Failed", "AIS Validate request Failed with ", mtcn, i);
                            if (otherRuleStatus.equals("ExitLoop")) {
                                break;
                            } else if (otherRuleStatus.equals("Iterate")) {
                                iterationCount++;
                            }
                        } else if (i == iterationCount && !validateRequestStatus && map.containsKey("Expected Result") && map.get("Expected Result").toString().equalsIgnoreCase("")) {
                            String otherRuleStatus = otherRuleHitHandling(errorCodeMessage, "AIS Validate Request negative scenario", "AIS Validate request should be successful", "AIS Validate request Failed with ", mtcn, i);
                            if (otherRuleStatus.equals("ExitLoop")) {
                            } else if (otherRuleStatus.equals("Iterate")) {
                                iterationCount++;
                            }
                        }
                        if (validateRequestStatus) {
                            //Store Request
                            storeRequestStatus = AISStoreRequest(map);
                            if(storeRequestStatus){
                                mtcn16 = AISStoreResponseXMLHM.get("new_mtcn");
                            }
                            Logger.info("AIS Store Request Status for Cycle" + i + ": " + storeRequestStatus);
                            if (storeRequestStatus == false)
                                errorCodeMessage = AISStoreResponseXMLHM.get("Error Message");
                            if (storeRequestStatus == false && (errorCodeMessage.contains("C7000") || errorCodeMessage.contains("T0411"))) {
                                Logger.info("ErrorMessage: " + errorCodeMessage);
                                for (int j = 0; j <= 2; j++) {
                                    Logger.info("Retrying the request..");
                                    storeRequestStatus = AISStoreRequest(map);
                                    Logger.info("AIS Store Request Status for Cycle" + i + ": " + storeRequestStatus);
                                    if (storeRequestStatus)
                                        break;
                                    else if (!storeRequestStatus && AISStoreResponseXMLHM.get("Error Message").contains("C7000")) {
                                        Logger.info("ErrorMessage: " + AISStoreResponseXMLHM.get("Error Message"));
                                    } else {
                                        errorCodeMessage = AISStoreResponseXMLHM.get("Error Message");
                                        break;
                                    }
                                }
                                if (storeRequestStatus == false && AISStoreResponseXMLHM.get("Error Message").contains("C7000")) {
                                    errorCodeMessage = AISStoreResponseXMLHM.get("Error Message");
                                    break;
                                }
                            } else if (!storeRequestStatus && i != iterationCount) {
                                String otherRuleStatus = otherRuleHitHandling(errorCodeMessage, "AIS Store Request", "AIS Store request should be successful", "AIS Store request Failed with ", mtcn, i);
                                if (otherRuleStatus.equals("ExitLoop")) {
                                    break;
                                } else if (otherRuleStatus.equals("Iterate")) {
                                    iterationCount++;
                                }
                            }
                            if (i == iterationCount && !storeRequestStatus && map.containsKey("Expected Result") && !(map.get("Expected Result").toString().equalsIgnoreCase("")) && errorCodeMessage.equalsIgnoreCase(map.get("Expected Result").toString())) {
                                Logger.info("Message: " + errorCodeMessage);
                            } else if (i == iterationCount && !storeRequestStatus && map.containsKey("Expected Result") && !(map.get("Expected Result").toString().equalsIgnoreCase("")) && !(errorCodeMessage.equalsIgnoreCase(map.get("Expected Result").toString()))) {
                                String otherRuleStatus = otherRuleHitHandling(errorCodeMessage, "AIS Store Request", "AIS Store request should be failed", "AIS Store request Failed with ", mtcn, i);
                                if (otherRuleStatus.equals("ExitLoop")) {
                                } else if (otherRuleStatus.equals("Iterate")) {
                                    iterationCount++;
                                }
                            }

                        }
                    }
                }

            } catch (Exception e) {
                Logger.info("Exception: " + e.getMessage());
            }
        }
        return mtcn16;
    }

    public static boolean AISFeeEnquiry(HashMap<String, Object> map) {
        boolean Status = true;
        try {
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(gatewayURL);
            String xmlvalue = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xrsi=\"http://www.westernunion.com/schema/xrsi\">\r\n" +
                    "   <soapenv:Header/>\r\n" +
                    "   <soapenv:Body>\r\n" +
                    "      <xrsi:feesurvey-request>\r\n" +
                    "         <device>\r\n" +
                    "            <id>" + map.get("Device_id") + "</id>\r\n" +
                    "            <type>" + map.get("Device_type") + "</type>\r\n" +
                    "         </device>\r\n" +
                    "         <channel>\r\n" +
                    "            <type>" + map.get("Channel_type") + "</type>\r\n" +
                    "            <name>" + map.get("Channel_name") + "</name>\r\n" +
                    "            <version>" + map.get("Channel_version") + "</version>\r\n" +
                    "         </channel>\r\n" +
                    "         <financials>\r\n" +
                    "            <originators_principal_amount>" + principalAmount + "</originators_principal_amount>\r\n" +
                    "         </financials>\r\n" +
                    "         <payment_details>\r\n" +
                    "            <expected_payout_location>\r\n" +
                    "               <state_code/>\r\n" +
                    "               <city/>\r\n" +
                    "            </expected_payout_location>\r\n" +
                    "            <recording_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("OriginatingCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </recording_country_currency>\r\n" +
                    "            <destination_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("DestinationCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("DestinationCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </destination_country_currency>\r\n" +
                    "            <originating_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("OriginatingCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </originating_country_currency>\r\n" +
                    "            <transaction_type>" + map.get("Transaction_type") + "</transaction_type>\r\n" +
                    "            <payment_type>Cash</payment_type>\r\n" +
                    "            <duplicate_detection_flag>N</duplicate_detection_flag>\r\n" +
                    "            <stage_pay_fields>\r\n" +
                    "               <snp_indicator>O</snp_indicator>\r\n" +
                    "            </stage_pay_fields>\r\n" +
                    "         </payment_details>\r\n" +
                    "         <delivery_services>\r\n" +
                    "            <code></code>\r\n" +
                    "         </delivery_services>\r\n" +
                    "         <foreign_remote_system>\r\n" +
                    "            <identifier>" + map.get("ForeignSystemIdentifier") + "</identifier>\r\n" +
                    "            <reference_no>" + map.get("ForeignSystemReferenceNo") + "</reference_no>\r\n" +
                    "            <counter_id>" + map.get("ForeignSystemCounterID") + "</counter_id>\r\n" +
                    "         </foreign_remote_system>\r\n" +
                    "      </xrsi:feesurvey-request>\r\n" +
                    "   </soapenv:Body>\r\n" +
                    "</soapenv:Envelope>";
            System.out.println("Fee request AIS:" + xmlvalue);
            InputStream xmlInput = new ByteArrayInputStream(xmlvalue.getBytes(StandardCharsets.UTF_8));
            post.setEntity(new InputStreamEntity(new DataInputStream(xmlInput)));
            post.setHeader("Content-Type", "text/xml;charset=UTF-8");
            post.setHeader("Accept-Encoding", "gzip,deflate");
            post.setHeader("SOAPAction", "FeeSurveyAction");
            post.setHeader("Connection", "Keep-Alive");
            HttpResponse response = client.execute(post);
            int ResponseCode = response.getStatusLine().getStatusCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = "";
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            Logger.info(" AIS Fee Enquiry Response " + sb);
            String abc = sb.toString();
            if (ResponseCode == 200) {
                Logger.info("*********** Start AIS FeeEnquiry ************");
                Logger.info("Successfully hit AIS Fee request with status code :" + ResponseCode);
                AISFeeResponseHMFiedlMapping(abc);
            } else {
                Logger.info("Failed to hit AIS Fee request due to status code :" + ResponseCode);
                AISFeeResponseXMLHM.put("Error Message", GetNodeValue(abc, "error"));
                Status = false;
            }
        } catch (Exception e) {
            Logger.info("Unable to get response from AIS Fee Enquiry due to : " + e.getMessage());
            Status = false;
        }
        return Status;

    }

    public boolean AISValidateRequest(HashMap<String, Object> map) {
        boolean Status = true;
        try {
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(gatewayURL);
            String xmlvalue = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xrsi=\"http://www.westernunion.com/schema/xrsi\">\r\n" +
                    "   <soapenv:Header/>\r\n" +
                    "   <soapenv:Body>\r\n" +
                    "      <xrsi:send-money-validation-request>\r\n" +
                    "         <device>\r\n" +
                    "            <id>" + map.get("Device_id") + "</id>\r\n" +
                    "            <type>" + map.get("Device_type") + "</type>\r\n" +
                    "         </device>\r\n" +
                    "         <channel>\r\n" +
                    "            <type>" + map.get("Channel_type") + "</type>\r\n" +
                    "            <name>" + map.get("Channel_name") + "</name>\r\n" +
                    "            <version>" + map.get("Channel_version") + "</version>\r\n" +
                    "         </channel>\r\n" +
                    "         <terminal>\r\n" +
                    "            <id></id>\r\n" +
                    "         </terminal>\r\n" +
                    "         <swb_fla_info>\r\n" +
                    "           <swb_operator_id>asfsd</swb_operator_id>\r\n" +
                    "           <fla_name name_type=\"D\">\r\n" +
                    "             <name_raw/>\r\n" +
                    "             <name_prefix>Ms.</name_prefix>\r\n" +
                    "             <first_name>Jose</first_name>\r\n" +
                    "             <middle_name/>\r\n" +
                    "             <last_name>Olloqui</last_name>\r\n" +
                    "             <name_suffix>Jr.</name_suffix>\r\n" +
                    "             <secondary_given_name/>\r\n" +
                    "             <secondary_paternal_name/>\r\n" +
                    "             <secondary_maternal_name/>\r\n" +
                    "           </fla_name>\r\n" +
                    "           <password/>\r\n" +
                    "           <read_privacynotice_flag>Y</read_privacynotice_flag>\r\n" +
                    "           <fla_certification_flag>Y</fla_certification_flag>\r\n" +
                    "         </swb_fla_info>\r\n" +
                    "         <sender>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + sndrFName + "</first_name>\r\n" +
                    "               <last_name>" + sndrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + sndrStreetName + "</addr_line1>\r\n" +
                    "               <addr_line2>" + sndrStreetName1 + "</addr_line2>\r\n" +
                    "               <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "               <state>" + map.get("SenderState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("SenderCountry") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "                  <country_name>" + map.get("Sender_country_name") + "</country_name>\r\n" +
                    "               </country_code>\r\n" +
//                    "               <local_area>"+localArea+" road</local_area>\r\n" +
                    "            </address>\r\n" +
                    "            <preferred_customer></preferred_customer>\r\n" +
                    "            <compliance_details>\r\n" +
                    "               <template_id>" + map.get("Send_template_id") + "</template_id>\r\n" +
                    "               <id_details>\r\n" +
                    "                  <id_type>" + map.get("Id_type") + "</id_type>\r\n" +
                    "                  <id_country_of_issue>" + map.get("Id_country_of_issue") + "</id_country_of_issue>\r\n" +
                    "                  <id_place_of_issue>" + map.get("Id_place_of_issue") + "</id_place_of_issue>\r\n" +
                    "                  <id_number>" + map.get("Id_number") + "</id_number>\r\n" +
                    "               </id_details>\r\n" +
                    "               <third_party_details>\r\n" +
                    "                  <flag_pay>" + map.get("Third_party_flag_pay") + "</flag_pay>\r\n" +
                    "               </third_party_details>\r\n" +
                    "               <third_id_number></third_id_number>\r\n" +
                    "               <id_issue_date>" + map.get("Id_issue_date") + "</id_issue_date>\r\n" +
                    "               <id_expiration_date>" + map.get("Id_expiration_date") + "</id_expiration_date>\r\n" +
                    "               <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "               <occupation>" + map.get("Occupation") + "</occupation>\r\n" +
                    "               <country_of_residence></country_of_residence>\r\n" +
                    "               <transaction_reason>" + map.get("Transaction_reason") + "</transaction_reason>\r\n" +
                    "               <Current_address>\r\n" +
                    "                  <addr_line1>" + sndrStreetName + "</addr_line1>\r\n" +
                    "                  <addr_line2>" + sndrStreetName1 + "</addr_line2>\r\n" +
                    "                  <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "                  <state_name>" + map.get("SenderState") + "</state_name>\r\n" +
                    "                  <state_code>" + map.get("SenderState") + "</state_code>\r\n" +
                    "                  <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "                  <country>" + map.get("Sender_country_name") + "</country>\r\n" +
                    "                  <zip>" + map.get("SenderZip") + "</zip>\r\n" +
                    "                  <email_address></email_address>\r\n" +
                    "               </Current_address>\r\n" +
                    "               <contact_phone>" + sndrPhoneNum + "</contact_phone>\r\n" +
                    "               <Country_of_Birth>" + map.get("Country_of_Birth") + "</Country_of_Birth>\r\n" +
                    "               <nationality>" + map.get("Nationality") + "</nationality>\r\n" +
                    "               <Gender>F</Gender>\r\n" +
                    "               <Is_a_resident>Y</Is_a_resident>\r\n" +
                    "               <Source_of_Funds>" + map.get("Source_of_Funds") + "</Source_of_Funds>\r\n" +
                    "               <Name_of_Employer_Business>" + map.get("Name_of_Employer_Business") + "</Name_of_Employer_Business>\r\n" +
                    "               <Nature_of_Work_Business>" + map.get("Nature_of_Work_Business") + "</Nature_of_Work_Business>\r\n" +
                    "               <Is_txn_Individual_or_Organization>I</Is_txn_Individual_or_Organization>\r\n" +
                    "               <Relationship_to_Receiver_Sender>" + map.get("Relationship_to_Receiver_Sender") + "</Relationship_to_Receiver_Sender>\r\n" +
                    "               <Does_the_ID_have_an_expiration_date>Y</Does_the_ID_have_an_expiration_date>\r\n" +
                    "               <City_of_Birth></City_of_Birth>\r\n" +
                    "               <Personal_Identification_Number>85962314071</Personal_Identification_Number>\r\n" +
                    "               <I_act_on_My_Behalf>" + map.get("I_act_on_My_Behalf") + "</I_act_on_My_Behalf>\r\n" +
                    "               <ack_flag>X</ack_flag>\r\n" +
//                    "               <Beneficiary_Nationality>Jordan</Beneficiary_Nationality>\r\n" +
                    "               <Other_Occupation/>\r\n" +
//                    "               <Was_A_Proof_Of_EU_Citizenship_Provided>Y</Was_A_Proof_Of_EU_Citizenship_Provided>\r\n" +
//                    "               <Was_A_Resident_Permit_Provided>Y</Was_A_Resident_Permit_Provided>\r\n" +
                    "               <STD_Phone_Number_Code></STD_Phone_Number_Code>\r\n" +
                    "               <Mobile_Phone_Number></Mobile_Phone_Number>\r\n" +
                    "               <Marital_Status></Marital_Status>\r\n" +
                    "               <Country_Code>" + map.get("SenderPhoneCntryCode") + "</Country_Code>\r\n" +
                    "               <Other_Purpose_of_Transaction>Saving/Investments</Other_Purpose_of_Transaction>\r\n" +
                    "               <WU_COM_Electronic_Validation>" + map.get("WU_COM_Electronic_Validation") + "</WU_COM_Electronic_Validation>\r\n" +
                    "               <second_id_issue_date/>\r\n" +
                    "               <second_id_expiration_date/>\r\n" +
                    "               <employer_address1/>\r\n" +
                    "               <is_addr_diff>N</is_addr_diff>\r\n" +
                    "               <category_code></category_code>\r\n" +
                    "               <business_phone_no/>\r\n" +
                    "               <are_you_a_PEP_relative_or_friend>" + map.get("Are_you_a_PEP_relative_or_friend") + "</are_you_a_PEP_relative_or_friend>\r\n" +
                    "               <annual_income></annual_income>\r\n" +
                    "               <employer_status>" + map.get("Employer_status") + "</employer_status>\r\n" +
                    "               <id_doc_control_number/>\r\n" +
//                    "               <temporary_address>\r\n" +
//                    "                  <addr_line1>"+sndrStreetName+"</addr_line1>\r\n" +
//                    "                  <addr_line2>"+sndrStreetName1+"</addr_line2>\r\n" +
//                    "                  <city>"+map.get("SenderCity")+"</city>\r\n" +
//                    "                  <state_name>"+map.get("SenderState")+"</state_name>\r\n" +
//                    "                  <state_code>"+map.get("SenderState")+"</state_code>\r\n" +
//                    "                  <postal_code>"+map.get("SenderZip")+"</postal_code>\r\n" +
//                    "                  <country>"+map.get("Sender_country_name")+"</country>\r\n" +
//                    "               </temporary_address>\r\n" +
                    "               <cust_relationship_flag>Y</cust_relationship_flag>\r\n" +
                    "               <prmt_proof_of_addr_doc_control_number/>\r\n" +
                    "               <purpose_of_txn_doc_control_number/>\r\n" +
                    "               <galactic_id/>\r\n" +
                    "               <multi_error_supported>N</multi_error_supported>\r\n" +
                    "               <funds_source_documented>Y</funds_source_documented>\r\n" +
                    "               <biometric_txn_ref_no></biometric_txn_ref_no>\r\n" +
                    "               <biometric_ack_status/>\r\n" +
                    "               <compliance_validation_flag></compliance_validation_flag>\r\n" +
                    "               <is_current_and_permanent_addr_same>Y</is_current_and_permanent_addr_same>\r\n" +
                    "               <employer_email_address></employer_email_address>\r\n" +
                    "               <business_phone_country_code></business_phone_country_code>\r\n" +
                    "               <employment_position_level/>\r\n" +
                    "               <PEP_Category/>\r\n" +
                    "               <Second_Nationality/>\r\n" +
                    "               <Does_Consumer_Have_Second_Nationality>N</Does_Consumer_Have_Second_Nationality>\r\n" +
                    "            </compliance_details>\r\n" +
                    "            <email>" + sndrMail + "</email>\r\n" +
                    "            <phone_country_code>" + map.get("SenderPhoneCntryCode") + "</phone_country_code>\r\n" +
                    "            <contact_phone>" + sndrPhoneNum + "</contact_phone>\r\n" +
                    "            <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "            <mobile_phone>\r\n" +
                    "               <phone_number>\r\n" +
                    "                  <country_code>" + map.get("SenderPhoneCntryCode") + "</country_code>\r\n" +
                    "                  <national_number>" + sndrPhoneNum + "</national_number>\r\n" +
                    "               </phone_number>\r\n" +
                    "            </mobile_phone>\r\n" +
                    "            <customer_resident_of_agentcountry></customer_resident_of_agentcountry>\r\n" +
                    "            <fraud_warning_consent>Y</fraud_warning_consent>\r\n" +
                    "            <bank_details>\r\n" +
                    "               <name/>\r\n" +
                    "               <account_number/>\r\n" +
                    "               <routing_number/>\r\n" +
                    "            </bank_details>\r\n" +
                    "            <sms_notification_flag>Y</sms_notification_flag>\r\n" +
                    "            <mothers_maiden_name>MOM</mothers_maiden_name>\r\n" +
                    "         </sender>\r\n" +
                    "         <receiver>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + rcvrFName + "</first_name>\r\n" +
                    "               <last_name>" + rcvrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + rcvrStreetName + "</addr_line1>\r\n" +
                    "               <city>" + map.get("ReceiverCity") + "</city>\r\n" +
                    "               <state>" + map.get("ReceiverState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("ReceiverZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("ReceiverCountryCode") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("DestinationCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "               </country_code>\r\n" +
                    "            </address>\r\n" +
                    "            <date_of_birth>" + map.get("Receiver_date_of_birth") + "</date_of_birth>\r\n" +
                    "         </receiver>\r\n" +
                    "         <payment_details>\r\n" +
                    "            <expected_payout_location>\r\n" +
                    "               <state_code>" + map.get("ReceiverState") + "</state_code>\r\n" +
                    "               <city>" + map.get("ReceiverCity") + "</city>\r\n" +
                    "            </expected_payout_location>\r\n" +
                    "            <recording_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("OriginatingCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </recording_country_currency>\r\n" +
                    "            <destination_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("DestinationCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("DestinationCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </destination_country_currency>\r\n" +
                    "            <originating_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("OriginatingCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </originating_country_currency>\r\n" +
                    "            <transaction_type>" + map.get("Transaction_type") + "</transaction_type>\r\n" +
                    "            <payment_type>" + map.get("Payment_type") + "</payment_type>\r\n" +
                    "            <fix_on_send>true</fix_on_send>\r\n" +
                    "            <pay_wo_id_indicator>N</pay_wo_id_indicator>\r\n" +
                    "            <credit_debit_card_details>\r\n" +
                    "               <card_number/>\r\n" +
                    "               <encryption_key/>\r\n" +
                    "               <track_data/>\r\n" +
                    "               <expiration_date/>\r\n" +
                    "            </credit_debit_card_details>\r\n" +
                    "            <duplicate_detection_flag></duplicate_detection_flag>\r\n" +
                    "            <stage_pay_fields>\r\n" +
                    "               <staging_buffer></staging_buffer>\r\n" +
                    "            </stage_pay_fields>\r\n" +
                    "         </payment_details>\r\n" +
                    "         <financials>\r\n" +
                    "            <originators_principal_amount>" + principalAmount + "</originators_principal_amount>\r\n" +
                    "         </financials>\r\n" +
                    "         <delivery_services>\r\n" +
                    "            <code>" + AISFeeResponseXMLHM.get("delivery_servicescode") + "</code>\r\n" +
                    "            <routing_code>" + AISFeeResponseXMLHM.get("delivery_servicesrouting_code") + "</routing_code>\r\n" +
                    "            <message>\r\n" +
                    "               <message_details context=\"0\"/>\r\n" +
                    "            </message>\r\n" +
                    "            <route_code/>\r\n" +
                    "         </delivery_services>\r\n" +
                    "         <emea_ii>\r\n" +
                    "            <key_serial_number/>\r\n" +
                    "         </emea_ii>\r\n" +
                    "         <customer_affidavit_number/>\r\n" +
                    "         <customer_affidavit/>\r\n" +
                    "         <cuba>\r\n" +
                    "            <name>\r\n" +
                    "               <given_name/>\r\n" +
                    "               <paternal_name/>\r\n" +
                    "               <maternal_name/>\r\n" +
                    "            </name>\r\n" +
                    "            <question1/>\r\n" +
                    "            <question2/>\r\n" +
                    "            <question3/>\r\n" +
                    "            <question4/>\r\n" +
                    "            <question5/>\r\n" +
                    "            <question6/>\r\n" +
                    "            <question7/>\r\n" +
                    "            <question8/>\r\n" +
                    "            <question9/>\r\n" +
                    "            <question10/>\r\n" +
                    "            <question11/>\r\n" +
                    "            <question12/>\r\n" +
                    "            <question13/>\r\n" +
                    "            <question14/>\r\n" +
                    "            <question15/>\r\n" +
                    "         </cuba>\r\n" +
                    "         <consumer_fraud_prompts>\r\n" +
                    "            <question1>N</question1>\r\n" +
                    "         </consumer_fraud_prompts>\r\n" +
                    "         <foreign_remote_system>\r\n" +
                    "            <identifier>" + map.get("ForeignSystemIdentifier") + "</identifier>\r\n" +
                    "            <reference_no>" + map.get("ForeignSystemReferenceNo") + "</reference_no>\r\n" +
                    "            <counter_id>" + map.get("ForeignSystemCounterID") + "</counter_id>\r\n" +
                    "         </foreign_remote_system>\r\n" +
                    "         <host_based_taxes>Y</host_based_taxes>\r\n" +
                    "      </xrsi:send-money-validation-request>\r\n" +
                    "   </soapenv:Body>\r\n" +
                    "</soapenv:Envelope>";
//            System.out.println("validate request AIS" + xmlvalue);
            InputStream xmlInput = new ByteArrayInputStream(xmlvalue.getBytes(StandardCharsets.UTF_8));
            post.setEntity(new InputStreamEntity(new DataInputStream(xmlInput)));
            post.setHeader("Content-Type", "text/xml;charset=UTF-8");
            post.setHeader("Accept-Encoding", "gzip,deflate");
            post.setHeader("SOAPAction", "FeeSurveyAction");
            post.setHeader("Connection", "Keep-Alive");
            HttpResponse response = client.execute(post);
            int ResponseCode = response.getStatusLine().getStatusCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = "";
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            Logger.info("Response after AIS validate request " + sb);
            String abc = sb.toString();
            if (ResponseCode == 200) {
                Logger.info("*********** Start Validate Request ************");
                Logger.info("Successfully hit AIS validate request with status code :" + ResponseCode);
                AISValidateResponseHMFiedlMapping(abc);
            } else {
                Logger.info("Failed to hit AIS validate request due to status code :" + ResponseCode);
                AISValidateResponseXMLHM.put("Error Message", GetNodeValue(abc, "error"));
                Status = false;
            }
        } catch (Exception e) {
            Logger.info("Unable to get response from AIS Validate request due to : " + e.getMessage());
            Status = false;
        }
        return Status;
    }

    public boolean AISStoreRequest(HashMap<String, Object> map) {
        boolean Status = true;
        try {
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(gatewayURL);
            String xmlvalue = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xrsi=\"http://www.westernunion.com/schema/xrsi\">\r\n" +
                    "   <soapenv:Header/>\r\n" +
                    "   <soapenv:Body>\r\n" +
                    "      <xrsi:send-money-store-request>\r\n" +
                    "         <device>\r\n" +
                    "            <id>" + map.get("Device_id") + "</id>\r\n" +
                    "            <type>" + map.get("Device_type") + "</type>\r\n" +
                    "         </device>\r\n" +
                    "         <channel>\r\n" +
                    "            <type>" + map.get("Channel_type") + "</type>\r\n" +
                    "            <name>" + map.get("Channel_name") + "</name>\r\n" +
                    "            <version>" + map.get("Channel_version") + "</version>\r\n" +
                    "         </channel>\r\n" +
                    "         <instant_notification>\r\n" +
                    "            <addl_service_charges>" + AISValidateResponseXMLHM.get("addl_service_charges") + "</addl_service_charges>\r\n" +
                    "         </instant_notification>\r\n" +
                    "         <swb_fla_info>\r\n" +
                    "           <swb_operator_id>asfsd</swb_operator_id>\r\n" +
                    "           <fla_name name_type=\"D\">\r\n" +
                    "             <name_raw/>\r\n" +
                    "             <name_prefix>Ms.</name_prefix>\r\n" +
                    "             <first_name>Jose</first_name>\r\n" +
                    "             <middle_name/>\r\n" +
                    "             <last_name>Olloqui</last_name>\r\n" +
                    "             <name_suffix>Jr.</name_suffix>\r\n" +
                    "             <secondary_given_name/>\r\n" +
                    "             <secondary_paternal_name/>\r\n" +
                    "             <secondary_maternal_name/>\r\n" +
                    "           </fla_name>\r\n" +
                    "           <password/>\r\n" +
                    "           <read_privacynotice_flag>Y</read_privacynotice_flag>\r\n" +
                    "           <fla_certification_flag>Y</fla_certification_flag>\r\n" +
                    "         </swb_fla_info>\r\n" +
                    "         <sender>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + sndrFName + "</first_name>\r\n" +
                    "               <last_name>" + sndrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + sndrStreetName + "</addr_line1>\r\n" +
                    "               <addr_line2>" + sndrStreetName1 + "</addr_line2>\r\n" +
                    "               <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "               <state>" + map.get("SenderState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("SenderCountry") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "                  <country_name>" + map.get("Sender_country_name") + "</country_name>\r\n" +
                    "               </country_code>\r\n" +
                    "               <local_area>" + localArea + "</local_area>\r\n" +
                    "               <address_type>I</address_type>\r\n" +
                    "            </address>\r\n" +
                    "            <compliance_details>\r\n" +
                    "               <template_id>" + map.get("Send_template_id") + "</template_id>\r\n" +
                    "               <id_details>\r\n" +
                    "                  <id_type>" + map.get("Id_type") + "</id_type>\r\n" +
                    "                  <id_country_of_issue>" + map.get("Id_country_of_issue") + "</id_country_of_issue>\r\n" +
                    "                  <id_place_of_issue>" + map.get("Id_place_of_issue") + "</id_place_of_issue>\r\n" +
                    "                  <id_number>" + map.get("Id_number") + "</id_number>\r\n" +
                    "               </id_details>\r\n" +
                    "               <third_id/>\r\n" +
                    "               <third_party_details>\r\n" +
                    "                  <flag_pay>N</flag_pay>\r\n" +
                    "               </third_party_details>\r\n" +
                    "               <third_id_number></third_id_number>\r\n" +
                    "               <compliance_flags_buffer/>\r\n" +
                    "               <compliance_data_buffer>" + AISValidateResponseXMLHM.get("compliance_data_buffer") + "</compliance_data_buffer>\r\n" +
                    "               <id_issue_date>" + map.get("Id_issue_date") + "</id_issue_date>\r\n" +
                    "               <id_expiration_date>" + map.get("Id_expiration_date") + "</id_expiration_date>\r\n" +
                    "               <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "               <occupation>" + map.get("Occupation") + "</occupation>\r\n" +
                    "               <country_of_residence></country_of_residence>\r\n" +
                    "               <transaction_reason>" + map.get("Transaction_reason") + "</transaction_reason>\r\n" +
                    "               <Current_address>\r\n" +
                    "                  <addr_line1>" + sndrStreetName + "</addr_line1>\r\n" +
                    "                  <addr_line2>" + sndrStreetName1 + "</addr_line2>\r\n" +
                    "                  <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "                  <state_name>" + map.get("SenderState") + "</state_name>\r\n" +
                    "                  <state_code>" + map.get("SenderState") + "</state_code>\r\n" +
                    "                  <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "                  <country>" + map.get("Sender_country_name") + "</country>\r\n" +
                    "                  <zip>" + map.get("SenderZip") + "</zip>\r\n" +
                    "                  <email_address></email_address>\r\n" +
                    "               </Current_address>\r\n" +
                    "               <contact_phone>" + sndrPhoneNum + "</contact_phone>\r\n" +
                    "               <Country_of_Birth>" + map.get("Country_of_Birth") + "</Country_of_Birth>\r\n" +
                    "               <nationality>" + map.get("Nationality") + "</nationality>\r\n" +
                    "               <Gender>F</Gender>\r\n" +
                    "               <Is_a_resident>N</Is_a_resident>\r\n" +
                    "               <Source_of_Funds>" + map.get("Source_of_Funds") + "</Source_of_Funds>\r\n" +
                    "               <Name_of_Employer_Business>" + map.get("Name_of_Employer_Business") + "</Name_of_Employer_Business>\r\n" +
                    "               <Nature_of_Work_Business>" + map.get("Nature_of_Work_Business") + " Technology</Nature_of_Work_Business>\r\n" +
                    "               <Is_txn_Individual_or_Organization>I</Is_txn_Individual_or_Organization>\r\n" +
                    "               <Relationship_to_Receiver_Sender>" + map.get("Relationship_to_Receiver_Sender") + "</Relationship_to_Receiver_Sender>\r\n" +
                    "               <Does_the_ID_have_an_expiration_date>Y</Does_the_ID_have_an_expiration_date>\r\n" +
                    "               <City_of_Birth></City_of_Birth>\r\n" +
                    "               <Personal_Identification_Number/>\r\n" +
                    "               <I_act_on_My_Behalf>" + map.get("I_act_on_My_Behalf") + "</I_act_on_My_Behalf>\r\n" +
                    "               <ack_flag>X</ack_flag>\r\n" +
                    "               <Beneficiary_Nationality></Beneficiary_Nationality>\r\n" +
                    "               <Other_Occupation/>\r\n" +
                    "               <Was_A_Proof_Of_EU_Citizenship_Provided>Y</Was_A_Proof_Of_EU_Citizenship_Provided>\r\n" +
                    "               <Was_A_Resident_Permit_Provided>Y</Was_A_Resident_Permit_Provided>\r\n" +
                    "               <STD_Phone_Number_Code></STD_Phone_Number_Code>\r\n" +
                    "               <Mobile_Phone_Number></Mobile_Phone_Number>\r\n" +
                    "               <Marital_Status></Marital_Status>\r\n" +
                    "               <Country_Code>" + map.get("SenderPhoneCntryCode") + "</Country_Code>\r\n" +
                    "               <Other_Purpose_of_Transaction>Saving/Investments</Other_Purpose_of_Transaction>\r\n" +
                    "               <WU_COM_Electronic_Validation/>\r\n" +
                    "               <second_id_issue_date/>\r\n" +
                    "               <second_id_expiration_date/>\r\n" +
                    "               <employer_address1/>\r\n" +
                    "               <is_addr_diff>N</is_addr_diff>\r\n" +
                    "               <category_code>325</category_code>\r\n" +
                    "               <business_phone_no/>\r\n" +
                    "               <are_you_a_PEP_relative_or_friend>" + map.get("Are_you_a_PEP_relative_or_friend") + "</are_you_a_PEP_relative_or_friend>\r\n" +
                    "               <annual_income></annual_income>\r\n" +
                    "               <employer_status>" + map.get("Employer_status") + "</employer_status>\r\n" +
                    "               <id_doc_control_number/>\r\n" +
                    "               <temporary_address>\r\n" +
                    "                  <addr_line1>" + sndrStreetName + "</addr_line1>\r\n" +
                    "                  <addr_line2>" + sndrStreetName1 + "</addr_line2>\r\n" +
                    "                  <city>" + map.get("SenderCity") + "</city>\r\n" +
                    "                  <state_name>" + map.get("SenderState") + "</state_name>\r\n" +
                    "                  <state_code>" + map.get("SenderState") + "</state_code>\r\n" +
                    "                  <postal_code>" + map.get("SenderZip") + "</postal_code>\r\n" +
                    "                  <country>" + map.get("Sender_country_name") + "</country>\r\n" +
                    "               </temporary_address>\r\n" +
                    "               <cust_relationship_flag>Y</cust_relationship_flag>\r\n" +
                    "               <prmt_proof_of_addr_doc_control_number/>\r\n" +
                    "               <purpose_of_txn_doc_control_number/>\r\n" +
                    "               <galactic_id/>\r\n" +
                    "               <multi_error_supported>N</multi_error_supported>\r\n" +
                    "               <funds_source_documented>Y</funds_source_documented>\r\n" +
                    "               <biometric_txn_ref_no></biometric_txn_ref_no>\r\n" +
                    "               <biometric_ack_status/>\r\n" +
                    "               <compliance_validation_flag></compliance_validation_flag>\r\n" +
                    "               <is_current_and_permanent_addr_same>Y</is_current_and_permanent_addr_same>\r\n" +
                    "               <employer_email_address></employer_email_address>\r\n" +
                    "               <business_phone_country_code></business_phone_country_code>\r\n" +
                    "               <employment_position_level/>\r\n" +
                    "               <PEP_Category/>\r\n" +
                    "               <Second_Nationality/>\r\n" +
                    "               <Does_Consumer_Have_Second_Nationality>N</Does_Consumer_Have_Second_Nationality>\r\n" +
                    "            </compliance_details>\r\n" +
                    "            <email>" + sndrMail + "</email>\r\n" +
                    "            <phone_country_code>" + map.get("SenderPhoneCntryCode") + "</phone_country_code>\r\n" +
                    "            <contact_phone>" + sndrPhoneNum + "</contact_phone>\r\n" +
                    "            <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "            <mobile_phone>\r\n" +
                    "               <phone_number>\r\n" +
                    "                  <country_code>" + map.get("SenderPhoneCntryCode") + "</country_code>\r\n" +
                    "                  <national_number>" + sndrPhoneNum + "</national_number>\r\n" +
                    "               </phone_number>\r\n" +
                    "            </mobile_phone>\r\n" +
                    "            <customer_resident_of_agentcountry/>\r\n" +
                    "            <fraud_warning_consent>Y</fraud_warning_consent>\r\n" +
                    "            <bank_details>\r\n" +
                    "               <name/>\r\n" +
                    "               <account_number/>\r\n" +
                    "               <routing_number/>\r\n" +
                    "            </bank_details>\r\n" +
                    "            <sms_notification_flag>Y</sms_notification_flag>\r\n" +
                    "            <mothers_maiden_name/>\r\n" +
                    "         </sender>\r\n" +
                    "         <receiver>\r\n" +
                    "            <name name_type=\"D\">\r\n" +
                    "               <first_name>" + rcvrFName + "</first_name>\r\n" +
                    "               <last_name>" + rcvrLName + "</last_name>\r\n" +
                    "            </name>\r\n" +
                    "            <address>\r\n" +
                    "               <addr_line1>" + rcvrStreetName + "</addr_line1>\r\n" +
                    "               <city>" + map.get("ReceiverCity") + "</city>\r\n" +
                    "               <state>" + map.get("ReceiverState") + "</state>\r\n" +
                    "               <postal_code>" + map.get("ReceiverZip") + "</postal_code>\r\n" +
                    "               <country_code>\r\n" +
                    "                  <iso_code>\r\n" +
                    "                     <country_code>" + map.get("ReceiverCountryCode") + "</country_code>\r\n" +
                    "                     <currency_code>" + map.get("DestinationCurrencyCode") + "</currency_code>\r\n" +
                    "                  </iso_code>\r\n" +
                    "               </country_code>\r\n" +
                    "               <address_type></address_type>\r\n" +
                    "            </address>\r\n" +
                    "            <date_of_birth>" + map.get("Date_of_birth") + "</date_of_birth>\r\n" +
                    "         </receiver>\r\n" +
                    "         <emea_ii>\r\n" +
                    "            <key_serial_number/>\r\n" +
                    "         </emea_ii>\r\n" +
                    "         <promotions>\r\n" +
                    "            <promo_sequence_no/>\r\n" +
                    "            <promo_name/>\r\n" +
                    "            <promo_message/>\r\n" +
                    "            <sender_promo_code/>\r\n" +
                    "         </promotions>\r\n" +
                    "         <payment_details>\r\n" +
                    "            <expected_payout_location>\r\n" +
                    "               <state_code>" + map.get("ReceiverState") + "</state_code>\r\n" +
                    "               <city>" + map.get("ReceiverCity") + "</city>\r\n" +
                    "            </expected_payout_location>\r\n" +
                    "            <recording_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("OriginatingCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </recording_country_currency>\r\n" +
                    "            <destination_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("DestinationCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("DestinationCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </destination_country_currency>\r\n" +
                    "            <originating_country_currency>\r\n" +
                    "               <iso_code>\r\n" +
                    "                  <country_code>" + map.get("OriginatingCountry") + "</country_code>\r\n" +
                    "                  <currency_code>" + map.get("OriginatingCurrencyCode") + "</currency_code>\r\n" +
                    "               </iso_code>\r\n" +
                    "            </originating_country_currency>\r\n" +
                    "            <transaction_type>" + map.get("Transaction_type") + "</transaction_type>\r\n" +
                    "            <payment_type>" + map.get("Payment_type") + "</payment_type>\r\n" +
                    "            <exchange_rate>" + AISValidateResponseXMLHM.get("exchange_rate") + "</exchange_rate>\r\n" +
                    "            <fix_on_send>Y</fix_on_send>\r\n" +
                    "            <pay_wo_id_indicator>N</pay_wo_id_indicator>\r\n" +
                    "            <credit_debit_card_details>\r\n" +
                    "               <card_number/>\r\n" +
                    "               <encryption_key/>\r\n" +
                    "               <track_data/>\r\n" +
                    "               <expiration_date/>\r\n" +
                    "            </credit_debit_card_details>\r\n" +
                    "            <mt_requested_status/>\r\n" +
                    "            <stage_pay_fields>\r\n" +
                    "               <staging_buffer></staging_buffer>\r\n" +
                    "            </stage_pay_fields>\r\n" +
                    "         </payment_details>\r\n" +
                    "         <financials>\r\n" +
                    "            <taxes>\r\n" +
                    "               <municipal_tax>" + AISValidateResponseXMLHM.get("municipal_tax") + "</municipal_tax>\r\n" +
                    "               <state_tax>" + AISValidateResponseXMLHM.get("state_tax") + "</state_tax>\r\n" +
                    "               <county_tax>" + AISValidateResponseXMLHM.get("county_tax") + "</county_tax>\r\n" +
                    "            </taxes>\r\n" +
                    "            <originators_principal_amount>" + principalAmount + "</originators_principal_amount>\r\n" +
                    "            <destination_principal_amount>" + AISValidateResponseXMLHM.get("destination_principal_amount") + "</destination_principal_amount>\r\n" +
                    "            <gross_total_amount>" + AISValidateResponseXMLHM.get("gross_total_amount") + "</gross_total_amount>\r\n" +
                    "            <plus_charges_amount>" + AISValidateResponseXMLHM.get("plus_charges_amount") + "</plus_charges_amount>\r\n" +
                    "            <charges>" + AISValidateResponseXMLHM.get("charges") + "</charges>\r\n" +
                    "            <message_charge>" + AISValidateResponseXMLHM.get("message_charge") + "</message_charge>\r\n" +
                    "            <total_undiscounted_charges>" + AISValidateResponseXMLHM.get("total_undiscounted_charges") + "</total_undiscounted_charges>\r\n" +
                    "            <total_discounted_charges>" + AISValidateResponseXMLHM.get("total_discounted_charges") + "</total_discounted_charges>\r\n" +
                    "         </financials>\r\n" +
                    "         <delivery_services>\r\n" +
                    "            <code>" + AISFeeResponseXMLHM.get("delivery_servicescode") + "</code>\r\n" +
                    "            <routing_code>" + AISFeeResponseXMLHM.get("delivery_servicesrouting_code") + "</routing_code>\r\n" +
                    "            <message>\r\n" +
                    "               <message_details context=\"\">\r\n" +
                    "                  <text>?</text>\r\n" +
                    "               </message_details>\r\n" +
                    "            </message>\r\n" +
                    "            <route_code/>\r\n" +
                    "         </delivery_services>\r\n" +
                    "         <mtcn>" + AISValidateResponseXMLHM.get("mtcn") + "</mtcn>\r\n" +
                    "         <new_mtcn>" + AISValidateResponseXMLHM.get("new_mtcn") + "</new_mtcn>\r\n" +
                    "         <money_transfer_key></money_transfer_key>\r\n" +
                    "         <customer_affidavit_number/>\r\n" +
                    "         <customer_affidavit/>\r\n" +
                    "         <df_fields>\r\n" +
                    "            <pds_required_flag>" + AISValidateResponseXMLHM.get("pds_required_flag") + "</pds_required_flag>\r\n" +
                    "            <df_transaction_flag>" + AISValidateResponseXMLHM.get("df_transaction_flag") + "</df_transaction_flag>\r\n" +
                    "             <partner_marketing_languages>\r\n" +
                    "               <locale>" + AISValidateResponseXMLHM.get("partner_marketing_languages_locale") + "</locale>\r\n" +
                    "               <locale>" + AISValidateResponseXMLHM.get("partner_marketing_languages_locale1") + "</locale>\r\n" +
                    "            </partner_marketing_languages>\r\n" +
                    "            <amount_to_receiver>" + AISValidateResponseXMLHM.get("amount_to_receiver") + "</amount_to_receiver>\r\n" +
                    "            <delivery_service_name>" + map.get("WU_product_name") + "</delivery_service_name>\r\n" +
                    "         </df_fields>\r\n" +
                    "         <cuba>\r\n" +
                    "            <name>\r\n" +
                    "               <given_name/>\r\n" +
                    "               <paternal_name/>\r\n" +
                    "               <maternal_name/>\r\n" +
                    "            </name>\r\n" +
                    "            <question2/>\r\n" +
                    "            <question3/>\r\n" +
                    "            <question4/>\r\n" +
                    "            <question5/>\r\n" +
                    "            <question6/>\r\n" +
                    "            <question7/>\r\n" +
                    "            <question8/>\r\n" +
                    "            <question9/>\r\n" +
                    "            <question10/>\r\n" +
                    "            <question11/>\r\n" +
                    "            <question12/>\r\n" +
                    "            <question13/>\r\n" +
                    "            <question14/>\r\n" +
                    "            <question16/>\r\n" +
                    "         </cuba>\r\n" +
                    "         <consumer_fraud_prompts>\r\n" +
                    "            <question1>N</question1>\r\n" +
                    "         </consumer_fraud_prompts>\r\n" +
                    "         <foreign_remote_system>\r\n" +
                    "            <identifier>" + map.get("ForeignSystemIdentifier") + "</identifier>\r\n" +
                    "            <reference_no>" + map.get("ForeignSystemReferenceNo") + "</reference_no>\r\n" +
                    "            <counter_id>" + map.get("ForeignSystemCounterID") + "</counter_id>\r\n" +
                    "         </foreign_remote_system>\r\n" +
                    "      </xrsi:send-money-store-request>\r\n" +
                    "   </soapenv:Body>\r\n" +
                    "</soapenv:Envelope>";
//            System.out.println("Store Request "+xmlvalue);
            InputStream xmlInput = new ByteArrayInputStream(xmlvalue.getBytes(StandardCharsets.UTF_8));
            post.setEntity(new InputStreamEntity(new DataInputStream(xmlInput)));
            post.setHeader("Content-Type", "text/xml;charset=UTF-8");
            post.setHeader("Accept-Encoding", "gzip,deflate");
            post.setHeader("SOAPAction", "FeeSurveyAction");
            post.setHeader("Connection", "Keep-Alive");
            HttpResponse response = client.execute(post);
            int ResponseCode = response.getStatusLine().getStatusCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
            String line = "";
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            Logger.info("AIS Store Response " + sb);
            String abc = sb.toString();
            if (ResponseCode == 200) {
                Logger.info("*********** Start AIS Store Request ************");
                Logger.info("Successfully hit AIS store request with status code :" + ResponseCode);
                AISStoreResponseHMFiedlMapping(abc);
            } else {
                Logger.info("Failed to hit AIS store request due to status code :" + ResponseCode);
                AISStoreResponseXMLHM.put("Error Message", GetNodeValue(abc, "error"));
                Status = false;
            }
        } catch (Exception e) {
            Logger.info("Unable to get response from AIS Store request due to : " + e.getMessage());
            Status = false;
        }
        return Status;
    }

    public static HashMap<String, String> AISFeeResponseHMFiedlMapping(String sDocumentxml) throws Exception {
        try {
            AISFeeResponseXMLHM.put("delivery_servicescode", GetChildNodeValue(sDocumentxml, "delivery_services", 0, "code"));
            AISFeeResponseXMLHM.put("delivery_servicesrouting_code", GetChildNodeValue(sDocumentxml, "delivery_services", 0, "routing_code"));
            AISFeeResponseXMLHM.put("delivery_servicesinformation", GetChildNodeValue(sDocumentxml, "delivery_services", 0, "information"));
            AISFeeResponseXMLHM.put("delivery_servicespayment_digest", GetChildNodeValue(sDocumentxml, "delivery_services", 0, "payment_digest"));
            AISFeeResponseXMLHM.put("financials:destination_principal_amount", GetChildNodeValue(sDocumentxml, "financials", 0, "destination_principal_amount"));
            AISFeeResponseXMLHM.put("financials:gross_total_amount", GetChildNodeValue(sDocumentxml, "financials", 0, "gross_total_amount"));
            AISFeeResponseXMLHM.put("financials:sum_charges", GetChildNodeValue(sDocumentxml, "financials", 0, "sum_charges"));
            AISFeeResponseXMLHM.put("financials:min_transaction_limit", GetChildNodeValue(sDocumentxml, "financials", 0, "min_transaction_limit"));
            AISFeeResponseXMLHM.put("financials:max_transaction_limit", GetChildNodeValue(sDocumentxml, "financials", 0, "max_transaction_limit"));
            AISFeeResponseXMLHM.put("promotions:promo_code_description", GetChildNodeValue(sDocumentxml, "promotions", 0, "promo_code_description"));
            AISFeeResponseXMLHM.put("promotions:promo_discount_amount", GetChildNodeValue(sDocumentxml, "promotions", 0, "promo_discount_amount"));
            AISFeeResponseXMLHM.put("payment_details:exchange_rate", GetChildNodeValue(sDocumentxml, "payment_details", 0, "exchange_rate"));
        } catch (Exception e) {
            Logger.info("Failed to read input from AIS Fee enquiry :" + e.getMessage());
        }
        return AISFeeResponseXMLHM;

    }

    public static HashMap<String, String> AISValidateResponseHMFiedlMapping(String sDocumentxml) throws Exception {
        try {
            AISValidateResponseXMLHM.put("addl_service_charges", GetNodeValue(sDocumentxml, "addl_service_charges"));
            AISValidateResponseXMLHM.put("compliance_data_buffer", GetNodeValue(sDocumentxml, "compliance_data_buffer"));
            AISValidateResponseXMLHM.put("exchange_rate", GetNodeValue(sDocumentxml, "exchange_rate"));
            AISValidateResponseXMLHM.put("municipal_tax", GetNodeValue(sDocumentxml, "municipal_tax"));
            AISValidateResponseXMLHM.put("state_tax", GetNodeValue(sDocumentxml, "state_tax"));
            AISValidateResponseXMLHM.put("county_tax", GetNodeValue(sDocumentxml, "county_tax"));
            AISValidateResponseXMLHM.put("destination_principal_amount", GetNodeValue(sDocumentxml, "destination_principal_amount"));
            AISValidateResponseXMLHM.put("gross_total_amount", GetNodeValue(sDocumentxml, "gross_total_amount"));
            AISValidateResponseXMLHM.put("plus_charges_amount", GetNodeValue(sDocumentxml, "plus_charges_amount"));
            AISValidateResponseXMLHM.put("charges", GetNodeValue(sDocumentxml, "charges"));
            AISValidateResponseXMLHM.put("message_charge", GetNodeValue(sDocumentxml, "message_charge"));
            AISValidateResponseXMLHM.put("total_undiscounted_charges", GetNodeValue(sDocumentxml, "total_undiscounted_charges"));
            if (AISValidateResponseXMLHM.get("total_undiscounted_charges") == null)
                AISValidateResponseXMLHM.put("total_undiscounted_charges", "0");
            AISValidateResponseXMLHM.put("total_discounted_charges", GetNodeValue(sDocumentxml, "total_discounted_charges"));
            if (AISValidateResponseXMLHM.get("total_discounted_charges") == null)
                AISValidateResponseXMLHM.put("total_discounted_charges", "0");
            AISValidateResponseXMLHM.put("promo_code_description", GetNodeValue(sDocumentxml, "promo_code_description"));
            AISValidateResponseXMLHM.put("promo_message", GetNodeValue(sDocumentxml, "promo_message"));
            AISValidateResponseXMLHM.put("sender_promo_code", GetNodeValue(sDocumentxml, "sender_promo_code"));
            AISValidateResponseXMLHM.put("mtcn", GetNodeValue(sDocumentxml, "mtcn"));
            AISValidateResponseXMLHM.put("new_mtcn", GetNodeValue(sDocumentxml, "new_mtcn"));
            AISValidateResponseXMLHM.put("pds_required_flag", GetNodeValue(sDocumentxml, "pds_required_flag"));
            if (AISValidateResponseXMLHM.get("pds_required_flag") == null)
                AISValidateResponseXMLHM.put("pds_required_flag", "0");
            AISValidateResponseXMLHM.put("df_transaction_flag", GetNodeValue(sDocumentxml, "df_transaction_flag"));
            if (AISValidateResponseXMLHM.get("df_transaction_flag") == null)
                AISValidateResponseXMLHM.put("df_transaction_flag", "0");
            AISValidateResponseXMLHM.put("partner_marketing_languages_locale", GetChildNodeValue(sDocumentxml, "partner_marketing_languages", 0, "locale"));
            AISValidateResponseXMLHM.put("partner_marketing_languages_locale1", GetChildNodeValue(sDocumentxml, "partner_marketing_languages", 1, "locale"));
            AISValidateResponseXMLHM.put("amount_to_receiver", GetNodeValue(sDocumentxml, "amount_to_receiver"));
            if (AISValidateResponseXMLHM.get("amount_to_receiver") == null)
                AISValidateResponseXMLHM.put("amount_to_receiver", AISValidateResponseXMLHM.get("destination_principal_amount").toString());
        } catch (Exception e) {
            Logger.info("Failed to read input from AIS validate request :" + e.getMessage());
        }

        return AISValidateResponseXMLHM;
    }

    public static HashMap<String, String> AISStoreResponseHMFiedlMapping(String sDocumentxml) throws Exception {
        try {
            AISStoreResponseXMLHM.put("new_mtcn", GetNodeValue(sDocumentxml, "new_mtcn"));
            Logger.info("16 digit mtcn = " + GetNodeValue(sDocumentxml, "new_mtcn"));
        } catch (Exception e) {
            Logger.info("Failed to read input from Store response :" + e.getMessage());
        }
        return AISStoreResponseXMLHM;

    }

    /* --------------------------------------------------------
     * ---------------  Common Functions  ---------------------
     * ---------------------------------------------------------*/


    public static String GetNodeValue(String sDocumentxml, String sNodeName) throws Exception {
        String NodeValue = null;
        try {
            Document xmlDoc = loadXMLString(sDocumentxml);
            NodeValue = xmlDoc.getElementsByTagName(sNodeName).item(0).getTextContent();
        } catch (Exception e) {

        }
        return NodeValue;
    }

    public static String GetChildNodeValue(String sDocumentxml, String ParentNode, int sindex, String childNode) throws Exception {
        String NodeValue = null;
        try {
            Document xmlDoc = loadXMLString(sDocumentxml);
            Node RootNode = xmlDoc.getElementsByTagName(ParentNode).item(sindex);
            NodeList list = RootNode.getChildNodes();
            for (int i = 0; i < list.getLength(); i++) {
                Node node = list.item(i);
                if (node.getNodeName().equalsIgnoreCase(childNode)) {
                    NodeValue = list.item(i).getTextContent();
                    break;
                }
            }
        } catch (Exception e) {

        }
        return NodeValue;
    }

    public static Document loadXMLString(String response) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(response));

        return db.parse(is);
    }

    public void GenerateTestDataForDynamicFields(HashMap<String, Object> map, String trnxType) throws ClassNotFoundException {
        sndrFName = (String) map.get("SenderFirstName");
        sndrLName = (String) map.get("SenderLastName");
        sndrStreetName = (String) map.get("SenderStreetName");
        sndrPhoneNum = (String) map.get("SenderPhoneNumber");
        rcvrFName = (String) map.get("ReceiverFirstName");
        rcvrLName = (String) map.get("ReceiverLastName");
        rcvrStreetName = (String) map.get("ReceiverStreetName");
        rcvrPhoneNum = (String) map.get("ReceiverPhoneNumber");
        sndrMail = (String) map.get("Email");
        rcvrStreetName1 = (String) map.get("ReceiverStreetName1");
        rcvrMail = (String) map.get("Receiver_email");
        rcvrFName = (String) map.get("ReceiverFirstName");
        rcvrLName = (String) map.get("ReceiverLastName");
    }

    public void readAndAssignTestCasePrerequisites(HashMap<String, Object> map) {
        entityType = map.get("Entity_Type").toString();
        Logger.info("entityType = " + entityType);
        if (entityType.equalsIgnoreCase("PAYEE_GI")) {
            sendEntityType = "SENDER_GI";
            payEntityType = "PAYEE_GI";
        } else {
            sendEntityType = entityType;
            payEntityType = entityType;
        }
        principalAmount = Integer.parseInt(map.get("Principal").toString());
        sMethodName = map.get("Method_Name").toString();
        queueNameExcel = map.get("QueueName").toString();
    }

    public String otherRuleHitHandling(String errorCodeMessage, String stepDescription, String expectedResult, String actualResult, String mtcn, int i) throws InterruptedException, ClassNotFoundException, SQLException {


        return "No Flag";
    }
    public HashMap<String, Object> getDataForMTCN_WURetail_SanctionssingleEntity(String fileName, int entityNo,int totalNoOfEntities) {
        int n;
        String rcvrFName = getRandomRcvrFName();
        String rcvrLName = getRandomRcvrLName();
        // String filePath = getFullPath_SANCTIONS("CaseCreateData"+ System.getProperty("file.separator") +fileName + ".properties");
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }

        Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date"));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue"));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name"));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality"));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2"));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState"));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip"));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", rcvrFName);
        map.put("ReceiverLastName", rcvrLName);
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number"));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date"));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth"));
        return map;
    }

    public HashMap<String, Object> getDataForMTCN_WURetail_L2_SanctionssingleEntity(String fileName, int entityNo,int totalNoOfEntities) {
        int n;
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth_"+n));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date_"+n));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue_"+n));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue_"+n));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry_"+n));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name_"+n));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality_"+n));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity_"+n));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2_"+n));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState_"+n));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip_" +n));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number_" +n));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date_"+n));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth_"+n));
        return map;
    }

    public HashMap<String, Object> getDataForMTCN_WUDigital_L2_SanctionssingleEntity(String fileName, int entityNo,int totalNoOfEntities)  {
        int n;
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);

        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Sndr_addr_line1", CommonFunctions.readFile(filePath, "Sndr_addr_line1"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity"));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState"));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry"));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name"));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode"));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderStreetName1", CommonFunctions.readFile(filePath, "SenderStreetName1"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue"));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number"));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date"));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth_"+n));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Mobile_override_flag", CommonFunctions.readFile(filePath, "Mobile_override_flag"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("Credit_debit_card_number", CommonFunctions.readFile(filePath, "Credit_debit_card_number"));
        map.put("Cvvii_code", CommonFunctions.readFile(filePath, "Cvvii_code"));
        map.put("Expiration_date", CommonFunctions.readFile(filePath, "Expiration_date"));
        map.put("Cub_source", CommonFunctions.readFile(filePath, "Cub_source"));
        map.put("Store_validate_flag", CommonFunctions.readFile(filePath, "Store_validate_flag"));
        map.put("Auto_aprv_id", CommonFunctions.readFile(filePath, "Auto_aprv_id"));
        map.put("Host_based_taxes", CommonFunctions.readFile(filePath, "Host_based_taxes"));
        map.put("Account_nbr", CommonFunctions.readFile(filePath, "Account_nbr"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Ip_address", CommonFunctions.readFile(filePath, "Ip_address"));
        map.put("Mobile_city_code", CommonFunctions.readFile(filePath, "Mobile_city_code"));
        map.put("RWC_flag", CommonFunctions.readFile(filePath, "RWC_flag"));
        map.put("Receiver_mobile_override_flag", CommonFunctions.readFile(filePath, "Receiver_mobile_override_flag"));
        return map;
    }

    public HashMap<String, Object> getDataForMTCN_WURetail_L3_SanctionssingleEntity(String fileName, int entityNo,int totalNoOfEntities) {
        int n;
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth_"+n));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date_"+n));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue_"+n));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue_"+n));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry_"+n));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name_"+n));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality_"+n));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName_"+n));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity_"+n));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2_"+n));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState_"+n));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip_" +n));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number_" +n));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date_"+n));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth_"+n));
        return map;
    }

    public HashMap<String, Object> getDataForMTCN_WUDigital_SanctionssingleEntity(String fileName, int entityNo,int totalNoOfEntities)  {
        int n;
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);

        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Sndr_addr_line1", CommonFunctions.readFile(filePath, "Sndr_addr_line1"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity"));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState"));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry"));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name"));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode"));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderStreetName1", CommonFunctions.readFile(filePath, "SenderStreetName1"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue"));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number"));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date"));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth"));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Mobile_override_flag", CommonFunctions.readFile(filePath, "Mobile_override_flag"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("Credit_debit_card_number", CommonFunctions.readFile(filePath, "Credit_debit_card_number"));
        map.put("Cvvii_code", CommonFunctions.readFile(filePath, "Cvvii_code"));
        map.put("Expiration_date", CommonFunctions.readFile(filePath, "Expiration_date"));
        map.put("Cub_source", CommonFunctions.readFile(filePath, "Cub_source"));
        map.put("Store_validate_flag", CommonFunctions.readFile(filePath, "Store_validate_flag"));
        map.put("Auto_aprv_id", CommonFunctions.readFile(filePath, "Auto_aprv_id"));
        map.put("Host_based_taxes", CommonFunctions.readFile(filePath, "Host_based_taxes"));
        map.put("Account_nbr", CommonFunctions.readFile(filePath, "Account_nbr"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Ip_address", CommonFunctions.readFile(filePath, "Ip_address"));
        map.put("Mobile_city_code", CommonFunctions.readFile(filePath, "Mobile_city_code"));
        map.put("RWC_flag", CommonFunctions.readFile(filePath, "RWC_flag"));
        map.put("Receiver_mobile_override_flag", CommonFunctions.readFile(filePath, "Receiver_mobile_override_flag"));
        return map;
    }

    public HashMap<String, Object> getDataForMTCN_WUDeferredSenderPotentialReceiver(String fileName, int entityNo,int totalNoOfEntities) {
        int n;

        String filePath = CommonFunctions.getFullPath_GSI_Deferred("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
        if (entityNo == 0) {
            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
        } else {
            n = entityNo;
        }
        Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth_" + n));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date_" + n));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue_" + n));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue_" + n));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type_" + n));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry_" + n));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name_" + n));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality_" + n));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode_" + n));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_" + n));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_" + n));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName_" + n));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber_" + n));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum_" + n));
        map.put("Email", CommonFunctions.readFile(filePath, "Email_" + n));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity_" + n));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2_" + n));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState_" + n));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip_" + n));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName" ));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName" ));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number_" + n));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date_" + n));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth_" + n));
        return map;
    }


    public HashMap<String, Object> getDataForMTCN_WURetail_L1_DualHitsingleEntity(String fileName, int entityNo,int totalNoOfEntities) {
        int n;
        // String filePath = getFullPath_SANCTIONS("CaseCreateData"+ System.getProperty("file.separator") +fileName + ".properties");
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        System.out.println(filePath);

        HashMap<String, Object> map = new HashMap<String, Object>();
//        if (entityNo == 0) {
//            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
//        } else {
//            n = entityNo;
//        }

        //Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date"));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue"));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name"));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality"));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
//        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
//        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName"));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName"));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2"));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState"));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip"));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number"));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date"));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth"));
        return map;
    }

    public HashMap<String, Object> getDataForMTCN_WURetail_L2_DualHitsingleEntity(String fileName, int entityNo,int totalNoOfEntities) {
        //int n;
        // String filePath = getFullPath_SANCTIONS("CaseCreateData"+ System.getProperty("file.separator") +fileName + ".properties");
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        System.out.println(filePath);

        HashMap<String, Object> map = new HashMap<String, Object>();
//        if (entityNo == 0) {
//            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
//        } else {
//            n = entityNo;
//        }

        //Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date"));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue"));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name"));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality"));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
//        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
//        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName"));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName"));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2"));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState"));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip"));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number"));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date"));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth"));
        return map;
    }

    public HashMap<String, Object> getDataForMTCN_WURetail_L3_DualHitsingleEntity(String fileName, int entityNo,int totalNoOfEntities) {
        //int n;
        // String filePath = getFullPath_SANCTIONS("CaseCreateData"+ System.getProperty("file.separator") +fileName + ".properties");
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        System.out.println(filePath);

        HashMap<String, Object> map = new HashMap<String, Object>();
//        if (entityNo == 0) {
//            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
//        } else {
//            n = entityNo;
//        }

        //Logger.info("Entity picked =" + n);
        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Receiver_date_of_birth", CommonFunctions.readFile(filePath, "Receiver_date_of_birth"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("Relationship_to_Receiver_Sender", CommonFunctions.readFile(filePath, "Relationship_to_Receiver_Sender"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Expected_Result", CommonFunctions.readFile(filePath, "Expected_Result"));
        map.put("No_of_Iterations", CommonFunctions.readFile(filePath, "No_of_Iterations"));
        map.put("Amount to be incremented for each iteration (Amount Agg rule only)", CommonFunctions.readFile(filePath, "Amount to be incremented for each iteration (Amount Agg rule only)"));
        map.put("Amount_Agg_Limit", CommonFunctions.readFile(filePath, "Amount_Agg_Limit"));
        map.put("BackDateType", CommonFunctions.readFile(filePath, "BackDateType"));
        map.put("BackDate_TimePeriod", CommonFunctions.readFile(filePath, "BackDate_TimePeriod"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("ReqDeliveryServicePositionforAgent", CommonFunctions.readFile(filePath, "ReqDeliveryServicePositionforAgent"));
        map.put("Send_template_id", CommonFunctions.readFile(filePath, "Send_template_id"));
        map.put("Transaction_type", CommonFunctions.readFile(filePath, "Transaction_type"));
        map.put("IsEnabled", CommonFunctions.readFile(filePath, "IsEnabled"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Id_issue_date", CommonFunctions.readFile(filePath, "Id_issue_date"));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue"));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name"));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality"));
        map.put("Receiveraddr_line1", CommonFunctions.readFile(filePath, "Receiveraddr_line1"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("SenderPhoneCntryCode", CommonFunctions.readFile(filePath, "SenderPhoneCntryCode"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
//        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
//        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName"));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName"));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("SenderAlphaNum", CommonFunctions.readFile(filePath, "SenderAlphaNum"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2"));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState"));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip"));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode" ));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode" ));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry" ));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number"));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date"));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth"));
        return map;
    }


    public HashMap<String, Object> getDataForMTCN_DualHit_Digital_L1_singleEntity(String fileName, int entityNo,int totalNoOfEntities)  {
        int n;
        String filePath = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData",fileName + ".properties");
        HashMap<String, Object> map = new HashMap<String, Object>();
//        if (entityNo == 0) {
//            n = ThreadLocalRandom.current().nextInt(1, totalNoOfEntities + 1);
//        } else {
//            n = entityNo;
//        }
//        Logger.info("Entity picked =" + n);

        map.put("Device_id", CommonFunctions.readFile(filePath, "Device_id"));
        map.put("Device_type", CommonFunctions.readFile(filePath, "Device_type"));
        map.put("Channel_type", CommonFunctions.readFile(filePath, "Channel_type"));
        map.put("Channel_name", CommonFunctions.readFile(filePath, "Channel_name"));
        map.put("Channel_version", CommonFunctions.readFile(filePath, "Channel_version"));
        map.put("Sndr_addr_line1", CommonFunctions.readFile(filePath, "Sndr_addr_line1"));
        map.put("Sndr_addr_line2", CommonFunctions.readFile(filePath, "Sndr_addr_line2"));
        map.put("SenderCity", CommonFunctions.readFile(filePath, "SenderCity"));
        map.put("SenderState", CommonFunctions.readFile(filePath, "SenderState"));
        map.put("SenderZip", CommonFunctions.readFile(filePath, "SenderZip"));
        map.put("SenderCountry", CommonFunctions.readFile(filePath, "SenderCountry"));
        map.put("OriginatingCurrencyCode", CommonFunctions.readFile(filePath, "OriginatingCurrencyCode"));
        map.put("Sender_country_name", CommonFunctions.readFile(filePath, "Sender_country_name"));
        map.put("OriginatingCountry", CommonFunctions.readFile(filePath, "OriginatingCountry"));
        map.put("DestinationCurrencyCode", CommonFunctions.readFile(filePath, "DestinationCurrencyCode"));
        map.put("DestinationCountry", CommonFunctions.readFile(filePath, "DestinationCountry"));
        map.put("Payment_type", CommonFunctions.readFile(filePath, "Payment_type"));
        map.put("ForeignSystemIdentifier", CommonFunctions.readFile(filePath, "ForeignSystemIdentifier"));
        map.put("ForeignSystemReferenceNo", CommonFunctions.readFile(filePath, "ForeignSystemReferenceNo"));
        map.put("ForeignSystemCounterID", CommonFunctions.readFile(filePath, "ForeignSystemCounterID"));
//        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName_"+n));
//        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName_"+n));
        map.put("SenderFirstName", CommonFunctions.readFile(filePath, "SenderFirstName"));
        map.put("SenderLastName", CommonFunctions.readFile(filePath, "SenderLastName"));
        map.put("SenderStreetName", CommonFunctions.readFile(filePath, "SenderStreetName"));
        map.put("SenderStreetName1", CommonFunctions.readFile(filePath, "SenderStreetName1"));
        map.put("SenderPhoneNumber", CommonFunctions.readFile(filePath, "SenderPhoneNumber"));
        map.put("ReceiverFirstName", CommonFunctions.readFile(filePath, "ReceiverFirstName"));
        map.put("ReceiverLastName", CommonFunctions.readFile(filePath, "ReceiverLastName"));
        map.put("ReceiverStreetName", CommonFunctions.readFile(filePath, "ReceiverStreetName"));
        map.put("ReceiverPhoneNumber", CommonFunctions.readFile(filePath, "ReceiverPhoneNumber"));
        map.put("ReceiverCity", CommonFunctions.readFile(filePath, "ReceiverCity"));
        map.put("ReceiverState", CommonFunctions.readFile(filePath, "ReceiverState"));
        map.put("ReceiverZip", CommonFunctions.readFile(filePath, "ReceiverZip"));
        map.put("ReceiverCountryCode", CommonFunctions.readFile(filePath, "ReceiverCountryCode"));
        map.put("Receivercountry_name", CommonFunctions.readFile(filePath, "Receivercountry_name"));
        map.put("Email", CommonFunctions.readFile(filePath, "Email"));
        map.put("ReceiverStreetName1", CommonFunctions.readFile(filePath, "ReceiverStreetName1"));
        map.put("Receiver_email", CommonFunctions.readFile(filePath, "Receiver_email"));
        map.put("Entity_Type", CommonFunctions.readFile(filePath, "Entity_Type"));
        map.put("Principal", CommonFunctions.readFile(filePath, "Principal"));
        map.put("Method_Name", CommonFunctions.readFile(filePath, "Method_Name"));
        map.put("QueueName", CommonFunctions.readFile(filePath, "QueueName"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Id_type", CommonFunctions.readFile(filePath, "Id_type"));
        map.put("Id_country_of_issue", CommonFunctions.readFile(filePath, "Id_country_of_issue"));
        map.put("Id_place_of_issue", CommonFunctions.readFile(filePath, "Id_place_of_issue"));
        map.put("Id_number", CommonFunctions.readFile(filePath, "Id_number"));
        map.put("Id_expiration_date", CommonFunctions.readFile(filePath, "Id_expiration_date"));
        map.put("Date_of_birth", CommonFunctions.readFile(filePath, "Date_of_birth"));
        map.put("Occupation", CommonFunctions.readFile(filePath, "Occupation"));
        map.put("Transaction_reason", CommonFunctions.readFile(filePath, "Transaction_reason"));
        map.put("Country_of_Birth", CommonFunctions.readFile(filePath, "Country_of_Birth"));
        map.put("Nationality", CommonFunctions.readFile(filePath, "Nationality"));
        map.put("Source_of_Funds", CommonFunctions.readFile(filePath, "Source_of_Funds"));
        map.put("Name_of_Employer_Business", CommonFunctions.readFile(filePath, "Name_of_Employer_Business"));
        map.put("Nature_of_Work_Business", CommonFunctions.readFile(filePath, "Nature_of_Work_Business"));
        map.put("I_act_on_My_Behalf", CommonFunctions.readFile(filePath, "I_act_on_My_Behalf"));
        map.put("WU_COM_Electronic_Validation", CommonFunctions.readFile(filePath, "WU_COM_Electronic_Validation"));
        map.put("Are_you_a_PEP_relative_or_friend", CommonFunctions.readFile(filePath, "Are_you_a_PEP_relative_or_friend"));
        map.put("Employer_status", CommonFunctions.readFile(filePath, "Employer_status"));
        map.put("Mobile_override_flag", CommonFunctions.readFile(filePath, "Mobile_override_flag"));
        map.put("WU_product_name", CommonFunctions.readFile(filePath, "WU_product_name"));
        map.put("Credit_debit_card_number", CommonFunctions.readFile(filePath, "Credit_debit_card_number"));
        map.put("Cvvii_code", CommonFunctions.readFile(filePath, "Cvvii_code"));
        map.put("Expiration_date", CommonFunctions.readFile(filePath, "Expiration_date"));
        map.put("Cub_source", CommonFunctions.readFile(filePath, "Cub_source"));
        map.put("Store_validate_flag", CommonFunctions.readFile(filePath, "Store_validate_flag"));
        map.put("Auto_aprv_id", CommonFunctions.readFile(filePath, "Auto_aprv_id"));
        map.put("Host_based_taxes", CommonFunctions.readFile(filePath, "Host_based_taxes"));
        map.put("Account_nbr", CommonFunctions.readFile(filePath, "Account_nbr"));
        map.put("Level_code", CommonFunctions.readFile(filePath, "Level_code"));
        map.put("Third_party_flag_pay", CommonFunctions.readFile(filePath, "Third_party_flag_pay"));
        map.put("Ip_address", CommonFunctions.readFile(filePath, "Ip_address"));
        map.put("Mobile_city_code", CommonFunctions.readFile(filePath, "Mobile_city_code"));
        map.put("RWC_flag", CommonFunctions.readFile(filePath, "RWC_flag"));
        map.put("Receiver_mobile_override_flag", CommonFunctions.readFile(filePath, "Receiver_mobile_override_flag"));
        return map;
    }
}
