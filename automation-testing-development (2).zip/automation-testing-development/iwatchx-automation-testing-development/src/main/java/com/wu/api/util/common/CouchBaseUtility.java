package com.wu.api.util.common;

import com.couchbase.client.core.env.SecurityConfig;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.ClusterOptions;
import com.couchbase.client.java.env.ClusterEnvironment;
import com.couchbase.client.java.json.JsonObject;
import com.couchbase.client.java.manager.bucket.BucketSettings;
import com.couchbase.client.java.manager.bucket.BucketType;
import com.couchbase.client.java.query.QueryResult;
import com.github.wnameless.json.flattener.JsonFlattener;
import com.wu.base.logger.Logger;
import com.wu.utils.AutProperties;
import io.qameta.allure.Allure;
import net.serenitybdd.core.Serenity;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class CouchBaseUtility {
    public static Cluster cluster = null;
    public static Bucket bucket = null;
    static String bucketName = null;
    static ClusterEnvironment env = null;

    public static void openBucket() {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        bucketName = CommonFunctions.readFile(fileName, "CouchBaseBucketName");
        String sCouchbaseUserName = CommonFunctions.readFile(fileName, "CouchbaseUserName");
        String sCouchBasePassword = CommonFunctions.readFile(fileName, "CouchBasePassword");
        String sCouchbaseServerIP = CommonFunctions.readFile(fileName, "CouchbaseServerIP");
        env = ClusterEnvironment.builder()
                .securityConfig(SecurityConfig.enableTls(true)
                        .trustCertificate(Paths.get("./capella_ssl_cert.pem")))
                .build();
        cluster = Cluster.connect(sCouchbaseServerIP, ClusterOptions.clusterOptions(sCouchbaseUserName, sCouchBasePassword).environment(env));
        bucket = cluster.bucket(bucketName);
        Serenity.getCurrentSession().put("CBActiveSession", true);
    }

    public static void closeBucket() {
        if (bucket != null) {
            cluster.disconnect();
            Serenity.getCurrentSession().put("CBActiveSession", false);
            Serenity.getCurrentSession().put("CBEntityActiveSession", false);
            cluster = null;
            bucket = null;
        }
    }

    public static QueryResult executeCBQuery(String query) throws Exception {
        System.out.println("***Before before bucket");
        return executeCBQuery(query, false);
    }

    public static QueryResult executeCBQuery(String query, boolean isEntityCaseManagementBucket) {
        Logger.info("Executing CB: " + query);
        QueryResult caseInformationResult = null;
        try {
            System.out.println("***Before bucket");
            openBucket();
            caseInformationResult = cluster.query(query);
        } catch (Exception e) {
            e.printStackTrace();
            Logger.info("Exception while executing CouchBase query");
        }
        return caseInformationResult;
    }

    public static Map<String, List<String>> executeCouchBaseQuery(String query) throws Exception {
        QueryResult caseInformationResult = executeCBQuery(query);
        int rowcount = caseInformationResult.rowsAsObject().size();
        List<JsonObject> result = caseInformationResult.rowsAsObject();
        Map<String, List<String>> map = new HashMap<String, List<String>>();
        for (int i = 0; i < rowcount; i++) {
            //check for value
            JsonObject CouchbaseQueryDocument = result.get(i);
            Map<String, Object> flattenMap_CouchbaseQuery = JsonFlattener
                    .flattenAsMap(CouchbaseQueryDocument.toString());
            ArrayList<String> list;
            for (Map.Entry<String, Object> entry : flattenMap_CouchbaseQuery.entrySet()) {
                Logger.info("Key = " + entry.getKey() + ", Value = " + entry.getValue().toString());
                if (map.containsKey(entry.getKey())) {
                    list = (ArrayList<String>) map.get(entry.getKey());
                    list.add((String) entry.getValue().toString().replace("[", "").replace("]", ""));
                } else {
                    list = new ArrayList<String>();
                    list.add((String) entry.getValue().toString().replace("[", "").replace("]", ""));
                    map.put(entry.getKey(), list);
                }
            }
        }
        return map;
    }

    public static String executeCouchBaseQueryReturnResultInJSON(String query) throws Exception {
        QueryResult caseInformationResult = executeCBQuery(query);
        String dbResult;
        if (caseInformationResult.rowsAsObject().size() > 0) {
            String result = ((ArrayList) ((QueryResult) caseInformationResult).rowsAsObject()).get(0).toString();
            dbResult = String.valueOf(result);
        } else {
            dbResult = "0 result";
        }
        Allure.addAttachment("DBResult", dbResult);
        return dbResult;
    }

    public static String executeCouchBaseQueryReturnFullResult(String query) throws Exception {
        QueryResult caseInformationResult = executeCBQuery(query);
        String dbResult;
        if (caseInformationResult.rowsAsObject().size() > 0) {
            ArrayList result = ((ArrayList) ((QueryResult) caseInformationResult).rowsAsObject());
            dbResult = String.valueOf(result);
        } else {
            dbResult = "0 result";
        }
        Allure.addAttachment("DBResult", dbResult);
        return dbResult;
    }

    public static void getRowCountCouchBaseQuery(String query) throws Exception {
        QueryResult caseInformationResult = executeCBQuery(query);
        int rowcount = caseInformationResult.rowsAsObject().size();
        List<JsonObject> result = caseInformationResult.rowsAsObject();
        for (int i = 0; i < rowcount; i++) {
            //Check for value
            JsonObject CouchbaseQueryDocument = result.get(i);
            Map<String, Object> flattenMap_CouchbaseQuery = JsonFlattener
                    .flattenAsMap(CouchbaseQueryDocument.toString());
            ArrayList<String> list;
            for (Map.Entry<String, Object> entry : flattenMap_CouchbaseQuery.entrySet()) {
                Logger.info("Key = " + entry.getKey() + ", Value = " + entry.getValue().toString());
                Serenity.getCurrentSession().put("CBRowCount", entry.getValue().toString());
            }
        }
        if (Serenity.getCurrentSession().get("CBActiveSession").equals(true)) {
        }
    }

    public static List<JsonObject> executeCouchBaseQuery1(String query) throws Exception {
        QueryResult caseInformationResult = executeCBQuery(query);
        List<JsonObject> result = caseInformationResult.rowsAsObject();
        return result;
    }

    public static void executeUpdateCouchBaseQuery() throws Exception {
        executeCBQuery("update CaseManagement set caseWeight=\"\" where  caseWeight=1 and documentType='Case'");
        // couchbaseBucket.close();
    }
//    public void queryAndSaveDocumentIDsInSession(String Query, String searchType) {
//        //Logger.info("Select * from CaseManagement where caseId = '" + caseID + "'");
//        QueryResult caseInformationResult = cluster
//                .query(QueryResult(Query), 5, TimeUnit.MINUTES);
//        //.query(N1qlQuery.simple(Query),5,"minutes");
//        List<JsonObject> row = caseInformationResult.rowsAsObject();
//        //check for vallue
//        JsonObject caseDetailsFromQuery = row.get(0);
//        Map<String, Object> flattenMap_caseDetailsFromQuery = JsonFlattener
//                .flattenAsMap(caseDetailsFromQuery.toString());
//        Logger.info("flattenMap_caseDetailsFromQuery       " + flattenMap_caseDetailsFromQuery);
//        if (searchType.equals("case")) {
//            String caseJsonDocumentID = row.get(0).value().getObject("CaseManagement").get("id")
//                    .toString();
//            String paymentJsonDocumentID = row.get(0).value().getObject("CaseManagement")
//                    .getObject("paymentTransaction")
//                    .get("paymentDocumentID").toString();// paymentTransaction.paymentDocumentID
//            Serenity.getCurrentSession().put("caseJsonDocumentID", caseJsonDocumentID);
//            Serenity.getCurrentSession().put("paymentJsonDocumentID", paymentJsonDocumentID);
//        }
//        Serenity.getCurrentSession()
//                .put("flattenMap_caseDetailsFromQuery", flattenMap_caseDetailsFromQuery);
//        Serenity.getCurrentSession().put("caseDetailsFromQuery", caseDetailsFromQuery);
//    }
}