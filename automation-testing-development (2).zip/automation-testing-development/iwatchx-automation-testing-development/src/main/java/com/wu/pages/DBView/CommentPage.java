package com.wu.pages.DBView;

import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class CommentPage extends BasePage {
    public WebElement getCommentTextbox() {

        return browserElementLocator.findElementByXpath("(//input[@ref='eInput'])[10]");
    }

    public WebElement getCommentFilterIcon() {
        return browserElementLocator.findElementByXpath("(//span[@class='ag-icon ag-icon-filter'])[10]");
    }

    public WebElement getCommentFilterTextbox() {
        return browserElementLocator.findElementByXpath("(//input[@ref='eInput'])[13]");
    }
}
