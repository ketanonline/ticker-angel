package com.wu.pages.Pharos.Interdictions;

import org.openqa.selenium.WebElement;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.Locale;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.WebDriver;

public class SwaggerPage extends BasePage {

    public WebElement getMethodBtn(String methodName) {
        methodName=methodName.toLowerCase(Locale.ROOT);
        return browserElementLocator.findElementByXpath("//div[@class='opblock-summary opblock-summary-"+methodName+"']/span[1]");
    }

    public WebElement getMultipleMethodBtn(String methodName) {
        methodName=methodName.toLowerCase(Locale.ROOT);
        System.out.println("****" +methodName);
        String [] methodName1 = methodName.split("_");
        System.out.println("****" +methodName1[0]);
        System.out.println("****" +methodName1[1]);
        System.out.println("(//div[@class='opblock-summary opblock-summary-"+methodName1[0]+"']/span[1])["+methodName1[1]+"]");
        return browserElementLocator.findElementByXpath("(//div[@class='opblock-summary opblock-summary-"+methodName1[0]+"']/span[1])["+methodName1[1]+"]");
    }

    public WebElement clickButton(String btnName) {
        return browserElementLocator.findElementByXpath("//button[contains(text(),'"+btnName+"')]");
    }
    public WebElement entersTenantPrimaryID() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[1]/td[2]/input");
    }
    public WebElement entersSecondaryID() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[2]/td[2]/input");
    }
    public WebElement entersGenre() {
        return browserElementLocator.findElementByXpath("//tr[@data-param-name='x-wu-genre']/td[2]//input");
    }
    public WebElement entersBussGroup() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[3]/td[2]/input");
    }
    public WebElement entersInvesGroup() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[4]/td[2]/input");
    }
    public WebElement entersUserId() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[5]/td[2]/input");
    }
    public WebElement entersEmail() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[6]/td[2]/input");
    }

    public WebElement enterUserName() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[7]/td[2]/input");
    }
    public WebElement entersCorrelationId() {
        return browserElementLocator.findElementByXpath("//div/table/tbody/tr[8]/td[2]/input");
    }
    public WebElement entersId() {
        return browserElementLocator.findElementByXpath("//tr[@data-param-name='id']/td[2]//input");
    }

    public WebElement entersDocRefNo() {
        return browserElementLocator.findElementByXpath("//input[@placeholder='docRefNum']");
    }

    public WebElement enterPageNo() {
        return browserElementLocator.findElementByXpath("//input[@placeholder='pageNo']");
    }
    public WebElement enterCaseID() {
        return browserElementLocator.findElementByXpath("//input[@placeholder='caseId']");
    }

    public WebElement enterProfileID() {
        return browserElementLocator.findElementByXpath("//input[@placeholder='profileId']");
    }

    public WebElement enterJson() {
        return browserElementLocator.findElementByXpath("//div/div/div/textarea");
    }

}
