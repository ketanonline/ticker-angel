package com.wu.pages.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.awt.*;
import java.time.Duration;
import java.util.List;

public class FabIconLabellingPage extends BasePage {

    public WebElement getAttachmentIconLabel() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'attach_file')]//parent::span//parent::button//parent::div//mat-chip");
    }

    public WebElement getShortcutIconLabel() {
        return browserElementLocator.findElementByXpath("//div[contains(@class,'wu-menu-list-items')]/div[2]/mat-chip");    }

    public WebElement getCustomerOutreachIconLabel() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'perm_phone_msg')]//parent::span//parent::button//parent::div//mat-chip");
    }

    public WebElement getStopIconLabel() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'pan_tool')]//parent::span//parent::button//parent::div//mat-chip");
    }

    public WebElement getAuditIconLabel() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'format_list_bulleted')]//parent::span//parent::button//parent::div//mat-chip");
    }

    public List<WebElement> getAllIcons() {
        return browserElementLocator.findElementsByXpath("//mat-chip[@role='option']");
    }

    public WebElement getCrossIcon() {
        return browserElementLocator.findElementByXpath("//mat-icon[text()='add']");
    }

    public WebElement getMenuPanel(){
        return browserElementLocator.findElementByXpath("//div[@class='wu-expander-wrapper']");
    }

    public WebElement getExpanderStatus(){
        return browserElementLocator.findElementByXpath("//div[@class='wu-expander-wrapper']/div/button/mat-icon");
    }

    public WebElement getButtonFromMenu(String button){
        return browserElementLocator.findElementByXpath("//div[@class='wu-expander-wrapper']/div/ul/li/span[contains(text(),'"+button+"')]");
    }

    public WebElement getTrigPanel(){
        return browserElementLocator.findElementByXpath("//span[@class='wu-sidebar-title']");
    }

    public WebElement getPanelClose(){
        return browserElementLocator.findElementByXpath("(//span/mat-icon[text()='close'])");
    }

    public WebElement getCollapseButton(){
        return browserElementLocator.findElementByXpath("//button/mat-icon");
    }

    public WebElement getHelpIcon(){
        return browserElementLocator.findElementByXpath("//span/mat-icon[text()='help_outline']");
    }

    public WebElement getShortcutsWindow(){
        return browserElementLocator.findElementByXpath("//span[text()='Shortcuts ']");
    }

    public void dragExpanderMenuValidation() throws AWTException, InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        WebElement Sourcelocator= getExpanderStatus();
//        WebElement Destinationlocator = browserElementLocator.findElementByXpath("(//div[@class='wu-country-flag']/span[1])[2]");

        action.moveToElement(Sourcelocator)
                .pause(Duration.ofSeconds(1))
                .clickAndHold(Sourcelocator)
                .pause(Duration.ofSeconds(1))
                .moveByOffset(0,50)
                .moveByOffset(0,50)
                .pause(Duration.ofSeconds(1))
                .release().build().perform();

//        action.moveToElement(Sourcelocator)
//                .pause(Duration.ofSeconds(1))
//                .clickAndHold(Sourcelocator)
//                .pause(Duration.ofSeconds(1))
//                .moveToElement(Destinationlocator)
//                .pause(Duration.ofSeconds(1))
//                .release().build().perform();

//        Point coordinates1 = Sourcelocator.getLocation();
//        Point coordinates2 = Destinationlocator.getLocation();
//        Robot robot = new Robot();
//        robot.mouseMove(coordinates1.getX(), coordinates1.getY());
//        robot.mousePress(InputEvent.BUTTON1_MASK);
//        robot.mouseMove(coordinates2.getX(), coordinates2.getY());
//        robot.mouseRelease(InputEvent.BUTTON1_MASK);

//        action.clickAndHold(Sourcelocator);
//        System.out.println("click and hold");
//        action.moveToElement(Destinationlocator);
//        System.out.println("move");
//        action.release(Destinationlocator);
//        System.out.println("release");
    }

}
