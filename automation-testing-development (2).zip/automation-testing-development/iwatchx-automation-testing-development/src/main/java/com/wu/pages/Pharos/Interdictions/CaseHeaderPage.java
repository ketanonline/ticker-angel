package com.wu.pages.Pharos.Interdictions;

import com.wu.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class CaseHeaderPage extends BasePage {

    public WebElement getPhaseData() {
        return browserElementLocator.findElementByXpath("//div[@id='cdk-accordion-child-0']/div/div[1]/div[1]/p");
    }

    public WebElement getMTCN_CaseHeader() {
        return browserElementLocator.findElementByXpath("//div[@id='wu-branding-left']");
    }

    public WebElement getBrand_CaseHeader() {
        return browserElementLocator.findElementByXpath("//h2[@class='wu-brand-name']");
    }

    public WebElement getCaseHeaderExpander() {
        return browserElementLocator.findElementByXpath("//mat-expansion-panel-header[contains(@id,'mat-expansion-panel-header')]/span[2]");
    }

    public void clickOnCaseHeader() {
        getCaseHeaderExpander().click();
    }

    public String getPhaseInCaseHeader()
    {
        return getPhaseData().getText().trim();
    }
    public WebElement getTierValue(String tier){
        return browserElementLocator.findElementByXpath("//div[contains(text(),'"+tier+"')]");
    }

    public void MyqueueButton() {
        getMyqueueButton().click();
    }

    private WebElement getMyqueueButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'assignment')]");
    }
}
