package com.wu.pages.Pharos.Interdictions;

import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.pages.BasePage;
import com.wu.utils.AutProperties;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class OpenSearchPage extends BasePage {
    BaseTestSetup baseTestSetup=new BaseTestSetup();

    public WebElement getOpensearchTile(){
        return browserElementLocator.findElementByXpath("//img[@alt='Opensearch  Dev logo']");
    }

    public void switchToSecondTab(){
        // Keys.Chord string
        String clickl = Keys.chord(Keys.CONTROL,Keys.ENTER);
        // switch tabs
        baseTestSetup.switchTabsInBrowser();
    }

    public WebElement getCustomDropdown(){
        return browserElementLocator.findElementByXpath("//div[contains(@class,'euiFormControlLayoutIcons')]/button");
    }

    public WebElement getComplianceOption(){
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Compliance')]");
    }

    public WebElement getConfirmButton(){
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Confirm')]");
    }

    public WebElement getOpensearchMenu(){
        return browserElementLocator.findElementByXpath("//span[@class='euiHeaderSectionItemButton__content'][1]");
    }

    public WebElement getDiscoverLink(){
        return browserElementLocator.findElementByXpath("//span[@title='Discover']");
    }

    public WebElement getDiscoverDropDown(){
        return browserElementLocator.findElementByXpath("(//span[@class='euiButtonEmpty__text'])[14]");
    }

    public WebElement getFilterSearch(){
        return browserElementLocator.findElementByXpath("(//input[@type='search'])[2]");
    }

    public WebElement getLogsQA(){
        return browserElementLocator.findElementByXpath("//span[contains(text(),'compliance-iwatchx-qa-*')]");
    }

    public WebElement getLogsUAT(){
        return browserElementLocator.findElementByXpath("//span[contains(text(),'compliance-iwatchx-uat-*')]");
    }

    public WebElement getSearchBar(){
        return browserElementLocator.findElementByXpath("//textarea");
    }

    public WebElement getFilterOption(String option){
        String optionxpath ="//button[@data-test-subj='fieldToggle-"+option+"']";
        return browserElementLocator.findElementByXpath(optionxpath);
    }

    public WebElement getCountTextFromLogs(){
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Total cases found with action failures in DB:')]");
    }

    public void moveToFilter(String option){
        String xpath="//span[@title='"+option+"']";
        WebElement optionelement= browserElementLocator.findElementByXpath(xpath);
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.moveToElement(optionelement).click().perform();
    }

}
