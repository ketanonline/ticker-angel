package com.wu.pages.Pharos.Interdictions;

import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.pages.BasePage;
import com.wu.utils.AutProperties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class RTRAPage extends BasePage {

    public void entersUidAndPwdForRTRASignInenvironment(String environment) throws InterruptedException {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String RTRAUserName = CommonFunctions.readFile(fileName, "RTRAUserName_" + environment);
        String RTRAPassword = CommonFunctions.readFile(fileName, "RTRAPassword_" + environment);
        System.out.println("*********" + RTRAPassword);
        getRTRAUserNameTextbox().sendKeys(RTRAUserName);
        getRTRAPasswordTextbox().sendKeys(RTRAPassword);
        getRTRASubmitButton().click();
        Thread.sleep(9000);
    }

    public WebElement getRTRASubmitButton() {
        return browserElementLocator.findElementByXpath("//input[@type='submit']");
    }

    public WebElement getRTRAPasswordTextbox() {
        return browserElementLocator.findElementByXpath("//input[@id='password']");
    }

    public WebElement getRTRAUserNameTextbox() {
        return browserElementLocator.findElementByXpath("//input[@id='userId']");
    }

    public void clickOnTransactionViewer() {
        getclickOnTransactionViewer().click();
    }

    public WebElement getclickOnTransactionViewer() {
        return browserElementLocator.findElementByXpath("//a[1]/span[contains(text(),'Transaction Viewer')]");
    }

    public void ClickOnEntityClearing() {
        getClickOnEntityClearing().click();
    }

    private WebElement getClickOnEntityClearing() {
        return browserElementLocator.findElementByXpath("//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']/span[contains(text(),'Entity Clearing')]");
    }

    public void ClickOnRevertEntityClearing() {
        getClickOnRevertEntityClearing().click();
    }

    public WebElement getClickOnRevertEntityClearing() {
       return browserElementLocator.findElementByXpath("//a[@class='ui-menuitem-link ui-corner-all']/span[contains(text(),'Revert Entity Clearing')]");
    }

//    public void enterGalacticIDSearchTextBox(String inputText) {
//            browserTextBox.sendKeys(getCaseIdInputBox(), inputText);
//
//    }


    private WebElement getCaseIdInputBox() {
        return browserElementLocator.findElementByXpath("//body[1]/div[5]/form[1]/div[1]/span[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[2]/textarea[1]");
    }
    public void enterGalacticIDSearchTextBox(String inputText) {
        browserTextBox.sendKeys(getGIdInputBox(), inputText);

    }


    public WebElement getGIdInputBox() {
        return browserElementLocator.findElementByXpath("//input[@formcontrolname='gId']");
    }


    public void ClickOnEntityClearingReasons() {
        getClickOnEntityClearingReasons().click();
    }

    public WebElement getClickOnEntityClearingReasons() {
        return browserElementLocator.findElementByXpath("//body[1]/div[5]/form[1]/div[1]/span[1]/div[1]/div[2]/table[1]/tbody[1]/tr[6]/td[2]/div[1]/div[3]/span[1]");
    }

    public void ClickOnRevertEntityClearingReasons() {
        getClickOnRevertEntityClearingReasons().click();
    }

    public WebElement getClickOnRevertEntityClearingReasons() {
        return browserElementLocator.findElementByXpath("//body[1]/div[10]/div[1]/ul[1]/li[contains(text(),'AML Ops - QA Review')]");
    }

    public void ClickOnEntityClearingsubmit() {
        getClickOnEntityClearingsubmit().click();
    }

    private WebElement getClickOnEntityClearingsubmit() {
        return browserElementLocator.findElementByXpath("//body[1]/div[5]/form[1]/div[1]/span[1]/div[1]/div[2]/table[1]/tbody[1]/tr[9]/td[2]/button[1]/span[contains(text(),'Submit')]");
    }

    public void ClickOnEntityClearingsubmitoption() {
        getClickOnEntityClearingsubmitoption().click();
    }

    private WebElement getClickOnEntityClearingsubmitoption() {
        return browserElementLocator.findElementByXpath("//body[1]/div[5]/form[1]/div[1]/span[1]/div[1]/div[2]/div[1]/div[3]/button[1]/span[contains(text(),'Yes')]");
    }

    public void MouseoverOnEntityClearing() {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        WebElement element = webDriver.findElement(By.xpath("//a[@class='ui-menuitem-link ui-submenu-link ui-corner-all']/span[contains(text(),'Entity Clearing')]"));
        Actions act = new Actions(webDriver);
        act.moveToElement(element).perform();
    }
}
