package com.wu.pages.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import com.wu.utils.CommonUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.List;

public class CaseAttachmentPage extends BasePage {

    public WebElement getDueDate() {
        return browserElementLocator.findElementByXpath("//div[contains(text(),'Due Date:')]//following::div[1]");
    }

    public WebElement getExpandElementFromFirstAttachment() {
        return browserElementLocator.findElementByXpath("(//div[@class='wu-attachment-box ng-star-inserted']//following::div)[1]");
    }

    public WebElement getTextUploadTime() {
        return browserElementLocator.findElementByXpath("//div[@class='wu-attachment-author ng-star-inserted']//span[2]");
    }

    public WebElement getPlusButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'add')]");
    }

    public WebElement getAttachmentButton() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'attach_file')]");
    }

    public WebElement getAttachmentPanelTitle() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Attachments')]");
    }

    public WebElement getAttachmentCount() {
        return browserElementLocator.findElementByXpath("//app-sidebar//span[@class='wu-sidebar-title']//span");
    }

    public WebElement getUploadAttachmentPanelTitle() {
        return browserElementLocator.findElementByXpath("//strong[contains(text(),'New Upload')]");
    }

    public WebElement getNewUploadSectionCollapseArrow() {
        return browserElementLocator.findElementByXpath("//div[@class='wu-attachment-upload']//mat-icon[contains(text(),'keyboard_arrow_down')]");
    }

    public WebElement getNewUploadSectionExpandArrow() {
        return browserElementLocator.findElementByXpath("//div[@class='wu-attachment-upload']//mat-icon[contains(text(),'keyboard_arrow_up')]");
    }

    public WebElement getUploadAttachmentPanelCloseButton() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Attachments ')]//following::button//following::mat-icon[contains(text(),'close')][1]");
    }

    public WebElement getAttachmentTypeDropDown() {
        return browserElementLocator.findElementByXpath("//select[@formcontrolname='type']");
    }

    public WebElement getToggle() {
        return browserElementLocator.findElementByXpath("//div[contains(@class,'wu-attachment-case-profile')]");
    }

    public WebElement getAttachmentSubTypeDropDown() {
        return browserElementLocator.findElementByXpath("//select[@formcontrolname='subtype']");
    }

    public WebElement getVisibilityDropDown() {
        return browserElementLocator.findElementByXpath("//select[@formcontrolname='visibility']");
    }

    public WebElement getAttachmentCommentInputBox() {
        return browserElementLocator.findElementByXpath("//textarea[@formcontrolname='comment']");
    }

    public WebElement getAttachmentUploadBrowseLink() {
        return browserElementLocator.findElementByXpath("//span[@class='wu-upload-input-browse']");
    }

    public WebElement getUploadedAttachmentDocumentsPanel() {
        return browserElementLocator.findElementByXpath("//div[@class='attachment-box ng-star-inserted']");
    }

    public WebElement getToaster() {
        return browserElementLocator.findElementByXpath("//*[@id='cdk-describedby-message-container']");
    }

    public WebElement getAttachmentLink() {
        return browserElementLocator.findElementByXpath("(//div[contains(@class,'wu-attachment-link')])[1]/a");
    }

    public WebElement getAttachmentWindow() {
        return browserElementLocator.findElementByXpath("//app-file-preview-overlay");
    }

    public WebElement closeattachment() throws InterruptedException {
        Thread.sleep(1000);
        return browserElementLocator.findElementByXpath("//div[@class='wu-container']/app-window-header/div/span/button[3]/span/mat-icon[contains(text(),'close')]");
    }

    public WebElement getImage() {
        return browserElementLocator.findElementByXpath("//img[@alt='attachmentFile.name']");
    }

    public WebElement getAttachmentpanel(){
        return browserElementLocator.findElementByXpath("//span[@class='wu-sidebar-title']");
    }


    public WebElement getCloseAttachemetIcon() throws InterruptedException {
        Thread.sleep(1000);
        return browserElementLocator.findElementByXpath("//div[@class='app-sidebar']/div/div[2]/button[2]/span/mat-icon");
    }

    public String getCountAttachment() {
        String text = getAttachmentCount().getText();
        String count = text.replaceAll("\\p{P}", "");
        return count;
    }

    public WebElement getUploadFileInput() {
        return browserElementLocator.findElementByXpath("//input[@class='wu-files-input']");
    }


    private WebElement getUploadAttachmentButton() {
        return browserElementLocator.findElementByXpath("//span[contains(text(),'Upload')]");
    }

    public void uploadFile(String fileName) throws InterruptedException, AWTException {
        Thread.sleep(2000);
        getUploadFileInput().sendKeys(new File(CommonUtils.getResourcePath("filestoupload") + File.separator + fileName).getAbsolutePath());
        WebElement element = BaseTestSetup.webDriver.findElement(By.className("wu-files-input"));
        element.sendKeys(new File(CommonUtils.getResourcePath("filestoupload") + File.separator + fileName).getAbsolutePath());
        Thread.sleep(2000);
//        Robot robot = new Robot();
//        robot.keyPress(KeyEvent.VK_ESCAPE);
//        robot.keyRelease(KeyEvent.VK_ESCAPE);
        Thread.sleep(1000);
    }

    public void clickOnPlusButton() {
        getPlusButton().click();
    }

    public void clickOnAttachmentButton() {
        getAttachmentButton().click();
    }

    public void verifyAttachmentPanelShouldOpen(String attachmentPanelTitle) throws InterruptedException {
        Thread.sleep(5000);
        Logger.info(getAttachmentPanelTitle().getText());
        if (getAttachmentPanelTitle().getText().contains(attachmentPanelTitle)) {
            Logger.info("Attachment panel opened");
        }
//        Assert.assertEquals(getAttachmentPanelTitle().getText(), attachmentPanelTitle, "Attachment Panel not opened");
    }

    public void verifyUploadAttachmentPanelShouldOpen() {
        Assert.assertEquals(getUploadAttachmentPanelTitle().getText(), "New Upload", "Upload Attachment Panel not opened");

    }

    public void selectAttachmentType(String attachmentType) throws  Exception{
//        Select type = new Select(getAttachmentTypeDropDown());
//        type.selectByVisibleText(attachmentType);
//        getAttachmentTypeDropDown().sendKeys(attachmentType);

        BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='type']")).click();
        Thread.sleep(2000);
        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//mat-option//span[contains(text(),'"+attachmentType+"')]"));
        System.out.println("******" +drpdwnValue);
        Thread.sleep(2000);
        drpdwnValue.click();
    }

    public void selectAttachmentSubType(String attachmentSubType) {
//        Select stype = new Select(getAttachmentSubTypeDropDown());
//        stype.selectByVisibleText(attachmentSubType);
        BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='subtype']")).click();
        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//mat-option//span[contains(text(),'"+attachmentSubType+"')]"));
        drpdwnValue.click();
    }

    public void selectVisibility(String visibility) throws Exception{
//        Select visible = new Select(getVisibilityDropDown());
//        java.util.List<WebElement> options = visible.getOptions();
//        for (WebElement web : options) {
//            if (web.getText().contains("Public")) {
//                Logger.info("Visibility option Public found");
//            } else if (web.getText().contains("Genre")) {
//                Logger.info("Visibility option Genre found");
//
//            } else if (web.getText().contains("Business Group")) {
//                Logger.info("Visibility option Business Group found");
//
//            } else if (web.getText().contains("Restricted")) {
//                Logger.info("Visibility option Restricted found");
//
//            }
//        }
//        visible.selectByVisibleText(visibility);

        BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='visibility']")).click();
        Thread.sleep(2000);
        WebElement drpdwnValue = BaseTestSetup.webDriver.findElement(By.xpath("//span[contains(text(),'"+visibility+"')]"));
        drpdwnValue.click();
    }

    public void addComments(String comments) {
        getAttachmentCommentInputBox().sendKeys(comments);
    }

    public void clickUploadBrowseLink() {
        getAttachmentUploadBrowseLink().click();
        Logger.info("Analyst clicked dropbox to browse file to be uploaded");
    }

    public void clickOnUploadAttachmentButton() throws InterruptedException {

        javaScriptExecutor.clickElementAfterFocus(getUploadAttachmentButton(), true);
//        getUploadAttachmentButton().click();
    }

    public void verifyUploadedAttachment(String attachmentLink) throws InterruptedException {
        // Verify name
//        Assert.assertEquals(getAttachmentLink().getText(), attachmentLink, "Not expected attachment link");

        // Verify Link
        Thread.sleep(4000);
        Logger.info("Attachment link name is : " + getAttachmentLink().getText());
        Assert.assertEquals(getAttachmentLink().getText(), attachmentLink, "Not expected attachment link");

    }

    public void userClicksOnAttachmentPanel() throws InterruptedException {
        getAttachmentLink().click();
        Logger.info("Analyst clicks on the latest uploaded attachment.");
    }

    public void userClicksOnAllAttachments() throws InterruptedException {
        List<WebElement> attachmentLinks = browserElementLocator.findElementsByXpath("(//div[contains(@class,'wu-attachment-link')])/a");
        Logger.info("Number of attachments present : "+attachmentLinks.size());
        for(int i=1;i<=attachmentLinks.size();i++) {
            WebElement attachLink = browserElementLocator.findElementByXpath("(//div[contains(@class,'wu-attachment-link')])[" + i + "]/a");
            Actions action = new Actions(BaseTestSetup.webDriver);
            action.moveToElement(attachLink).click().perform();
//            WebElement source = browserElementLocator.findElementByXpath("(//div[contains(@id,'windowContainer')]["+i+"]/div)[1]");
//            WebElement target = browserElementLocator.findElementByXpath("(//div[@class='wu-hits']/div[1]//button[1])["+(i+3)+"]");
//            javaScriptExecutor.executeScriptMove(source);
            //executor.executeScript("arguments[0].setAttribute('style', 'left: 227px; top: 334px; width: 561px; height: 392px; z-index: 801637');", notesWindow);
            //browserElements.dragAndDrop(source,target);
            Logger.info("Analyst opens attachment : "+i);
            Thread.sleep(1000);
        }
    }

    public void userClicksOnAttachmentFromProfile() throws InterruptedException {
        browserElementLocator.findElementByXpath("(//app-profile-attachment-view/div/div//a)[1]").click();
        Logger.info("Analyst open the attachment from the profile view");
        Thread.sleep(1000);
    }

    public void userClicksOnAllProfileAttachments() throws InterruptedException {
        List<WebElement> proAttachmentLinks = browserElementLocator.findElementsByXpath("//app-profile-attachment-view/div/div//a");
        Logger.info("Number of attachments present : "+proAttachmentLinks.size());
        for (int i = 1; i <= proAttachmentLinks.size(); i++) {
            browserElementLocator.findElementByXpath("(//app-profile-attachment-view/div/div//a)[" + i + "]").click();
            Logger.info("Analyst opens attachment from profile: " + i);
            Thread.sleep(1000);
        }
    }

    public void userClicksOnMinimize() throws InterruptedException {
        browserElementLocator.findElementByXpath("//div[contains(@id,'windowContainer')]//span[2]/button[1]/span/mat-icon").click();
        Logger.info("Analyst verifies minimize button of the attachment.");
        Thread.sleep(1000);

    }


    public void userClicksOnMaximize() throws InterruptedException {
        browserElementLocator.findElementByXpath("//div[contains(@id,'windowContainer')]//span[2]/button[2]/span/mat-icon").click();
        Thread.sleep(1000);
        Logger.info("Analyst verifies maximize button of the attachment.");

    }

    public void userClicksOnZoomInButton() throws InterruptedException {
        for(int c=1; c<3; c++) {
            browserElementLocator.findElementByXpath("//button/span/mat-icon[contains(text(),'zoom_in')]").click();
            Thread.sleep(1000);
            Logger.info("Analyst verifies zoom in button of the attachment.");
        }
    }

    public void userClicksOnZoomOutButton() throws InterruptedException {
        for(int c=1; c<3; c++) {
            browserElementLocator.findElementByXpath("//button/span/mat-icon[contains(text(),'zoom_out')]").click();
            Thread.sleep(1000);
            Logger.info("Analyst verifies zoom out button of the attachment.");
        }

    }

    public void userClicksOnCloseButton() throws InterruptedException {
        browserElementLocator.findElementByXpath("//div[contains(@id,'windowContainer')]//span[2]/button[3]/span/mat-icon").click();
        Thread.sleep(1000);
        Logger.info("Analyst verifies close button of the attachment.");

    }


    public void verifyUploadBtnEnabled() {
        Assert.assertTrue(getUploadAttachmentButton().isEnabled(), "Upload button is verified");
    }

//    -------------------------------------------------------------------------------------------------------------------------


    public java.util.List<WebElement> getTypeDrpDownValues() {
        //return browserElementLocator.findElementsByXpath("//div[@class='mat-form-field-infix ng-tns-c152-26']/select/option");
        return browserElementLocator.findElementsByXpath("//select[@formcontrolname='type']/option");
    }

    public java.util.List<WebElement> getsubTypeDrpDownValues() {
        return browserElementLocator.findElementsByXpath("//select[@formcontrolname='subtype']/option");
    }

    public java.util.List<WebElement> getVisibilityDrpDownValues() {
        return browserElementLocator.findElementsByXpath("//select[@formcontrolname='visibility']/option");
    }


    public void clickTypeDropDown() {
        getAttachmentTypeDropDown().click();
    }

    public void clickOnVisbibilityDd() {
        getVisibilityDropDown().click();
    }


    public boolean typeDropDownValidation(java.util.List<String> details) {


        java.util.List<WebElement> iWtcXDrpDwn = getTypeDrpDownValues();
        String[] actualDrpDownValues = new String[details.size()];

        for (int i = 0; i < iWtcXDrpDwn.size(); i++) {

            String drpdownValue = iWtcXDrpDwn.get(i).getAttribute("value");
            System.out.println("Dropdown values from the iWatchX application:" + drpdownValue);
            actualDrpDownValues[i] = drpdownValue;

        }

        //Creating a string Array to Story the input values given in the Feature File. Dynamically the String array is created.
        String inputValues[] = new String[details.size()];
        for (int j = 0; j < details.size(); j++) {
            inputValues[j] = details.get(j);
            System.out.println("Given input Values:" + inputValues[j]);
        }
        Logger.info("All the input Values are stored in the input Values Array");

        //This for loop is to check if both the inputValues & actual values are matching.
        for (int i = 0; i < inputValues.length; i++) {
            if (!inputValues[i].equals(actualDrpDownValues[i]))

                return false;
        }

        return true;
    }

    public void selectTypeOnNewUplForm(String type) {

        Select typeValue = new Select(getAttachmentTypeDropDown());

        switch (type) {
            case "Letter of Explanation":
                typeValue.selectByValue("Letter of Explanation");
                Logger.info("Letter of Explanation is selected");
                break;

        }

    }

    public boolean subTypeDropDownValidation(java.util.List<String> subTypes) {

        String[] actualDrpDownValues = new String[subTypes.size()];

        java.util.List<WebElement> iWtcXDrpDwn = getsubTypeDrpDownValues();

        for (int i = 0; i < iWtcXDrpDwn.size(); i++) {

            String drpdownValue = iWtcXDrpDwn.get(i).getAttribute("value");
            System.out.println("Dropdown values from the iWatchX application:" + drpdownValue);
            actualDrpDownValues[i] = drpdownValue.trim();
        }

        //Creating a string Array to Story the input values given in the Feature File. Dynamically the String array is created.
        String inputValues[] = new String[subTypes.size()];
        for (int j = 0; j < subTypes.size(); j++) {
            inputValues[j] = subTypes.get(j);
            System.out.println("Given input Values:" + inputValues[j]);
        }
        Logger.info("All the input Values are stored in the input Values Array");

        //This for loop is to check if both the inputValues & actual values are matching.
        for (int i = 0; i < inputValues.length; i++) {
            if (!inputValues[i].equals(actualDrpDownValues[i]))
                return false;
        }

        return true;
    }

    public boolean visibilityDropdwnValidation(java.util.List<String> visibilityList) {

        String[] actualDrpDownValues = new String[visibilityList.size()];

        List<WebElement> iWtcXDrpDwn = getVisibilityDrpDownValues();

        for (int i = 0; i < iWtcXDrpDwn.size(); i++) {
            String drpdownValue = iWtcXDrpDwn.get(i).getText();
            System.out.println("Dropdown values from the iWatchX application:" + drpdownValue);
            actualDrpDownValues[i] = drpdownValue.trim();
        }

        //Creating a string Array to Story the input values given in the Feature File. Dynamically the String array is created.
        String inputValues[] = new String[visibilityList.size()];
        for (int j = 0; j < visibilityList.size(); j++) {
            inputValues[j] = visibilityList.get(j);
            System.out.println("Given visibility Values:" + inputValues[j]);
        }
        Logger.info("All the visibility Values are stored in the input Values Array");

        //This for loop is to check if both the inputValues & actual values are matching.
        for (int i = 0; i < inputValues.length; i++) {
            if (!inputValues[i].equals(actualDrpDownValues[i]))
                return false;
        }

        return true;
    }


    public void pressESCkey() {
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.sendKeys(Keys.ESCAPE);
    }

    public String getAttachmentTimeFieldFromPanel() {
        return getTextUploadTime().getText();
    }

    public void expandFirstAttachment() {
        getExpandElementFromFirstAttachment().click();
    }

    public boolean visibilityDropDownValidation(java.util.List<String> visibilityList) {

        String[] actualDrpDownValues = new String[visibilityList.size()];

        List<WebElement> iWtcXDrpDwn = getVisibilityDrpDownValues();

        for (int i = 0; i < iWtcXDrpDwn.size(); i++) {
            String drpdownValue = iWtcXDrpDwn.get(i).getText();
            System.out.println("Dropdown values from the iWatchX application:" + drpdownValue);
            actualDrpDownValues[i] = drpdownValue.trim();
        }

        //Creating a string Array to Story the input values given in the Feature File. Dynamically the String array is created.
        String inputValues[] = new String[visibilityList.size()];
        for (int j = 0; j < visibilityList.size(); j++) {
            inputValues[j] = visibilityList.get(j);
            System.out.println("Given visibility Values:" + inputValues[j]);
        }
        Logger.info("All the visibility Values are stored in the input Values Array");

        //This for loop is to check if both the inputValues & actual values are matching.
        for (int i = 0; i < inputValues.length; i++) {
            if (!inputValues[i].equals(actualDrpDownValues[i]))
                return false;
        }

        return true;
    }

    public void getProfileViewIcon() throws InterruptedException {
        Thread.sleep(1000);
        WebElement profileViewIcon = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'person')])[2]"));
        profileViewIcon.click();
        Thread.sleep(2000);
    }

    public void analystVerifyProfileAttachmentIsPresentOrNot(String presentNotPresent) {
        WebElement ProfileAttachment = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='app-profile-attachment']"));
        if (presentNotPresent.equalsIgnoreCase("present")) {
            if (ProfileAttachment.isDisplayed()) {
                Assert.assertTrue(ProfileAttachment.isDisplayed(), "ProfileAttachment is  present");
            }
        }
    }


    public void verifyErrorMessage(String msg){
        Assert.assertEquals(getErrorLink().getText(),"Pharos cannot open this document. Please use DMS.","Attachment Error message not found");
        Logger.info("Pharos cannot open this document. Please use DMS message is displayed");
    }
    public WebElement getErrorLink(){
        return browserElementLocator.findElementByXpath("(//div[contains(@class,'wu-attachment-box')]/div/div)[1]");
    }

    public void verifyErrorToasterMessage(String msgtoaster){
        Assert.assertEquals(getToasterLink().getText(),msgtoaster,"Attachment Error message not found");
        Logger.info("Unable to retrieve profile attachment. Please retry. - message is displayed");

    }

    public WebElement getToasterLink(){
        return browserElementLocator.findElementByXpath("//*[@class='cdk-overlay-container']/div/div/snack-bar-container/div/div/simple-snack-bar/span");
    }
}
