package com.wu.base;

/**
 * @author vivek_lande
 */

public class TestGroup {

    // --------- Test Groups Based On Priority --------//
    public static final String P1 = "P1";
    public static final String P2 = "P2";
    public static final String P3 = "P3";
    public static final String BAT = "BAT";
    public static final String REGRESSION = "REGRESSION";

    // --------- Test Groups Based On Component --------//
}
