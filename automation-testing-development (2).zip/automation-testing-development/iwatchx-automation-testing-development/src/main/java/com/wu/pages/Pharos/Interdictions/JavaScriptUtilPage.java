package com.wu.pages.Pharos.Interdictions;

import com.wu.pages.BasePage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class JavaScriptUtilPage extends BasePage{



    public static void  flash(WebElement element,WebDriver webDriver){
        JavascriptExecutor je =((JavascriptExecutor) webDriver);
        String bgcolor = element.getCssValue("backgroundColor");
        for (int i=0;i<500;i++){
            changeColor("#0000000", element,webDriver);//1
            changeColor("bgcolor", element,webDriver);//1
        }
    }
    public static void changeColor(String color, WebElement element, WebDriver webDriver) {
        JavascriptExecutor je = ((JavascriptExecutor) webDriver);
        je.executeScript("arguments[0].style.backgroundColor'" + color, element);

        try {
            Thread.sleep(20);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
    public static void drawboarder(WebElement element,WebDriver webDriver){
        JavascriptExecutor je= ((JavascriptExecutor) webDriver);
        je.executeScript("arguments[0].style.border= 3px solid red'",element);
    }


}

