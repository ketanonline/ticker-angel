package com.wu.pages.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import cucumber.api.java.en.When;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;

public class CaseDispositionControlPage extends BasePage {

    public WebElement getWarningIcon() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(@class,'mat-icon notranslate orange-fg wu-action-workflow-icon')]");
    }

    public WebElement getDurationDropdown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='duration']");
    }

    public WebElement getPendTab() {
        return browserElementLocator.findElementByXpath("//div[contains(text(),'Pend')]");
    }

    public WebElement getReasonDropdown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='reason']");
    }

    public WebElement getWorkFlow() {
        return browserElementLocator.findElementByXpath("//div[contains(@class,'wu-case-stages')][2]");
    }


    public WebElement getPendWorkFlow() {
        return browserElementLocator.findElementByXpath("(//div[contains(@class,'wu-workflow-node')])[2]");
    }

    public WebElement getDueDate() {
        return browserElementLocator.findElementByXpath("//div[contains(text(),'Due Date:')]//following::div[1]");
    }

    public WebElement getCaseSubmitToggleBtn() {
        return browserElementLocator.findElementByXpath("//div[@role='tab']//div[contains(.,'Submit')]");
    }

    public WebElement getFabIcon() {
        return browserElementLocator.findElementByXpath("//mat-icon[contains(text(),'pan_tool')]//parent::span//parent::button");
    }

    public WebElement getSelectPendDurationDropDownOption(String option) {
        return browserElementLocator.findElementByXpath("//mat-option//span[contains(text(),'" + option + "')]");
    }

    public WebElement getPendButton() {
        return browserElementLocator.findElementByXpath("//button[@type='submit']");
    }

    public WebElement getSelectPendDropDownOption(String option) {
        return browserElementLocator.findElementByXpath("//mat-option//span[contains(text(),'" + option + "')]");
    }

    public WebElement getSelectPendDropDown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='reason']");
    }

    public WebElement getSelectPendDurationDropDown() {
        return browserElementLocator.findElementByXpath("//mat-select[@formcontrolname='duration']");
    }

    public WebElement getPendCaseToggleBtn() {
        return browserElementLocator.findElementByXpath("//div[@role='tab']//div[contains(.,'Pend')]");
    }

    public WebElement getActionWorkFlowText() {
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.moveToElement(browserElementLocator.findElementByXpath("//div[@class='wu-action-workflow-div wu-flex-direction-row wu-flex-stretch-start']")).build().perform();
        return browserElementLocator.findElementByXpath("//div[@class='wu-action-workflow-div wu-flex-direction-row wu-flex-stretch-start']");
    }

    public List getBuckets() {
        return browserElementLocator.findElementsByXpath("//mat-button-toggle//following::span[@class='wu-investigation-card-button-badge']");
    }

    public List getEnabledOptions() {
        return browserElementLocator.findElementsByXpath("//mat-option[@aria-disabled='false']");
    }

    public WebElement getFinalCaseSubmitBtn() {
        return browserElementLocator.findElementByXpath("//button[@type='submit']");
    }

    public void getBucketWithEntities() {
        List<WebElement> buc = getBuckets();
        for (WebElement ele : buc) {
            int count = Integer.parseInt(ele.getText());
            if (count > 0) {
                ele.click();
            }
        }
    }

    public void userSelectsReason() throws InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.keyDown(Keys.SHIFT).sendKeys("r").keyUp(Keys.SHIFT).perform();
        action.keyDown(Keys.SHIFT).sendKeys("n").keyUp(Keys.SHIFT).perform();
        Logger.info("Analyst selects the reason for entities");
    }

    public void userDispositionPendingInfo() throws InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.keyDown(Keys.ALT).sendKeys("z").keyUp(Keys.ALT).perform();
        Logger.info("Analyst disposes the entities with Pending Info");
    }

    public void userDispositionMatch() throws InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.keyDown(Keys.ALT).sendKeys("m").keyUp(Keys.ALT).perform();
        Logger.info("Analyst disposes the entities with Match");
    }

    public void userDispositionFalseMatch() throws InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.keyDown(Keys.ALT).sendKeys("f").keyUp(Keys.ALT).perform();
        Logger.info("Analyst disposes the entities with False Match");
    }

    public void userDispositionPossibleMatch() throws InterruptedException {
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.keyDown(Keys.ALT).sendKeys("p").keyUp(Keys.ALT).perform();
        Logger.info("Analyst disposes the entities with Possible Match");
    }

    public void clickDispositionDropDown() throws InterruptedException {
        Thread.sleep(1000);
        WebElement arrow = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='disposition']//div[contains(@class,'mat-select-arrow')]"));
        arrow.click();
    }

    public void verifiesInterimDispositionforMatch() throws InterruptedException {
        List<WebElement> options = getEnabledOptions();
        for (WebElement ele : options) {
            String text = ele.getText();
            if (text.equals("Declined")) {
                Logger.info("Analyst verifies the final disposition over interim disposition : 'Declined' value found");
            } else if ((text.contains("Pending Info"))) {
                Logger.info("Analyst verifies the final disposition over interim disposition : 'Pending Info' value found");
            } else {
                Logger.info("Scenario failed : Disposition values displayed wrongly");
            }
            Thread.sleep(1000);
        }
    }

    public void verifiesInterimDispositionforFMatch() throws InterruptedException {
        List<WebElement> options = getEnabledOptions();
        for (WebElement ele : options) {
            String text = ele.getText();
            if (text.equals("Approved")) {
                Logger.info("Analyst verifies the final disposition over interim disposition : 'Approved' value found");
            } else if ((text.contains("Pending Info"))) {
                Logger.info("Analyst verifies the final disposition over interim disposition : 'Pending Info' value found");
            } else {
                Logger.info("Scenario failed : Disposition values displayed wrongly");
            }
            Thread.sleep(1000);
        }
    }

    public void verifiesInterimDispositionforPMatch() throws InterruptedException {
        List<WebElement> options = getEnabledOptions();
        for (WebElement ele : options) {
            String text = ele.getText();
            if (text.equals("Not Set")) {
                Logger.info("Analyst verifies the final disposition over interim disposition : 'Not Set' value found");
            } else if ((text.contains("Pending Info"))) {
                Logger.info("Analyst verifies the final disposition over interim disposition : 'Pending Info' value found");
            } else {
                Logger.info("Scenario failed : Disposition values displayed wrongly");
            }
            Thread.sleep(1000);
        }
    }

    public void verifiesInterimDispositionforPI() throws InterruptedException {
        Thread.sleep(1000);
        List<WebElement> options = getEnabledOptions();
        for (WebElement ele : options) {
            String text = ele.getText();
            Thread.sleep(1000);
            if ((text.contains("Pending Info"))) {
                Logger.info("Analyst verifies the final disposition over interim disposition : 'Pending Info' value found");
            } else {
                Logger.info("Scenario failed : Disposition values displayed wrongly");
            }
            Thread.sleep(1000);
        }
    }

    public WebElement getActionDropdown() {
        return browserElementLocator.findElementById("dispositionAction");
    }

    public void selectPendingInfoDispositionDropDown() {
        WebElement PendingInfo = BaseTestSetup.webDriver.findElement(By.xpath("//mat-option//span[contains(text(),'Pending Info')]"));
        PendingInfo.click();
    }

    public void validateCTMAck_WithoutCheck(String ackWF) {
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String expAckWF = ackWF;
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("ActionWorkFlow displayed in UI is validated :" + ackWF);
        else
            Logger.error("ActionWorkFlow displayed in UI is not correct :" + actActionWF);

        assertThat("ActionWorkFlow displayed is validated", expAckWF.equals(actActionWF));
    }

    public void selectAction(String action) throws java.lang.Exception {

        WebElement option = BaseTestSetup.webDriver.findElement(By.id("dispositionAction"));
        String defaultItem = option.getText().trim();
        if (defaultItem.equalsIgnoreCase(action)) {
            Logger.info("Expected Action is already selected : " + defaultItem);
        } else {
            getActionDropdown().sendKeys(action);
            Logger.info("Expected Action is selected in UI : " + action);
        }
    }

    public void clickPendToggleBtn() throws InterruptedException {
        getPendCaseToggleBtn().click();
    }

    public void selectPendDropdown(String option) throws InterruptedException {
        getSelectPendDropDown().click();
        getSelectPendDropDownOption(option).click();
    }

    public void selectPendDurationDropdown(String option) throws InterruptedException {
        getSelectPendDurationDropDown().click();
        getSelectPendDurationDropDownOption(option).click();
    }

    public void clickPendBtn() throws InterruptedException {
        getPendButton().click();
    }

    public void verifyfabicon() throws InterruptedException {
        if (getFabIcon().isEnabled()) {
            Thread.sleep(2000);
            Logger.info("Existing attachment list are displayed in VIEW only modeFab icon got enabled after the pend action.Scenario passed");
        }
    }

    public void verifySubmitDisabledAfterPend() throws InterruptedException {
        getCaseSubmitToggleBtn().click();
        if (getFinalCaseSubmitBtn().isEnabled()) {
            Thread.sleep(2000);
            Logger.info("Scenario failed.After a pend action,submit button should be disabled");
        } else {
            Logger.info("Scenario passed.After the pend action,Submit button is disabled");
        }
    }

    public void verifyDueDate() {
        String duedate = getDueDate().getText();
        Logger.info("Successfully validated Duedate for the recently pended case");
        Logger.info("The due date verified as : " + duedate);
    }

    public void verifiesWorkFlow() throws java.lang.Exception {
        Thread.sleep(2000);
        String actWorkFlow = getWorkFlow().getText().trim();
        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();
//        actWorkFlow=actWorkFlow.replaceAll(" ","");

        String expWorkFlow = "Newcheckkeyboard_arrow_rightReady For Workcheckkeyboard_arrow_rightInvestigatingcheckkeyboard_arrow_rightCompletedcheckkeyboard_arrow_rightConcludedcheck";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
//        assertThat("WorkFlow is validated", actWorkFlow.equals(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);
    }

    public void validateCTMAck_WithClose(String ackWF) {
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "close" + ackWFArr[0];
        ackWFArr[1] = "close" + ackWFArr[1];
        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1];
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is not done as expected");
        else
            Logger.error("Action WorkFlow acknowledgement is done : " + actActionWF);

        assertThat("Action WorkFlow acknowledgement is not done as expected", expAckWF.equals(actActionWF));
    }

    public void validateCTMAck_CBQ(String ackWF) {
        String actActionWF = getActionWorkFlowText().getText();
        System.out.println(actActionWF);
        System.out.println(ackWF);
        if (actActionWF.contains("check") && actActionWF.contains(ackWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");
    }

    public void verifiesWorkFlow_PI() throws java.lang.Exception {
        Thread.sleep(2000);
        String actWorkFlow = getWorkFlow().getText().trim();
        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();
//        actWorkFlow=actWorkFlow.replaceAll(" ","");

        String expWorkFlow = "Newcheckkeyboard_arrow_rightReady For Workcheckkeyboard_arrow_rightInvestigatingEvaluating Entitiescheckkeyboard_arrow_rightPending Info";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
//        assertThat("WorkFlow is validated", actWorkFlow.equals(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);
    }

    public void validateTierInCTM(String tier){


        if(tier.equalsIgnoreCase("SI")){
            String ctmText = browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][1]/strong").getText();
            Assert.assertEquals(tier,ctmText,"Tier is not present in the CTM Ack");

        }
        else if(tier.equalsIgnoreCase("EI")){
            String ctmText = browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][2]/strong").getText();
            Assert.assertEquals(tier,ctmText,"Tier is not present in the CTM Ack");

        }
        else if(tier.equalsIgnoreCase("AI")){
            String ctmText = browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][3]/strong").getText();
            Assert.assertEquals(tier,ctmText,"Tier is not present in the CTM Ack");

        }
        else{
            String ctmText = browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][4]/strong").getText();
            Assert.assertEquals(tier,ctmText,"Tier is not present in the CTM Ack");

        }
        Logger.info("Analyst validated tier - "+tier+" in the CTM ACK");

    }

    public void validateCTMAck(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String[] ackWFArr = ackWF.split(">");
//        ackWFArr[0] = "check" + ackWFArr[0];
//        ackWFArr[1] = "check" + ackWFArr[1];
//        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1];
//        expAckWF = expAckWF.replaceAll(" ", "").trim();
        String expAckWF="";
        for(int i=0;i<ackWFArr.length;i++){
            if(i>1) {
                ackWFArr[i] = "check" + ackWFArr[i];
                expAckWF = expAckWF+ ">" +ackWFArr[i];
            }
            else if(i==1){
                ackWFArr[i] = "check" + ackWFArr[i];
                expAckWF = expAckWF +ackWFArr[i];
            }
            else{
                ackWFArr[i] = ackWFArr[i];
                expAckWF = expAckWF +ackWFArr[i];
            }


        }
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }

    public String getSICTMText(){
        return browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][1]").getText();
    }

    public String getEICTMText(){
        return browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][2]").getText();
    }

    public String getAICTMText(){
        return browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][3]").getText();
    }

    public String getIACTMText(){
        return browserElementLocator.findElementByXpath("//span[contains(@class,'wu-action-workflow-container')][4]").getText();
    }

    public void validateCTMActionTimeline(String actCTM, String expCTM){
        Logger.info("actual ctm: "+actCTM);
        Logger.info("expected ctm : "+expCTM);

        String[] expCTMArr = expCTM.split(">");

        if(expCTMArr.length == 2){
            expCTM = expCTMArr[0] + "check"+ expCTMArr[1];

        }
        else{
            expCTM = expCTMArr[0] + "check"+ expCTMArr[1] +"check"+expCTMArr[2];

        }
        expCTM = expCTM.replaceAll(" ","").trim();

        actCTM =actCTM.replaceAll("\\R", "").trim();
        actCTM = actCTM.replaceAll(" ", "").trim();
        String[] actArr = actCTM.split(">");

        String actActionWF = "";
        for(int i=0;i<actArr.length;i++){
                actArr[i] = actArr[i];
                actActionWF = actActionWF+actArr[i];
        }
        actActionWF = actActionWF.replaceAll(" ", "").trim();


        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expCTM);
        if (actActionWF.equalsIgnoreCase(expCTM))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expCTM.equals(actActionWF));


    }

    public void validateCTMActionTimelineWithoutTick(String actCTM, String expCTM){

        String[] expCTMArr = expCTM.split(">");

        if(expCTMArr.length == 2){
            expCTM = expCTMArr[0] + expCTMArr[1];

        }
        else{
            expCTM = expCTMArr[0]+ expCTMArr[1] +expCTMArr[2];

        }
        expCTM = expCTM.replaceAll(" ","").trim();

        actCTM =actCTM.replaceAll("\\R", "").trim();
        actCTM = actCTM.replaceAll(" ", "").trim();
        String[] actArr = actCTM.split(">");

        String actActionWF = "";
        for(int i=0;i<actArr.length;i++){
            actArr[i] = actArr[i];
            actActionWF = actActionWF+actArr[i];
        }
        actActionWF = actActionWF.replaceAll(" ", "").trim();

        String ctmwithoutcheck = actActionWF;
        ctmwithoutcheck=ctmwithoutcheck.replaceAll("check","");
        ctmwithoutcheck = ctmwithoutcheck.replaceAll("close","");

//        Logger.info("ctm without check : "+ctmwithoutcheck);

        System.out.println("Actual : " + ctmwithoutcheck);
        System.out.println("Expected : " + expCTM);

        assertThat("Action WorkFlow verification with green tick  is done", ctmwithoutcheck.equals(expCTM));
        Logger.info("CTM ACK Message verified");


    }

    public void validateCTMActionTimelineWithTick(String actCTM, String expCTM){

        String[] expCTMArr = expCTM.split(">");

        if(expCTMArr.length == 2){
            expCTM = expCTMArr[0] + "check" + expCTMArr[1];

        }
        else{
            expCTM = expCTMArr[0]+ "check" + expCTMArr[1]+"check" +expCTMArr[2];

        }
        expCTM = expCTM.replaceAll(" ","").trim();

        actCTM =actCTM.replaceAll("\\R", "").trim();
        actCTM = actCTM.replaceAll(" ", "").trim();
        String[] actArr = actCTM.split(">");

        String actActionWF = "";
        for(int i=0;i<actArr.length;i++){
            actArr[i] = actArr[i];
            actActionWF = actActionWF+actArr[i];
        }
        actActionWF = actActionWF.replaceAll(" ", "").trim();

        String ctmwithticks = actActionWF;
//        ctmwithoutcheck=ctmwithoutcheck.replaceAll("check","");
//        ctmwithoutcheck = ctmwithoutcheck.replaceAll("close","");

//        Logger.info("ctm without check : "+ctmwithoutcheck);

        System.out.println("Actual : " + ctmwithticks);
        System.out.println("Expected : " + expCTM);

        assertThat("Action WorkFlow verification with green tick  is done", ctmwithticks.equals(expCTM));
        Logger.info("CTM ACK Message verified");


    }


    public void validateCTMActionTimelineOverride(String actCTM, String expCTM){

        String[] expCTMArr = expCTM.split(">");

        if(expCTMArr.length == 2){
            expCTM = expCTMArr[0] + "check" + expCTMArr[1];

        }
        else{
            expCTM = expCTMArr[0]+ "check" + expCTMArr[1]+"published_with_changescheck" +expCTMArr[2];

        }
        expCTM = expCTM.replaceAll(" ","").trim();

        actCTM =actCTM.replaceAll("\\R", "").trim();
        actCTM = actCTM.replaceAll(" ", "").trim();
        String[] actArr = actCTM.split(">");

        String actActionWF = "";
        for(int i=0;i<actArr.length;i++){
            actArr[i] = actArr[i];
            actActionWF = actActionWF+actArr[i];
        }
        actActionWF = actActionWF.replaceAll(" ", "").trim();

        String ctmwithticks = actActionWF;

        System.out.println("Actual : " + ctmwithticks);
        System.out.println("Expected : " + expCTM);

        assertThat("published_with_changes", ctmwithticks.equals(expCTM));
        Logger.info("CTM ACK Message verified -- published_with_changes");


    }



    public void validateCTMActionTimelineOnHold(String actCTM, String expCTM){

        String[] expCTMArr = expCTM.split(">");

        if(expCTMArr.length == 3){
            expCTM = expCTMArr[0] + "hourglass_top" + expCTMArr[1] +"hourglass_top" + expCTMArr[2];

        }
        else{
            expCTM = expCTMArr[0]+ "hourglass_top" + expCTMArr[1]+"hourglass_top+" +expCTMArr[2];

        }
        expCTM = expCTM.replaceAll(" ","").trim();

        actCTM =actCTM.replaceAll("\\R", "").trim();
        actCTM = actCTM.replaceAll(" ", "").trim();
        String[] actArr = actCTM.split(">");

        String actActionWF = "";
        for(int i=0;i<actArr.length;i++){
            actArr[i] = actArr[i];
            actActionWF = actActionWF+actArr[i];
        }
        actActionWF = actActionWF.replaceAll(" ", "").trim();

        String ctmwithticks = actActionWF;
//        ctmwithoutcheck=ctmwithoutcheck.replaceAll("check","");
//        ctmwithoutcheck = ctmwithoutcheck.replaceAll("close","");

//        Logger.info("ctm without check : "+ctmwithoutcheck);

        System.out.println("Actual : " + ctmwithticks);
        System.out.println("Expected : " + expCTM);

        assertThat("Action WorkFlow verification with action hold is done", ctmwithticks.equals(expCTM));
        Logger.info("CTM ACK Message verified");


    }


    public void validateCTMAckOnlytext(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String[] ackWFArr = ackWF.split(">");

        String expAckWF="";
        for(int i=0;i<ackWFArr.length;i++){
            if(i>1) {
                ackWFArr[i] = ackWFArr[i];
                expAckWF = expAckWF+ ">" +ackWFArr[i];
            }
            else if(i==1){
                ackWFArr[i] = ackWFArr[i];
                expAckWF = expAckWF +ackWFArr[i];
            }
            else{
                ackWFArr[i] = ackWFArr[i];
                expAckWF = expAckWF +ackWFArr[i];
            }


        }
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }


    public void validateCTMAckNoAction(String ackWF) throws Exception{
        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[1] = "check" + ackWFArr[1];
        ackWFArr[2] = "close" + ackWFArr[2];
        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1]+">" + ackWFArr[2];
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }


    public void validateCTMAckEntClearingBulk(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();
//        System.out.println("Actual : " + actActionWF);

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
//        System.out.println("Actual after \\R : " + actActionWF);
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        //    System.out.println("Actual : after replace space" + actActionWF);
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "close" + ackWFArr[0];
        ackWFArr[1] = "close" + ackWFArr[1];
        ackWFArr[2] = "check" + ackWFArr[2];
        System.out.println("3rd value:"+ackWFArr[2]);

        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1]+ ">" + ackWFArr[2];
        expAckWF = expAckWF.replaceAll(" ", "").trim();
        System.out.println("Actual : " + actActionWF);


        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }

    public void validateCTMAckCrossEntClearing(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();
//        System.out.println("Actual : " + actActionWF);

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
//        System.out.println("Actual after \\R : " + actActionWF);
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        //    System.out.println("Actual : after replace space" + actActionWF);
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "close" + ackWFArr[0];
        ackWFArr[1] = "close" + ackWFArr[1];
        ackWFArr[2] = "close" + ackWFArr[2];

        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1] +">" + ackWFArr[2];
        expAckWF = expAckWF.replaceAll(" ", "").trim();
        System.out.println("Actual : " + actActionWF);


        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }

    public void validateCTMAckCross(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();
//        System.out.println("Actual : " + actActionWF);

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
//        System.out.println("Actual after \\R : " + actActionWF);
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        //    System.out.println("Actual : after replace space" + actActionWF);
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "close" + ackWFArr[0];
        ackWFArr[1] = "close" + ackWFArr[1];

        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1];
        expAckWF = expAckWF.replaceAll(" ", "").trim();
        System.out.println("Actual : " + actActionWF);


        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }


    public void verifiesWorkFlow_Pend() throws java.lang.Exception {
        Thread.sleep(2000);
        String actWorkFlow = getWorkFlow().getText().trim();
        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();
//        actWorkFlow=actWorkFlow.replaceAll(" ","");

        String expWorkFlow = "Newcheckkeyboard_arrow_rightReady For Workcheckkeyboard_arrow_rightInvestigatingEvaluating Entitiescheckkeyboard_arrow_rightPend";
//        String expWorkFlow = "Newcheckkeyboard_arrow_rightInvestigatingEvaluating Entitiescheckkeyboard_arrow_rightPend";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
        assertThat("WorkFlow is validated", actWorkFlow.equals(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);
    }

    public void clickOnPendTab() {
        getPendTab().click();
    }

    public void selectReason(String reason) throws java.lang.Exception {

        WebElement option = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='reason']"));
        String defaultItem = option.getText().trim();
        //System.out.println(defaultItem );
        if (defaultItem.equalsIgnoreCase(reason)) {
            Logger.info("Expected Reason is already selected : " + defaultItem);
        } else {
            getReasonDropdown().sendKeys(reason);
            Logger.info("Expected Reason is selected in UI : " + reason);
        }
    }

    public void selectDuration(String reason) throws java.lang.Exception {

        WebElement option = getDurationDropdown();
        String defaultItem = option.getText().trim();
        //System.out.println(defaultItem );
        if (defaultItem.equalsIgnoreCase(reason)) {
            Logger.info("Expected Reason is already selected : " + defaultItem);
        } else {
            getDurationDropdown().sendKeys(reason);
            Logger.info("Expected Reason is selected in UI : " + reason);
        }
    }

    public void clickOnPendButton() {
        getPendButton().click();
    }

    public void validateCTMAck_WarningEntityClearing(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "check" + ackWFArr[0];
        ackWFArr[1] = "check" + ackWFArr[1];
        ackWFArr[2] = "check" + ackWFArr[2];
        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1] + ">" + ackWFArr[2];
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");

        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));

        if (getWarningIcon().isDisplayed()) {
            Logger.info("Warning tick is present in Action WF");
        } else
            Logger.error("Warning tick is not present in Action WF");
    }

    public void validateCTMAck_GreenEntityClearing(String ackWF) throws Exception {

        browserElements.waitForWebElementIsDisplayed(getActionWorkFlowText(), 5000);
        String actActionWF = getActionWorkFlowText().getText();

        actActionWF = actActionWF.replaceAll("\\R", "").trim();
        actActionWF = actActionWF.replaceAll(" ", "").trim();
        String[] ackWFArr = ackWF.split(">");
        ackWFArr[0] = "check" + ackWFArr[0];
        ackWFArr[1] = "check" + ackWFArr[1];
        ackWFArr[2] = "check" + ackWFArr[2];
        String expAckWF = ackWFArr[0] + ">" + ackWFArr[1] + ">" + ackWFArr[2];
        expAckWF = expAckWF.replaceAll(" ", "").trim();

        System.out.println("Actual : " + actActionWF);
        System.out.println("Expected : " + expAckWF);
        if (actActionWF.equalsIgnoreCase(expAckWF))
            Logger.info("Action WorkFlow acknowledgement is done");
        else
            Logger.error("Action WorkFlow acknowledgement is not done");
//        assertThat("Action WorkFlow acknowledgement is done", expAckWF.equals(actActionWF));
    }

    public void validateReason(String reason) {

        WebElement option = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='reason']"));
        String defaultItem = option.getText().trim();
        if (defaultItem.equalsIgnoreCase(reason)) {
            Logger.info("Expected Reason is displayed : " + reason);
        } else
            Logger.info("Expected Reason is not displayed.Reason in UI : " + defaultItem);
        Assert.assertEquals(defaultItem, reason, "Expected Reason is not displayed in UI");
    }

    public void verifiesWorkFlow_CNA() throws java.lang.Exception {
        Thread.sleep(2000);
        String actWorkFlow = getWorkFlow().getText().trim();
        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();

        String expWorkFlow = "Newcheckkeyboard_arrow_rightCompletedcheckkeyboard_arrow_rightConcludedcheck";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
        assertThat("WorkFlow is validated", actWorkFlow.equals(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);
    }

    public void verifiesClickToAcessScrollAudit(String actual) throws InterruptedException {
        Thread.sleep(3000);
        String actWorkFlow = getAuditLastElement().getText().trim();
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement Audit = webDriver.findElement(By.xpath("//app-audit[1]/div[1]/div[2]/table[1]/tbody[1]/tr[last()]/td[3]"));
        je.executeScript("arguments[0].scrollIntoView(true);", Audit);
        Thread.sleep(2000);
        WebElement element = webDriver.findElement(By.xpath("//app-audit[1]/div[1]/div[2]/table[1]/tbody[1]/tr[last()]/td[3]"));
        je.executeScript("arguments[0].style.border='3px solid red'", element);

        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();

        String expWorkFlow = "" + actual + "";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
        assertThat("WorkFlow is validated", actWorkFlow.equals(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);

    }

    private WebElement getAuditLastElement() {
        return browserElementLocator.findElementByXpath("//app-audit[1]/div[1]/div[2]/table[1]/tbody[1]/tr[last()]/td[3]");
    }

    public void verifiesGetCaseWorkFlow() throws InterruptedException {
        Thread.sleep(2000);
        String actWorkFlow = getWorkFlow().getText().trim();
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement submit = webDriver.findElement(By.xpath("//div[@class='wu-workflow-node']"));
        je.executeScript("arguments[0].style.border='3px solid red'", submit);
        Thread.sleep(3000);

        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();
//        actWorkFlow=actWorkFlow.replaceAll(" ","");

        String expWorkFlow = "Newcheckkeyboard_arrow_rightReady For Workcheckkeyboard_arrow_rightInvestigatingEvaluating Entities";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
//        assertThat("WorkFlow is validated", actWorkFlow.equals(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);
    }
    public void MouseOverOnPendTad() throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        WebElement element = webDriver.findElement(By.xpath("//div[contains(text(),'Submit')]"));
        WebElement Pend = webDriver.findElement(By.xpath("//div[contains(text(),'Pend')]"));
        Actions act = new Actions(webDriver);
        act.moveToElement(Pend).doubleClick();
        Thread.sleep(2000);
    }
    public void ClicksOnPentab() {
        getclicksPendTab().click();

    }

    private WebElement getclicksPendTab() {
        return browserElementLocator.findElementByXpath("//div[contains(text(),'Pend')]");

    }
    public void verifiesPendCaseWorkFlow() throws InterruptedException {
        Thread.sleep(2000);
        String actWorkFlow = getWorkFlow().getText().trim();
        actWorkFlow = actWorkFlow.replace("check", "");
        actWorkFlow = actWorkFlow.replace("keyboard_arrow_right", ">");

        actWorkFlow = actWorkFlow.replaceAll("\\n", "");
        actWorkFlow = actWorkFlow.replaceAll("\\R", "").trim();

        String expWorkFlow = "checkkeyboard_arrow_rightPend";
        expWorkFlow = expWorkFlow.replace("check", "");
        expWorkFlow = expWorkFlow.replace("keyboard_arrow_right", ">");

        System.out.println("Act:" + actWorkFlow);
        System.out.println("Exp:" + expWorkFlow);
        assertThat("WorkFlow is validated", actWorkFlow.contains(expWorkFlow));
        Logger.info("WorkFlow displayed in UI is validated:" + actWorkFlow);
    }
    public WebElement getSummaryValue(String InvFocus) {
        return browserElementLocator.findElementByXpath("//span[@class='entityLabel'][contains(text(),'"+InvFocus+"')]/following::span[1]");
    }
}
