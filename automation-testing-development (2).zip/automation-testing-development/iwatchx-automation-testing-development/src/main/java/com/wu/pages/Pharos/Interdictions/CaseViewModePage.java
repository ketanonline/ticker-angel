package com.wu.pages.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class CaseViewModePage extends BasePage {


    public WebElement getStageAtCaseHeader() {
        return browserElementLocator.findElementByXpath("//p[@class='wu-timeline-nodes wu-timeline-active-node']");
    }
    
    public WebElement getCaseSubmitToggleBtn() {
        return browserElementLocator.findElementByXpath("//div[@role='tab']//div[contains(.,'Submit')]");
    }

    public WebElement getCaseIDHeader() {
        return browserElementLocator.findElementByXpath("(//mat-panel-title[@class='mat-expansion-panel-header-title ng-star-inserted']//following::div[@class='ng-star-inserted'])[1]");
    }

    public WebElement getEntityInfo() {
        return browserElementLocator.findElementByXpath("//a[contains(.,'Info')]");
    }

    public WebElement getDispositionDisabledDrpdwn() {
        return browserElementLocator.findElementByXpath("//select[@formcontrolname='disposition' and @aria-invalid='false']");
    }

    public void verifyCaseSubmit() {
        getCaseSubmitToggleBtn().click();
        if (getCaseSubmitToggleBtn().isEnabled()) {
            Logger.info("Case disposition section is enabled.Scenario Failed");
        } else {
            Logger.info("Case disposition section is disabled.Case is opened at VIEW only mode");
        }
    }

    public void verifyCaseDispositionDisabled() {
        getCaseSubmitToggleBtn().click();
        if (getDispositionDisabledDrpdwn().isDisplayed()) {
            Logger.info("Case disposition section is enabled.Scenario Failed");
        } else {
            Logger.info("Case disposition section is disabled.Case is opened at VIEW only mode");
        }
    }

    public void verifyScroll() throws Exception {
        getEntityInfo().click();
        Thread.sleep(2000);
        String execScript = "return document.documentElement.scrollHeight>document.documentElement.clientHeight;";
        JavascriptExecutor scrollBarPresent = (JavascriptExecutor) BaseTestSetup.webDriver;
        Boolean test = (Boolean) (scrollBarPresent.executeScript(execScript));
        if (test) {
            System.out.print("Scrollbar is present.");
        } else {
            System.out.print("Scrollbar is not present.");
        }
    }

    public void verifyCaseHeaderExpansion() {
        getCaseIDHeader().click();
        if (getStageAtCaseHeader().isDisplayed()) {
            Logger.info("Case Header is not expanded.Scenario failed");
        } else {
            Logger.info("Case Header is expanded opened at VIEW only mode");
        }
    }


}
