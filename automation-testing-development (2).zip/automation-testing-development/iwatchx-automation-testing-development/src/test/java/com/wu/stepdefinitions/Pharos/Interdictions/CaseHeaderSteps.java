package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseHeaderPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps.getCaseData;
import static org.hamcrest.MatcherAssert.assertThat;

public class CaseHeaderSteps {

    CaseHeaderPage caseHeaderPage = new CaseHeaderPage();

    @Then("Analyst verifies {string} in Case Header is 10 digits")
    public void analystVerifiesMTCN(String mtcn) throws Exception {
        String actMTCN = caseHeaderPage.getMTCN_CaseHeader().getText().trim();
        assertThat("MTCN in Case Header is validated", actMTCN.equals(mtcn));
        Logger.info("MTCN in Case Header is validated :" + actMTCN);

        if (actMTCN.length() == 10)
            Logger.info("MTCN displayed in Case Header is 10 digits");
        else
            Logger.error("MTCN displayed in Case Header is not 10 digits:" + actMTCN);
    }

    @Then("Analyst validates {string} brand image in case sub header")
    public void analystValidatesBrand(String brand) throws Exception {
        String actBrand = caseHeaderPage.getBrand_CaseHeader().getText().trim();
        assertThat("Brand in Case Header is validated", actBrand.equals(brand));
        Logger.info("Brand in Case Header is validated :" + actBrand);

    }

    @When("Analyst expands on Case Header")
    public void analystClickOnCaseHeaderExpander() throws InterruptedException {
        caseHeaderPage.clickOnCaseHeader();
        Logger.info("Analyst Expands on Case Header");
    }

    @Then("{string} should be present in phases")
    public void thenStandardInvestigationShouldBeDisplayedInPhases(String phaseName) throws InterruptedException {
        String actualPhase = caseHeaderPage.getPhaseInCaseHeader();
        System.out.println(actualPhase);
        Assert.assertEquals(actualPhase, phaseName, phaseName + " is not present in Phases of Case Header");
        Logger.info(phaseName + " is present in Phases of Case Header");
    }

    @Then("Analyst verifies the tier as {string}")
    public void verifiesTier(String tier) {
        String actualTierValue = caseHeaderPage.getTierValue(tier).getText();
        if (actualTierValue.contains(tier)) {
            Logger.info("Tier value has been verified as -" + tier);
        } else {
            Logger.error("Tier value is not as expected -" + tier);
        }
    }

    @Then("Analyst clicks on MyQueue And Validate case is {string} Present")
    public void analystValidatesCasePresentMyQueue(String caseId) throws InterruptedException {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        caseId = getCaseData(caseId).toString();
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.navigate().refresh();
        Thread.sleep(8000);
        caseHeaderPage.MyqueueButton();
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement Actualcase = webDriver.findElement(By.xpath("//td[contains(text(),'" + caseId + "')]"));
        je.executeScript("arguments[0].scrollIntoView(true);", Actualcase);
        Assert.assertTrue(Actualcase.isDisplayed());
        Logger.info("Case is present in My Queue");
        Thread.sleep(2000);
    }

    @Then("Analyst clicks on MyQueue And Validate RefId is {string} Present")
    public void analystValidateRefIdPresentMyQueue(String refId) throws InterruptedException {
        if (refId.contains("$")) refId = refId.substring(refId.indexOf("$") + 1);
        refId = getCaseData(refId).toString();
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.navigate().refresh();
        Thread.sleep(8000);
        caseHeaderPage.MyqueueButton();
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement ActualrefId = webDriver.findElement(By.xpath("//td[contains(text(),'" + refId + "')]"));
        je.executeScript("arguments[0].scrollIntoView(true);", ActualrefId);
        String ExceptedrefId = webDriver.findElement(By.xpath("//td[contains(text(),'" + refId + "')]")).getText();
        Logger.info("case is not  present Analyst Myqueue ActualActvityRefId" + refId + " ExceptedActvityRefId " + ExceptedrefId + "");
        Assert.assertEquals("case is not  present Analyst Myqueue ActualActvityRefId" + refId + "" + ExceptedrefId + "", ExceptedrefId, refId);
        Thread.sleep(2000);
    }

    @Then("Analyst clicks on MyQueue And Validate caseRefNo is {string} Present")
    public void analystValidatecaseRefNoPresentMyQueue(String caseRefNo) throws InterruptedException {
        if (caseRefNo.contains("$")) caseRefNo = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
        caseRefNo = getCaseData(caseRefNo).toString();
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.navigate().refresh();
        Thread.sleep(8000);
        caseHeaderPage.MyqueueButton();
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement ActualcaseRefNo = webDriver.findElement(By.xpath("//td[contains(text(),'" + caseRefNo + "')]"));
        je.executeScript("arguments[0].scrollIntoView(true);", ActualcaseRefNo);
        String ExceptedcaseRefNo = webDriver.findElement(By.xpath("//td[contains(text(),'" + caseRefNo + "')]")).getText();
        Logger.info("case is not  present Analyst Myqueue ActualActvitycaseRefNo" + caseRefNo + " ExceptedActvitycaseRefNo " + ExceptedcaseRefNo + "");
        Assert.assertEquals("case is not  present Analyst Myqueue ActualActvitycaseRefNo" + caseRefNo + "" + ExceptedcaseRefNo + "", ExceptedcaseRefNo, caseRefNo);
        Thread.sleep(2000);
    }

//    @Then("Analyst clicks on MyQueue And Validate case is {string} Present")
//    public void analystValidatesCasePresentMyQueue(String caseId) throws InterruptedException {
//        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
//        WebDriver webDriver = BaseTestSetup.webDriver;
//        webDriver.navigate().refresh();
//        Thread.sleep(8000);
//        caseHeaderPage.MyqueueButton();
//        webDriver.manage().window().maximize();
//        JavascriptExecutor je = (JavascriptExecutor) webDriver;
////        je.executeScript("window.scrollBy(0,1000)");
////        String Exceptedcase = webDriver.findElement(By.xpath("//td[contains(text(),'"+ caseId +"')]")).getText();
////        Assert.assertTrue("Case Is present in Analyst Myqueue Bucket ", caseId == Exceptedcase);
//        Thread.sleep(2000);
//    }
}
