package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import com.wu.pages.Pharos.Interdictions.EntityDispositionPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.qameta.allure.Allure;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.*;

import java.awt.*;
import java.io.File;
import java.util.List;

public class EntityDispositionSteps extends BasePage {

    EntityDispositionPage entityDispositionPage = new EntityDispositionPage();

    @Then("Action workflow should have {string}")
    public void analystSeesActionWorkFlowRes(String actionWfResult) throws Exception {
        Thread.sleep(3000);
        entityDispositionPage.validateCTMAck_WithoutCheck(actionWfResult);
        addScreenshotToAllureReport("Action WorkFlow");
    }

    @When("Analyst selects value {string} in Action")
    public void analystSelectsAction(String action) throws Exception {
        Thread.sleep(2000);
        entityDispositionPage.selectAction(action);
        Logger.info("Analyst selects value " + action + " in Action");
    }

    @When("Analyst clicks on PendingInfo Bucket")
    public void analystClicksOnPendingInfoBucket() {
        entityDispositionPage.clickOnPendingInfoBucket();
        Logger.info("Analyst Clicks on PendingInfo Bucket");
    }

    @When("Analyst clicks on NotDisposition Bucket")
    public void analystClicksOnNotDisBucket() {
        entityDispositionPage.clickOnNotDispositionBucket();
        Logger.info("Analyst Clicks on NotDisposition Bucket");
    }

    @When("Analyst clicks on Possible Match Bucket")
    public void analystClicksOnPosMatchBucket() {
        entityDispositionPage.clickOnPosMatchBucket();
        Logger.info("Analyst Clicks on Possible Match Bucket");
    }

    @When("Analyst clicks on False Match Bucket")
    public void analystClicksOnFalMatchBucket() {
        entityDispositionPage.clickOnFalseMatchBucket();
        Logger.info("Analyst Clicks on False Match Bucket");
    }

    @When("Analyst clicks on Match Bucket")
    public void analystClicksOnMatchBucket() {
        entityDispositionPage.clickOnMatchBucket();
        Logger.info("Analyst Clicks on Match Bucket");
    }

    @When("Analyst clicks on Entity")
    public void analystClickOnEntity() {
        entityDispositionPage.clickOnEntity();
        Logger.info("Analyst Clicks on Entity");
    }

    @When("Analyst performs {string} and {string} disposition on entities")
    public void analystPerformsDispositionOnEntities(String disPosition1, String disPosition2) {
        disposeEntities(disPosition1, disPosition2);
        Logger.info("Analyst performs " + disPosition1 + " and " + disPosition2 + " disposition on entities");
    }

    public void disposeEntities(String disPosition1, String disPosition2) {
        List<WebElement> entities = entityDispositionPage.getEntities();
        int rows_count = entities.size();
        disPosition1 = switchEntitiesFunc(disPosition1);
        disPosition2 = switchEntitiesFunc(disPosition2);
        for (int i = 1; i <= rows_count; i++) {
            WebElement eleExp = browserElementLocator.findElementByXpath("//app-hit-entity[@class='ng-star-inserted'][1]");
            eleExp.click();
            analystSendsKeysOnEntities("Alt+I");
            analystSendsKeysOnEntities("Alt+D");
            if ((i % 2) == 0) {
                analystSendsKeysOnEntities(disPosition2);
            } else {
                analystSendsKeysOnEntities(disPosition1);
            }
        }
    }

    private String switchEntitiesFunc(String disPosition) {
        String finalDisposition = null;
        switch (disPosition) {
            case "Not Dispositioned":
                finalDisposition = "Alt+T";
                break;
            case "False Match":
                finalDisposition = "Alt+F";
                break;
            case "Match":
                finalDisposition = "Alt+M";
                break;
            case "Possible Match":
                finalDisposition = "Alt+P";
                break;
            case "Pending Info":
                finalDisposition = "Alt+Z";
                break;
        }
        return finalDisposition;
    }

    public void analystSendsKeysOnEntities(String keys) {

        int key1 = 0, key2 = 0;
        key1 = 18;
        switch (keys) {
            case "Alt+S":
                key2 = 83;
                break;
            case "Alt+R":
                key2 = 82;
                break;
            case "Alt+T":
                key2 = 84;
                break;
            case "Alt+D":
                key2 = 68;
                break;
            case "Alt+C":
                key2 = 67;
                break;
            case "Alt+F":
                key2 = 70;
                break;
            case "Alt+I":
                key2 = 73;
                break;
            case "Alt+N":
                key2 = 78;
                break;
            case "Alt+M":
                key2 = 77;
                break;
            case "Alt+G":
                key2 = 71;
                break;
            case "Alt+P":
                key2 = 80;
                break;
            case "Alt+Z":
                key2 = 90;
                break;
        }

        try {
            Robot robot = new Robot();
            robot.keyPress(key1);
            Thread.sleep(1000);
            robot.keyPress(key2);
            robot.keyRelease(key1);
            robot.keyRelease(key2);

            Logger.info("Analyst sends " + keys + " on selected Entity");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }

    @When("Analyst selects Enhanced Investigation value {string} in Action")
    public void analystSelectsEnhancedInvestigationActionValue(String action) {
        if (action.equalsIgnoreCase("Move to Advanced Investigation")) {
            entityDispositionPage.selectEnhancedmovetoadvAction(action);
            Logger.info("Analyst selects value " + action + " in Action");
        } else {
            if (action.equalsIgnoreCase("Hop to Advanced Investigation")) {
                entityDispositionPage.selectEnhancedhoptoadvAction(action);
                Logger.info("Analyst selects value " + action + " in Action");

            }
        }
    }

    @When("Analyst selects Enhanced Investigation Approved dispostion value {string} in Action")
    public void analystSelectsEnhancedInvestigationApprovedActionValue(String action) {
        if (action.equalsIgnoreCase("Release Funds")) {
            entityDispositionPage.selectEnhancedReleaseFundsAction(action);
            Logger.info("Analyst selects value " + action + " in Action");
        } else {
            if (action.equalsIgnoreCase("ReturnFunds")) {
                entityDispositionPage.selectEnhancedReturnFundsAction(action);
                Logger.info("Analyst selects value " + action + " in Action");

            } else {
                if (action.equalsIgnoreCase("CancelFunds")) {
                    entityDispositionPage.selectEnhancedCancelFundsAction(action);
                    Logger.info("Analyst selects value " + action + " in Action");
                } else {
                    if (action.equalsIgnoreCase("Return Funds (Owned)")) ;
                    entityDispositionPage.selectEnhancedReturnFundsOwnedAction(action);
                    Logger.info("Analyst selects value " + action + " in Action");
                }
            }
        }
    }

    @When("Analyst selects Advanced Investigation Declined dispostion value {string} in Action")
    public void AnalystselectsAdvancedInvestigationDeclineddispostion(String action) {
        if (action.equalsIgnoreCase("Block Funds")) {
            entityDispositionPage.selectsAdvancedBlockFundsAction(action);
            Logger.info("Analyst selects value " + action + " in Action");
        } else {
            if (action.equalsIgnoreCase("Block Funds (Owned)")) {
                entityDispositionPage.selectsAdvancedBlockFundsOwnedAction(action);
                Logger.info("Analyst selects value " + action + " in Action");

            } else {
                if (action.equalsIgnoreCase("Return Funds")) {
                    entityDispositionPage.selectsAdvancedReturnFundsAction(action);
                    Logger.info("Analyst selects value " + action + " in Action");
                } else {
                    if (action.equalsIgnoreCase("Return Funds (Owned)")) ;
                    entityDispositionPage.selectsAdvancedReturnFundsOwnedAction(action);
                    Logger.info("Analyst selects value " + action + " in Action");
                }
            }
        }
    }

    @When("Analyst is highligthing the Breadcrumvalues {string}")
    public void analystIsHighligthingBreadcrumValues(String Breadcrum) throws Exception {
        if (Breadcrum.equals("CTM Notification")) {
            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            JavascriptExecutor je = (JavascriptExecutor) webDriver;
            WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'CTM Notification')]"));
            je.executeScript("arguments[0].style.border='3px solid red'", element);
            addScreenshotToAllureReport("Breadcrums");
            Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
        } else {
            if (Breadcrum.equals("Release")) {
                WebDriver webDriver = BaseTestSetup.webDriver;
                webDriver.manage().window().maximize();
                JavascriptExecutor je = (JavascriptExecutor) webDriver;
                WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Release')]"));
                je.executeScript("arguments[0].style.border='5px solid green'", element);
                addScreenshotToAllureReport("Breadcrums");
                Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
            } else {
                if (Breadcrum.equals("Move to Refund Queue")) {
                    WebDriver webDriver = BaseTestSetup.webDriver;
                    webDriver.manage().window().maximize();
                    JavascriptExecutor je = (JavascriptExecutor) webDriver;
                    WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Move to Refund Queue')]"));
                    je.executeScript("arguments[0].style.border='5px solid green'", element);
                    addScreenshotToAllureReport("Breadcrums");
                    Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                } else {
                    if (Breadcrum.equals("Keep in Queue")) {
                        WebDriver webDriver = BaseTestSetup.webDriver;
                        webDriver.manage().window().maximize();
                        JavascriptExecutor je = (JavascriptExecutor) webDriver;
                        WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Keep in Queue')]"));
                        je.executeScript("arguments[0].style.border='5px solid green'", element);
                        addScreenshotToAllureReport("Breadcrums");
                        Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                    } else {
                        if (Breadcrum.equals("Move to Escalated Queue")) {
                            WebDriver webDriver = BaseTestSetup.webDriver;
                            webDriver.manage().window().maximize();
                            JavascriptExecutor je = (JavascriptExecutor) webDriver;
                            WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Move to Escalated Queue')]"));
                            je.executeScript("arguments[0].style.border='5px solid green'", element);
                            addScreenshotToAllureReport("Breadcrums");
                            Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                        } else {
                            if (Breadcrum.equals("Move to CallBack Queue")) {
                                WebDriver webDriver = BaseTestSetup.webDriver;
                                webDriver.manage().window().maximize();
                                JavascriptExecutor je = (JavascriptExecutor) webDriver;
                                WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Move to CallBack Queue')]"));
                                je.executeScript("arguments[0].style.border='5px solid green'", element);
                                addScreenshotToAllureReport("Breadcrums");
                                Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                            } else {
                                if (Breadcrum.equals("Hop to Escalated Queue")) {
                                    WebDriver webDriver = BaseTestSetup.webDriver;
                                    webDriver.manage().window().maximize();
                                    JavascriptExecutor je = (JavascriptExecutor) webDriver;
                                    WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Hop to Escalated Queue')]"));
                                    je.executeScript("arguments[0].style.border='5px solid green'", element);
                                    addScreenshotToAllureReport("Breadcrums");
                                    Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                                } else {
                                    if (Breadcrum.equals("Entity Clearance")) {
                                        WebDriver webDriver = BaseTestSetup.webDriver;
                                        webDriver.manage().window().maximize();
                                        JavascriptExecutor je = (JavascriptExecutor) webDriver;
                                        WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Entity Clearing Req. ')]"));
                                        je.executeScript("arguments[0].style.border='5px solid yellow'", element);
                                        addScreenshotToAllureReport("Breadcrums");
                                        Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                                    } else {
                                        if (Breadcrum.equals("Keep in Seizure Queue")) {
                                            WebDriver webDriver = BaseTestSetup.webDriver;
                                            webDriver.manage().window().maximize();
                                            JavascriptExecutor je = (JavascriptExecutor) webDriver;
                                            WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Keep in Seizure Queue')]"));
                                            je.executeScript("arguments[0].style.border='5px solid green'", element);
                                            Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                                        } else {
                                            if (Breadcrum.equals("Cancel")) {
                                                WebDriver webDriver = BaseTestSetup.webDriver;
                                                webDriver.manage().window().maximize();
                                                JavascriptExecutor je = (JavascriptExecutor) webDriver;
                                                WebElement element = webDriver.findElement(By.xpath("//span[contains(text(),'Cancel ')]"));
                                                je.executeScript("arguments[0].style.border='5px solid green'", element);
                                                Logger.info("Analyst is highligthing the Breadcrumvalues" + Breadcrum + " in Action");
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            }


        }


    }

    @When("Analyst Clicks to scrollDown")
    public void analystClickToAcessScroll() throws InterruptedException {
        Thread.sleep(2000);
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
//        js.executeScript("window.scrollBy(0,1000)","");
        WebElement submit = webDriver.findElement(By.xpath("(//span[@class='mat-button-wrapper']/mat-icon)[6]"));
        je.executeScript("arguments[0].scrollIntoView(true);", submit);
        Logger.info("Analyst Clicks to access  scroll");
    }

    @When("Analyst Capture screenshort for particular location")
    public static void addScreenshotToAllureReport(String screenShotName) {
        try {
            File scrFile;
            if (null != BaseTestSetup.windowsDriver) {
                scrFile = ((TakesScreenshot) BaseTestSetup.windowsDriver).getScreenshotAs(OutputType.FILE);
                Allure.addAttachment(screenShotName, FileUtils.openInputStream(scrFile));
            } else if (null != BaseTestSetup.webDriver) {
                scrFile = ((TakesScreenshot) BaseTestSetup.webDriver).getScreenshotAs(OutputType.FILE);
                Allure.addAttachment(screenShotName, FileUtils.openInputStream(scrFile));
            }
        } catch (Exception e) {
            e.printStackTrace();
            Logger.warning("Unable to add Screenshot for " + screenShotName, e);
        }
    }

    @When("Analyst selects Enhanced Investigation value {string} in Reason")
    public void analystSelectsEnhancedInvestigationReasonValue(String action) {
        if (action.equalsIgnoreCase("Customer Changed Mind (CCM)")) {
            entityDispositionPage.selectEnhancedCustomerChangedReason(action);
            Logger.info("Analyst selects value " + action + " in Reason");
        } else {
            if (action.equalsIgnoreCase("Money Not Collected (MNC)")) {
                entityDispositionPage.selectEnhancedMoneyNotCollectedReason(action);
                Logger.info("Analyst selects value " + action + " in Reason");
            } else {
                if (action.equalsIgnoreCase("Sent with Wrong Info (WIR)")) {
                    entityDispositionPage.selectEnhancedSentwithWrongInfoWIRReason(action);
                    Logger.info("Analyst selects value " + action + " in Reason");
                } else {
                    if (action.equalsIgnoreCase("Consumer Fraud (CFR)")) {
                        entityDispositionPage.selectEnhancedConsumerFraudCFRReason(action);
                        Logger.info("Analyst selects value " + action + " in Reason");
                    } else {
                        if (action.equalsIgnoreCase("Test Transaction Refund (TTR)")) {
                            entityDispositionPage.selectEnhancedTestTransactionRefundTTRReason(action);
                            Logger.info("Analyst selects value " + action + " in Reason");
                        } else {
                            if (action.equalsIgnoreCase("Test Transaction Cancel (TTC)")) {
                                entityDispositionPage.selectEnhancedTestTransactionCancelReason(action);
                                Logger.info("Analyst selects value " + action + " in Reason");
                            } else {
                                if (action.equalsIgnoreCase("Insufficient Source Details (ISD)")) {
                                    entityDispositionPage.selectEnhancedInsufficientSourceDetailsReason(action);
                                    Logger.info("Analyst selects value " + action + " in Reason");
                                } else {
                                    if (action.equalsIgnoreCase("Similar Information (SIM)")) {
                                        entityDispositionPage.selectEnhancedSimilarInformationReason(action);
                                        Logger.info("Analyst selects value " + action + " in Reason");
                                    } else {
                                        if (action.equalsIgnoreCase("Customer Allowed (OKC)")) {
                                            entityDispositionPage.selectEnhancedApprovedCustomerAllowedOKCReason(action);
                                            Logger.info("Analyst selects value " + action + " in Reason");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @When("Analyst selects Advanced Investigation Approved value {string} in Reason")
    public void analystSelectsAdvancedInvestigationReasonValue(String Reason) {
        if (Reason.equalsIgnoreCase("Customer Changed Mind (CCM)")) {
            entityDispositionPage.selectAdvancedApproveCustomerChangedReason(Reason);
            Logger.info("Analyst selects value " + Reason + " in Reason");
        } else {
            if (Reason.equalsIgnoreCase("Money Not Collected (MNC)")) {
                entityDispositionPage.selectAdvancedApproveMoneyNotCollectedReason(Reason);
                Logger.info("Analyst selects value " + Reason + " in Reason");
            } else {
                if (Reason.equalsIgnoreCase("Sent with Wrong Info (WIR)")) {
                    entityDispositionPage.selectAdvancedApproveSentwithWrongInfoWIRReason(Reason);
                    Logger.info("Analyst selects value " + Reason + " in Reason");
                } else {
                    if (Reason.equalsIgnoreCase("Consumer Fraud (CFR)")) {
                        entityDispositionPage.selectAdvancedApproveConsumerFraudCFRReason(Reason);
                        Logger.info("Analyst selects value " + Reason + " in Reason");
                    } else {
                        if (Reason.equalsIgnoreCase("Test Transaction Refund (TTR)")) {
                            entityDispositionPage.selectAdvancedApproveTestTransactionRefundTTRReason(Reason);
                            Logger.info("Analyst selects value " + Reason + " in Reason");
                        } else {
                            if (Reason.equalsIgnoreCase("Internal Policy (LVL)")) {
                                entityDispositionPage.selectAdvancedApproveInternalPolicyCancelReason(Reason);
                                Logger.info("Analyst selects value " + Reason + " in Reason");


                            }
                        }
                    }
                }
            }
        }
    }

    @When("Analyst selects Investigation Approver value {string} in Action")
    public void analystSelectInvestigationApproverActionValue(String action) {
        if (action.equalsIgnoreCase("Approve Entity-(ies)")) {
            entityDispositionPage.selectInvestigationApproverApproveEntityAction(action);
            Logger.info("Analyst selects value " + action + " in action");
        } else {
            if (action.equalsIgnoreCase("Approve Entity-(ies) & Coach")) {
                entityDispositionPage.selectInvestigationApproverApproveEntityCoachAction(action);
                Logger.info("Analyst selects value " + action + " in action");
            } else {
                if (action.equalsIgnoreCase("Critical Coaching")) {
                    entityDispositionPage.selectInvestigationApproverApproveCriticalCoachingAction(action);
                    Logger.info("Analyst selects value " + action + " in action");
                } else {
                    if (action.equalsIgnoreCase("Elevated Coaching")) {
                        entityDispositionPage.selectInvestigationApproverApproveElevatedCoachingAction(action);
                        Logger.info("Analyst selects value " + action + " in action");
                    }
                }
            }
        }
    }

    @When("Analyst selects Investigation Approver value {string} in Reason")
    public void analystSelectInvestigationApproverReasomValue(String Reason) {
        if (Reason.equalsIgnoreCase("Interim Suspension (SUS)")) {
            entityDispositionPage.selectInvestigationInterimSuspensionReason(Reason);
            Logger.info("Analyst selects value " + Reason + " in action");
        } else {
            if (Reason.equalsIgnoreCase("Recovered in Queue (QUE)")) {
                entityDispositionPage.selectInvestigationRecoveredinQueueReason(Reason);
                Logger.info("Analyst selects value " + Reason + " in action");
            } else {
                if (Reason.equalsIgnoreCase("Allowed in Error (ERR)")) {
                    entityDispositionPage.selectInvestigationAllowedinErrorReason(Reason);
                    Logger.info("Analyst selects value " + Reason + " in action");
                } else {
                    if (Reason.equalsIgnoreCase("Decision OK (OKD)")) {
                        entityDispositionPage.selectInvestigationApproverDecisionOKCoachingAction(Reason);
                        Logger.info("Analyst selects value " + Reason + " in action");
                    }
                }
            }
        }
    }

    @When("Analyst selects Advanced Investigation Declined value {string} in Reason")
    public void analystSelectsAdvancedInvestigationDeclinedReasonValue(String Reason) {
        if (Reason.equalsIgnoreCase("Customer Changed Mind (CCM)")) {
            entityDispositionPage.selectAdvancedDeclinedCustomerChangedReason(Reason);
            Logger.info("Analyst selects value " + Reason + " in Reason");
        } else {
            if (Reason.equalsIgnoreCase("Money Not Collected (MNC)")) {
                entityDispositionPage.selectAdvancedDeclinedMoneyNotCollectedReason(Reason);
                Logger.info("Analyst selects value " + Reason + " in Reason");
            } else {
                if (Reason.equalsIgnoreCase("Sent with Wrong Info (WIR)")) {
                    entityDispositionPage.selectAdvancedDeclinedSentwithWrongInfoWIRReason(Reason);
                    Logger.info("Analyst selects value " + Reason + " in Reason");
                } else {
                    if (Reason.equalsIgnoreCase("Consumer Fraud (CFR)")) {
                        entityDispositionPage.selectAdvancedDeclinedConsumerFraudCFRReason(Reason);
                        Logger.info("Analyst selects value " + Reason + " in Reason");
                    } else {
                        if (Reason.equalsIgnoreCase("Test Transaction Refund (TTR)")) {
                            entityDispositionPage.selectAdvancedDeclinedTestTransactionRefundTTRReason(Reason);
                            Logger.info("Analyst selects value " + Reason + " in Reason");
                        } else {
                            if (Reason.equalsIgnoreCase("Internal Policy (LVL)")) {
                                entityDispositionPage.selectAdvancedDeclinedInternalPolicyCancelReason(Reason);
                                Logger.info("Analyst selects value " + Reason + " in Reason");
                            } else {
                                if (Reason.equalsIgnoreCase("Per Regulation (LVL)")) {
                                    entityDispositionPage.selectAdvancedDeclinedPerRegulationLVLReason(Reason);
                                    Logger.info("Analyst selects value " + Reason + " in Reason");


                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @When("Analyst Click on total count Cases on {string}")
    public void analystClickOnTotalCountNumber(String Invgrp) {
        if (Invgrp.equalsIgnoreCase("Standard Investigation")) ;
        entityDispositionPage.analystClickOnTotalNumber(Invgrp);
        Logger.info("Analyst selects value " + Invgrp + " in Reason");
    }

    @When("Analyst Click on total count Grid {string}")
    public void analystClickOnTotalCountGrid(String Invgrp) {
        if (Invgrp.equalsIgnoreCase("Standard Investigation")) {
            entityDispositionPage.analystClickOnTotalNumberGRID(Invgrp);
            Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
        } else {
            if (Invgrp.equalsIgnoreCase("Enhanced Investigation")) {
                entityDispositionPage.analystClickOnTotalNumberGRIDEH(Invgrp);
                Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
            } else {
                if (Invgrp.equalsIgnoreCase("Advanced Investigation")) {
                    entityDispositionPage.analystClickOnTotalNumberGRIDAD(Invgrp);
                    Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
                } else {
                    if (Invgrp.equalsIgnoreCase("Investigation Approver")) {
                        entityDispositionPage.analystClickOnTotalNumberGRIDIA(Invgrp);
                        Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
                    }
                }
            }

        }
    }
    @When("Analyst Click on total count Grid {string} for DataCaseFilter")
    public void analystClickOnTotalCountGridDataCaseFilter(String Invgrp) {
        if (Invgrp.equalsIgnoreCase("Standard Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-flex-width-15 ml-12 wu-btn-clickable wu-case-count']")).size()>0) {
            entityDispositionPage.analystClickOnTotalNumberGRID(Invgrp);
            Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
        } else {
            if (Invgrp.equalsIgnoreCase("Enhanced Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[2]/div[1]/div[2]")).size()>0) {
                entityDispositionPage.analystClickOnTotalNumberGRIDEH(Invgrp);
                Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
            } else {
                if (Invgrp.equalsIgnoreCase("Advanced Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[3]/div[1]/div[2]")).size()>0) {
                    entityDispositionPage.analystClickOnTotalNumberGRIDAD(Invgrp);
                    Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
                } else {
                    if (Invgrp.equalsIgnoreCase("Investigation Approver") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[4]/div[1]/div[2]")).size()>0) {
                        entityDispositionPage.analystClickOnTotalNumberGRIDIA(Invgrp);
                        Logger.info("Analyst Click on total count Grid" + Invgrp + " ");
                    }
                }
            }

        }
    }
    @Then("Analyst Click on total count Grid {string} in progress panel for {string}")
    public void analystClickOnTotalCountGridInProg(String Invgrp, String BusinessGrp) throws InterruptedException {
        if (Invgrp.equalsIgnoreCase("Standard Investigation")) {
            entityDispositionPage.analystClickOnTotalNumberGRIDInProg();
            Logger.info("Analyst Click on total count Grid - In Progress panel" + Invgrp + " ");
            Thread.sleep(3000);
        }
        else if (Invgrp.equalsIgnoreCase("Enhanced Investigation")) {
            entityDispositionPage.analystClickOnTotalNumberGRIDEHInProg();
            Logger.info("Analyst Click on total count Grid - In Progress panel" + Invgrp + " ");
            Thread.sleep(3000);
        }
        else if(Invgrp.equalsIgnoreCase("Advanced Investigation")) {
            entityDispositionPage.analystClickOnTotalNumberGRIDADInProg();
            Logger.info("Analyst Click on total count Grid - In Progress panel" + Invgrp + " ");
            Thread.sleep(3000);
        } else if (Invgrp.equalsIgnoreCase("Investigation Approver")) {
            entityDispositionPage.analystClickOnTotalNumberGRIDIAInProg(Invgrp, BusinessGrp);
            Logger.info("Analyst Click on total count Grid - In Progress panel" + Invgrp + " ");
            Thread.sleep(3000);
        }
    }

    @When("Analyst Verifying total count Cases plus one on {string}")
    public void analystVerifyingOnTotalCountNumber(String Invgrp) {
        if (Invgrp.equalsIgnoreCase("Standard Investigation")) ;
        entityDispositionPage.analystClickOnTotalNumber(Invgrp);
        Logger.info("Analyst selects value " + Invgrp + " in Reason");
    }
    @Then("Analyst verifies CAT5 entity card as {string}")
    public void verifyEntityCard(String entityCard){
        Assert.assertTrue(BaseTestSetup.webDriver.findElement(By.xpath("//mat-card-title[contains(text(),'"+entityCard+"')]")).isDisplayed());
        Logger.info("CAT 5 entity card is displayed under Sanctions");

    }

    @Then("Analyst prints all Sanctions entity cards Original Source in Console")
    public void analystPrintsAllSanctionsEntityCardsOriginalSourceInConsole() {
        entityDispositionPage.clickOnAllEntityCards();
    }

    @Then("Analyst verifies INTR entity card has Category info displayed")
    public void analystVerifiesINTREntityCardHasCategoryInfoDisplayed() {
        WebDriver webDriver = BaseTestSetup.webDriver;
        String Entitycard = webDriver.findElement(By.xpath("//mat-card-title[contains(text(),'INTR')]")).getText();
        Logger.info("INTR entity card has Category info displayed " + Entitycard + "'");

    }
}
