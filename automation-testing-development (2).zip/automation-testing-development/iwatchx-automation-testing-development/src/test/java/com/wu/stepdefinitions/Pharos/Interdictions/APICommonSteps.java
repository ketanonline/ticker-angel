package com.wu.stepdefinitions.Pharos.Interdictions;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import com.jayway.jsonpath.internal.JsonContext;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.wu.api.util.common.CommonFunctions;
import com.wu.api.util.common.CouchBaseUtility;
import com.wu.base.BaseTestSetup;
import com.wu.pages.Pharos.Interdictions.CaseDispositionControlPage;
import com.wu.pages.Pharos.Interdictions.CaseInvestigationPage;
import com.wu.pages.Pharos.Interdictions.DashboardPage;
import com.wu.pages.Pharos.Interdictions.OpenSearchPage;
import com.wu.stepdefinitions.Pharos.Sanctions.CaseCreationSanctionsSteps;
import cucumber.api.java.en.Then;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import com.wu.base.logger.Logger;
import com.wu.utils.AutProperties;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.minidev.json.JSONArray;
import org.apache.commons.lang.math.NumberUtils;
import org.hamcrest.Matchers;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class APICommonSteps {

    static Configuration config = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
            .mappingProvider(new JacksonMappingProvider()).build();

    public String inputPayloadJSON = null;
    static Map<String, Object> headerMap = new HashMap<>();
    static Map<String, Object> params = new HashMap<>();
    static Map<String, Object> caseData = new HashMap<>();

    static Response apiResponse = null;
    static String dbResult = null;
    private Object UUID;

    OpenSearchPage openSearchPage=new OpenSearchPage();

    public void addCaseData(String key, String value) {

        if (caseData.containsKey(key)) {
            caseData.replace(key, value);
        } else {
            caseData.put(key, value);
        }
        System.out.println("Casedata="+caseData);
    }

    public void addCaseData(String key, int value) {

        if (caseData.containsKey(key)) {
            caseData.replace(key, value);
        } else {
            caseData.put(key, value);
        }
        System.out.println("Casedata="+caseData);
    }

    public static String getCaseData(String key) {
        if (caseData.containsKey(key)) {
            return caseData.get(key).toString();
        }
        return null;
    }

    public String getDynamicValueForVariable(String variable) {
        if (variable.contains("$")) {
            String value;
            String tempValue = variable.substring(variable.indexOf("$") + 1);
            if (tempValue.contains("$")) {
                value = tempValue.substring(0, tempValue.indexOf("$"));
                String valueToBeReplace = getCaseData(value);
                variable = variable.replace("$" + value + "$", valueToBeReplace);
            } else if (tempValue.contains(" ")) {
                value = tempValue.substring(0, tempValue.indexOf(" "));
                String valueToBeReplace = getCaseData(value);
                variable = variable.replace("$" + value, valueToBeReplace);
            } else {
                value = tempValue;
                String valueToBeReplace = getCaseData(value);
                variable = variable.replace("$" + value, valueToBeReplace);
            }
        }
        return variable;
    }

    @Given("User has input json for {string} API")
    public void givenUserHasInputJSON(String jsonName) throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", jsonName + ".json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        Logger.info("Input payload JSON for " + jsonName + " API loaded!");
    }

    @Given("User has blank input json")
    public void givenUserHasBlankInputJSON() {
        inputPayloadJSON = "";
        Logger.info("Blank input payload JSON loaded!");
    }

    @And("User deletes all the nodes in input JSON")
    public void andDeletesAllTheNodesOfInputJSON() {
        inputPayloadJSON = "{}";
        Logger.info("User deletes all the nodes in input JSON");
    }

    @And("User generates new unique guid as {string} number")
    public void andUserGeneratesNewUniqueNumber(String guidVariableName) {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String mtcnNumber = Long.toString(timestamp.getTime());
        mtcnNumber = "T" + mtcnNumber;
        guidVariableName = guidVariableName.substring(guidVariableName.indexOf("$") + 1);
        addCaseData(guidVariableName, mtcnNumber);
        Logger.info("Unique guid generated " + mtcnNumber);
    }

    @When("User updates the JSON field {string} values to {string} in the input JSON")
    public void whenUserUpdatesInputJSON(String jsonField, String expectedValues) {
        expectedValues = getDynamicValueForVariable(expectedValues);
        if (expectedValues.equalsIgnoreCase("null"))
            inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, null).json().toString();
        else if (expectedValues.equalsIgnoreCase("blank"))
            inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, "").json().toString();
        else
            inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, expectedValues).json().toString();

        Logger.info("User updates the JSON field " + jsonField + " values to " + expectedValues + " in the input JSON successfully!");
    }

    @When("User updates the JSON field {string} values to {long} in the input JSON")
    public void whenUserUpdatesInputJSON(String jsonField, Long value) {
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, value).json().toString();
        Logger.info("User updates the JSON field " + jsonField + " values to " + value + " in the input JSON successfully!");
    }

    @When("User deletes the node {string} in the input JSON")
    public void whenUserDeletesTheJSONNode(String jsonNodeToBeDeleted) {
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).delete(jsonNodeToBeDeleted).json().toString();
    }

    @When("User updates the JSON field {string} values to integer {string} in the input JSON")
    public void whenUserUpdatesIntegerInputJSON(String jsonField, String value) {
        if (NumberUtils.isNumber(value)) {
            int val = Integer.parseInt(value);
            inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, val).json().toString();
        } else {
            if (value.contains("$")) {
                value = value.substring(value.indexOf("$") + 1);
                value = getCaseData(value);
            } else {
                int i = 0;
                int val = Integer.parseInt(value + i);
                inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, val).json().toString();
            }
        }
        Logger.info("User updates the JSON field " + jsonField + " values to " + value + " in the input JSON successfully!");
    }

    @When("User adds the node {string} with value {string} in the input JSON")
    public void whenUserAddsTheJSONNode(String jsonNodeToBeAdded, String nodeValue) throws ParseException {
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).add(jsonNodeToBeAdded, jsonNodeToBeAdded).json().toString();
    }

    @When("User saves random caseId in {string}")
    public void userSavesRandomCaseId(String caseId) {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = "GSI::" + CommonFunctions.randomString(35);
        Logger.info("Case ID = " + caseIdval);
        addCaseData(caseId, caseIdval);
    }

    @When("User saves Current Timestamp in {string}")
    public void whenUserSavesCurrentTimeStamp(String timestmp) {
        if (timestmp.contains("$")) {
            timestmp = timestmp.substring(timestmp.indexOf("$") + 1);
        }
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
        Date date = new Date();

        addCaseData(timestmp, dateFormat.format(date).toString());

        Logger.info("Timestamp saved in  object " + dateFormat.format(date));
    }

    @When("User saves {string} minutes less than current Timestamp in {string}")
    public void whenUserSaves30minLTCurentTimeStamp(String min,String timestmp){
        if (timestmp.contains("$")) {
            timestmp = timestmp.substring(timestmp.indexOf("$") + 1);
        }
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");

        int minutes= Integer.parseInt(min);
        Logger.info("Given minutes: "+minutes);

        int minToMilliSec = minutes * 60 * 1000;

        Date date = new Date(System.currentTimeMillis() - minToMilliSec);
        //1 Hour - 60min -> 60min * 60sec = 3600sec (1 hour has these many seconds so multiply with 1000 to get milli seconds)
        // For half an hour it will be -->1800

        addCaseData(timestmp, dateFormat.format(date).toString());

        Logger.info(+minutes+" minutes minus current Timestamp saved:  " + dateFormat.format(date));
    }

    @Given("User saves docRefNum {string} in {string}")
    public void givenSavesDocRefNum(String docRefNumName, String docRefNum) {
        if (docRefNum.contains("$")) {
            docRefNum = docRefNum.substring(docRefNum.indexOf("$") + 1);
        }
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String docRefNumVal = CommonFunctions.readFile(fileName, docRefNumName);
        addCaseData(docRefNum, docRefNumVal);
    }

    @Given("User has a valid refId in {string}")
    public void givenUserHasValidRefId(String refIdVar) throws Exception {
        if (refIdVar.contains("$")) {
            refIdVar = refIdVar.substring(refIdVar.indexOf("$") + 1);
        }
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String refId = CommonFunctions.readFile(fileName, "ss_activityRefNo");
        addCaseData(refIdVar, refId);
        Logger.info("Ref Id '" + refId + "' saved in '" + refIdVar + "'");
    }

    @Given("User has input json for Interim API - {string} Sender case")
    public void givenUserHasInterimJSONSender(String value) throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", value + "_interimService.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.id", CommonFunctions.readFile(fileName, value + "ss_subjectId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.type", CommonFunctions.readFile(fileName, value + "ss_subjectType")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("actTimestamp", CommonFunctions.readFile(fileName, value + "ss_actTimestamp")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("activityRefNo", CommonFunctions.readFile(fileName, value + "ss_activityRefNo")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("attemptId", CommonFunctions.readFile(fileName, value + "ss_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("tranSurKey", CommonFunctions.readFile(fileName, value + "ss_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("transactionSide", CommonFunctions.readFile(fileName, value + "ss_transactionSide")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("hitSide", CommonFunctions.readFile(fileName, value + "ss_hitSide")).json().toString();
        Logger.info("Input payload JSON for Interim API loaded in session object for - GSI Sender case");
    }

    @Given("User has input json for Interim API - GSI Sender case")
    public void givenUserHasInterimJSONGSISender() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "interimService.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.id", CommonFunctions.readFile(fileName, "ss_subjectId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.type", CommonFunctions.readFile(fileName, "ss_subjectType")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("actTimestamp", CommonFunctions.readFile(fileName, "ss_actTimestamp")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("activityRefNo", CommonFunctions.readFile(fileName, "ss_activityRefNo")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("attemptId", CommonFunctions.readFile(fileName, "ss_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("tranSurKey", CommonFunctions.readFile(fileName, "ss_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("transactionSide", CommonFunctions.readFile(fileName, "ss_transactionSide")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("hitSide", CommonFunctions.readFile(fileName, "ss_hitSide")).json().toString();
        Logger.info("Input payload JSON for Interim API loaded in session object for - GSI Sender case");
    }

    @Given("User has input json for Interim API - {string} case")
    public void givenUserHasInterimJSONGSIReceiver(String value) throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "interimService.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.id", CommonFunctions.readFile(fileName, value + "_subjectId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.type", CommonFunctions.readFile(fileName, value + "_subjectType")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("actTimestamp", CommonFunctions.readFile(fileName, value + "_actTimestamp")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("activityRefNo", CommonFunctions.readFile(fileName, value + "_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("attemptId", CommonFunctions.readFile(fileName, value + "_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("tranSurKey", CommonFunctions.readFile(fileName, value + "_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("transactionSide", CommonFunctions.readFile(fileName, value + "_transactionSide")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("hitSide", CommonFunctions.readFile(fileName, value + "_hitSide")).json().toString();
        Logger.info("Input payload JSON for Interim API loaded in session object for - GSI Receiver case");
    }

    @Given("User has input json for Orch_TxnLookup API - GSI Sender case")
    public void givenUserHasTxnLookupJSONGSISender() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "TxnLookupRoute.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("header.correlationId", CommonFunctions.readFile(fileName, "ss_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnMtcn", CommonFunctions.readFile(fileName, "ss_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnAttemptID", CommonFunctions.readFile(fileName, "ss_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSurKey", CommonFunctions.readFile(fileName, "ss_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSide", CommonFunctions.readFile(fileName, "ss_transactionSide")).json().toString();
        Logger.info("Input payload JSON for TxnLookup Route API loaded in session object for - GSI Sender case");
    }

    @Given("User has input json for Orch_TxnLookup API - GSI Receiver case")
    public void givenUserHasTxnLookupJSONGSIReceiver() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "TxnLookupRoute.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("header.correlationId", CommonFunctions.readFile(fileName, "rr_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnMtcn", CommonFunctions.readFile(fileName, "rr_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnAttemptID", CommonFunctions.readFile(fileName, "rr_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSurKey", CommonFunctions.readFile(fileName, "rr_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSide", CommonFunctions.readFile(fileName, "rr_transactionSide")).json().toString();
        Logger.info("Input payload JSON for TxnLookup Route API loaded in session object for - GSI Receiver case");
    }

    @When("User has input json for Receiver at SendSide Interim API - GSI Receiver at SendSide")
    public void givenUserHasInterimJSONGSIReceiveratSendSide() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "interimService.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.id", CommonFunctions.readFile(fileName, "RS_subjectId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.type", CommonFunctions.readFile(fileName, "RS_subjectType")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("actTimestamp", CommonFunctions.readFile(fileName, "RS_actTimestamp")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("activityRefNo", CommonFunctions.readFile(fileName, "RS_activityRefNo")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("attemptId", CommonFunctions.readFile(fileName, "RS_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("tranSurKey", CommonFunctions.readFile(fileName, "RS_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("transactionSide", CommonFunctions.readFile(fileName, "RS_transactionSide")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("hitSide", CommonFunctions.readFile(fileName, "RS_hitSide")).json().toString();
        Logger.info("User has input json for Receiver at SendSide Interim API - GSI Receiver at SendSide");
    }

    @Given("User has input json for Orch_EntityLookup API - GSI Sender case")
    public void givenUserHasEntityLookupJSONGSISender() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "entityLookupRoute.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("header.correlationId", CommonFunctions.readFile(fileName, "ss_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("referenceNumber", CommonFunctions.readFile(fileName, "ss_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnAttemptID", CommonFunctions.readFile(fileName, "ss_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSurKey", CommonFunctions.readFile(fileName, "ss_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSide", CommonFunctions.readFile(fileName, "ss_transactionSide")).json().toString();
        Logger.info("Input payload JSON for Entity Lookup Route API loaded in session object for - GSI Sender case");
    }

    @Given("User has input json for Orch_EntityLookup API - GSI Receiver case")
    public void givenUserHasEntityLookupJSONGSIReceiver() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "entityLookupRoute.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("header.correlationId", CommonFunctions.readFile(fileName, "rr_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("referenceNumber", CommonFunctions.readFile(fileName, "rr_activityRefNo")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnAttemptID", CommonFunctions.readFile(fileName, "rr_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSurKey", CommonFunctions.readFile(fileName, "rr_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("txnSide", CommonFunctions.readFile(fileName, "rr_transactionSide")).json().toString();
        Logger.info("Input payload JSON for Entity Lookup Route API loaded in session object for - GSI Receiver case");
    }

    @When("DBResult = query for ProfileAttachment with subjectId = {string}")
    public void dbQueryForProfileAttachmentWithSubjectId(String subjectId) throws Exception {
        String query;
        if (subjectId.contains("$")) {
            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
            subjectId = getCaseData(subjectId);
        }
        query = "SELECT *\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='profileAttachment'\n" +
                "    AND subject.id='" + subjectId + "'\n" +
                "ORDER BY createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("query for ProfileAttachment with caserefno = {string}")
    public void dbQueryForProfileAttachmentWithcaserefno(String caseRefNo) throws Exception {
        String query;
        if (caseRefNo.contains("$")) {
            caseRefNo = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
            caseRefNo = getCaseData(caseRefNo);
        }
        query = "SELECT subject.id as subjectId FROM iWatchXCustomerJourney\n" +
                "WHERE docType='gsiCase'\n" +
                "AND caseRefNo='" + caseRefNo + "'\n" +
                "ORDER BY createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("subjectId = {string} for caserefno = {string}")
    public void thenUserSavesTheSubjectIdForcaserefno(String subjectId, String caseRefNo) throws Exception {
        if (caseRefNo.contains("$")) {
            caseRefNo = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
            caseRefNo = getCaseData(caseRefNo).toString();
        }
        if (subjectId.contains("$")) {
            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
        }
        dbQueryForProfileAttachmentWithcaserefno(caseRefNo);
        String subjectIdVal = (String) CommonFunctions.getValueFromJSON("subjectId", dbResult);
        addCaseData(subjectId, subjectIdVal);
        Logger.info("\"subjectId\" = " + getCaseData(subjectId) + " for this caseRefNo");

    }
// Completed updates to input payload methods

    // Adding Headers
    @And("User has header for GSI INTR {string} API")
    public void userHasHeader(String apiName) {
        UUID uuid = java.util.UUID.randomUUID();
        headerMap.clear();
        switch (apiName) {
            case "Gateway":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-bizGrp", "GSI");
                headerMap.put("x-wu-invGrp", "INTR");
                String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
                headerMap.put("Authorization", "Bearer " + CommonFunctions.readFile(fileName, "gwToken"));
                headerMap.put("x-api-key", CommonFunctions.readFile(fileName, "x_api_key"));
                break;
            case "RefreshMetric":
                headerMap.put("x-wu-correlationId","b04c0de8-7862-4868-b46c-308ad6be298b");
                headerMap.put("x-wu-tenantpid","WU");
                headerMap.put("x-wu-tenantsid","CMT");
                headerMap.put("x-wu-bizgrp","GSI");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-userid", "321381");
                headerMap.put("x-wu-username","Swaraj");
                headerMap.put("x-wu-useremail","S@wu.com");
                headerMap.put("Content-Type","application/json");
                break;
            case "AFRefreshMetric":
                headerMap.put("x-wu-correlationId","b04c0de8-7862-4868-b46c-308ad6be298b");
                headerMap.put("x-wu-tenantpid","WU");
                headerMap.put("x-wu-tenantsid","CMT");
                headerMap.put("x-wu-bizgrp","GSI");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-userid", "321381");
                headerMap.put("x-wu-username","Swaraj");
                headerMap.put("x-wu-useremail","S@wu.com");
                headerMap.put("Content-Type","application/json");
                break;

            case "Gateway2":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-bizGrp", "GSI");
                headerMap.put("x-wu-invGrp", "INTR");
                String fileName2 = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
                headerMap.put("Authorization", "Bearer " + CommonFunctions.readFile(fileName2, "gwToken"));
                headerMap.put("x-api-key", CommonFunctions.readFile(fileName2, "x_api_key"));
                headerMap.put("x-apigw-api-id", "5wkt6cw6yf");
                break;

            case "AssignToAnalyst":
            case "skipDocUpload":
            case "skipEvaluation":
            case "skipTxnVerification":
            case "startWFM":
            case "reEvaluation":
            case "inforamtionReceived":
            case "evaluateEntities":
            case "CaseManager_Pend":
            case "attachment_Upload":
            case "attachment_download":
            case "attachment_getMetadata":
            case "ProfileAttachmentGet":
            case "ComplianceVisibility_CaseList":
            case "ComplianceVisibility_CaseStatus":
            case "casedispositionhierarchy":
            case "interimService":
            case "CM_GridView":
            case "CaseManager_View":
            case "CaseManager_Work":
            case "entityLookupRoute":
            case "interimServiceRoute":
            case "action_failure":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-bizGrp", "GSI");
                headerMap.put("x-wu-invGrp", "INTR");
                headerMap.put("x-wu-userId", "4521");
                headerMap.put("x-wu-userEmail", "priya@Wu.com");
                headerMap.put("x-wu-userName", "priyanka goli");
                headerMap.put("x-wu-correlationId", uuid);
                break;

            default:
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-bizGrp", "GSI");
                headerMap.put("x-wu-invGrp", "INTR");
                headerMap.put("x-wu-userId", "4521");
                headerMap.put("x-wu-userEmail", "priya@Wu.com");
                headerMap.put("x-wu-userName", "priyanka goli");
                headerMap.put("x-wu-correlationId", uuid);
                break;


            case "audit_save":
            case "WFM_addAudit":
                userHasHeader("default");
                headerMap.put("x-wu-serviceid", "IWXCJWFM");
                break;

            case "casecreationcomment":
                userHasHeader("default");
                headerMap.put("eventType", "CASE_CREATION_COMMENT");
                break;

            case "casedisposition_comment":
                userHasHeader("default");
                headerMap.put("eventType", "CASE_DISPOSITION_COMMENT");
                break;

            case "casedisposition":
                userHasHeader("default");
                headerMap.put("eventType", "CASE_DISPOSITION");
                break;

            case "caseconversationcomment":
                userHasHeader("default");
                headerMap.put("eventType", "CASE_CONVERSATION_COMMENT");
                break;

            case "BulkUpload_FileInput":
//                headerMap.put("x-wu-tenantPid", "WU");
//                headerMap.put("x-wu-tenantSid", "CMT");
//                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-bizGrp", "GSI");
//                headerMap.put("x-wu-invGrp", "INTR");
//                headerMap.put("x-wu-userId", "4521");
//                headerMap.put("x-wu-userEmail", "priya@Wu.com");
//                headerMap.put("x-wu-userName", "priyanka goli");
//                headerMap.put("x-wu-correlationId", uuid);
            case "BulkUpload_DataRange":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-bizGrp", "GSI");
                headerMap.put("x-wu-correlationId", uuid);
                break;
            case "BulkUpload_ByRequestID":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-correlationId", uuid);
                break;

            case "CVS_SingleFind":
            case "CVS_MultiFind":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-userId", "4521");
                headerMap.put("x-wu-userEmail", "ravi@wu.com");
                headerMap.put("x-wu-userName", "ravi kapoor");
                headerMap.put("x-wu-correlationId", uuid);
                break;

            case "Orch_ProfileAttachment":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-bizGrp", "GSI");
                headerMap.put("x-wu-invGrp", "INTR");
                headerMap.put("x-wu-userId", "4521");
                headerMap.put("x-wu-userEmail", "sabitha@wu.com");
                headerMap.put("x-wu-userName", "Sabitha Ijanagiri");
                headerMap.put("x-wu-correlationId", uuid);
                break;

            case "Orch_CVS_SingleFind":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-genre", "CJ");
                headerMap.put("x-wu-userId", "4521");
                headerMap.put("x-wu-userEmail", "sabitha@wu.com");
                headerMap.put("x-wu-userName", "Sabitha Ijanagiri");
                headerMap.put("x-wu-correlationId", uuid);
                break;

            case "txnloookuproute":
                headerMap.put("x-wu-tenantPid", "WU");
                headerMap.put("x-wu-tenantSid", "CMT");
                headerMap.put("x-wu-bizGrp", "GSI");
                headerMap.put("x-wu-invGrp", "INTR");
                break;

        }
        Logger.info("Header for " + apiName + " API loaded!");
    }

    @And("User has header for KYC {string} API")
    public void userHasHeaderForKYC(String apiName) {
        headerMap.clear();
        headerMap.put("x-wu-tenantPid", "WU");
        headerMap.put("x-wu-tenantSid", "CMT");
        headerMap.put("x-wu-genre", "CJ");
        headerMap.put("x-wu-bizGrp", "KYC");
        headerMap.put("x-wu-invGrp", "CDR");
        headerMap.put("x-wu-userId", "8419549");
        headerMap.put("x-wu-userEmail", "Prajna.Kargupta@wu.com");
        headerMap.put("x-wu-userName", "Prajna");
        headerMap.put("x-wu-correlationId", "7894561230");
        Logger.info("Header for KYC " + apiName + "' API loaded!");
    }


    @And("User has header for GSI SANC {string} API")
    public void userHasHeaderForGSISanc(String apiName) {
        headerMap.clear();
        userHasHeader(apiName);
        headerMap.put("x-wu-invGrp", "SANC");
        Logger.info("Header for GSI Sanctions '" + apiName + "' API loaded!");
    }

    @And("User has header for GSI Dual {string} API")
    public void userHasHeaderForGSIDual(String apiName) {
        headerMap.clear();
        userHasHeader(apiName);
        headerMap.put("x-wu-invGrp", "GSI");
        Logger.info("Header for GSI  '" + apiName + "' API loaded!");
    }

    @And("User deletes header {string}")
    public void andUserDeletesHeader(String headerKey) {
        headerMap.remove(headerKey);
        Logger.info("Header for " + headerKey + " removed");
    }

    @And("User updates header {string} to value {string}")
    public void andUserUpdatesHeader(String headerKey, String headerValue) {
        if (headerValue.equalsIgnoreCase("blank"))
            headerValue = "";
        headerMap.replace(headerKey, headerValue);
        Logger.info("Header for " + headerKey + " updated to " + headerValue);
    }

    @And("User has no headers")
    public void userHasNoHeaders() {
        headerMap.clear();
    }

// Completed Adding Header method

// Starting API call

    @When("User calls the {string} API with {string} method")
    public void whenUserCallsTheAPI(String apiName, String methodType) throws NullPointerException {
        String apiURL = CommonFunctions.getApiURL(apiName);
        apiResponse = CommonFunctions.apiCall(apiURL, apiName, methodType, inputPayloadJSON, headerMap, params);
        Logger.info("User calls the " + apiName + " API with " + methodType + " method");
    }

    @When("User calls the {string} API with {string} method with headers and Query params {string} and values {string}")
    public void whenUserCallsTheAPIWithHeadersWithQueryParams(String apiName, String methodType, String paramNames, String paramValues) throws NullPointerException {
        String[] paramNm = paramNames.split(";");
        String[] paramVal = paramValues.split(";");

        Map<String, Object> params = new HashMap<>();

        for (int index = 0; index < paramNm.length; index++) {
            String paramName = paramNm[index];
            String paramValue = paramVal[index];

            paramValue = getDynamicValueForVariable(paramValue);
            params.put(paramName, paramValue);
        }
        String apiURL = CommonFunctions.getApiURL(apiName);
        apiResponse = CommonFunctions.apiCallWithQueryParams(apiURL, apiName, methodType, inputPayloadJSON, headerMap, params);
        Logger.info("User calls the " + apiName + " API with " + methodType + " method and params " + params);

    }

    @When("User calls the {string} API with {string} method and headers and authorization {string}")
    public void whenUserCallsTheAPIWithHeadersAndAuth(String apiName, String methodName, String token) {
        if (token.contains("$")) {
            token = (String) getCaseData("Token");
        }
        headerMap.put("Authorization", "Bearer " + token);
        whenUserCallsTheAPI(apiName, methodName);
    }

    @When("User calls the {string} API with {string} method and Path Params {string} and values {string}")
    public void whenUserCallsTheAPIWithPathParams(String apiName, String methodType, String paramNames, String paramValues) throws NullPointerException {
        String[] paramNm = paramNames.split(";");
        String[] paramVal = paramValues.split(";");
        Map<String, Object> params = new HashMap<>();

        for (int index = 0; index < paramNm.length; index++) {
            String paramName = paramNm[index];
            String paramValue = paramVal[index];

            if (paramValue.contains("$")) {
                paramValue = paramValue.substring(paramValue.indexOf("$") + 1);
                paramValue = getCaseData(paramValue).toString();
            }
            params.put(paramName, paramValue);
        }
        String apiURL = CommonFunctions.getApiURL(apiName);
        apiResponse = CommonFunctions.apiCall(apiURL, apiName, methodType, inputPayloadJSON, headerMap, params);
        Logger.info("User calls the " + apiName + " API with " + methodType + " method with Path Params as {" + paramNames + "} and Values ={" + paramValues + "}");

    }

    @When("User calls the {string} API with {string} method and headers and Path Params {string} and values {string}")
    public void whenUserCallsTheAPIWithHeadersWithPathParams(String apiName, String methodType, String paramNames, String paramValues) {
        String[] paramNm = paramNames.split("[;]");
        String[] paramVal = paramValues.split("[;]");
        int size = paramNm.length;
        Map<String, Object> params = new HashMap<>();
        for (int index = 0; index < size; index++) {
            String paramName = paramNm[index];
            String paramValue = paramVal[index];
            if (paramValue.equalsIgnoreCase("blank")) {
                paramValue = "";
            } else {
                paramValue = getDynamicValueForVariable(paramValue);
            }
            params.put(paramName, paramValue);
        }
        Logger.info("User calls the " + apiName + " API with " + methodType + " method and headers with Path Params as \"paramNames\" = {" + paramNames + "} and Values = {" + paramValues + "}");
        String apiURL = CommonFunctions.getApiURL(apiName);
        apiResponse = CommonFunctions.apiCall(apiURL, apiName, methodType, inputPayloadJSON, headerMap, params);

    }

    @When("User calls the {string} API with {string} method and headers with file name {string}, extension {string}")
    public void whenUserCallsTheAPIWithFile(String apiName, String methodType, String filename, String extension) {
        String mimeType = null;
        String filePath = CommonFunctions.getFullPath("uploadFiles", filename + "." + extension);
        switch (extension.toUpperCase()) {
            case "PNG":
                mimeType = "image/png";
                break;
            case "PDF":
                mimeType = "application/pdf";
                break;
            case "JPEG":
            case "JPG":
                mimeType = "image/jpeg";
                break;
            case "xls":
                mimeType = "application/vnd.ms-excel";
                break;
        }
        String apiURL = CommonFunctions.getApiURL(apiName);
        apiResponse = CommonFunctions.apiCallWithFile(apiURL, apiName, methodType, inputPayloadJSON, filePath, mimeType, headerMap, params);
        Logger.info("User calls the " + apiName + " API with " + methodType + " method" + "with " + extension + " file");

    }

    @When("User calls the {string} API with {string} method and headers and authorization {string} with file name {string}, extension {string}, mime {string}")
    public void whenUserCallsTheAPIWithFile(String apiName, String methodName, String token, String filename, String extension, String mimeType) {
        if (token.contains("$")) {
            token = (String) getCaseData("Token");
        }
        headerMap.put("Authorization", "Bearer " + token);
        whenUserCallsTheAPIWithFile(apiName, methodName, filename, extension);

    }

    @When("User calls the {string} API with {string} method and headers and authorization {string} and Path Params {string} and values {string}")
    public void whenUserCallsTheAPIWithHeadersAndAuthWithPathParams(String apiName, String methodName, String Auth, String paramNames, String paramValues) {
        if (Auth.contains("$")) {
            Auth = (String) getCaseData("Token");
        }
        headerMap.put("Authorization", "Bearer " + Auth);
        whenUserCallsTheAPIWithHeadersWithPathParams(apiName, methodName, paramNames, paramValues);

    }

    @When("User calls the {string} API with {string} method and headers with only file name {string}, extension {string}")
    public void whenUserCallsTheAPIWithOnlyFile(String apiName, String methodType, String filename, String extension) {
        String mimeType = null;
        String filePath = CommonFunctions.getFullPath("uploadFiles", filename + "." + extension);
        switch (extension.toUpperCase()) {
            case "PNG":
                mimeType = "image/png";
                break;
            case "PDF":
                mimeType = "application/pdf";
                break;
            case "JPEG":
            case "JPG":
                mimeType = "image/jpeg";
                break;
            case "xls":
                mimeType = "application/vnd.ms-excel";
                break;
            case "xlsx":
                mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                break;
        }
        String apiURL = CommonFunctions.getApiURL(apiName);
        apiResponse = CommonFunctions.apiCallWithFile(apiURL, apiName, methodType, "{}", filePath, mimeType, headerMap, params);
        Logger.info("User calls the " + apiName + " API with " + methodType + " method" + "with " + extension + " file");

    }

    // API call completed here
    @When("User waits for {int} hours")
    public void whenUserWaitsFor(int i) throws InterruptedException {
        Thread.sleep((long) i * 60 * 60 * 1000);
    }
// Started verification

    @Then("API response statusCode should be {string}")
    public void thenUserVerifiedAPIResponseStatusCode(String expectedAPIResponseStatusCode) {
        Logger.info("Verify API response statusCode should be " + expectedAPIResponseStatusCode);
        assertThat("API request should successfully posted", CommonFunctions.getStatusCode(apiResponse).toString(),
                (equalTo(expectedAPIResponseStatusCode)));
    }

    @Then("User waits for the update in database")
    public void thenUserWaitsForDatabaseUpdate() throws InterruptedException {
        Thread.sleep(10000);
    }

    @Then("API response should have {string} matches with DBResult {string}")
    public void thenUserVerifiesAPIResponseWithDBResult(String apiResponseNode, String dbResultJsonNode) {
        Object val1 = CommonFunctions.getTagVal(apiResponse, apiResponseNode);
        Object val2 = CommonFunctions.getValueFromJSON(dbResultJsonNode, dbResult);
        Logger.info("Verify API response should have " + apiResponseNode + " matches with DBResult " + dbResultJsonNode);
        assertThat("API response validation :", val1.equals(val2));
    }

    @Then("API response should have pretier {string}")
    public void thenUserValidateAPIResponse(String apiResponseNode) {
        if (apiResponseNode.equalsIgnoreCase("[0].prevTierAnalyst.id")) {
            String EntityIdVal = (String) CommonFunctions.getValueFromJSON("[0].prevTierAnalyst.id", apiResponseNode);
            EntityIdVal.getBytes();
            Logger.info("Verify API response should have " + apiResponseNode + " matches with DBResult " + EntityIdVal);
        }
    }

    @And("User verifies that {string} is not present in the case list response")
    public void userVerifiesCaseIsNotPresentInCaselist(String caseId){
        String status = CommonFunctions.getStatusCode(apiResponse).toString();
        Logger.info("status is : "+status);
        if(status.equals("200")) {
            int i = 0;
//            Logger.info("before if loop .. case id :"+CommonFunctions.getTagValue(apiResponse, "caseId[1]"));
            while (CommonFunctions.getTagValue(apiResponse, "caseId[" + i + "]") != null) {
//                Logger.info("while loop");
            if ((CommonFunctions.getTagValue(apiResponse, "caseId[" + i + "]").equals(caseId))) {
                Logger.info("Case :"+CommonFunctions.getTagValue(apiResponse, "caseId[" + i + "]"));
                Assert.assertTrue(FALSE,"Case should not be present in the case list");
                break;
            }
            i++;
        }
        }
        else if(status.equals("400")){
            Logger.info("No cases in this criteria");
        }
        else{
            Assert.assertTrue(FALSE,"Status code error");
        }
//
//        assertThat("API response validation for Node : errorDetails.field ", validation, equalTo(TRUE));
        Logger.info("Case is not present in the Action failure case list ");
    }


    @Then("API response should have {string} as {string}")
    public String thenUserVerifiedAPIResponse(String responseJSONNode, String expectedValues) {
        if (expectedValues.contains("$")) {
            String value;
            String tempValue = expectedValues.substring(expectedValues.indexOf("$") + 1);
            if (tempValue.contains("$")) {
                value = tempValue.substring(0, tempValue.indexOf("$"));
                String valueToBeReplace = getCaseData(value);
                expectedValues = expectedValues.replace("$" + value + "$", valueToBeReplace);
            } else if (tempValue.contains(" ")) {
                value = tempValue.substring(0, tempValue.indexOf(" "));
                String valueToBeReplace = getCaseData(value);
                expectedValues = expectedValues.replace("$" + value, valueToBeReplace);
            } else {
                value = tempValue;
                String valueToBeReplace = getCaseData(value);
                expectedValues = expectedValues.replace("$" + value, valueToBeReplace);
            }
        } else if (expectedValues.equalsIgnoreCase("null")) {
            assertThat("API response validation for Node :" + responseJSONNode, CommonFunctions.getTagValue(apiResponse, responseJSONNode),
                    nullValue());
            return null;
        }
        Logger.info("API response should have " + responseJSONNode + " as " + expectedValues + "");
        assertThat("API response validation for Node :" + responseJSONNode, CommonFunctions.getTagValue(apiResponse, responseJSONNode),
                (equalTo(expectedValues)));
        return null;
    }

    @Then("API response should have errorDetails field as {string}")
    public void thenUserVerifiedAPIResponseErrorDetailsField(String expectedValues) {
        int i = 0;
        boolean validation = FALSE;
        while (CommonFunctions.getTagValue(apiResponse, "errorDetails[" + i + "].field") != null) {
            if (Objects.equals(CommonFunctions.getTagValue(apiResponse, "errorDetails[" + i + "].field"), expectedValues)) {
                validation = TRUE;
                Logger.info("API response should have errorDetails.fields as" + expectedValues);

                break;
            }
            i++;
        }
        assertThat("API response validation for Node : errorDetails.field ", validation, equalTo(TRUE));
    }

    @Then("API response should have errorDetails field for {string}, issue as {string}")
    public void thenUserVerifiedAPIResponseErrorDetailsIssue(String errorField, String errorIssue) {
        int i = 0;
        boolean validation = FALSE;
        String[] errorIssues = errorIssue.split("[;]");
        for (String issue : errorIssues) {
            while (CommonFunctions.getTagValue(apiResponse, "errorDetails[" + i + "].issue") != null) {
//                Assert.assertEquals(CommonFunctions.getTagValue(apiResponse, "errorDetails[" + i + "].issue"), issue);
                if (Objects.equals(CommonFunctions.getTagValue(apiResponse, "errorDetails[" + i + "].issue"), issue)) {
                    validation = TRUE;
                    Logger.info("API response should have errorDetails.fields as" + issue);
                    break;
                }
                i++;
            }
        }
//        assertThat("API response validation for Node : errorDetails.issue ", validation, equalTo(TRUE));
    }

    @Then("API response should have {string} as {string} includes {string}")
    public void thenUserVerifiedAPIResponse(String responseJSONNode, String values, String dynamicValues) {
        String expected = values + getCaseData(dynamicValues).toString();
        assertThat("API response validation :", CommonFunctions.getTagValue(apiResponse, responseJSONNode),
                (equalTo(expected)));
    }

    @Then("API response should have {string} as Null")
    public void thenUserVerifiedAPIResponse(String responseJSONNode) {
        Logger.info("API response should have " + responseJSONNode + " as Null");
        assertThat("API response validation :", CommonFunctions.getTagValue(apiResponse, responseJSONNode),
                (equalTo(null)));
    }

    @Then("API response should have {string} as Not Null")
    public void thenUserVerifiedAPIResponseAsNotNull(String responseJSONNode) {
        Logger.info("API response should have " + responseJSONNode + " as NOT Null");
        assertThat("API response validation :", CommonFunctions.getTagValue(apiResponse, responseJSONNode), Matchers.notNullValue());
    }

    @Then("API response should have {string} as digit {string}")
    public void thenUserVerifiedAPIResponseAsdigit(String responseJSONNode, String digit) {

        Object value = CommonFunctions.getTagValue(apiResponse, responseJSONNode);
        int size = value.toString().length();
        int digitNo = Integer.parseInt(digit);
        assertThat("API response validation :", size, Matchers.equalTo(digitNo));
        Logger.info("API response should have node " + responseJSONNode + " have " + size + " digit");
    }

    @Then("API response should have node {string}")
    public void thenUserVerifiesAPIResponseShouldHaveNode(String responseJSONNode) {
        Logger.info("API response should have node " + responseJSONNode);
        assertThat("API response should have node \"" + responseJSONNode + "\"",
                CommonFunctions.verifyJSONObjectHasTag(responseJSONNode, CommonFunctions.getResponseAsJSONObject(apiResponse)), equalTo(TRUE));
    }

    @Then("API response {string} should not be empty")
    public void thenUserVerifiedAPIResponseNotEmpty(String responseJSONNode) {
        if (responseJSONNode.equals("$")) Logger.info("API response should not be empty");
        else Logger.info("API response node \"" + responseJSONNode + "\" should not be empty");
        assertThat("API response validation :", CommonFunctions.getResponseSize(apiResponse, responseJSONNode), Matchers.notNullValue());
    }

    @Then("API response {string} should be empty")
    public void thenUserVerifiedAPIResponseEmptyArray(String responseJSONNode) {
        Logger.info("User verifies apiResponse should be Empty");
        assertThat("API response validation :", CommonFunctions.getResponseSize(apiResponse, responseJSONNode), Matchers.equalTo(0));
    }

    @When("User saves {string} value of {string} into {string}")
    public void whenUserSavesCouchbaseDataToVariable(String JSONResult, String fieldName, String variable) {
        if (JSONResult.contains("$")) {
            JSONResult = JSONResult.substring(JSONResult.indexOf("$") + 1);
        }
        Object JSONvalue = CommonFunctions.getValueFromJSON(fieldName, JSONResult);
        addCaseData(variable, JSONvalue.toString());

        Logger.info("User saves from " + JSONResult + ": Value of \" " + fieldName + "\" to Variable " + variable);
    }

    @Then("API response should have {string} as {string} or {string}")
    public void thenUserVerifiedAPIResponseWithTwoValues(String responseJSONNode, String expectedValue1, String expectedValue2) {
        if (expectedValue1.contains("$")) {
            expectedValue1 = expectedValue1.substring(expectedValue1.indexOf("$") + 1);
            expectedValue1 = (String) getCaseData(expectedValue1);
        }
        if (expectedValue2.contains("$")) {
            expectedValue2 = expectedValue2.substring(expectedValue2.indexOf("$") + 1);
            expectedValue2 = (String) getCaseData(expectedValue2);
        }
        if (responseJSONNode.contains("$")) {
            responseJSONNode = expectedValue2.substring(responseJSONNode.indexOf("$") + 1);
            responseJSONNode = (String) getCaseData(responseJSONNode);

        }
        Logger.info("API response should have " + responseJSONNode + " as " + expectedValue1 + " or " + expectedValue2);
        assertThat("API response validation :", ((CommonFunctions.getTagValue(apiResponse, responseJSONNode).equals(expectedValue1)) || (CommonFunctions.getTagValue(apiResponse, responseJSONNode).equals(expectedValue2))));
    }

    @Then("User saves API Response value of {string} into {string}")
    public void thenUserSavesAPIResponseValue(String responseJSONNode, String variable) {
        if (variable.contains("$")) {
            variable = variable.substring(variable.indexOf("$") + 1);
        }
        if (responseJSONNode.contains("$")) {
            responseJSONNode = responseJSONNode.substring(responseJSONNode.indexOf("$") + 1);
        }
        addCaseData(variable, CommonFunctions.getTagValue(apiResponse, responseJSONNode));
        Logger.info((String) getCaseData(variable));
    }

    @Then("API response contains header {string}")
    public void thenUserVerifiesAPIResponseHeaderContainsExpHeader(String expResponseHeader) {
        Headers allHeaders = apiResponse.headers();
        assertThat("API Response contains Header \"" + expResponseHeader + "\"", allHeaders.hasHeaderWithName(expResponseHeader), equalTo(TRUE));
        Logger.info("API Response contains Header \"" + expResponseHeader + "\"");
    }

    @Then("API response contains {string} as {string}")
    public void thenUserVerifiedAPIResponseContainsExpMsg(String responseJSONNode, String expectedValues) {
        if (expectedValues.contains("$")) {
            String value = expectedValues.substring(expectedValues.indexOf("$") + 1);
            String valueToBeReplace = getCaseData(value);
            expectedValues = expectedValues.replace("$" + value, valueToBeReplace);
        }
        if (CommonFunctions.getTagValue(apiResponse, responseJSONNode).contains(expectedValues))
            Logger.info("API response should have " + responseJSONNode + " as " + expectedValues + "");
        else
            Logger.info("API response doesn't have " + responseJSONNode + " as " + expectedValues + "");
    }

    @And("Analyst saves total count of action failures from API response in {string}")
    public void AnalystSavesTotalCountFromResponse(String totalcount){
        Logger.info("variable :"+totalcount);
        if (totalcount.contains("$")) {
            totalcount = totalcount.substring(totalcount.indexOf("$") + 1);
            String totalCountFromResponse =  CommonFunctions.getTagValue(apiResponse, "actionFailureMetrics.totalCases");
            addCaseData(totalcount,totalCountFromResponse);
            Logger.info("Total count from response is : "+totalCountFromResponse);

        }


    }



    @And("Analyst saves correlationid from API Response in {string}")
    public void analystSavesCorrelationId(String correlationId){
        if (correlationId.contains("$")) {
            correlationId = correlationId.substring(correlationId.indexOf("$") + 1);
            String correlationIdFromResponse =  CommonFunctions.getTagValue(apiResponse, "traceId");
            addCaseData(correlationId,correlationIdFromResponse);
            Logger.info("Correlation Id from response is : "+correlationIdFromResponse);

        }
    }

// DB result Verification

    @Then("DBResult should be empty")
    public void thenUserVerifiedDBResultEmptyArray() {
        Logger.info("User verifies DBResult should be empty");
        assertThat("API response validation :", dbResult, Matchers.equalTo("0 result"));
    }

    @Then("DBResult should not be empty")
    public void thenUserVerifiedDBResultNotEmptyArray() {
        Logger.info("User verifies DBResult should not be empty");
        assertThat("API response validation :", dbResult, Matchers.not("0 result"));
    }

    @When("DBResult = query {string}")
    public void whenUserExecutesDatabaseQuery(String query) throws Exception {
        if (query.contains("$")) {
            String value = query.substring(query.indexOf("$") + 1);
            String valueToBeReplace = "'" + getCaseData(value).toString() + "'";
            query = query.replace("$" + value, valueToBeReplace);
        }
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query);
        dbResult = queryResult;
        System.out.println(queryResult);
    }

    @Then("User verifies {string} with {string} as per {string} file")
    public void whenUserVerfiesCouchbaseData(String apiResponse, String cbQueryResult, String mappingFile) throws Exception {
        Logger.info("User verifies " + apiResponse + " with " + cbQueryResult + " as per " + mappingFile + " file");
        String filePath = CommonFunctions.getFullPath_GSI_INTR("field-mapping", mappingFile + ".txt");
        List<String> mappingRecords = CommonFunctions.readFileData(filePath);

        if (apiResponse.contains("$")) {
            apiResponse = apiResponse.substring(apiResponse.indexOf("$") + 1);
        }
        if (cbQueryResult.contains("$")) {
            cbQueryResult = cbQueryResult.substring(cbQueryResult.indexOf("$") + 1);
        }
        for (String str : mappingRecords) {
            String str1 = str.split(":")[0];
            String str2 = str.split(":")[1];

            Object val1 = CommonFunctions.getValueFromJSON(str1, apiResponse);
            Object val2 = CommonFunctions.getValueFromJSON(str2, cbQueryResult);
            assertThat("API response validation :", val1.equals(val2));
        }
    }

    @Then("User verifies DBResult with Input Payload JSON as per {string} file")
    public void thenUserVerifiesCouchbaseDataWithInputPayloadJSON(String mappingFile) throws Exception {
        Logger.info("User verifies DBResult with Input Payload JSON as per " + mappingFile + " file");
        String filePath = CommonFunctions.getFullPath_GSI_INTR("field-mapping", mappingFile + ".txt");
        List<String> mappingRecords = CommonFunctions.readFileData(filePath);
        for (String str : mappingRecords) {

            String str1 = str.split(":")[0];
            String str2 = str.split(":")[1];
            Object val1 = null;
            Object val2 = null;
            try {
                val1 = JsonPath.read(dbResult, str1);
                val2 = JsonPath.read(inputPayloadJSON, str2);

                assertThat("Validation - Data is stored in DB as per Input Payload JSON :", val1, (equalTo(val2)));
                Logger.info("Validated:" + "DB Node : " + str1 + " Value : " + val1 + "IS EQUAL to" + "InputJSON Node : " + str2 + val2);
            } catch (PathNotFoundException exc) {
                Logger.info("API Node : " + str1 + " not found");
            }
        }
    }

    // TODO - Need to discuss with Ravi and Sabitha
    @Given("User verifies api response with {string} as per {string} file")
    public void whenUserVerifiesCouchbaseData(String cbQueryResult, String mappingFile) throws Exception {
       // System.out.print("Inside the method");
        String filePath = CommonFunctions.getFullPath_GSI_INTR("field-mapping", mappingFile + ".txt");
        List<String> mappingRecords = CommonFunctions.readFileData(filePath);
        List<String> apiResponseFields = new ArrayList<>();
        List<String> dbResultFields = new ArrayList<>();
        for (String str : mappingRecords) {
            apiResponseFields.add(str.split(":")[0]);
//            System.out.println("apiresponse after split:"+apiResponseFields);
            dbResultFields.add(str.split(":")[1]);
//            System.out.println("DB response after split:"+dbResultFields);
        }

        if (cbQueryResult.contains("$")) {
            cbQueryResult = cbQueryResult.substring(cbQueryResult.indexOf("$") + 1);
        }
        Logger.info("User verifies API Response with " + cbQueryResult + " as per \"" + mappingFile + "\" file");

        String responseStr = apiResponse.body().asString();
        JsonContext responseJSON = (JsonContext) new JsonContext().parse(responseStr);

        String DBResult = (String) dbResult;
        JsonContext DBResultJSON = (JsonContext) new JsonContext().parse(DBResult);

        for (int i = 0; i < apiResponseFields.size(); i++) {
            try {
                Object val1 = responseJSON.read(apiResponseFields.get(i));
                System.out.println("api response is : "+val1);
                Object val2 = DBResultJSON.read(dbResultFields.get(i));
                System.out.println("DB response is : "+val2);


                Logger.info("Validated:" + "API Node : " + apiResponseFields.get(i) + " Value : " + val1 + "IS EQUAL to" + "DB Node : " + dbResultFields.get(i) + val2);
                assertThat("API response validation with DB values :", val1, (equalTo(val2)));
            } catch (PathNotFoundException exc) {
                Logger.info("API Node : " + apiResponseFields.get(i) + " not found");
            }
        }

    }

    @Then("User verifies {string} with {string} should have {string}")
    public void thenUserVerifiesCouchbaseDataWithExpResult(String cbQueryResult, String fieldName, String ExpData) {
        Logger.info("User verifies DB Response with " + cbQueryResult + " as per " + ExpData);
        if (cbQueryResult.contains("$")) {
            cbQueryResult = cbQueryResult.substring(cbQueryResult.indexOf("$") + 1);
        }
        Object val = CommonFunctions.getValueFromJSON(fieldName, cbQueryResult);
        assertThat("DB result validation :", val, (equalTo(ExpData)));
    }

    @Then("User verifies DBResult path {string} should have {string}")
    public void thenUserVerifiesCouchbaseDataWithExpResult(String fieldName, String ExpData) {
        ExpData = getDynamicValueForVariable(ExpData);
        Logger.info("User verifies DB Result path '" + fieldName + "' value is '" + ExpData + "'");
        Object val = CommonFunctions.getValueFromJSON(fieldName, dbResult);
        assertThat("DB result validation :", val, (equalTo(ExpData)));
    }

    @Then("User verifies DBResult path {string} contains {string}")
    public void thenUserVerifiesCouchbaseDataContainsExpResult(String fieldName, String ExpData) {
        ExpData = getDynamicValueForVariable(ExpData);
        Logger.info("User verifies DB Result path '" + fieldName + "' contains string  '" + ExpData + "'");
        String val = (String) (CommonFunctions.getValueFromJSON(fieldName, dbResult));
        assertThat("DB result validation :", val, containsString(ExpData));
    }

    @Then("User verifies DBResult does not have {string}")
    public void thenUserVerifiesDBResultDoesNotHave(String fieldName) {
        Logger.info("User verifies DBResult does not have '" + fieldName + "'");
        assertThat("DBResult does not have '" + fieldName + "'", dbResult, not(containsString(fieldName)));
    }

    @Then("User saves DBResult value of {string} into {string}")
    public void thenUserSavesDBResultToVariable(String fieldName, String variable) {
        if (variable.contains("$")) {
            variable = variable.substring(variable.indexOf("$") + 1);
        }
        Object JSONvalue = CommonFunctions.getValueFromJSON(fieldName, dbResult);
        addCaseData(variable, JSONvalue.toString());
        Logger.info("User saves from DB Result : Value of \"" + fieldName + "\"  = \"" + JSONvalue + "\" to variable \"" + variable + "\"");
    }

    @Then("DBResult should have {string} as NULL")
    public void thenUserVerifiesDBResultAsNull(String JSONNode) {
        if (JSONNode.contains("$")) {
            JSONNode = JSONNode.substring(JSONNode.indexOf("$") + 1);
        }
        Object JSONvalue = CommonFunctions.getValueFromJSON(JSONNode, dbResult);
        assertThat("DB Result  validation : \"" + JSONNode + "\" is NULL", JSONvalue, (equalTo(null)));
    }

    @Then("DBResult should have {string} as Not NULL")
    public void thenUserVerifiesDBResultAsNotNull(String JSONNode) {
        if (JSONNode.contains("$")) {
            JSONNode = JSONNode.substring(JSONNode.indexOf("$") + 1);
        }
        Object JSONvalue = CommonFunctions.getValueFromJSON(JSONNode, dbResult);
        assertThat("DB Result  validation : \"" + JSONNode + "\" is not NULL", JSONvalue, Matchers.notNullValue());
    }

    // TODO - Need to discuss below methods with Sabitha and Ravi
    @When("caseId is updated to {string} for {string} API")
    public void whenUserHasCaseId(String caseIdVal, String apiName) {
        addCaseData("CaseId", caseIdVal);
        Logger.info("User has CaseId " + caseIdVal);
    }


    @Given("User verifies API response Array with DBResults as per {string} file for {string} API")
    public void whenUserVerfiesCouchbaseDatawithAPIResponseArray(String mappingFile, String API) throws Exception {
        Logger.info("User verifies API response Array with DBResults as per \"" + mappingFile + "\" file");

        String APIResponseContext = null;
        String dbResultContext = "$";
        String identifier = null;
        Object apiValue = null;
        Object dbValue = null;
        String filePath = CommonFunctions.getFullPath_GSI_INTR("field-mapping", mappingFile + ".txt");
        List<String> mappingRecords = CommonFunctions.readFileData(filePath);
        List<String> apiResponseFields = new ArrayList<String>();
        List<String> dbResultFields = new ArrayList<String>();
        for (String str : mappingRecords) {
            apiResponseFields.add(str.split(":")[0]);
            dbResultFields.add(str.split(":")[1]);
        }

        switch (API) {
            case "Conversations":
                APIResponseContext = "conversations";
                break;
            case "CVS_MultiFind":
            case "CaseFind":
                APIResponseContext = "$";
                break;
            case "audit_get":
                APIResponseContext = "audits";
                dbResultContext = "audits";
//                identifier = "caseId";
                break;
            case "ProfileAttachmentGet":
                APIResponseContext = "attachments";
                break;
        }

        String responseStr = apiResponse.body().asString();
        JsonContext responseJSON = (JsonContext) new JsonContext().parse(responseStr);

        String DBResult = (String) dbResult;
        JsonContext DBResultJSON = (JsonContext) new JsonContext().parse(DBResult);

        int noOfAPIResults = apiResponse.jsonPath().getList(APIResponseContext).size();


//        for (int i = 0; i < noOfAPIResults; i++) {
//            for (int j = 0; j < noOfAPIResults; j++) {
//                String apiIdentifierVal = responseJSON.read(
//                        APIResponseContext + "[" + i + "]." +
//                                apiResponseFields.get(0));
//                String dbIdentifierVal = DBResultJSON.read(APIResponseContext + "[" + j + "]." + dbResultFields.get(0));
//                if (apiIdentifierVal.equals(dbIdentifierVal)) {
//                    for (int k = 0; k < apiResponseFields.size(); k++) {
//                        apiValue = responseJSON.read(APIResponseContext + "[" + i + "]." + apiResponseFields.get(k));
//                        dbValue = DBResultJSON.read(APIResponseContext + "[" + j + "]." + dbResultFields.get(k));
//                        assertThat("API response validation with DB values :", apiValue, (equalTo(dbValue)));
//                        Logger.info("Validated:\n" +
//                                "API Node : " + APIResponseContext + "[" + i + "]." + apiResponseFields.get(k) + " = \"" + apiValue + "\"\n" +
//                                "IS EQUAL to\n" +
//                                "DB Node :" + "$[" + j + "]." + dbResultFields.get(k) + " = \"" + dbValue + "\n--------------------------");
//
//                    }
//                        break;
//
//                    }
//
//
//                }
//            }
        for (int i = 0; i < noOfAPIResults; i++) {
            for (int k = 0; k < apiResponseFields.size(); k++) {
                try {
                    switch (API) {
                        case "ProfileAttachmentGet":
                        case "Conversations":
                        case "CVS_MultiFind":
                        case "audit_get":
                        case "CaseFind":

                            apiValue = responseJSON.read(APIResponseContext + "[" + i + "]." + apiResponseFields.get(k));
                            dbValue = DBResultJSON.read(dbResultContext + "[" + i + "]." + dbResultFields.get(k));
                            Logger.info("Validated:\n" +
                                    "API Node : " + APIResponseContext + "[" + i + "]." + apiResponseFields.get(k) + " = \"" + apiValue + "\"\n" +
                                    "IS EQUAL to\n" +
                                    "DB Node : " + dbResultContext + "[" + i + "]." + dbResultFields.get(k) + " =\n " + dbValue + "\n--------------------------");

                            assertThat("API response validation with DB values :", apiValue, (equalTo(dbValue)));
                            break;

                        case "CVS_singleFind":
                            apiValue = responseJSON.read(apiResponseFields.get(k));
                            dbValue = DBResultJSON.read(dbResultFields.get(k));
                            assertThat("API response validation with DB values :", apiValue, (equalTo(dbValue)));
                            Logger.info("Validated:\n" +
                                    "API Node : " + apiResponseFields.get(k) + " = \"" + apiValue + "\"\n" +
                                    "IS EQUAL to\n" +
                                    "DB Node : " + dbResultFields.get(k) + " =\n " + dbValue + "\n--------------------------");
                            break;

                    }
                } catch (PathNotFoundException exc) {
                    Logger.info("API field " + apiResponseFields.get(k) + " not found");
                }


            }
        }
    }


    @When("subjectId = {string} for caseId = {string}")
    public void thenUserSavesTheSubjectIdForCaseid(String subjectId, String caseId) throws Exception {
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (subjectId.contains("$")) {
            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
        }
        dbQueryForCaseBasicDetails(caseId);
        String subjectIdVal = (String) CommonFunctions.getValueFromJSON("subjectId", dbResult);
        addCaseData(subjectId, subjectIdVal);
        Logger.info("\"subjectId\" = " + getCaseData(subjectId) + " for this caseId");

    }

    @When("RefId = {string} for caseId = {string}")
    public void thenUserSavesTheRefIdForCaseId(String refId, String caseId) throws Exception {
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
        }
        dbQueryForCaseBasicDetails(caseId);
        String refIdVal = (String) CommonFunctions.getValueFromJSON("refId", dbResult);
        addCaseData(refId, refIdVal);
        Logger.info("\"RefId\" = " + getCaseData(refId) + " for this caseId");

    }

    @When("MTCN10 = {string} for caseId = {string}")
    public void thenUserSavesTheMTCN10ForCaseId(String refId, String caseId) throws Exception {
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
        }
        dbQueryForCaseBasicDetails(caseId);
        String refIdVal = (String) CommonFunctions.getValueFromJSON("refId", dbResult);
        String MTCN10 = refIdVal.substring(6);
        addCaseData(refId, MTCN10);
        Logger.info("\"MTCN10\" = " + getCaseData(refId) + " for this caseId");

    }

    @When("MTCN16 = {string} for caseId = {string}")
    public void thenUserSavesTheMTCN16ForCaseId(String refId, String caseId) throws Exception {
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
        }
        dbQueryForCaseBasicDetails(caseId);
        String refIdVal = (String) CommonFunctions.getValueFromJSON("refId", dbResult);
        String MTCN16 = refIdVal;
        addCaseData(refId, MTCN16);
        Logger.info("\"MTCN16\" = " + getCaseData(refId) + " for this caseId");

    }

    @When("caseRefNo = {string} for caseId = {string}")
    public void thenUserSavesThecaseRefNoForCaseId(String caseRefNo, String caseId) throws Exception {
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }

        if (caseRefNo.contains("$")) {
            caseRefNo = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
        }
        dbQueryForCaseBasicDetails(caseId);
        String caseRefNoVal = (String) CommonFunctions.getValueFromJSON("caseRefNo", dbResult);
        addCaseData(caseRefNo, caseRefNoVal);
        Logger.info("\"caseRefNo\" = " + getCaseData(caseRefNo) + " for this caseId");

    }


    @When("User saves RFW caseId in {string}")
    public void userSavesRFWcaseIdinVariable(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getRFWcaseId();
        Logger.info("RFW caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }

    @When("User saves invGroup= {string} and tier= {string} RFW caseId in {string}")
    public void userSavesINTRSANCRFWcaseIdinVariable(String invGroup, String tier, String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getINTRSANCRFWcaseId(invGroup, tier);
        Logger.info("RFW caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }

    @When("User saves invGroup= {string} and tier= {string} SLABreached caseId in {string}")
    public void userSavesINTRSANCRFWSLAcaseIdinVariable(String invGroup, String tier, String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getSLABreachedRFWcaseId(invGroup, tier);
        Logger.info("SLABreached caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }

    @When("Analyst saves BG={string} and invGroup={string} caseId from action failure in {string}")
    public void analystSavesCaseFromActionFailure(String BG, String invGroup, String caseId) throws Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getActionFailurecaseId(invGroup, BG);
        Logger.info("Action failure caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);

    }

    @And("Analyst saves {string} count for {string} invgrp and {string} bg in {string}")
    public void analystSavesCountOfActionFailureCases(String criteria,String invGrp, String bg, String count) throws Exception {
        if (criteria.contains("$")) criteria = criteria.substring(criteria.indexOf("$") + 1);
        if (invGrp.contains("$")) invGrp = invGrp.substring(invGrp.indexOf("$") + 1);
        if (bg.contains("$")) bg = bg.substring(bg.indexOf("$") + 1);
        if (count.contains("$")) count = count.substring(count.indexOf("$") + 1);

        String countval = getActionFailureCount(criteria, invGrp,bg);
        addCaseData(count, countval);



    }

    @When("Analyst saves {string} original hitside value in {string}")
    public void analystSavesHitsideOfCaseId(String caseId, String hitside) throws Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        if (hitside.contains("$")) hitside = hitside.substring(hitside.indexOf("$") + 1);

        String hitsideValue = getHitSideOfcaseId(caseId);
        Logger.info("Hitside saved: "+hitsideValue);
        addCaseData(hitside, hitsideValue);
    }

    @And("Analyst updates hitside to {string} for the case {string}")
    public void analystUpdatesHitsideofCaseId(String newHitSide, String caseId) throws Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        if (newHitSide.contains("$")){
            newHitSide = newHitSide.substring(newHitSide.indexOf("$") + 1);
            newHitSide = getCaseData(newHitSide);
        }

        caseId = getCaseData(caseId);
        Logger.info("Hitside:"+newHitSide);
        Logger.info("CaseId: "+caseId);
        DBQueryToUpdateHitsideForcaseId(caseId,newHitSide);
        Logger.info("Hitside updated to "+newHitSide);
    }

    @When("User saves SANC RFW caseId in {string}")
    public void userSavesSANCRFWcaseIdinVariable(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getSANCRFWcaseId();
        Logger.info("RFW caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }


    public String getRFWcaseId() throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSIRFWcaseid();
//        dbResult="0 result";
        if (dbResult.equals("0 result")) {
            Logger.info("No RFW case found in DB; hence generating a new WU Retail case");
            CreateCaseSteps createCase = new CreateCaseSteps();
            createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
            createCase.userWaitsForCaseIdToMoveToRFW("newCaseId");
            caseIdVal = (String) getCaseData("newCaseId");
        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        return caseIdVal;
    }

    public String getINTRSANCRFWcaseId(String invGroup, String tier) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSIINTRSANCRFWcaseid(invGroup, tier);
        if (dbResult.equals("0 result")) {
            if (invGroup.equals("INTR_SI")) {
                Logger.info("No Interdiction RFW case found in DB; hence generating a new WU Retail case");
                CreateCaseSteps createCase = new CreateCaseSteps();
                createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");

            } else {
                CaseCreationSanctionsSteps createCase = new CaseCreationSanctionsSteps();
                if (invGroup.equals("Dual_SI")) {
                    createCase.givenUserCreatesCaseForWURetailDualHitSenderSide("L1", "newCaseId");
                } else if (invGroup.equals("Dual_EI")) {
                    createCase.givenUserCreatesCaseForWURetailDualHitSenderSide("L2", "newCaseId");
                } else if (invGroup.equals("Dual_AI")) {
                    createCase.givenUserCreatesCaseForWURetailDualHitSenderSide("L3", "newCaseId");
                } else if (invGroup.equals("SANC_SI")) {
                    createCase.givenUserCreatesCaseForWURetailSanctionsSenderSide("L1", "newCaseId");
                } else if (invGroup.equals("SANC_EI")) {
                    createCase.givenUserCreatesCaseForWURetailSanctionsSenderSide("L2", "newCaseId");
                } else if (invGroup.equals("SANC_AI")) {
                    createCase.givenUserCreatesCaseForWURetailSanctionsSenderSide("L3", "newCaseId");

                }
            }
            Logger.info("No Sanction RFW case found in DB; hence generating a new WU Retail case");
            caseIdVal = (String) getCaseData("newCaseId");


        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        return caseIdVal;
    }

    public String getSLABreachedRFWcaseId(String invGroup, String tier) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSIBreachedSANCRFWcaseid(invGroup, tier);
        if (dbResult.equals("0 result")) {
            Logger.info("No SLA breached RFW case found in DB");
        }
        caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        return caseIdVal;
    }

    public String getActionFailurecaseId(String invGrp, String BG) throws Exception {
        String caseIdVal;
        String dbResult = dbQueryForActionFailurecaseid(invGrp, BG);
        Logger.info("DB result : "+dbResult);
        if (dbResult.equals("0 result")) {
            Logger.info("No failed case found in DB for invgrp: "+invGrp+"and BG: "+BG);
        }
        caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        return caseIdVal;
    }

    public String getActionFailureCount(String criteria, String invGrp, String bg) throws Exception {
        String countVal;
        String dbResult = dbQueryForActionFailureCount(criteria, invGrp, bg);
        Logger.info("DB result : "+dbResult);
        if (dbResult.equals("0 result")) {
            Logger.info("No failed case found in DB for invgrp: "+invGrp+"and BG: "+bg);
        }
        countVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        return countVal;
    }

    public String getHitSideOfcaseId(String caseId) throws Exception {
        String hitsideVal;
        String dbResult = dbQueryForHitsideOfcaseid(caseId);
        Logger.info("DB result : "+dbResult);
        hitsideVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        return hitsideVal;
    }


    public String getSANCRFWcaseId() throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSISANCRFWcaseid();
//        dbResult="0 result";
        if (dbResult.equals("0 result")) {
            Logger.info("No RFW case found in DB; hence generating a new WU Retail case");
            CreateCaseSteps createCase = new CreateCaseSteps();
            createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
            caseIdVal = (String) getCaseData("newCaseId");
        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        return caseIdVal;
    }

    public String getGSISLAcaseId() throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSISLAcaseId();
        if (dbResult.equals("0 result")) {
            Logger.info("No GSI SLA case found in DB; hence generating a new WU Retail case");
            CreateCaseSteps createCase = new CreateCaseSteps();
            createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
            caseIdVal = (String) getCaseData("newCaseId");
        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        Logger.info("GSI SLA case id =" + caseIdVal);
        return caseIdVal;
    }

    @When("User saves any status caseId in {string}")
    public void userSavesAnyStatusCaseID(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String dbResult = dbQueryForAnyStatusCaseId();
        String caseIdVal;
        if (dbResult.equals("0 result")) {
            CreateCaseSteps createCase = new CreateCaseSteps();
            createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
            caseIdVal = (String) getCaseData("newCaseId");
        } else {
//            getCaseData("DBResult");
            caseIdVal = dbResult;
        }
        addCaseData(caseId, caseIdVal);
        Logger.info("CaseID for this scenario= " + caseIdVal);
    }


    @When("User saves Concluded caseId in {string}")
    public void userSavesConcludedcaseIdinVariable(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String dbResult = dbQueryForGSIConcludedcaseId();
        String caseIdVal;
        if (dbResult.equals("0 result")) {
            CreateCaseSteps createCase = new CreateCaseSteps();
            createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
            caseIdVal = (String) getCaseData("newCaseId");
            Logger.info("Conluded caseId \"" + caseIdVal + "\" saved in \"" + caseId + "\"");
        } else {
//            getCaseData("DBResult");
            caseIdVal = dbResult;
        }
        addCaseData(caseId, caseIdVal);
    }

    public ArrayList EntityData(String caseId) throws Exception {
        ArrayList<HashMap<Object, String>> entityList = null;
        HashMap<Object, String> entityMap = new HashMap<Object, String>();
        String dbResult = dbQueryForGSIhitsDoc(caseId);
        int noOfEntities, i;
        JsonPath path = JsonPath.compile("$.iWatchXCustomerJourney.entities[*]");
        JSONArray entityIds = path.read(dbResult);
        Logger.info("No of entities = " + entityIds.size());
        noOfEntities = entityIds.size();
        for (i = 0; i < noOfEntities; i++) {
            entityMap.clear();
            entityMap.put("entityId",
                    (String) CommonFunctions.getValueFromJSON("$.iWatchXCustomerJourney.entities[" + i + "].id", dbResult));
            entityMap.put("category",
                    (String) CommonFunctions.getValueFromJSON("$.iWatchXCustomerJourney.entities[" + i + "].category.name", dbResult));
            entityList.add(entityMap);
        }
        return entityList;
    }

    @When("User saves EE caseId in {string}")
    public void userSavesEEcaseIdinVariable(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdVal = getEEcaseId();
        addCaseData(caseId, caseIdVal);
        Logger.info("SI.INV.EE caseId \"" + caseIdVal + "\" saved in \"" + caseId + "\"");
    }

    public String getEEcaseId() throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSIEEcaseId();
//        dbResult = "0 result";
        if (dbResult.equals("0 result")) {
            Logger.info("No EE case found in DB; hence fetching a SLA case and moving it to EE");
            caseIdVal = getGSISLAcaseId();
            userHasHeader("WFM_Work");
            givenUserHasBlankInputJSON();
            whenUserCallsTheAPIWithHeadersWithPathParams("WFM_Work", "POST", "id", caseIdVal);
        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        Logger.info("EE case id = " + caseIdVal);
        return caseIdVal;
    }

    @When("User saves PI caseId in {string}")
    public void userSavesPIcaseIdinVariable(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getPIcaseId();
        Logger.info("PI caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }

    public String getPIcaseId() throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSIPIcaseId();
        if (dbResult.equals("0 result")) {
            Logger.info("No PI case found in DB; hence fetching a EE case and moving it to PI");
            caseIdVal = getEEcaseId();
            userHasHeader("WFM_Dispose");
            givenUserHasInputJSON("WFM_Dispose");
            whenUserUpdatesInputJSON("case.disposition.value", "Pending Info");
            whenUserUpdatesInputJSON("case.disposition.reason", "Collecting Customer Info (CCI)");
            whenUserUpdatesInputJSON("case.disposition.action", "Hold Funds");
            whenUserCallsTheAPIWithHeadersWithPathParams("WFM_Dispose", "POST", "id", caseIdVal);
        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        Logger.info("PI case id = " + caseIdVal);
        return caseIdVal;
    }

    @When("DBResult = query Profile Attachment for subjectId = {string}")
    public void dbQueryForPAT(String subjectId) throws Exception {
        subjectId = getDynamicValueForVariable(subjectId);
        String query = "SELECT *\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='profileAttachment'\n" +
                "    AND subject.id='" + subjectId + "' order by createdTimestamp desc limit 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query invalid Profile Attachment for subjectId = {string}")
    public void dbQueryForInvalidPAT(String subjectId) throws Exception {
        subjectId = getDynamicValueForVariable(subjectId);
        String query = "SELECT *,META().id\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='invalidPAT'\n" +
                "    AND subjectId='" + subjectId + "'\n" +
                "    AND createdTimestamp IS NOT MISSING\n" +
                "ORDER BY createdTimestamp DESC LIMIT 1";
        Thread.sleep(5000);
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());

        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query Profile Attachment for caseId = {string}")
    public void dbQueryForPATwithCaseRefNo(String caseId) throws Exception {
        if (caseId.contains("$")) {
            String value = caseId.substring(caseId.indexOf("$") + 1);
            String valueToBeReplace = getCaseData(value);
            caseId = caseId.replace("$" + value, valueToBeReplace);
        }
        String query = "SELECT *\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='profileAttachment'\n" +
                "  and subject.id is not missing\n" +
                "  and caseId= '" + caseId + "'\n" +
                "ORDER BY createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);

    }


    @When("DBResult = query for Compliance Visibility - Single Find with caseId = {string}")
    public void dbQueryForCaseStatusComplianceVisibility(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        query = "SELECT META().id AS caseId,\n" +
                "       gsiCase.workflow.status.tier,\n" +
                "       gsiCase.workflow.status.stage,\n" +
                "       gsiCase.workflow.status.subprocess,\n" +
                "       gsiCase.workflow.status.id,\n" +
                "       gsiCase.modifiedTimestamp,\n" +
                "       gsiCase.caseRefNo AS caseRefNo,\n" +
                "       gsiCase.classification.businessGroup,\n" +
                "       gsiCase.disposition AS disposition,\n" +
                "       gsiCase.subject.id AS subjectId,\n" +
                "       gsiCase.createdTimestamp\n" +
                "FROM `iWatchXCustomerJourney` AS gsiCase USE KEYS '" + caseId + "'\n";

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Compliance Visibility - Multi Find with refId = {string}, type = {string}")
    public void dbQueryForCaseListComplianceVisibility(String refId, String type) throws Exception {
        String query;
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
            refId = getCaseData(refId).toString();
        }
        query = "SELECT META(gsicase).id AS caseId,\n" +
                "       gsicase.workflow.status.tier,\n" +
                "       gsicase.workflow.status.stage,\n" +
                "       gsicase.workflow.status.subprocess,\n" +
                "       gsicase.workflow.status.id,\n" +
                "       gsicase.modifiedTimestamp,\n" +
                "       gsicase.caseRefNo AS caseRefNo,\n" +
                "       gsicase.caseType AS caseType,\n" +
                "       gsicase.classification.businessGroup,\n" +
                "       gsicase.disposition AS disposition,\n" +
                "       subject.subjectId,\n" +
                "       subject.name.fullName,\n" +
                "       gsicase.createdTimestamp\n" +
                "FROM iWatchXCustomerJourney activity\n" +
                "    JOIN iWatchXCustomerJourney gsicase ON gsicase.activityId = META(activity).id\n" +
                "LET subject = (FIRST c FOR c IN activity.parties WHEN c.subjectId = gsicase.subject.id END)\n" +
                "WHERE activity.docType = 'activity'\n" +
                "    AND gsicase.docType = 'gsiCase'\n" +
                "    AND activity.refId = '" + refId + "'\n" +
                "    AND activity.type.`value`='" + type + "'"+
                "    LIMIT 1";

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @Then("User saves count in {string} and cases in {string} within {string} and {string} for {string} InvGroup from DB")
    public void dbQueryToGetCasesWithATimeRange(String count, String caseList, String updatedTimeStamp, String CurrentTimeStamp, String invGrp) throws Exception {
        String id = null;

        if (updatedTimeStamp.contains("$")) {
            updatedTimeStamp = updatedTimeStamp.substring(updatedTimeStamp.indexOf("$") + 1);
            updatedTimeStamp = getCaseData(updatedTimeStamp).toString();
        }
        if (CurrentTimeStamp.contains("$")) {
            CurrentTimeStamp = CurrentTimeStamp.substring(CurrentTimeStamp.indexOf("$") + 1);
            CurrentTimeStamp = getCaseData(CurrentTimeStamp).toString();
        }

        if (invGrp.contains("$")) {
            invGrp = invGrp.substring(invGrp.indexOf("$") + 1);
            invGrp = getCaseData(invGrp).toString();
        }
        if (count.contains("$")) {
            count = count.substring(count.indexOf("$") + 1);
        }

        if (caseList.contains("$")) {
            caseList = caseList.substring(caseList.indexOf("$") + 1);
        }


        String docTypeValue = null;
        if(invGrp.equalsIgnoreCase("CDR") || invGrp.equalsIgnoreCase("CKYC")){
            docTypeValue = "kycCase";
            id = "CA.CON.CC";
        }
        else if(invGrp.equalsIgnoreCase("INTR") || invGrp.equalsIgnoreCase("SANC") || invGrp.equalsIgnoreCase("GSI")) {
            docTypeValue = "gsiCase";
            if (invGrp.equalsIgnoreCase("INTR")) {
                id = "SI.CON.CC";

            } else {
                id = "CA.CON.CC";
            }
        }

        String query;

        query = "SELECT meta().id FROM iWatchXCustomerJourney\n"+
                "        WHERE docType = '"+ docTypeValue +"'\n"+
                "        AND workflow.status.id NOT IN ['"+id+"']\n"+
                "        AND caseRefNo IS NOT MISSING\n"+
                "        AND classification.invGroup = '"+invGrp+"'\n"+
                "        AND STR_TO_MILLIS(createdTimestamp) BETWEEN\n"+
                "        STR_TO_MILLIS('"+updatedTimeStamp+"')\n"+
                "        AND STR_TO_MILLIS('"+CurrentTimeStamp+"')\n";

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        String countFromDB;
        Logger.info("Query Result : " + queryResult);
        if (queryResult.equals("0 result")) {
            countFromDB = Integer.toString(0);
            Assert.assertTrue(false,"There are no cases within the given time");
            //Assertion is just to fail the test
        }else{
            String cases[]= queryResult.split(",");
            countFromDB = Integer.toString(cases.length);
            Logger.info("Count : "+countFromDB);
            addCaseData(count, countFromDB);
            addCaseData(caseList, queryResult);

        }

    }

    @And("User validates cases {string} bulk update by range in UI")
    public void userValidatesBulkUpdateByRangeInUI(String caseList) throws Exception {
        if (caseList.contains("$")) {
            caseList = caseList.substring(caseList.indexOf("$") + 1);
            caseList = getCaseData(caseList).toString();
        }

        //Saving case ids in a list

        Logger.info("Cases list : "+caseList);
        String cases[]= caseList.split(",");
        ArrayList<String> updatedCList=new ArrayList<String>();
        for(int i =0;i<cases.length;i++){
//            System.out.println("cases after split : "+cases[i]);
            updatedCList.add(cases[i].substring(8,49));
//            System.out.println("cases after substring : "+cases[i].substring(8,49));
        }

        //For all the cases ids - validate bulk update in UI
        for(String c:updatedCList){
            Logger.info("Case : "+c);
            //Storing case id in variable 'c'

            System.out.println("**************************Bulk update validation - Start***********************");
            DashboardPage dashboardPage= new DashboardPage();

            Logger.info("------------------------------------------------------");
            dashboardPage.enterCaseIdInSearchTextBox(c);
            Logger.info("Enters case id in search box -->"+c);
            dashboardPage.clickOnSearchButton();
            Logger.info("Clicks on search button");
            dashboardPage.clickOnCaseActionButton("View Case");
            Logger.info("Clicks on view and waits for the case to open");
            Thread.sleep(5000);

            String disposition = dashboardPage.getCaseDispositionFromCase().getText();
            Logger.info("Disposition value from UI:"+disposition);


            // ----- Audit
            CaseInvestigationPage caseInvestigationPage= new CaseInvestigationPage();
            caseInvestigationPage.clickOnPlusSymbol();
            caseInvestigationPage.clickOnAuditLogSymbol();
            Logger.info("Analyst Clicks on Audit Log symbol");
            caseInvestigationPage.validateAuditLog("via bulk operation");
            Logger.info("Audit log verified : 'via bulk operation'");


            dashboardPage.getDashboardLink().click();
            Thread.sleep(2000);
            Logger.info("------------------------------------------------------");




        }
        System.out.println("Number of cases verified:"+(updatedCList.size()));

        System.out.println("**************************Bulk update validation - End***********************");

    }




    @When("DBResult = query for Conversations with caseId = {string}")
    public void dbQueryForConversationSearchWithCaseId(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        query = "SELECT DISTINCT META(Conversations).id,\n" +
                "       Conversations.analyst AS analyst,\n" +
                "       Conversations.caseId AS caseId,\n" +
                "       Conversations.text AS text,\n" +
                "       Conversations.subjectId AS subjectId,\n" +
                "       Conversations.refId AS refId,\n" +
                "       Conversations.visibility AS visibility,\n" +
                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
                "       Conversations.genreId AS genreId,\n" +
                "       Conversations.docType AS docType\n" +
                "FROM Conversations AS Conversations\n" +
                "WHERE Conversations.docType='conversation'\n" +
                "    AND Conversations.caseId='" + caseId + "'\n" +
                "ORDER BY Conversations.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Conversations with subjectId = {string}")
    public void dbQueryForConversationSearchWithSubjectId(String subjectId) throws Exception {
        String query;
        if (subjectId.contains("$")) {
            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
            subjectId = getCaseData(subjectId).toString();
        }
        query = "SELECT DISTINCT META(Conversations).id,\n" +
                " Conversations.analyst AS analyst,\n" +
                " Conversations.caseId AS caseId,\n" +
                " Conversations.text AS text,\n" +
                " Conversations.subjectId AS subjectId,\n" +
                " Conversations.refId AS refId,\n" +
                " Conversations.visibility AS visibility,\n" +
                " Conversations.createdTimestamp AS createdTimestamp,\n" +
                " Conversations.genreId AS genreId,\n" +
                " Conversations.docType AS docType\n" +
                "                FROM Conversations AS Conversations\n" +
                "                UNNEST subjectId AS sid\n" +
                "                WHERE Conversations.docType='conversation'\n" +
                "                AND sid='" + subjectId + "'\n" +
                "                AND Conversations.caseId IS NOT MISSING\n" +
                "                ORDER BY Conversations.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Conversations with refId = {string}")
    public void dbQueryForConversationSearchWithRefId(String refId) throws Exception {
        String query;
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
            refId = getCaseData(refId).toString();
        }
        query = "SELECT DISTINCT META(Conversations).id,\n" +
                "       Conversations.analyst AS analyst,\n" +
                "       Conversations.caseId AS caseId,\n" +
                "       Conversations.text AS text,\n" +
                "       Conversations.subjectId AS subjectId,\n" +
                "       Conversations.refId AS refId,\n" +
                "       Conversations.visibility AS visibility,\n" +
                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
                "       Conversations.genreId AS genreId,\n" +
                "       Conversations.docType AS docType\n" +
                "FROM Conversations AS Conversations\n" +
                "                UNNEST refId AS refId\n" +
                "                WHERE Conversations.docType='conversation'\n" +
                "                AND refId='" + refId + "'\n" +
                "AND Conversations.caseId is not missing\n" +
                "ORDER BY Conversations.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Conversations with caseId = {string} AND subjectId = {string}")
    public void dbQueryForConversationSearchWithcaseIdORsubjectId(String caseId, String subjectId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (subjectId.contains("$")) {
            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
            subjectId = getCaseData(subjectId).toString();
        }
        query = "SELECT DISTINCT META(Conversations).id,\n" +
                "       Conversations.analyst AS analyst,\n" +
                "       Conversations.caseId AS caseId,\n" +
                "       Conversations.text AS text,\n" +
                "       Conversations.subjectId AS subjectId,\n" +
                "       Conversations.refId AS refId,\n" +
                "       Conversations.visibility AS visibility,\n" +
                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
                "       Conversations.genreId AS genreId,\n" +
                "       Conversations.docType AS docType\n" +
                "FROM Conversations AS Conversations\n" +
                "                UNNEST subjectId AS subjectId\n" +
                "                WHERE Conversations.docType='conversation'\n" +
                "    AND Conversations.caseId = '" + caseId + "'\n" +
                "    AND subjectId='" + subjectId + "'\n" +
                "ORDER BY Conversations.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Conversations with caseId = {string} AND refId = {string}")
    public void dbQueryForConversationSearchWithcaseIdORrefId(String caseId, String refId) throws Exception {
        String query;
        query = "SELECT DISTINCT META(Conversations).id,\n" +
                "       Conversations.analyst AS analyst,\n" +
                "       Conversations.caseId AS caseId,\n" +
                "       Conversations.text AS text,\n" +
                "       Conversations.subjectId AS subjectId,\n" +
                "       Conversations.refId AS refId,\n" +
                "       Conversations.visibility AS visibility,\n" +
                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
                "       Conversations.genreId AS genreId,\n" +
                "       Conversations.docType AS docType\n" +
                "FROM Conversations AS Conversations\n" +
                "                UNNEST refId AS refId\n" +
                "                WHERE Conversations.docType='conversation'\n" +
                "    AND Conversations.caseId = '" + caseId + "'\n" +
                "    AND refId='" + refId + "'\n" +
                "ORDER BY Conversations.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Conversations with subjectId = {string} OR refId = {string}")
    public void dbQueryForConversationSearchWithsubjectIdORrefId(String subjectId, String refId) throws Exception {
        String query;
        query = "SELECT DISTINCT META(Conversations).id,\n" +
                "       Conversations.analyst AS analyst,\n" +
                "       Conversations.caseId AS caseId,\n" +
                "       Conversations.text AS text,\n" +
                "       Conversations.subjectId AS subjectId,\n" +
                "       Conversations.refId AS refId,\n" +
                "       Conversations.visibility AS visibility,\n" +
                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
                "       Conversations.genreId AS genreId,\n" +
                "       Conversations.docType AS docType\n" +
                "FROM Conversations AS Conversations\n" +
                "                UNNEST refId AS refId\n" +
                "                UNNEST subjectId AS subjectId\n" +
                "                WHERE Conversations.docType='conversation'\n" +
                "    AND subjectId='" + subjectId + "'\n" +
                "    AND refId='" + refId + "'\n" +
                "ORDER BY Conversations.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Conversations with subjectId = {string} OR refId = {string} OR caseId = {string}")
    public void dbQueryForConversationSearchWithsubjectIdORrefIdOrcaseId(String subjectId, String refId, String caseId) throws Exception {
        String query;
        query = "SELECT DISTINCT META(Conversations).id,\n" +
                "       Conversations.analyst AS analyst,\n" +
                "       Conversations.caseId AS caseId,\n" +
                "       Conversations.text AS text,\n" +
                "       Conversations.subjectId AS subjectId,\n" +
                "       Conversations.refId AS refId,\n" +
                "       Conversations.visibility AS visibility,\n" +
                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
                "       Conversations.genreId AS genreId,\n" +
                "       Conversations.docType AS docType\n" +
                "FROM Conversations AS Conversations\n" +
                "                UNNEST refId AS refId\n" +
                "                UNNEST subjectId AS subjectId\n" +
                "                WHERE Conversations.docType='conversation'\n" +
                "    AND subjectId='" + subjectId + "'\n" +
                "    AND refId='" + refId + "'\n" +
                "    AND Conversations.caseId='" + caseId + "'\n" +
                "ORDER BY Conversations.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }


    @When("DBResult = query for SaveConversations with caseId = {string}")
    public void dbQueryForSaveConversationSearchWithcaseId(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        query = "SELECT META().id,\n" +
                "       Conversations.analyst AS analyst,\n" +
                "       Conversations.caseId AS caseId,\n" +
                "       Conversations.text AS text,\n" +
                "       Conversations.subjectId AS subjectId,\n" +
                "       Conversations.refId AS refId,\n" +
                "       Conversations.visibility AS visibility,\n" +
                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
                "       Conversations.genreId AS genreId,\n" +
                "       Conversations.docType AS docType\n" +
                "FROM Conversations AS Conversations\n" +
                "WHERE Conversations.docType='conversation'\n" +
                "    AND Conversations.caseId='" + caseId + "'\n" +
                "ORDER BY Conversations.createdTimestamp DESC LIMIT 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }


    @When("DBResult = query for Audit - Audit as createdTimestamp {string} with caseId = {string}")
    public void dbQueryForAudit(String createdTimestamp, String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (createdTimestamp.contains("$")) {
            createdTimestamp = createdTimestamp.substring(createdTimestamp.indexOf("$") + 1);
            createdTimestamp = getCaseData(createdTimestamp).toString();
        }
        query = "SELECT audit \n" +
                "FROM iWatchXCustomerJourney AS CJ\n" +
                "UNNEST audits AS audit\n" +
                "WHERE CJ.docType = 'audit'\n" +
                "AND CJ.caseId ='" + caseId + "'\n" +
                "And audit.createdTimestamp='" + createdTimestamp + "'\n" +
                "LIMIT 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Audit - Audit as action {string} with caseId = {string}")
    public void dbQueryForAuditWithCaseidAndAction(String action, String caseId) throws Exception {
        String query;
        action = getDynamicValueForVariable(action);
        caseId = getDynamicValueForVariable(caseId);
        query = "SELECT audit \n" +
                "FROM iWatchXCustomerJourney AS CJ\n" +
                "UNNEST audits AS audit\n" +
                "WHERE CJ.docType = 'audit'\n" +
                "AND CJ.caseId ='" + caseId + "'\n" +
                "And audit.action='" + action + "'\n" +
                "LIMIT 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query audit details for caseId = {string}")
    public void dbQueryForAuditLogDesc(String caseId) throws Exception {
        String query;
        caseId = getDynamicValueForVariable(caseId);
        query = "SELECT audit \n" +
                "FROM iWatchXCustomerJourney AS CJ\n" +
                "UNNEST audits AS audit\n" +
                "WHERE CJ.docType = 'audit'\n" +
                "AND CJ.caseId ='" + caseId + "'\n" +
                "ORDER BY audit.createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query audit details in ASC order for caseId = {string}")
    public void dbQueryForAuditLogAsc(String caseId) throws Exception {
        String query;
        caseId = getDynamicValueForVariable(caseId);
        query = "SELECT audit \n" +
                "FROM iWatchXCustomerJourney AS CJ\n" +
                "UNNEST audits AS audit\n" +
                "WHERE CJ.docType = 'audit'\n" +
                "AND CJ.caseId ='" + caseId + "'\n" +
                "ORDER BY audit.createdTimestamp ASC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for getAudit - getAudit with caseId = {string}")
    public void dbQueryForgetAudit(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        query = "SELECT result.audits\n" +
                "FROM iWatchXCustomerJourney AS result\n" +
                "WHERE caseId = '" + caseId + "'\n" +
                "    AND docType = \"audit\"";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for casedesposition - case desposition with caseId = {string}")
    public void dbQueryForgetDisposition(String caseId) throws Exception {
        String query;
        query = "SELECT gsicase.disposition AS disposition\n" +
                "FROM `iWatchXCustomerJourney` AS gsicase\n" +
                "WHERE META(gsicase).id = '" + caseId + "'";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for workmode")
    public void dbQueryForgetworkmode(String caseId) throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType='gsiCase'\n" +
                "    AND docRetrieve.tenant= {'pId': 'WU', 'sId': 'CMT'}\n" +
                "    AND docRetrieve.classification.businessGroup= 'GSI'\n" +
                "    AND docRetrieve.classification.invGroup='INTERDICTION'\n" +
                "    AND docRetrieve.workflow.status.id IN ['SI.RFW.CA','SI.INV.PE']\n" +
                "    AND docRetrieve.workflow.targetTimestamp > CLOCK_STR()\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         hitSide,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for find CaseId through refId with caseId = {string}")
    public void dbQueryForgetcaseId(String caseType, String refId, String caseId) throws Exception {
        String query;
        String fieldName = "id";
        String id;
        if (caseType.equals("L1_S") || caseType.equals("L1_R")) {
            id = "SI.RFW.AP";
        } else {
            if (caseType.equals("L2_S") || caseType.equals("L2_R")) {
                id = "EI.RFW.AP";
            } else {
                id = "AI.RFW.AP";
            }
        }
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney caseDoc\n" +
                "WHERE caseDoc.docType=\"gsiCase\"\n" +
                "AND caseDoc.caseRefNo IS NOT MISSING\n" +
                "AND caseDoc.refId = '" + refId + "'\n" +
                "AND caseDoc.workflow.status.id='" + id + "'\n" +
                "ORDER BY caseDoc.createdTimestamp DESC\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
        }
        Object JSONvalue = CommonFunctions.getValueFromJSON(fieldName, dbResult);
        addCaseData(caseId, JSONvalue.toString());
        Logger.info("User saves from DB Result : Value of \"" + fieldName + "\"  = \"" + JSONvalue + "\" to variable \"" + caseId + "\" ");


        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Viewmode with caseId = {string}")
    public void dbQueryForgetviewmode(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        query = "SELECT META(`case`).id AS caseId,\n" +
                "       META(activity).id AS activityId,\n" +
                "       META(hits).id AS hitsId,\n" +
                "       *\n" +
                "FROM iWatchXCustomerJourney `case` USE KEYS '" + caseId + "'\n" +
                "    JOIN iWatchXCustomerJourney activity ON `case`.activityId = META(activity).id\n" +
                "INNER JOIN iWatchXCustomerJourney hits ON hits.caseId = META(`case`).id\n" +
                "    AND hits.docType='hits';";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for intrim with refId = {string}")
    public void dbQueryForgetintrim(String refId) throws Exception {
        String query;
        query = "SELECT META(gsicase).id AS caseId\n" +
                "FROM `iWatchXCustomerJourney` gsicase\n" +
                "JOIN `iWatchXCustomerJourney` activity ON gsicase.activityId = META(activity).id\n" +
                "WHERE activity.refId='" + refId + "'";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);

    }

    @When("DBResult = query for Workflow with caseId = {string}")
    public void dbQueryForgetworkflow(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            String value = caseId.substring(caseId.indexOf("$") + 1);
            String valueToBeReplace = getCaseData(value);
            caseId = caseId.replace("$" + value, valueToBeReplace);
        }
        query = "SELECT workflow.status.id,\n" +
                "       workflow.status.phase,\n" +
                "       workflow.status.stage,\n" +
                "       workflow.status.subprocess\n" +
                "FROM iWatchXCustomerJourney\n" +
                "WHERE docType = 'gsiCase'\n" +
                "    AND META().id ='" + caseId + "' AND caseRefNo IS NOT MISSING";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }


    public void dbQueryForCaseBasicDetails(String caseId) throws Exception {
        String query;
        query = "SELECT META(gsicase).id AS caseId,\n" +
                "       activity.refId AS refId,\n" +
                "       gsicase.subject.id AS subjectId,\n" +
                "       gsicase.caseRefNo\n" +
                "FROM `iWatchXCustomerJourney` AS gsicase USE KEYS \"" + caseId + "\"\n" +
                "    JOIN `iWatchXCustomerJourney` AS activity ON gsicase.activityId = META(activity).id";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    public String dbQueryForGSISLAcaseIds() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\",\"SI.INV.PE\",\"SI.INV.TO\"]\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }

    public String dbQueryForGSIRFWcaseId() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\"]\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1\n";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
//        return queryResult;
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }

    public String dbQueryForGSIRFWcaseid() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\"]\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1\n";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        return queryResult;
    }

    public String dbQueryForGSIINTRSANCRFWcaseid(String invGroup, String tier) throws Exception {
        String query;
        String id;
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserId = "";
        if (invGroup.equals("SANC_SI")) {
            invGroup = "SANC";
            tier = "Standard Investigation";
            id = "'SI.RFW.CA','SI.RFW.AP'";

        } else {
            if (invGroup.equals("SANC_EI")) {
                invGroup = "SANC";
                tier = "Enhanced Investigation";
                id = "'EI.RFWA.AP','EI.RFW.AP','EI.INV.TO'";
                oktaUserId = CommonFunctions.readFile(fileName, "oktaUserName_" + tier);
            } else {
                if (invGroup.equals("SANC_AI")) {
                    invGroup = "SANC";
                    tier = "Advanced Investigation";
                    id = "'AI.RFW.AP', 'AI.INV.PE', 'AI.INV.TO'";
                    oktaUserId = CommonFunctions.readFile(fileName, "oktaUserName_" + tier);
                } else {
                    if (invGroup.equals("Dual_SI")) {
                        invGroup = "GSI";
                        tier = "Standard Investigation";
                        id = "'SI.RFW.CA','SI.RFW.AP'";

                    } else {
                        if (invGroup.equals("Dual_EI")) {
                            invGroup = "GSI";
                            tier = "Enhanced Investigation";
                            id = "'EI.RFWA.AP','EI.RFW.AP','EI.INV.TO'";
                            oktaUserId = CommonFunctions.readFile(fileName, "oktaUserName_" + tier);
                        } else {
                            if (invGroup.equals("Dual_AI")) {
                                invGroup = "GSI";
                                tier = "Advanced Investigation";
                                id = "'AI.RFW.AP', 'AI.INV.PE', 'AI.INV.TO'";
                                oktaUserId = CommonFunctions.readFile(fileName, "oktaUserName_" + tier);
                            } else {
                                invGroup = "INTR";
                                tier = "Standard Investigation";
                                id = "'SI.RFW.CA','SI.INV.PE','SI.INV.TO'";
                            }
                        }
                    }
                }
            }
        }


        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType='gsiCase'\n" +
                "    AND docRetrieve.tenant.sId = 'CMT'\n" +
                "    AND docRetrieve.tenant.pId = 'WU'\n" +
                "    AND docRetrieve.classification.businessGroup = 'GSI'\n" +
                "    AND docRetrieve.classification.invGroup IN [\"" + invGroup + "\"]\n" +
                "    AND docRetrieve.genreId ='CJ'\n" +
                "    AND docRetrieve.workflow.status.tier = \"" + tier + "\"\n" +
                "    AND docRetrieve.workflow.status.id IN [" + id + "]\n" +
                "    AND (docRetrieve.analyst.id is missing OR docRetrieve.analyst.id <> [" + oktaUserId + "])\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        System.out.println("query result is "+result);
        if(result.equals("0 result")){
            dbResult=result;
        }
        else{
            String[] arrayResult = result.split(":");
            dbResult = arrayResult[1]+"::"+arrayResult[3];

        }
        return dbResult;
    }

    public String dbQueryForActionFailurecaseid(String invGrp, String BG) throws Exception {
        String query;

        query = "select meta().id from iWatchXCustomerJourney WHERE createdTimestamp >= DATE_ADD_STR(CLOCK_STR(), -3, 'month')\n"+
                "and classification.businessGroup = '"+BG+"'\n"+
                "and classification.invGroup = '"+invGrp+"'\n"+
                "and dispositionActions is not missing\n"+
                "and dispositionActions is not null\n"+
                "AND caseRefNo IS NOT MISSING\n"+
                "AND dispositionActions IS NOT MISSING\n"+
                "AND ANY tier IN dispositionActions SATISFIES (\n"+
                "ANY action IN tier.actions SATISFIES (\n"+
                "action.status IN ['F','A']    AND action.name IN ['Release','Move to Refund Queue','Cancel','Move to CallBack Queue','Keep in Queue','Keep in Seizure Queue','Hop to Escalated Queue','Profile Update','Account Update']\n"+
                ")  END\n"+
                ")  END\n"+
                "LIMIT 1";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        return queryResult;

    }

    public String dbQueryForActionFailureCount(String criteria,String invGrp,String bg) throws Exception {
        String query;

        if(criteria.equalsIgnoreCase("total")){
            query ="select COUNT(meta().id) from iWatchXCustomerJourney\n"+
                   "WHERE classification.businessGroup = '"+bg+"'\n"+
                   "and classification.invGroup = '"+invGrp+"'\n"+
                   "and dispositionActions is not missing\n"+
                   "and dispositionActions is not null\n"+
                   "AND caseRefNo IS NOT MISSING\n"+
                   "AND dispositionActions IS NOT MISSING\n"+
                   "AND ANY tier IN dispositionActions SATISFIES (\n"+
                    "ANY action IN tier.actions SATISFIES (\n"+
                    "action.status IN ['F','A']    AND action.name IN ['Release','Move to Refund Queue','Cancel','Move to CallBack Queue','Keep in Queue','Keep in Seizure Queue','Hop to Escalated Queue','Profile Update','Account Update']\n"+
                    ") END\n"+
                    ") END";
        }
        else{
            String timeperiod = null;

            if(criteria.equalsIgnoreCase("week")){
                timeperiod="createdTimestamp >= DATE_ADD_STR(CLOCK_STR(), -1, 'week')";
            }
            else if(criteria.equalsIgnoreCase("today")){
                timeperiod="createdTimestamp >= DATE_ADD_STR(CLOCK_STR(), -1, 'day')";
            }
            else if(criteria.equalsIgnoreCase("older")){
                timeperiod="createdTimestamp >= DATE_ADD_STR(CLOCK_STR(), -3, 'month')";
            }
            else{
                Assert.assertTrue(false,"Given criteria is not valid");
            }

            query ="select COUNT(meta().id) from iWatchXCustomerJourney\n"+
                    "WHERE "+timeperiod+"\n"+
                    "and classification.businessGroup = '"+bg+"'\n"+
                    "and classification.invGroup = '"+invGrp+"'\n"+
                    "and dispositionActions is not missing\n"+
                    "and dispositionActions is not null\n"+
                    "AND caseRefNo IS NOT MISSING\n"+
                    "AND dispositionActions IS NOT MISSING\n"+
                    "AND ANY tier IN dispositionActions SATISFIES (\n"+
                    "ANY action IN tier.actions SATISFIES (\n"+
                    "action.status IN ['F','A']    AND action.name IN ['Release','Move to Refund Queue','Cancel','Move to CallBack Queue','Keep in Queue','Keep in Seizure Queue','Hop to Escalated Queue','Profile Update','Account Update']\n"+
                    ") END\n"+
                    ") END";

        }

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1];
        dbResult = queryResult;
        return queryResult;
    }

    public String dbQueryForHitsideOfcaseid(String caseId) throws Exception {
        String query;

        query = "Select hitSide.`value` from iWatchXCustomerJourney\n"+
                "WHERE META().id='GSI::ded257d5-15dc-4c4c-a1fe-3c26193bb021'\n"+
                "AND docType='gsiCase'\n"+
                "AND caseRefNo IS NOT MISSING\n";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1];
        dbResult = queryResult;
        return queryResult;

    }

    public void DBQueryToUpdateHitsideForcaseId(String caseId, String hitside) throws Exception {
        String query;

        query = "UPDATE iWatchXCustomerJourney SET hitSide.`value`='"+hitside+"'\n"+
                "WHERE META().id='"+caseId+"'\n"+
                "AND docType='gsiCase'\n"+
                "AND caseRefNo IS NOT MISSING";
        Logger.info(query);

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        Logger.info("Update hitside Query result : "+result);
    }

    public String dbQueryForGSIBreachedSANCRFWcaseid(String invGroup, String tier) throws Exception {
        String query;
        String id;
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserId = "";
        if (invGroup.equals("SANC_SI")) {
            invGroup = "'SANC'";
            tier = "Standard Investigation";
            id = "'SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP'";

        } else {
            if (invGroup.equals("SANC_EI")) {
                invGroup = "'SANC'";
                tier = "Enhanced Investigation";
                id = "'EI.RFWA.AP','EI.RFW.AP','EI.INV.TO'";
            } else {
                if (invGroup.equals("SANC_AI")) {
                    invGroup = "'SANC'";
                    tier = "Advanced Investigation";
                    id = "'AI.RFW.AP', 'AI.INV.PE', 'AI.INV.TO'";
                } else {
                    if (invGroup.equals("SANC_IA")) {
                        invGroup = "'SANC'";
                        tier = "Investigation Approval";
                        id = "'IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'";

                    } else {
                        if (invGroup.equals("Dual_SI")) {
                            invGroup = "'GSI'";
                            tier = "Standard Investigation";
                            id = "'SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP'";

                        } else {
                            if (invGroup.equals("Dual_EI")) {
                                invGroup = "'GSI'";
                                tier = "Enhanced Investigation";
                                id = "'EI.RFWA.AP','EI.RFW.AP','EI.INV.TO'";
                            } else {
                                if (invGroup.equals("Dual_AI")) {
                                    invGroup = "'GSI'";
                                    tier = "Advanced Investigation";
                                    id = "'AI.RFW.AP', 'AI.INV.PE', 'AI.INV.TO'";
                                } else {
                                    if (invGroup.equals("Dual_IA")) {
                                        invGroup = "'GSI'";
                                        tier = "Investigation Approval";
                                        id = "'IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'";

                                    }else {
                                        invGroup = "'INTR'";
                                        tier = "Standard Investigation";
                                        id = "'SI.RFW.CA','SI.INV.PE','SI.INV.TO'";
                                    }
                                }
                            }
                        }

                    }
                }
            }
        }

        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType='gsiCase'\n" +
                "    AND docRetrieve.tenant.sId = 'CMT'\n" +
                "    AND docRetrieve.tenant.pId = 'WU'\n" +
                "    AND docRetrieve.classification.businessGroup = 'GSI'\n" +
                "    AND docRetrieve.classification.invGroup IN [" + invGroup + "]\n" +
                "    AND docRetrieve.genreId ='CJ'\n" +
                "    AND docRetrieve.workflow.status.tier = \"" + tier + "\"\n" +
                "    AND docRetrieve.workflow.status.id IN [" + id + "]\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL \n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "    AND STR_TO_MILLIS(docRetrieve.createdTimestamp) IS NOT NULL \n" +
                "    AND STR_TO_MILLIS(docRetrieve.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL())";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        return queryResult;
    }

    public String dbQueryForGSISANCRFWcaseid() throws Exception {
        String query;
        query = "SELECT meta().id\n" +
                "                    FROM iWatchXCustomerJourney docCase\n" +
                "                    WHERE docCase.docType='gsiCase'\n" +
                "                    AND docCase.tenant.sId = 'CMT'\n" +
                "                    AND docCase.tenant.pId = 'WU'\n" +
                "                    AND docCase.classification.businessGroup = 'GSI'\n" +
                "                    AND docCase.classification.invGroup ='SANC'\n" +
                "                    AND docCase.genreId ='CJ'\n" +
                "                    AND docCase.workflow.status.id IN [\"SI.RFW.CA\",\"SI.INV.PE\",\"SI.INV.TO\", \"EI.RFW.AP\"]\n" +
                "                    AND STR_TO_MILLIS(docCase.workflow.targetTimestamp) IS NOT NULL\n" +
                "                    AND STR_TO_MILLIS(docCase.createdTimestamp) IS NOT NULL\n" +
                "                    AND docCase.hitSide.`index` IS NOT NULL AND docCase.hitSide.`index` <> ''\n" +
                "                    AND docCase.caseRefNo IS NOT NULL AND docCase.caseRefNo <> ''\n" +
                "                    AND docCase.transitStore IS MISSING\n" +
                "                    order by STR_TO_MILLIS(docCase.workflow.targetTimestamp),\n" +
                "                    docCase.hitSide.`index`,\n" +
                "                    STR_TO_MILLIS(docCase.createdTimestamp)\n" +
                "                    LIMIT 1\n";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        return queryResult;
    }

    public String dbQueryForGSISancRFWcaseid() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"SANC\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.AP\"]\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1\n";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        return queryResult;
    }

    public String dbQueryForGSIEEcaseId() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.INV.EE\"]\n" +
//                "   AND docRetrieve.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n"+
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY \n" +
//                "docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
        return queryResult;
    }

    public String dbQueryForGSISLAcaseId() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\",\"SI.INV.PE\",\"SI.INV.TO\"]\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1\n";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info("queryResult = " + queryResult);
        return queryResult;
    }

    public String dbQueryForAnyStatusCaseId() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType =\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\" \n" +
                "    AND docRetrieve.tenant.pId = \"WU\" \n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY createdTimestamp DESC\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
//        return queryResult;
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }

    public String dbQueryForGSIConcludedcaseId() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.CON.CC\"]\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY createdTimestamp DESC \n" +
                "LIMIT 1\n";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
//        return queryResult;
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }


    @When("DBResult = query caseRetriever for caseId")
    public void dbQueryForcaseRetriever() throws Exception {
        String query;
        query = "SELECT META(docCase).id\n" +
                "FROM iWatchXCustomerJourney docCase\n" +
                "WHERE docCase.docType='gsiCase'\n" +
                "    AND docCase.tenant.sId = 'CMT'\n" +
                "    AND docCase.tenant.pId = 'WU'\n" +
                "    AND docCase.classification.businessGroup = 'GSI'\n" +
                "    AND docCase.classification.invGroup ='INTR'\n" +
                "    AND docCase.genreId ='CJ'\n" +
                "    AND docCase.workflow.status.tier ='Standard Investigation'\n" +
                "    AND docCase.workflow.status.id IN ['SI.RFW.CA','SI.INV.PE','SI.INV.TO']\n" +
                "    AND STR_TO_MILLIS(docCase.workflow.targetTimestamp) IS NOT NULL\n" +
                "    AND STR_TO_MILLIS(docCase.createdTimestamp) IS NOT NULL\n" +
                "    AND docCase.hitSide.`index` IS NOT NULL\n" +
                "    AND docCase.hitSide.`index` <> ''\n" +
                "    AND docCase.caseRefNo IS NOT NULL\n" +
                "    AND docCase.caseRefNo <> ''\n" +
                "    AND docCase.transitStore IS MISSING\n" +
                "ORDER BY STR_TO_MILLIS(docCase.workflow.targetTimestamp),\n" +
                "         docCase.hitSide.`index`,\n" +
                "         STR_TO_MILLIS(docCase.createdTimestamp)\n" +
                "LIMIT 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query case details for caseId = {string}")
    public void dbQueryForCaseDetails(String caseId) throws Exception {
        if (caseId.contains("$")) {
            String value = caseId.substring(caseId.indexOf("$") + 1);
            String valueToBeReplace = getCaseData(value);
            caseId = caseId.replace("$" + value, valueToBeReplace);
        }
        String query;
        query = "SELECT  META().id,*\n" +
                "FROM `iWatchXCustomerJourney`\n" +
                "WHERE docType=\"gsiCase\"\n" +
                "    AND META().id=\"" + caseId + "\"\n" +
                "    AND caseRefNo IS NOT MISSING";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    public String dbQueryForGSIhitsDoc(String caseId) throws Exception {
        String query;
        query = "SELECT  META().id,*\n" +
                "FROM `iWatchXCustomerJourney`\n" +
                "WHERE docType=\"hits\"\n" +
                "    AND caseId=\"" + caseId + "\"";

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        return queryResult;
    }

    @When("DBResult = query for case Attachment for caseid={string}")
    public String dbQueryForCaseAttachment(String caseId) throws Exception {
        if (caseId.contains("$")) {
            String value = caseId.substring(caseId.indexOf("$") + 1);
            String valueToBeReplace = getCaseData(value);
            caseId = caseId.replace("$" + value, valueToBeReplace);
        }
        String query;
        query = "SELECT meta().id,*\n" +
                "FROM iWatchXCustomerJourney\n" +
                "WHERE\n" +
                "caseId = '" + caseId + "'\n" +
                "AND docType='caseAttachment'";


        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        System.out.println(queryResult);
        dbResult = queryResult;
        return queryResult;
    }

    public String dbQueryForGSIPIcaseId() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.INV.PI\"]\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1\n";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info("queryResult = " + queryResult);
        return queryResult;
    }

    @When("DBResult = query for ProfileAttachment with subjectId = {string} And Currenttime= {string}")
    public void dbQueryForProfileAttachmentWithSubjectIdandtime(String subjectId, String Currenttime) throws Exception {
        String query;
        if (subjectId.contains("$")) {
            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
            subjectId = getCaseData(subjectId).toString();
        }
        if (Currenttime.contains("$")) {
            Currenttime = subjectId.substring(Currenttime.indexOf("$") + 1);
            Currenttime = getCaseData(Currenttime).toString();
        }
        query = "SELECT *\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='profileAttachment'\n" +
                "    AND subject.id='" + subjectId + "'\n" +
                "ocr.issueDate='" + Currenttime + "'";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Interim with refId ={string}")
    public void dbQueryForInterim(String refId) throws Exception {
        String query;
        query = "SELECT META().id AS caseId,\n" +
                "       createdTimestamp\n" +
                "FROM `iWatchXCustomerJourney`\n" +
                "WHERE docType=\"gsiCase\"\n" +
                "    AND caseRefNo IS NOT MISSING\n" +
                "    AND refId='" + CommonFunctions.readFile(CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName()), refId) + "'\n" +
                "    ORDER BY createdTimestamp DESC Limit 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        addCaseData("caseId", CommonFunctions.getValueFromJSON("caseId", dbResult.toString()).toString());

    }

    @When("DBResult = query for ProfileAttachment with subjectId = {string} AND customerId={string}")
    public void dbQueryForProfileAttachmentWithSubjectId(String subjectId, String customerId) throws Exception {
        String query;
        if (subjectId.contains("$")) {
            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
            subjectId = getCaseData(subjectId).toString();
        }
        query = "SELECT *\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='profileAttachment'\n" +
                "    AND subject.id='" + subjectId + "'\n" +
                "And customerId='" + customerId + "'\n" +
                "ORDER BY createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for ProfileAttachment with refId ={string} AND customerId={string}")
    public void dbQueryForProfileAttachmentWithrefId(String refId, String customerId) throws Exception {
        String query;
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
            refId = getCaseData(refId).toString();
        }
        query = "SELECT *\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='profileAttachment'\n" +
                "    AND caseRefNo='" + refId + "'\n" +
                "    AND subject.id IS NOT MISSING\n" +
                "ORDER BY createdTimestamp DESC";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for invalid profileAttachment for caseRefNo ={string}")
    public void dbQueryForinvalidprofileAttachment(String caseRefNo) throws Exception {
        if (caseRefNo.contains("$")) {
            String value = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
            String valueToBeReplace = getCaseData(value);
            caseRefNo = caseRefNo.replace("$" + value, valueToBeReplace);
        }
        String query;
        query = "SELECT *,\n" +
                "       META().id\n" +
                "FROM ProfileAttachment\n" +
                "WHERE docType='invalidPAT'\n" +
                "    AND caseRefNo='" + caseRefNo + "'\n" +
                "    AND createdTimestamp IS NOT MISSING";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("User has Case WF for {string}")
    public void userHasCaseWFfromDB(String caseId) throws Exception {
        caseId = getDynamicValueForVariable(caseId);
        dbResult = getCaseWFdataFromDB(caseId);
        Logger.info("Query Result : " + dbResult);
        addCaseData("caseWFstate", dbResult);
    }

    public String getCaseWFdataFromDB(String caseId) throws Exception {
        String query;
        query = "SELECT caseDoc.workflow\n" +
                "FROM iWatchXCustomerJourney caseDoc\n" +
                "WHERE caseDoc.docType=\"gsiCase\"\n" +
                "    AND caseDoc.caseRefNo IS NOT MISSING\n" +
                "    AND META(caseDoc).id= '" + caseId + "'";
        return CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());

    }

    @When("User verifies Case current WF same as previous WF for {string}")
    public void userVerifiesCasecurrentWFSameAsPrevWF(String caseId) throws Exception {
        caseId = getDynamicValueForVariable(caseId);
        dbResult = getCaseWFdataFromDB(caseId);
        Logger.info("Query Result : " + dbResult);
        assertThat("User verifies Case current WF same as previous WF for caseId", dbResult, equalTo(getCaseData("caseWFstate")));
    }

    @When("User moves case {string} to SI.INV.EE")
    public void userMovesCaseToEE(String caseId) throws Exception {
        caseId = getDynamicValueForVariable(caseId);
        userHasHeader("WFM_Work");
        givenUserHasBlankInputJSON();
        whenUserCallsTheAPIWithHeadersWithPathParams("WFM_Work", "POST", "id", caseId);
        Logger.info("User moves case " + caseId + " to SI.INV.EE");
    }

    @When("DBResult = query for cjcc - cjcc with refId = {string}")
    public void dbQuerycjcc(String refId) throws Exception {
        String query;
        refId = getDynamicValueForVariable(refId);
        Thread.sleep(3000);
        query = "select meta(caseDoc).id as caseId, activityDoc.parties[0] as parties0, hitsDoc.entities[0] as entities0\n" +
                "from iWatchXCustomerJourney caseDoc\n" +
                "join iWatchXCustomerJourney activityDoc\n" +
                "on caseDoc.activityId = meta(activityDoc).id\n" +
                "join iWatchXCustomerJourney hitsDoc\n" +
                "on meta(caseDoc).id = hitsDoc.caseId\n" +
                "where caseDoc.docType=\"gsiCase\" \n" +
                "and caseDoc.caseRefNo is not missing \n" +
                "and activityDoc.docType = \"activity\"\n" +
                "and activityDoc.refId = '" + refId + "'\n" +
                "and hitsDoc.docType = \"hits\"\n" +
                "order by caseDoc.createdTimestamp DESC\n" +
                "limit 10";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for Viewmode case tribe with refId= {string}")
    public void dbQueryForgetviewmodecasetribe(String refId) throws Exception {
        String query;
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
            refId = getCaseData(refId).toString();
        }
        query = "select meta().id, caseDoc.*\n" +
                "from iWatchXCustomerJourney caseDoc\n" +
                "where caseDoc.docType=\"gsiCase\"\n" +
                "and caseDoc.caseRefNo is not missing\n" +
                "and caseDoc.refId = '" + refId + "'\n" +
                "order by caseDoc.createdTimestamp DESC\n" +
                "limit 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for cjcc - case tribe with refId = {string}")
    public void dbQuerycjcccasetribe(String refId) throws Exception {
        String query;
        refId = getDynamicValueForVariable(refId);
        query = "select meta().id, caseDoc.*\n" +
                "from iWatchXCustomerJourney caseDoc\n" +
                "where caseDoc.docType=\"gsiCase\"\n" +
                "and caseDoc.caseRefNo is not missing\n" +
                "and caseDoc.refId = '" + refId + "'\n" +
                "order by caseDoc.createdTimestamp DESC\n" +
                "limit 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for interim with refId = {string}")
    public void dbQueryinterim(String refId) throws Exception {
        String query;
        refId = getDynamicValueForVariable(refId);
        query = "select meta(caseDoc).id, caseDoc.*\n" +
                "from iWatchXCustomerJourney caseDoc\n" +
                "where caseDoc.docType=\"gsiCase\"\n" +
                "and caseDoc.caseRefNo is not missing\n" +
                "and caseDoc.refId = '" + refId + "'\n" +
                "order by caseDoc.createdTimestamp DESC\n" +
                "limit 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for SANC Viewmode case tribe with caseId= {string}")
    public void dbQueryForgetSANCviewmodecasetribe(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        query = "SELECT META(`case`).id AS caseId,\n" +
                "       META(activity).id AS activityId,\n" +
                "       META(hits).id AS hitsId,\n" +
                "       *\n" +
                "FROM iWatchXCustomerJourney `case` USE KEYS '" + caseId + "'\n" +
                "    JOIN iWatchXCustomerJourney activity ON `case`.activityId = META(activity).id\n" +
                "INNER JOIN iWatchXCustomerJourney hits ON hits.caseId = META(`case`).id\n" +
                "    AND hits.docType='hits';";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for SANC {string} Interim with caseId ={string}")
    public void dbQueryForsancInterim(String entities, String caseId) throws Exception {
        caseId = getDynamicValueForVariable(caseId);
        String query;
        query = "SELECT entities[" + entities + "] as PB FROM iWatchXCustomerJourney where docType='hits' and caseId in ['" + caseId + "']\n";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("User saves SANC SI RFW caseId in {string}")
    public void userSavesSancRFWcaseIdinVariable(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getSancRFWcaseId();
        Logger.info("RFW caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }

    public String getSancRFWcaseId() throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSISancRFWcaseid();
//        dbResult="0 result";

        caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);

        return caseIdVal;
    }

    @When("DBResult = query for Interim with caseId ={string} for {string}")
    public void dbQueryForInterimCaseId(String caseId, String category) throws Exception {
        caseId = getDynamicValueForVariable(caseId);
        String query;
        if (category.equalsIgnoreCase("Request for Interview")) {
            query = "SELECT entities[3] as PB FROM iWatchXCustomerJourney where docType='hits' and caseId in ['" + caseId + "']\n";
        } else if (category.equalsIgnoreCase("Seizure")) {
            query = "SELECT entities[1] as PB FROM iWatchXCustomerJourney where docType='hits' and caseId in ['" + caseId + "']\n";
        } else if (category.equalsIgnoreCase("Refuse")) {
            query = "SELECT entities[0] as PB FROM iWatchXCustomerJourney where docType='hits' and caseId in ['" + caseId + "']\n";
        } else {
            query = "SELECT entities[2] as PB FROM iWatchXCustomerJourney where docType='hits' and caseId in ['" + caseId + "']\n";
        }
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }


    @When("User saves any sanc status caseId in {string}")
    public void userSavesAnySancStatusCaseID(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String dbResult = dbQueryForAnySancStatusCaseId();
        String caseIdVal;
//            getCaseData("DBResult");
        caseIdVal = dbResult;

        addCaseData(caseId, caseIdVal);
        Logger.info("CaseID for this scenario= " + caseIdVal);
    }

    @When("User saves any {string} invGrp status caseId in {string}")
    public void userSavesAnyStatusCaseID(String invGrp, String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String dbResult = dbQueryForAnySancStatusCaseId(invGrp);
        String caseIdVal;
//            getCaseData("DBResult");
        caseIdVal = dbResult;

        addCaseData(caseId, caseIdVal);
        Logger.info("CaseID for this scenario= " + caseIdVal);
    }

    @When("DBResult = query for CaseFind - CaseFind with caseId = {string}")
    public void dbQueryForgetcasefind(String caseId) throws Exception {
        String query;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }

        query = "SELECT DISTINCT META(caseData).id AS caseId,\n" +
                "       caseActivity.refId,\n" +
                "       x AS partyName,\n" +
                "       caseData.caseRefNo,\n" +
                "       caseData.workflow,\n" +
                "       caseData.disposition,\n" +
                "       caseData.analyst,\n" +
                "       caseData.hitSide,\n" +
                "       caseData.createdTimestamp,\n" +
                "       caseData.modifiedTimestamp,\n" +
                "caseData.tenant,\n" +
                "caseData.classification,\n" +
                "caseData.genreId\n" +
                "FROM iWatchXCustomerJourney AS caseData\n" +
                "INNER JOIN iWatchXCustomerJourney caseActivity ON caseData.activityId = META(caseActivity).id\n" +
                "LET x = FIRST i.name.fullName FOR i IN caseActivity.parties WHEN ARRAY_LENGTH(i.caseIds) > 0 END\n" +
                "WHERE caseData.docType = 'gsiCase'\n" +
                "    AND META(caseData).id = '" + caseId + "'\n" +
                "    AND caseData.tenant.pId = 'WU'\n" +
                "    AND caseData.tenant.sId = 'CMT'\n" +
                "    AND caseData.genreId= 'CJ'\n" +
                "    AND caseData.classification.businessGroup = 'GSI'\n" +
                "    AND caseData.classification.invGroup = 'SANC'";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    public String dbQueryForAnySancStatusCaseId(String invGrp) throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType =\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\" \n" +
                "    AND docRetrieve.tenant.pId = \"WU\" \n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup ='" + invGrp + "'\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY createdTimestamp DESC\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
//        return queryResult;
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }
    public String dbQueryForAnySancStatusCaseId() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType =\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\" \n" +
                "    AND docRetrieve.tenant.pId = \"WU\" \n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"SANC\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY createdTimestamp DESC\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
//        return queryResult;
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }


    @When("DBResult = query CasePull invGroup = {string} and tier = {string} and id = {string} and for caseId")
    public void dbQueryForSANCSIcaseRetriever(String invGroup, String tier, String id) throws Exception {
        String query;
        query = "SELECT META(docCase).id\n" +
                "FROM iWatchXCustomerJourney docCase\n" +
                "INNER JOIN iWatchXCustomerJourney docHit ON KEY docHit.caseId FOR docCase\n" +
                "WHERE docCase.docType='gsiCase'\n" +
                "    AND docHit.docType='hits'\n" +
                "    AND docCase.tenant.sId =\"CMT\"\n" +
                "    AND docCase.tenant.pId =\"WU\"\n" +
                "    AND docCase.classification.businessGroup = \"GSI\"" +
                "    AND docCase.classification.invGroup IN [" + invGroup + "]\n" +
                "    AND docCase.genreId ='CJ'\n" +
                "    AND docCase.workflow.status.tier = \"" + tier + "\"\n" +
                "    AND docCase.workflow.status.id IN [" + id + "]\n" +
                "    AND STR_TO_MILLIS(docCase.workflow.targetTimestamp) IS NOT NULL\n" +
                "    AND STR_TO_MILLIS(docCase.createdTimestamp) IS NOT NULL\n" +
                "    AND docCase.hitSide.`index` IS NOT NULL\n" +
                "    AND docCase.hitSide.`index` <> ''\n" +
                "    AND docCase.caseRefNo IS NOT NULL\n" +
                "    AND docCase.caseRefNo <> ''\n" +
                "    AND docCase.transitStore IS MISSING\n" +
                "    AND IFMISSINGORNULL((FIRST hitDisp FOR hitDisp IN ARRAY_REVERSE(docHit.entities[0].hitDispositions) WHEN hitDisp.tier <> docCase.workflow.status.tier END).analyst.id <> '65565683', TRUE)= TRUE\n" +
                "ORDER BY STR_TO_MILLIS(docCase.workflow.targetTimestamp),\n" +
                "         docCase.hitSide.`index`,\n" +
                "         STR_TO_MILLIS(docCase.createdTimestamp),\n" +
                "         docCase.classification.invIdx\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        addCaseData("DBResult", dbResult);
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query CasePull SANC and tier= {string} for caseId")
    public void dbQueryForSANCSIcaseRetriever(String tier) throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docCase\n" +
                "WHERE docCase.docType='gsiCase'\n" +
                "    AND docCase.tenant.sId = 'CMT'\n" +
                "    AND docCase.tenant.pId = 'WU'\n" +
                "    AND docCase.classification.businessGroup = 'GSI'\n" +
                "    AND docCase.classification.invGroup ='SANC'\n" +
                "    AND docCase.genreId ='CJ'\n" +
                "    AND docCase.workflow.status.tier =\"" + tier + "\"\n" +
                "    AND docCase.workflow.status.id IN ['IA.INV.PE','IA.INV.TO','IA.RFW.AP','AI.INV.PE','AI.INV.TO','AI.RFW.AP','EI.INV.PE','EI.INV.TO','EI.RFWA.AP','EI.RFW.AP','SI.RFW.AP','SI.RFW.CA','SI.INV.PE','SI.INV.TO']\n" +
                "    AND STR_TO_MILLIS(docCase.workflow.targetTimestamp) IS NOT NULL\n" +
                "    AND STR_TO_MILLIS(docCase.createdTimestamp) IS NOT NULL\n" +
                "    AND docCase.hitSide.`index` IS NOT NULL\n" +
                "    AND docCase.hitSide.`index` <> ''\n" +
                "    AND docCase.caseRefNo IS NOT NULL\n" +
                "    AND docCase.caseRefNo <> ''\n" +
                "    AND docCase.transitStore IS MISSING\n" +
                "ORDER BY STR_TO_MILLIS(docCase.workflow.targetTimestamp),\n" +
                "         docCase.hitSide.`index`,\n" +
                "         STR_TO_MILLIS(docCase.createdTimestamp)\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        addCaseData("DBResult", dbResult);
        Logger.info("Query Result : " + queryResult);
    }

    @Given("User creates Sanc {string} case through Interim and caseId saved in {string}")
    public void UserCreatesCaseSancThroughInterim(String caseType, String caseIdVar) throws Exception {
        userHasHeader("interimServiceRoute");
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "interimServiceRoute.json");
        String filePathSANC = CommonFunctions.getFullPath_SANCTIONS("CaseCreateData", "DEV_Interim_SANC_CaseCreator" + ".properties");

        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();


        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.id", CommonFunctions.readFile(filePathSANC, "subject.id_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.type", CommonFunctions.readFile(filePathSANC, "type_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("actTimestamp", CommonFunctions.readFile(filePathSANC, "actTimestamp_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("activityRefNo", CommonFunctions.readFile(filePathSANC, "activityRefNo_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("attemptId", CommonFunctions.readFile(filePathSANC, "attemptId_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("tranSurKey", CommonFunctions.readFile(filePathSANC, "tranSurKey_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("transactionSide", CommonFunctions.readFile(filePathSANC, "transactionSide_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("hitSide", CommonFunctions.readFile(filePathSANC, "hitSide_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("riskLevel", CommonFunctions.readFile(filePathSANC, "riskLevel_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("qualifiers[0]", CommonFunctions.readFile(filePathSANC, "qualifiers_" + caseType)).json().toString();


        whenUserCallsTheAPI("Orch_Interim", "POST");
        String refid = CommonFunctions.readFile(filePathSANC, "activityRefNo_" + caseType);
        dbQueryForgetcaseId(caseType, refid, caseIdVar);


    }

    @When("DBResult = query for interim Basic Gsi details with refId = {string}")
    public void dbQueryInterimBasicGsi(String refId) throws Exception {
        String query;
        refId = getDynamicValueForVariable(refId);
        query = "select meta(caseDoc).id as caseId, caseDoc.caseRefNo, activityDoc.refId as refId\n" +
                "from iWatchXCustomerJourney caseDoc\n" +
                "join iWatchXCustomerJourney activityDoc\n" +
                "on caseDoc.activityId = meta(activityDoc).id\n" +
                "where caseDoc.docType=\"gsiCase\"\n" +
                "and caseDoc.caseRefNo is not missing\n" +
                "and activityDoc.docType = \"activity\"\n" +
                "and activityDoc.refId ='" + refId + "'\n" +
                "order by caseDoc.createdTimestamp DESC\n" +
                "limit 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("caseId = {string} for refId = {string}")
    public void thenUserSavesTheCaseIdForRefId(String caseId, String refId) throws Exception {
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
            refId = getCaseData(refId).toString();
        }
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
        }
        dbQueryInterimBasicGsi(refId);
        String caseIdVal = (String) CommonFunctions.getValueFromJSON("caseId", dbResult);
        addCaseData(caseId, caseIdVal);
        Logger.info("\"caseId\" = " + getCaseData(caseId) + " for this refId");

    }

    @When("User saves any status {string} caseId in {string}")
    public void userSavesAnyINTRSANCStatusCaseID(String InvGroup, String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String dbResult = dbQueryForAnyINTRSANCStatusCaseId(InvGroup);
        String caseIdVal;
        if (dbResult.equals("0 result")) {
            if (InvGroup.equals("INTR")) {
                Logger.info("No Interdiction RFW case found in DB; hence generating a new WU Retail case");
                CreateCaseSteps createCase = new CreateCaseSteps();
                createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
                caseIdVal = (String) getCaseData("newCaseId");
            } else {
                CaseCreationSanctionsSteps createCase = new CaseCreationSanctionsSteps();
                createCase.givenUserCreatesCaseForWUDigitalSenderSide("L1", "newCaseId");
                caseIdVal = (String) getCaseData("newCaseId");
            }
        } else {
//            getCaseData("DBResult");
            caseIdVal = dbResult;
        }

        addCaseData(caseId, caseIdVal);
        Logger.info("CaseID for this scenario= " + caseIdVal);
    }

    public String dbQueryForAnyINTRSANCStatusCaseId(String InvGroup) throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType='gsiCase'\n" +
                "    AND docRetrieve.tenant.sId = 'CMT'\n" +
                "    AND docRetrieve.tenant.pId = 'WU'\n" +
                "    AND docRetrieve.classification.businessGroup = 'GSI'\n" +
                "    AND docRetrieve.classification.invGroup IN [\"" + InvGroup + "\"]\n" +
                "    AND docRetrieve.genreId ='CJ'\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
//        return queryResult;
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }

    @Given("User has input json for SANC Interim API - GSI SANC Sender case")
    public void givenUserHasInterimJSONSANCGSISender() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "SANC_EntityInterim.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.id", CommonFunctions.readFile(fileName, "SANCENSS_subjectId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.type", CommonFunctions.readFile(fileName, "SANCENSS_subjectType")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("actTimestamp", CommonFunctions.readFile(fileName, "SANCENSS_actTimestamp")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("activityRefNo", CommonFunctions.readFile(fileName, "SANCENSS_activityRefNo")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("attemptId", CommonFunctions.readFile(fileName, "SANCENSS_attemptId")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("tranSurKey", CommonFunctions.readFile(fileName, "SANCENSS_tranSurKey")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("transactionSide", CommonFunctions.readFile(fileName, "SANCENSS_transactionSide")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("hitSide", CommonFunctions.readFile(fileName, "SANCENSS_hitSide")).json().toString();
//        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("riskLevel", CommonFunctions.readFile(fileName, "SANCENSS_riskLevel")).json().toString();
        Logger.info("Input payload JSON for Interim API loaded in session object for - GSI Sender case");

    }

    @Given("User has input json for Activity_StatusRFW API - Sender side ActivityStatusRFW")
    public void givenUserHasinputjsonActivityStatusRFW() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "Activity_StatusRFW.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_SUR_KEY", CommonFunctions.readFile(fileName, "AS_TRNS_SUR_KEY")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN16", CommonFunctions.readFile(fileName, "AS_MTCN16")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN", CommonFunctions.readFile(fileName, "AS_MTCN")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_TS", CommonFunctions.readFile(fileName, "AS_TRNS_TS")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPTID", CommonFunctions.readFile(fileName, "AS_ATTEMPTID")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("QUE_NAME", CommonFunctions.readFile(fileName, "AS_QUE_NAME")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRANSACTIONSTATE", CommonFunctions.readFile(fileName, "AS_TRANSACTIONSTATE")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("SEND_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "AS_SEND_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("PAY_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "AS_PAY_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("GSI_CASE_CREATED", CommonFunctions.readFile(fileName, "AS_GSI_CASE_CREATED")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("STATUS", CommonFunctions.readFile(fileName, "AS_STATUS")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPT_TIMESTAMP", CommonFunctions.readFile(fileName, "AS_ATTEMPT_TIMESTAMP")).json().toString();

        Logger.info("Input payload JSON for Interim API loaded in session object for - GSI Sender case");


    }

    @When("DBResult = query for Entity Basic details with CaseId = {string}")
    public void dbQueryEntityBasicDetails(String caseId) throws Exception {
        String query;
        caseId = getDynamicValueForVariable(caseId);
        query = "SELECT hits.entities[*].id\n" +
                "FROM iWatchXCustomerJourney cases USE KEYS '" + caseId + "'\n" +
                "JOIN iWatchXCustomerJourney activity\n" +
                "ON cases.activityId = meta(activity).id \n" +
                "INNER JOIN iWatchXCustomerJourney hits\n" +
                "ON hits.caseId = meta(cases).id\n" +
                "AND meta(cases).id = '" + caseId + "'\n" +
                "AND hits.docType='hits'";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        String[] VAR2;
        VAR2 = queryResult.split("\\},");
        Logger.info("Query Result : " + queryResult);
        Logger.info("Query Result : " + VAR2);
    }

    @When("EntityId1 = {string} for caseId = {string}")
    public void thenUserSavesTheEntityId1ForCaseId(String EntityId1, String caseId) throws Exception {

        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (EntityId1.contains("$")) {
            EntityId1 = EntityId1.substring(EntityId1.indexOf("$") + 1);
        }
        dbQueryEntityBasicDetails(caseId);
        String EntityIdVal = (String) CommonFunctions.getValueFromJSON("id.[0]", dbResult);
        addCaseData(EntityId1, EntityIdVal);
        Logger.info("\"EntityId1\" = " + getCaseData(EntityId1) + " for this caseID");

    }

    @When("EntityId2 = {string} for caseId = {string}")
    public void thenUserSavesTheEntityId2ForCaseId(String EntityId2, String caseId) throws Exception {

        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (EntityId2.contains("$")) {
            EntityId2 = EntityId2.substring(EntityId2.indexOf("$") + 1);
        }
        dbQueryEntityBasicDetails(caseId);
        String EntityId2Val = (String) CommonFunctions.getValueFromJSON("id.[1]", dbResult);
        addCaseData(EntityId2, EntityId2Val);
        Logger.info("\"EntityId2\" = " + getCaseData(EntityId2) + " for this caseID");

    }

    @When("EntityId3 = {string} for caseId = {string}")
    public void thenUserSavesTheEntityId3ForCaseId(String EntityId3, String caseId) throws Exception {

        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
            caseId = getCaseData(caseId).toString();
        }
        if (EntityId3.contains("$")) {
            EntityId3 = EntityId3.substring(EntityId3.indexOf("$") + 1);
        }
        dbQueryEntityBasicDetails(caseId);
        String EntityId2Val = (String) CommonFunctions.getValueFromJSON("id.[2]", dbResult);
        addCaseData(EntityId3, EntityId2Val);
        Logger.info("\"EntityId2\" = " + getCaseData(EntityId3) + " for this caseID");

    }

    @When("CreationTimestamp = {string} for refId = {string}")
    public void creationTimestampFromRefId(String CreationTimestamp, String refId) throws Exception {
        if (refId.contains("$")) {
            refId = refId.substring(refId.indexOf("$") + 1);
            refId = getCaseData(refId).toString();
        }
        if (CreationTimestamp.contains("$")) {
            CreationTimestamp = CreationTimestamp.substring(CreationTimestamp.indexOf("$") + 1);
        }
        userFetchesCreationTimeStampFromRefId(refId);
        String CreationTimestampVal = (String) CommonFunctions.getValueFromJSON("actDoc.createdTimestamp", dbResult);
        addCaseData(CreationTimestamp, CreationTimestampVal);
        Logger.info("\"CreationTimestamp\" = " + getCaseData(CreationTimestamp) + " for this refId");

    }


    @When("User fetches Creation Timestamp from {string}")
    public void userFetchesCreationTimeStampFromRefId(String refId) throws Exception {
        String query;
        refId = getDynamicValueForVariable(refId);
        query = "select *\n" +
                "from ActivityStatus actDoc\n" +
                "where actDoc.docType=\"actStatus\"\n" +
                "and actDoc.refId ='" + refId + "'\n" +
                "order by caseDoc.createdTimestamp DESC  limit 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @And("Analyst open the case upto this {string}")
    public void analystsWaitForCaseToOpenUpto(String Time) throws InterruptedException {
        if (Time.equals("1mins")) {
            Thread.sleep(60000);
        } else {
            if (Time.equals("6mins")) {
                Thread.sleep(360000);
            } else {
                Thread.sleep(600000);
            }

        }

        Logger.info("Analyst wait for case to open");
        Thread.sleep(5000);
    }

    @When("User verifies Target Timestamp in CaseList response is {string} current time")
    public void userVerifiesTargetTSinCaseListResponseComparedToUTC(String compare) {
        List createdTSList = apiResponse.jsonPath().getList("workflow.targetTimestamp");
        Instant currentUTC, value;
        currentUTC = getCurrentUTCTime();
        Boolean isCurrentTS;
        if (createdTSList.size() > 0) {
            if (compare.toLowerCase().equals("after")) {
                for (int i = 1; i < createdTSList.size(); i++) {
                    value = Instant.parse((String) createdTSList.get(i));
                    isCurrentTS = currentUTC.isBefore(value);
                    assertThat("Verify that Target TS [" + i + "] is after Current UTC time - " + currentUTC, isCurrentTS);

                }
            } else if (compare.toLowerCase().equals("before")) {
                for (int i = 1; i < createdTSList.size(); i++) {
                    value = Instant.parse((String) createdTSList.get(i));
                    isCurrentTS = value.isBefore(currentUTC);
                    assertThat("Verify that Target TS [" + i + "] is before Current UTC time - " + currentUTC, isCurrentTS);

                }
            }

        }
    }


    public Instant getCurrentUTCTime() {
        Instant currentInstant = Instant.now();
        return currentInstant;


    }

    @When("User verifies createdTimestamp in CaseList response is in increasing order")
    public void userVerifiesCreatedTSinCaseListResponseIsInIncreasingOrder() {
        List createdTSList = apiResponse.jsonPath().getList("createdTimestamp");
        Instant previousValue, value;
        Boolean isCurrentTS;
        if (createdTSList.size() > 0) {
            previousValue = Instant.parse((String) createdTSList.get(0));
            if (createdTSList.size() > 1) {
                for (int i = 1; i < createdTSList.size(); i++) {
                    value = Instant.parse((String) createdTSList.get(i));
                    isCurrentTS = previousValue.isBefore(value);
                    assertThat("Verify that created TS [" + (i - 1) + "} is less than created TS [" + i + "]", isCurrentTS);
                    previousValue = value;
                }
            }
        }
    }

    @When("User updates the JSON field {string} values to boolean {string} in the input JSON")
    public void whenUserUpdatesInputJSONtoBoolean(String jsonField, String expectedValues) {
        expectedValues = getDynamicValueForVariable(expectedValues);
        if (expectedValues.equalsIgnoreCase("null"))
            inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, null).json().toString();
        else if (expectedValues.equalsIgnoreCase("blank"))
            inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, "").json().toString();
        else
            inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set(jsonField, Boolean.parseBoolean(expectedValues.toUpperCase())).json().toString();

        Logger.info("User updates the JSON field " + jsonField + " values to boolean " + expectedValues + " in the input JSON successfully!");
    }

    @When("User saves any SANC EE caseId in {string}")
    public void userSavesAnYSANCEECaseID(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String dbResult = dbQueryForAnYSANCEECaseID();
        String caseIdVal;
        if (dbResult.equals("0 result")) {
            CreateCaseSteps createCase = new CreateCaseSteps();
            createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
            caseIdVal = (String) getCaseData("newCaseId");
        } else {
//            getCaseData("DBResult");
            caseIdVal = dbResult;
        }
        addCaseData(caseId, caseIdVal);
        Logger.info("CaseID for this scenario= " + caseIdVal);
    }

    public String dbQueryForAnYSANCEECaseID() throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup =\"SANC\"\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"SI.INV.EE\"]\n" +
//                "   AND docRetrieve.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY \n" +
//                "docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
//        return queryResult;
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }

    @When("User saves SANC Concluded caseId in {string}")
    public void userSavesSANCConcludedcaseIdinVariable(String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        //     String dbResult = dbQueryForGSISancConcludedcaseId();
        String caseIdVal;






//            getCaseData("DBResult");
        caseIdVal = dbResult;
        addCaseData(caseId, caseIdVal);
    }

    @When("User saves {string} invGrp Concluded caseId in {string}")
    public void userSavesConcludedcaseId(String invGrp, String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String dbResult = dbQueryForGSISancConcludedcaseId(invGrp);
        String caseIdVal;
        caseIdVal = dbResult;
        addCaseData(caseId, caseIdVal);
    }

    public String dbQueryForGSISancConcludedcaseId(String invGrp) throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
                "    AND docRetrieve.classification.invGroup ='" + invGrp + "'\n" +
                "    AND docRetrieve.genreId =\"CJ\"\n" +
                "    AND docRetrieve.workflow.status.id IN [\"AI.CON.CC\",\"CA.CON.CC\",\"IA.CON.CC\"]\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY createdTimestamp DESC \n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info(queryResult);
        if (queryResult.equals("0 result")) {
            return "0 result";
        } else
            return (String) CommonFunctions.getValueFromJSON("$", dbResult);
    }


    @When("DBResult = query for CaseSearch Restriction with CaseId = {string} and Analyst Id = {string}")
    public void dbqueryForCaseSearchRestrictionWithCaseId(String caseId, String AnalystId) throws Exception {
        caseId = getDynamicValueForVariable(caseId);
        String query;
        query = "SELECT meta(docCase).id as caseId, docCase.analyst, docCase.workflow.status.id as wfId\n" +
                "            FROM iWatchXCustomerJourney docCase\n" +
                "            USE KEYS '" + caseId + "'\n" +
                "            INNER JOIN iWatchXCustomerJourney docHit ON docHit.caseId = META(docCase).id  AND docHit.docType='hits'\n" +
                "            WHERE\n" +
                "            (docCase.workflow.status.id NOT IN [\"SI.INV.EE\",\"SI.CMP.NA\",\"SI.CON.CC\",\"EI.CMP.NA\",\"AI.CMP.NA\",\"CA.CON.CC\",\"IA.CMP.NA\"])\n" +
                "            AND (NOT REGEXP_CONTAINS(docCase.workflow.status.id, 'TEMP'))\n" +
                "            AND docCase.caseRefNo IS NOT NULL AND docCase.caseRefNo <> ''\n" +
                "            AND docCase.transitStore IS MISSING\n" +
                "            AND IFMISSINGORNULL(\n" +
                "                ( FIRST hitDisp FOR hitDisp IN ARRAY_REVERSE(docHit.entities[0].hitDispositions)\n" +
                "                     WHEN hitDisp.tier <> docCase.workflow.status.tier END).analyst.id <> '" + AnalystId + "',\n" +
                "                TRUE) = TRUE\n";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("DBResult = query for CaseId through refId with caseId = {string}")
    public void GetcaseId(String refId, String caseId) throws Exception {
        String query;
        String fieldName = "id";
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney caseDoc\n" +
                "WHERE caseDoc.docType=\"gsiCase\"\n" +
                "AND caseDoc.caseRefNo IS NOT MISSING\n" +
                "AND caseDoc.refId = '" + refId + "'\n" +
                "AND caseDoc.workflow.status.id='SI.RFW.CA','SI.RFW.AP','EI.RFW.AP','AI.RFW.AP'\n" +
                "ORDER BY caseDoc.createdTimestamp DESC\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
        }
        Object JSONvalue = CommonFunctions.getValueFromJSON(fieldName, dbResult);
        addCaseData(caseId, JSONvalue.toString());
        Logger.info("User saves from DB Result : Value of \"" + fieldName + "\"  = \"" + JSONvalue + "\" to variable \"" + caseId + "\" ");


        Logger.info("Query Result : " + queryResult);
    }


    @When("DBResult = query for CaseSearch Restriction with CaseId = {string} and Analyst Name = {string}")
    public void dbqueryForCaseSearchRestrictionWithAnalystName(String caseId, String AnalystId) throws Exception {
        caseId = getDynamicValueForVariable(caseId);
        String query;
        query = "SELECT meta(docCase).id as caseId, docCase.analyst, docCase.workflow.status.id as wfId\n" +
                "            FROM iWatchXCustomerJourney docCase\n" +
                "            USE KEYS '" + caseId + "'\n" +
                "            INNER JOIN iWatchXCustomerJourney docHit ON docHit.caseId = META(docCase).id  AND docHit.docType='hits'\n" +
                "            WHERE\n" +
                "            (docCase.workflow.status.id NOT IN [\"SI.INV.EE\",\"SI.CMP.NA\",\"SI.CON.CC\",\"EI.CMP.NA\",\"AI.CMP.NA\",\"CA.CON.CC\",\"IA.CMP.NA\"])\n" +
                "            AND (NOT REGEXP_CONTAINS(docCase.workflow.status.id, 'TEMP'))\n" +
                "            AND docCase.caseRefNo IS NOT NULL AND docCase.caseRefNo <> ''\n" +
                "            AND docCase.transitStore IS MISSING\n" +
                "            AND IFMISSINGORNULL(\n" +
                "                ( FIRST hitDisp FOR hitDisp IN ARRAY_REVERSE(docHit.entities[0].hitDispositions)\n" +
                "                     WHEN hitDisp.tier <> docCase.workflow.status.tier END).analyst.id <> '" + AnalystId + "',\n" +
                "                TRUE) = TRUE\n";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @Given("User creates {string} case through Interim and caseId saved in {string}")
    public void UserCreatesCaseThroughInterim(String caseType, String caseIdVar) throws Exception {
        userHasHeader("interimServiceRoute");
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "interimServiceRoute.json");
        String filePathSANC = CommonFunctions.getFullPath_GSI_INTR("CaseCreateData", "QACMT_Interim_CaseCreator" + ".properties");

        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();


        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.id", CommonFunctions.readFile(filePathSANC, "subject.id_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("subject.type", CommonFunctions.readFile(filePathSANC, "type_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("actTimestamp", CommonFunctions.readFile(filePathSANC, "actTimestamp_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("activityRefNo", CommonFunctions.readFile(filePathSANC, "activityRefNo_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("attemptId", CommonFunctions.readFile(filePathSANC, "attemptId_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("tranSurKey", CommonFunctions.readFile(filePathSANC, "tranSurKey_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("transactionSide", CommonFunctions.readFile(filePathSANC, "transactionSide_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("hitSide", CommonFunctions.readFile(filePathSANC, "hitSide_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("riskLevel", CommonFunctions.readFile(filePathSANC, "riskLevel_" + caseType)).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("qualifiers[0]", CommonFunctions.readFile(filePathSANC, "qualifiers_" + caseType)).json().toString();


        whenUserCallsTheAPI("Orch_Interim", "POST");
        String refid = CommonFunctions.readFile(filePathSANC, "activityRefNo_" + caseType);
        GetcaseId(refid, caseIdVar);


    }

    @When("DBResult = query for Interim Index with refId ={string}")
    public void dbQueryInterimIndex(String refId) throws Exception {
        String query;
        refId = getDynamicValueForVariable(refId);
        query = "SELECT META().id,workflow,caseDoc.classification.invGroup,caseDoc.hitSide,createdTimestamp\n" +
                "FROM iWatchXCustomerJourney caseDoc\n" +
                "WHERE caseDoc.docType=\"gsiCase\"\n" +
                "AND caseDoc.caseRefNo IS NOT MISSING\n" +
                "    AND caseDoc.refId = '" + refId + "'\n" +
                "    ORDER BY caseDoc.createdTimestamp DESC\n" +
                "LIMIT 1";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        addCaseData("DBResult", queryResult);
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @Then("User verifies DBResult path {string} should have Integer {string}")
    public void thenUserVerifiesCouchbaseDataWithIntegerExpResult(String fieldName, String ExpData) {
        ExpData = getDynamicValueForVariable(ExpData);
        int ExpResult = Integer.parseInt(ExpData);
        Logger.info("User verifies DB Result path '" + fieldName + "' value is '" + ExpData + "'");
        Object val = CommonFunctions.getValueFromJSON(fieldName, dbResult);
        assertThat("DB result validation :", val, (equalTo(ExpResult)));
    }

    @When("User saves invGroup= {string} and tier= {string} concluded caseId in {string}")
    public void userSavesINTRSANCconcludedcaseIdinVariable(String invGroup, String tier, String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getINTRSANCconcludedcaseId(invGroup, tier);
        Logger.info("RFW caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }

    private String getINTRSANCconcludedcaseId(String invGroup, String tier) throws InterruptedException, ClassNotFoundException, SQLException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSIINTRSANCRConcludedcaseid(invGroup, tier);
        if (dbResult.equals("0 result")) {
















            Logger.info("No Sanction RFW case found in DB; hence generating a new WU Retail case");
            caseIdVal = (String) getCaseData("newCaseId");


        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        return caseIdVal;
    }

    private String dbQueryForGSIINTRSANCRConcludedcaseid(String invGroup, String tier) throws Exception {
        String query;
        String id;
        if (invGroup.equals("SANC_AI")) {
            invGroup = "SANC";
            tier = "Advanced Investigation";
            id = "'AI.CON.CC','CA.CON.CC'";
        } else {
            if (invGroup.equals("Dual_AI")) {
                invGroup = "GSI";
                tier = "Advanced Investigation";
                id = "'AI.CON.CC','CA.CON.CC'";
            } else {
                invGroup = "INTR";
                tier = "Standard Investigation";
                id = "'SI.CON.CC','CA.CON.CC'";
            }
        }


        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType='gsiCase'\n" +
                "    AND docRetrieve.tenant.sId = 'CMT'\n" +
                "    AND docRetrieve.tenant.pId = 'WU'\n" +
                "    AND docRetrieve.classification.businessGroup = 'GSI'\n" +
                "    AND docRetrieve.classification.invGroup IN [\"" + invGroup + "\"]\n" +
                "    AND docRetrieve.genreId ='CJ'\n" +
                "    AND docRetrieve.workflow.status.tier = \"" + tier + "\"\n" +
                "    AND docRetrieve.workflow.status.id IN [" + id + "]\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        return queryResult;
    }

    @When("DBResult = query MYQUEUE details for AnalystId = {string}")
    public String dbqueryForMyqueue(String AnalystId) throws Exception {
        String query;
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney caseDoc\n" +
                "WHERE caseDoc.docType=\"gsiCase\"\n" +
                "    AND caseDoc.caseRefNo IS NOT MISSING\n" +
                "    AND caseDoc.analyst.id='" + AnalystId + "'\n" +
                "    AND workflow.status.id IN ['SI.INV.EE','EI.INV.EE','AI.INV.EE','IA.INV.EE']";
        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        Logger.info("queryResult = " + queryResult);
        return queryResult;
    }

    @Given("User has input json for Activity_StatusRFW API - INTR Sender side ActivityStatusRFW")
    public void givenUserHasinputjsonINTRActivityStatusRFW() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "Activity_StatusRFW.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_SUR_KEY", CommonFunctions.readFile(fileName, "INTRAS_TRNS_SUR_KEY")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN16", CommonFunctions.readFile(fileName, "INTRAS_MTCN16")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN", CommonFunctions.readFile(fileName, "INTRAS_MTCN")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_TS", CommonFunctions.readFile(fileName, "INTRAS_TRNS_TS")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPTID", CommonFunctions.readFile(fileName, "INTRAS_ATTEMPTID")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("QUE_NAME", CommonFunctions.readFile(fileName, "INTRAS_QUE_NAME")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRANSACTIONSTATE", CommonFunctions.readFile(fileName, "INTRAS_TRANSACTIONSTATE")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("SEND_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_SEND_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("PAY_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_PAY_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("GSI_CASE_CREATED", CommonFunctions.readFile(fileName, "INTRAS_GSI_CASE_CREATED")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("STATUS", CommonFunctions.readFile(fileName, "INTRAS_STATUS")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPT_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_ATTEMPT_TIMESTAMP")).json().toString();

        Logger.info("User has input json for Activity_StatusRFW API - INTR Sender side ActivityStatusRFW");


    }

    @Given("User has input json for Activity_StatusRFW API - SANC Sender side ActivityStatusRFW")
    public void givenUserHasinputjsonSANCActivityStatusRFW() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "SANC_Activity_StatusRFW.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_SUR_KEY", CommonFunctions.readFile(fileName, "INTRAS_TRNS_SUR_KEY")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN16", CommonFunctions.readFile(fileName, "INTRAS_MTCN16")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN", CommonFunctions.readFile(fileName, "INTRAS_MTCN")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_TS", CommonFunctions.readFile(fileName, "INTRAS_TRNS_TS")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPTID", CommonFunctions.readFile(fileName, "INTRAS_ATTEMPTID")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("QUE_NAME", CommonFunctions.readFile(fileName, "INTRAS_QUE_NAME")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRANSACTIONSTATE", CommonFunctions.readFile(fileName, "INTRAS_TRANSACTIONSTATE")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("SEND_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_SEND_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("PAY_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_PAY_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("GSI_CASE_CREATED", CommonFunctions.readFile(fileName, "INTRAS_GSI_CASE_CREATED")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("STATUS", CommonFunctions.readFile(fileName, "INTRAS_STATUS")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPT_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_ATTEMPT_TIMESTAMP")).json().toString();

        Logger.info("User has input json for Activity_StatusRFW API - INTR Sender side ActivityStatusRFW");


    }

    @Given("User has input json for Activity_StatusRFW API - {string} ActivityStatusRFW")
    public void givenUserHasinputjsonSANCActivityStatusRFW(String value) throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", value + "_Activity_StatusRFW.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_SUR_KEY", CommonFunctions.readFile(fileName, "INTRAS_TRNS_SUR_KEY")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN16", CommonFunctions.readFile(fileName, "INTRAS_MTCN16")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN", CommonFunctions.readFile(fileName, "INTRAS_MTCN")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_TS", CommonFunctions.readFile(fileName, "INTRAS_TRNS_TS")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPTID", CommonFunctions.readFile(fileName, "INTRAS_ATTEMPTID")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("QUE_NAME", CommonFunctions.readFile(fileName, "INTRAS_QUE_NAME")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRANSACTIONSTATE", CommonFunctions.readFile(fileName, "INTRAS_TRANSACTIONSTATE")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("SEND_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_SEND_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("PAY_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_PAY_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("GSI_CASE_CREATED", CommonFunctions.readFile(fileName, "INTRAS_GSI_CASE_CREATED")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("STATUS", CommonFunctions.readFile(fileName, "INTRAS_STATUS")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPT_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRAS_ATTEMPT_TIMESTAMP")).json().toString();

        Logger.info("User has input json for Activity_StatusRFW API - INTR Sender side ActivityStatusRFW");


    }


    @Given("User has input json for Activity_StatusRFW API - INTR receiver side ActivityStatusRFW")
    public void givenUserHasinputjsonINTRArecctivityStatusRFW() throws Exception {
        inputPayloadJSON = "{}";
        String filePath = CommonFunctions.getFullPath_GSI_INTR("json-api", "Activity_StatusRFW.json");
        inputPayloadJSON = JsonPath.using(config).parse(new File(filePath)).set("{", "{").json().toString();
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_SUR_KEY", CommonFunctions.readFile(fileName, "INTRRCAS_TRNS_SUR_KEY")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN16", CommonFunctions.readFile(fileName, "INTRRCAS_MTCN16")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("MTCN", CommonFunctions.readFile(fileName, "INTRRCAS_MTCN")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRNS_TS", CommonFunctions.readFile(fileName, "INTRRCAS_TRNS_TS")).json().toString();
        ;
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPTID", CommonFunctions.readFile(fileName, "INTRRCAS_ATTEMPTID")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("QUE_NAME", CommonFunctions.readFile(fileName, "INTRRCAS_QUE_NAME")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("TRANSACTIONSTATE", CommonFunctions.readFile(fileName, "INTRRCAS_TRANSACTIONSTATE")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("SEND_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRRCAS_SEND_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("PAY_UPDATE_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRRCAS_PAY_UPDATE_TIMESTAMP")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("GSI_CASE_CREATED", CommonFunctions.readFile(fileName, "INTRRCAS_GSI_CASE_CREATED")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("STATUS", CommonFunctions.readFile(fileName, "INTRRCAS_STATUS")).json().toString();
        inputPayloadJSON = JsonPath.using(config).parse(inputPayloadJSON).set("ATTEMPT_TIMESTAMP", CommonFunctions.readFile(fileName, "INTRRCAS_ATTEMPT_TIMESTAMP")).json().toString();

        Logger.info("User has input json for Activity_StatusRFW API - INTR reciver side ActivityStatusRFW");


    }

    @When("DBResult = query for CaseMetrics")
    public void dbQueryForgetcasefind() throws Exception {
        String query;
        query = "WITH SI_SLAIN_Count AS (\n" +
                "    SELECT COUNT(*) AS SI_SLAIN\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Standard Investigation']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                "SI_SLAB_Count AS (\n" +
                "    SELECT COUNT(*) AS SI_SLAB\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Standard Investigation']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                "EI_SLIN_Count AS (\n" +
                "    SELECT COUNT(*) AS EI_SLAIN\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Enhanced Investigation']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['EI.INV.PE', 'EI.INV.TO','EI.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                "EI_SLAB_Count AS (\n" +
                "    SELECT COUNT(*) AS EI_SLAB\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Enhanced Investigation']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['EI.INV.PE', 'EI.INV.TO','EI.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                "AI_SLIN_Count AS (\n" +
                "    SELECT COUNT(*) AS AI_SLAIN\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Advanced Investigation']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                "AI_SLAB_Count AS (\n" +
                "    SELECT COUNT(*) AS AI_SLAB\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Advanced Investigation']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                "IA_SLIN_Count AS (\n" +
                "    SELECT COUNT(*) AS IA_SLAIN\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Investigation Approval']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                "IA_SLAB_Count AS (\n" +
                "    SELECT COUNT(*) AS IA_SLAB\n" +
                "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                "        AND iwxcjbucket.genreId = 'CJ'\n" +
                "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                "        AND iwxcjbucket.workflow.status.tier IN ['Investigation Approval']\n" +
                "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                "        AND iwxcjbucket.workflow.status.id IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP']\n" +
                "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                "        AND iwxcjbucket.caseRefNo <> ''\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL()))\n" +
                "SELECT SI_SLAIN_Count[0].SI_SLAIN AS RFW_SLANB_SI,\n" +
                "       SI_SLAB_Count[0].SI_SLAB AS RFW_SLAB_SI,\n" +
                "       EI_SLIN_Count[0].EI_SLAIN AS RFW_SLANB_EI,\n" +
                "       EI_SLAB_Count[0].EI_SLAB AS RFW_SLAB_EI,\n" +
                "       AI_SLIN_Count[0].AI_SLAIN AS RFW_SLANB_AI,\n" +
                "       AI_SLAB_Count[0].AI_SLAB AS RFW_SLAB_AI,\n" +
                "       IA_SLIN_Count[0].IA_SLAIN AS RFW_SLANB_IA,\n" +
                "       IA_SLAB_Count[0].IA_SLAB AS RFW_SLAB_IA ";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
    }

    @When("Analyst validates if the {string} - InProgress UI count matches DB count")
    public void analystValidatesSICountIP(String tier) throws Exception {
        String queryB;
        queryB = "WITH GSI_CASES as (\n" +
                "  SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts\n" +
                "  FROM iWatchXCustomerJourney as iwxcjbucket\n" +
                "  WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = 'WU' AND iwxcjbucket.tenant.sId = 'CMT' AND iwxcjbucket.classification.businessGroup = 'GSI' AND iwxcjbucket.genreId = 'CJ' AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "  )\n" +
                " SELECT (\n" +
                " SELECT RAW Count(*)\n" +
                " from GSI_CASES AS iwxbucket\n" +
                " WHERE iwxbucket.statusId IN ['"+tier+".INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL())\n" +
                " )[0] AS WU_CMT_CJ_GSI_IP_"+tier+"_SLAB;" ;
        //System.out.println(queryB);
        String result = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(queryB.trim());
        Logger.info("Query Result for "+tier+" - Breached InProgress count: " + result);
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1];
        dbResult =queryResult.substring(0,(queryResult.length()-2));
        int countB = Integer.parseInt(dbResult);
        // Logger.info("After split B :"+dbResult);
        Logger.info("Breached count of "+tier+" is : "+countB);

        String queryNB;
        queryNB = "WITH GSI_CASES as (\n" +
                "  SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts\n" +
                "  FROM iWatchXCustomerJourney as iwxcjbucket\n" +
                "  WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = 'WU' AND iwxcjbucket.tenant.sId = 'CMT' AND iwxcjbucket.classification.businessGroup = 'GSI' AND iwxcjbucket.genreId = 'CJ' AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                "  )\n" +
                " SELECT (\n" +
                " SELECT RAW Count(*)\n" +
                " from GSI_CASES AS iwxbucket\n" +
                " WHERE iwxbucket.statusId IN ['"+tier+".INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL())\n" +
                " )[0] AS WU_CMT_CJ_GSI_IP_"+tier+"_SLANB;" ;
        // System.out.println(queryNB);
        String result1 = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(queryNB.trim());
        Logger.info("Query Result for "+tier+" - Non Breached InProgress count: " + result1);
        String[] arrayResult1 = result1.split(":");
        String queryResult1 = arrayResult1[1];
        dbResult =queryResult1.substring(0,(queryResult1.length()-2));
        int countNB = Integer.parseInt(dbResult);
        //Logger.info("After split :"+dbResult);
        Logger.info("Non breached count for "+tier+" is : "+countNB);
        int totalCount = countB + countNB;


        DashboardPage dashboardPage = new DashboardPage();
        if(tier.equalsIgnoreCase("SI")){
            int countFromUI = Integer.parseInt(dashboardPage.getSIInProgCountFromUI());
            Logger.info("Total count from UI for SI Tier: "+countFromUI);
            if(totalCount!=0){
                Assert.assertEquals(totalCount,countFromUI, "Count of SI does not match");
                Logger.info("Analyst has validated count for "+tier);
            }else {Logger.info("No cases for SI in InProgress"); }
        }
        else if(tier.equalsIgnoreCase("EI")){
            int countFromUI = Integer.parseInt(dashboardPage.getEIInProgCountFromUI());
            Logger.info("Total count from UI for EI Tier: "+countFromUI);
            if(totalCount!=0){
                Assert.assertEquals(totalCount,countFromUI, "Count of EI does not match");
                Logger.info("Analyst has validated count for "+tier);
            }else {Logger.info("No cases for EI in InProgress"); }
        }
        else if(tier.equalsIgnoreCase("AI")){
            int countFromUI = Integer.parseInt(dashboardPage.getAIInProgCountFromUI());
            Logger.info("Total count from UI for AI: "+countFromUI);
            if(totalCount!=0){
                Assert.assertEquals(totalCount,countFromUI, "Count of AI does not match");
                Logger.info("Analyst has validated count for "+tier);
            }else {Logger.info("No cases for AI in InProgress"); }
        }
        else if(tier.equalsIgnoreCase("AI")){
            int countFromUI = Integer.parseInt(dashboardPage.getIAInProgCountFromUI());
            Logger.info("Total count from UI for IA: "+countFromUI);
            if(totalCount!=0){
                Assert.assertEquals(totalCount,countFromUI, "Count of IA does not match");
                Logger.info("Analyst has validated count for "+tier);
            }else {Logger.info("No cases for IA in InProgress"); }
        }



    }

    @Then("API response field {string} value save in {string}")
    public String thenUserSaveFildAPIResponse(String responseJSONNode, String fieldValue) {
        if (fieldValue.contains("$")) fieldValue = fieldValue.substring(fieldValue.indexOf("$") + 1);
        String value = CommonFunctions.getTagValue(apiResponse, responseJSONNode);

        addCaseData(fieldValue, value);
        Logger.info(responseJSONNode + " = " + value);
        return null;

    }

    @Then("Value increase by 1 for {string} and Save in {string}")
    public String thenUserIncreasethevalueBy1(String fieldValue, String incresedValue) {
        String expectedValue;
        if (fieldValue.contains("$")) {
            fieldValue = fieldValue.substring(fieldValue.indexOf("$") + 1);
            fieldValue = getCaseData(fieldValue).toString();


        }
        int value = Integer.parseInt(fieldValue);
        Logger.info("Value before Incresed by 1 = " + value);
        value = value + 1;
        expectedValue = String.valueOf(value);

        if (incresedValue.contains("$")) {
            incresedValue = incresedValue.substring(incresedValue.indexOf("$") + 1);


        }
        addCaseData(incresedValue, expectedValue);
        Logger.info("Value  after Incresed by 1 = " + expectedValue);

        return null;

    }

    @Then("Value decreased by 1 for {string} and Save in {string}")
    public String thenUserDecreasethevalueBy1(String fieldValue, String decreasedValue) {
        String expectedValue;
        if (fieldValue.contains("$")) {
            fieldValue = fieldValue.substring(fieldValue.indexOf("$") + 1);
            fieldValue = getCaseData(fieldValue).toString();


        }
        int value = Integer.parseInt(fieldValue);
        Logger.info("Value before decreased by 1 = " + value);
        value = value - 1;
        expectedValue = String.valueOf(value);

        if (decreasedValue.contains("$")) {
            decreasedValue = decreasedValue.substring(decreasedValue.indexOf("$") + 1);

        }
        addCaseData(decreasedValue, expectedValue);
        Logger.info("Value  after decreased by 1 = " + expectedValue);


        return null;

    }

    @When("User calls the {string} API with unsanitized data {string} with {string} method and headers and Path Params {string} and values {string}")
    public void whenUserCallsTheUnsanitizedAPIWithHeadersWithPathParams(String apiName, String value, String methodType, String paramNames, String paramValues) {
        String[] paramNm = paramNames.split("[;]");
        String[] paramVal = paramValues.split("[;]");
        int size = paramNm.length;
        Map<String, Object> params = new HashMap<>();
        for (int index = 0; index < size; index++) {
            String paramName = paramNm[index];
            String paramValue = paramVal[index];
            if (paramValue.equalsIgnoreCase("blank")) {
                paramValue = "";
            } else {
                paramValue = getDynamicValueForVariable(paramValue);
            }
            params.put(paramName, paramValue);
        }
        Logger.info("User calls the " + apiName + " API with " + methodType + " method and headers with Path Params as \"paramNames\" = {" + paramNames + "} and Values = {" + paramValues + "}");
        String apiURL = CommonFunctions.getApiURL(apiName);
        String apiURL1 = apiURL + value;
        System.out.println("*********" + apiURL1);
        apiResponse = CommonFunctions.apiCall(apiURL1, apiName, methodType, inputPayloadJSON, headerMap, params);

    }

    @When("User calls the {string} API with unsanitized data {string} with {string} method")
    public void whenUserCallsTheUnsanitizedAPI(String apiName, String blackListValue, String methodType) throws NullPointerException {
        String apiURL = CommonFunctions.getApiURL(apiName);
        String apiURL1 = apiURL + blackListValue;
        apiResponse = CommonFunctions.apiCall(apiURL1, apiName, methodType, inputPayloadJSON, headerMap, params);
        Logger.info("User calls the " + apiName + " API with " + methodType + " method");
    }

    @When("DBResult =query for CaseMetrics businessgroup as {string}")
    public void dbQueryForgetcasefindasbussinessgroup(String Businessgroup) throws Exception {
        String query;
        if (Businessgroup.equalsIgnoreCase("GSI")) {
            query = "WITH SI_SLAIN_Count AS (\n" +
                    "    SELECT COUNT(*) AS SI_SLAIN\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Standard Investigation']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                    "SI_SLAB_Count AS (\n" +
                    "    SELECT COUNT(*) AS SI_SLAB\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Standard Investigation']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                    "EI_SLIN_Count AS (\n" +
                    "    SELECT COUNT(*) AS EI_SLAIN\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Enhanced Investigation']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['EI.INV.PE', 'EI.INV.TO','EI.RFW.AP', 'EI.RFW.CA']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                    "EI_SLAB_Count AS (\n" +
                    "    SELECT COUNT(*) AS EI_SLAB\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Enhanced Investigation']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['EI.INV.PE', 'EI.INV.TO','EI.RFW.AP', 'EI.RFW.CA']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                    "AI_SLIN_Count AS (\n" +
                    "    SELECT COUNT(*) AS AI_SLAIN\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Advanced Investigation']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP', 'AI.RFW.CA']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                    "AI_SLAB_Count AS (\n" +
                    "    SELECT COUNT(*) AS AI_SLAB\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Advanced Investigation']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP', 'AI.RFW.CA']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                    "IA_SLIN_Count AS (\n" +
                    "    SELECT COUNT(*) AS IA_SLAIN\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Investigation Approval']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC', 'GSI']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP', 'IA.RFW.CA']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) >= STR_TO_MILLIS(CLOCK_LOCAL())),\n" +
                    "IA_SLAB_Count AS (\n" +
                    "    SELECT COUNT(*) AS IA_SLAB\n" +
                    "    FROM iWatchXCustomerJourney iwxcjbucket\n" +
                    "    WHERE iwxcjbucket.docType ='gsiCase'\n" +
                    "        AND iwxcjbucket.tenant.pId = 'WU'\n" +
                    "        AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                    "        AND iwxcjbucket.genreId = 'CJ'\n" +
                    "        AND iwxcjbucket.classification.businessGroup = 'GSI'\n" +
                    "        AND iwxcjbucket.workflow.status.tier IN ['Investigation Approval']\n" +
                    "        AND iwxcjbucket.classification.invGroup IN ['INTR', 'SANC']\n" +
                    "        AND iwxcjbucket.workflow.status.id IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP', 'IA.RFW.CA']\n" +
                    "        AND iwxcjbucket.caseRefNo IS NOT NULL\n" +
                    "        AND iwxcjbucket.caseRefNo <> ''\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL\n" +
                    "        AND STR_TO_MILLIS(iwxcjbucket.workflow.targetTimestamp) < STR_TO_MILLIS(CLOCK_LOCAL()))\n" +
                    "SELECT SI_SLAIN_Count[0].SI_SLAIN AS RFW_SLANB_SI,\n" +
                    "       SI_SLAB_Count[0].SI_SLAB AS RFW_SLAB_SI,\n" +
                    "       EI_SLIN_Count[0].EI_SLAIN AS RFW_SLANB_EI,\n" +
                    "       EI_SLAB_Count[0].EI_SLAB AS RFW_SLAB_EI,\n" +
                    "       AI_SLIN_Count[0].AI_SLAIN AS RFW_SLANB_AI,\n" +
                    "       AI_SLAB_Count[0].AI_SLAB AS RFW_SLAB_AI,\n" +
                    "       IA_SLIN_Count[0].IA_SLAIN AS RFW_SLANB_IA,\n" +
                    "       IA_SLAB_Count[0].IA_SLAB AS RFW_SLAB_IA";
            String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
            dbResult = queryResult;
            Logger.info("Query Result : " + queryResult);
            int SLABVALUE1 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLAB_AI", dbResult);
            int SLABVALUE2 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLAB_EI", dbResult);
            int SLABVALUE3 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLAB_IA", dbResult);
            int SLABVALUE4 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLAB_SI", dbResult);
            int SLABVALUE5 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLANB_AI", dbResult);
            int SLABVALUE6 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLANB_EI", dbResult);
            int SLABVALUE7 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLANB_IA", dbResult);
            int SLABVALUE8 = (int) CommonFunctions.getValueFromJSON("[0].RFW_SLANB_SI", dbResult);
            int Total=0;
            Total=SLABVALUE1+SLABVALUE2+SLABVALUE3+SLABVALUE4+SLABVALUE5+SLABVALUE6+SLABVALUE7+SLABVALUE8;
            Logger.info("Total case count from couchDB "+Total+"");

        }else {
            if (Businessgroup.equalsIgnoreCase("BKYC")) {
                query = "WITH BKYC_CASES as (SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as TS\n" +
                        "FROM iWatchXCustomerJourney as iwxcjbucket\n" +
                        "WHERE iwxcjbucket.docType ='bkycCase'\n" +
                        "AND iwxcjbucket.tenant.pId = 'WU'\n" +
                        "AND iwxcjbucket.tenant.sId = 'CMT'\n" +
                        "AND iwxcjbucket.classification.businessGroup = 'BKYC'\n" +
                        "AND iwxcjbucket.genreId = 'CJ'\n" +
                        "AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> ''\n" +
                        "AND STR_TO_MILLIS(iwxcjbucket.createdTimestamp) IS NOT NULL)\n" +
                        "SELECT (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE\n" +
                        "iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO']\n" +
                        "AND STR_TO_MILLIS(iwxbucket.TS) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_SI_RFW_SLANB,\n" +
                        "(SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO']\n" +
                        "AND STR_TO_MILLIS(iwxbucket.TS) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_SI_RFW_SLAB,\n" +
                        "(SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE']\n" +
                        "AND STR_TO_MILLIS(iwxbucket.TS) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_EI_RFW_SLANB,\n" +
                        "(SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE']\n" +
                        "AND STR_TO_MILLIS(iwxbucket.TS) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_EI_RFW_SLAB,\n" +
                        "(SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE']\n" +
                        "AND STR_TO_MILLIS(iwxbucket.TS) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IA_RFW_SLANB,\n" +
                        "(SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE']\n" +
                        "AND STR_TO_MILLIS(iwxbucket.TS) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IA_RFW_SLAB; ";
                String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnFullResult(query.trim());
                dbResult = queryResult;
                Logger.info("Query Result : " + queryResult);
            }
        }
    }



    @When("User verfiy {string} as digit {string}")
    public void userVerifyCasrefernoasdigit(String caseRefNo, String Digit){
        if (caseRefNo.contains("$")) {
            caseRefNo = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
        }
        int caseRefNovalue = String.valueOf(caseRefNo).length();
        int Digitvalue =Integer.parseInt(Digit);
        Assert.assertEquals(caseRefNovalue,Digitvalue,"Caseref number dosnot contains 13 Digits");
        Logger.info("User verfiy "+caseRefNo+" as digit "+Digit+"");
    }
    @When("User saves Gsi invGroup= {string} and tier= {string} RFW caseId in {string}")
    public void userSavesGsiINTRSANCRFWcaseIdinVariable(String invGroup, String tier, String caseId) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        String caseIdval = getGSIRFWcaseId(invGroup, tier);
        Logger.info("RFW caseId \"" + caseIdval + "\" saved in \"" + caseId + "\"");
        addCaseData(caseId, caseIdval);
    }
    public String getGSIRFWcaseId(String invGroup, String tier) throws InterruptedException, SQLException, ClassNotFoundException, Exception {
        String caseIdVal;
        String dbResult = dbQueryForGSIRFWcaseid(invGroup, tier);
        if (dbResult.equals("0 result")) {
            if (invGroup.equals("INTR_SI")) {
                Logger.info("No Interdiction RFW case found in DB; hence generating a new WU Retail case");
                CreateCaseSteps createCase = new CreateCaseSteps();
                createCase.givenUserCreatesWUgsiCaseSenderSide("newCaseId");
                caseIdVal = (String) getCaseData("newCaseId");
            } else {
                CaseCreationSanctionsSteps createCase = new CaseCreationSanctionsSteps();
                if (tier.equals("SI")) {
                    createCase.givenUserCreatesCaseForWURetailSanctionsSenderSide("L1", "newCaseId");
                } else if (tier.equals("EI")) {
                    createCase.givenUserCreatesCaseForWURetailSanctionsSenderSide("L2", "newCaseId");
                } else if (tier.equals("AI")) {
                    createCase.givenUserCreatesCaseForWURetailSanctionsSenderSide("L3", "newCaseId");

                }
            }
            Logger.info("No Sanction RFW case found in DB; hence generating a new WU Retail case");
            caseIdVal = (String) getCaseData("newCaseId");


        } else {
            caseIdVal = (String) CommonFunctions.getValueFromJSON("$", dbResult);
        }
        return caseIdVal;
    }

    @Then("Analyst get count of {string} from DB for {string}")
    public void analystGetCountOfFromDB(String fieldName,String BG) throws Exception {
        String param="";

        switch (fieldName) {
            case "Last 24 Hours Cases":
                param = "-1,'day'";
                break;
            case "Last 7 Days Cases":
                param = "-1,'week'";
                break;
            case "Older Cases":
                param = "-3,'month'";
                break;

        }
        String query="SELECT count(*) as COUNT FROM iWatchXCustomerJourney\n" +
                "WHERE docType ='"+BG.toLowerCase()+"Case' \n" +
                "AND createdTimestamp >= DATE_ADD_STR(CLOCK_STR(),"+param+")    \n" +
                "                   AND tenant.pId = 'WU'\n" +
                "                   AND tenant.sId = 'CMT'\n" +
                "                   AND classification.businessGroup = '"+BG+"'\n" +
                "                   AND genreId = 'CJ'\n" +
                "                   AND caseRefNo IS NOT MISSING\n" +
                "                   AND dispositionActions IS NOT MISSING\n" +
                "                   AND ANY tier IN dispositionActions SATISFIES (\n" +
                "                           ANY action IN tier.actions SATISFIES (\n" +
                "                               action.status IN ['F','A']    AND action.name IN ['Release','Move to Refund Queue','Cancel','Move to CallBack Queue','Move to Escalated Queue','Keep in Queue','Keep in Seizure Queue','Hop to Escalated Queue','Profile Update','Account Update']\n" +
                "                           ) END\n" +
                "                       ) END;\n";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        int countVal = (int) CommonFunctions.getIntValueFromJSON("COUNT", dbResult);

        addCaseData("count", countVal);
        Logger.info("\"count\" = " + getCaseData("count") + " for "+fieldName);

    }

    public String dbQueryForGSIRFWcaseid(String invGroup, String tier) throws Exception {
        String query;
        String id;
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserId = "";
        if (invGroup.equals("SANC_SI")) {
            invGroup = "GSI";
            tier = "Standard Investigation";
            id = "'SI.RFW.CA','SI.RFW.AP'";

        } else {
            if (invGroup.equals("SANC_EI")) {
                invGroup = "GSI";
                tier = "Enhanced Investigation";
                id = "'EI.RFWA.AP','EI.RFW.AP','EI.INV.TO'";
                oktaUserId = CommonFunctions.readFile(fileName, "oktaUserName_" + tier);
            } else {
                if (invGroup.equals("SANC_AI")) {
                    invGroup = "GSI";
                    tier = "Advanced Investigation";
                    id = "'AI.RFW.AP', 'AI.INV.PE', 'AI.INV.TO'";
                    oktaUserId = CommonFunctions.readFile(fileName, "oktaUserName_" + tier);
                } else {
                    invGroup = "INTR";
                    tier = "Standard Investigation";
                    id = "'SI.RFW.CA','SI.INV.PE','SI.INV.TO'";

                }
            }
        }
        query = "SELECT META().id\n" +
                "FROM iWatchXCustomerJourney docRetrieve\n" +
                "WHERE docRetrieve.docType='gsiCase'\n" +
                "    AND docRetrieve.tenant.sId = 'CMT'\n" +
                "    AND docRetrieve.tenant.pId = 'WU'\n" +
                "    AND docRetrieve.classification.businessGroup = 'GSI'\n" +
                "    AND docRetrieve.classification.invGroup IN [\"" + invGroup + "\"]\n" +
                "    AND docRetrieve.genreId ='CJ'\n" +
                "    AND docRetrieve.workflow.status.tier = \"" + tier + "\"\n" +
                "    AND docRetrieve.workflow.status.id IN [" + id + "]\n" +
                "    AND (docRetrieve.analyst.id is missing OR docRetrieve.analyst.id <> [" + oktaUserId + "])\n" +
                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
                "    AND docRetrieve.createdTimestamp <> ''\n" +
                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
                "    AND docRetrieve.hitSide.`index` <> ''\n" +
                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
                "    AND docRetrieve.caseRefNo <> ''\n" +
                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
                "         docRetrieve.hitSide.`index`,\n" +
                "         createdTimestamp\n" +
                "LIMIT 1";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        System.out.println("DB Result: "+result);
        String[] arrayResult = result.split(":");
        String queryResult = arrayResult[1]+"::"+arrayResult[3];
        dbResult = queryResult;
        return queryResult;
    }
    @And("User enters the input json for {string} API in Request body section")
    public void enterRequestBody(String jsonName) throws Exception {

        switch (jsonName) {
            case "Audit_Get":
                inputPayloadJSON = "";
                break;

//
        }
        System.out.println("*****" + inputPayloadJSON);
        Logger.info("Input payload JSON for " + jsonName + " API loaded!");
        if (jsonName.equalsIgnoreCase("Attachment_Post")) {
            BaseTestSetup.webDriver.findElement(By.xpath("//input[@placeholder='data']")).sendKeys(inputPayloadJSON);
        } else {
            BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='opblock-section opblock-section-request-body']/div[2]//textarea")).clear();
            BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='opblock-section opblock-section-request-body']/div[2]//textarea")).sendKeys(inputPayloadJSON);
        }
    }

    @Then("Validate bulk update functionality for all the case ids in the bulk template")
    public void validateBulkUpdate() throws Exception {
        System.out.println("**************************Bulk update validation - Start***********************");
        DashboardPage dashboardPage= new DashboardPage();
        CaseDispositionControlPage caseDispositionControlPage = new CaseDispositionControlPage();
        List<String> caseList = CommonFunctions.readColumnValuesFromBulkExcel(0,0);
        Logger.info("List of caseids : "+caseList);

        //Disposition
        List<String> dispositionList = CommonFunctions.readColumnValuesFromBulkExcel(2,0);
        Logger.info("List of Disposition : "+dispositionList);

        //Case Reasons
        List<String> caseReasonList = CommonFunctions.readColumnValuesFromBulkExcel(3,0);
        Logger.info("List of Case Reasons : "+caseReasonList);

        //case Action
        List<String> caseActionList = CommonFunctions.readColumnValuesFromBulkExcel(4,0);
        Logger.info("List of Case Action : "+caseReasonList);

        //Executeactions
        List<Boolean> executeActionList = CommonFunctions.readBooleanColumnValuesFromBulkExcel(7,0);
        Logger.info("List of Execute action : "+executeActionList);

        //ctm
        List<String> ctmList = CommonFunctions.readColumnValuesFromBulkExcel(8,1);
        Logger.info("List of ctm messages :"+ctmList);

        for(int i=0;i<caseList.size();i++){
            Logger.info("------------------------------------------------------");
            dashboardPage.enterCaseIdInSearchTextBox(caseList.get(i));
            Logger.info("Enters case id in search box -->"+caseList.get(i));
            dashboardPage.clickOnSearchButton();
            Logger.info("Clicks on search button");
            dashboardPage.clickOnCaseActionButton("View Case");
            Logger.info("Clicks on view and waits for the case to open");
            Thread.sleep(5000);

            String disposition = dashboardPage.getCaseDispositionFromCase().getText();
            Logger.info("Disposition value from UI:"+disposition);
            Assert.assertTrue(disposition.equalsIgnoreCase(dispositionList.get(i)));
            Logger.info("Successfully validated disposition value :"+dispositionList.get(i));

            // ----CTM From second sheet. --- true/false - entity clearing

            if(executeActionList.get(i) == TRUE && ctmList.get(i).contains("Entity Clear")){
                caseDispositionControlPage.validateCTMAckEntClearingBulk(ctmList.get(i));
                Logger.info("CTM Ack verified for entity clearing via bulk");
            }
            else if(executeActionList.get(i) == FALSE && ctmList.get(i).contains("Entity Clear")){
                caseDispositionControlPage.validateCTMAckCrossEntClearing(ctmList.get(i));
                Logger.info("CTM Ack verified for bulk upload");

            }
            else{
                caseDispositionControlPage.validateCTMAckCross(ctmList.get(i));
                Logger.info("CTM Ack verified for bulk upload");

            }

            // ----- Audit
            CaseInvestigationPage caseInvestigationPage= new CaseInvestigationPage();
            caseInvestigationPage.clickOnPlusSymbol();
            caseInvestigationPage.clickOnAuditLogSymbol();
            Logger.info("Analyst Clicks on Audit Log symbol");
            caseInvestigationPage.validateAuditLog("via bulk operation");
            Logger.info("Audit log verified : 'via bulk operation'");


            dashboardPage.getDashboardLink().click();
            Thread.sleep(2000);
            Logger.info("------------------------------------------------------");




        }
        System.out.println("Number of rows verified:"+(caseList.size()));

        System.out.println("**************************Bulk update validation - End***********************");

    }

    @When("User validates bulk update for {string} in UI")
    public void userValidatesBulkInUI(String caseList){
        Logger.info("validate bulk in ui");
        if (caseList.contains("$")) {
            caseList = caseList.substring(caseList.indexOf("$") + 1);
            caseList = getCaseData(caseList);
            Logger.info("cases : "+caseList);
        }

    }

    @And("Analyst verifies if status is updated to {string} for action {string} for case {string}")
    public void analystValidatesStatusForAction(String status, String action, String caseId) throws Exception {
        if (status.contains("$")) status = status.substring(status.indexOf("$") + 1);
        if (action.contains("$")) action = action.substring(action.indexOf("$") + 1);
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);


        String statusValue = getstatusForcaseId(status, action, caseId);
        //Get status
        //{"failureActions":["A"]}
        Logger.info("db result : "+statusValue);
        String[] statusArray = statusValue.split(":");
        Logger.info("Array : "+statusArray[1]);
        // Verify if it is M
//        Assert.assertTrue(statusArray[1].contains("M"));
//        Assert.assertTrue(statusArray[1].equals("[\"M\"]}"));
        Assert.assertEquals(statusArray[1],"[\"M\"]}","Status is not M");

        Logger.info("Status is \"" + statusArray[1] + "\" for action : \"" + action + "\"");
    }

    @And("Analyst saves action failure count from DB in {string}")
    public void analystSavesFailureCountFromDB(String FailureCount) throws Exception {
        if (FailureCount.contains("$")) {
            FailureCount = FailureCount.substring(FailureCount.indexOf("$") + 1);
        }
        String count = getActionFailureCountFromDB();
        Logger.info("Count of action failure count : "+count);

        addCaseData(FailureCount, count);
    }

    @Then("Analyst verifies action failure count from DB {string} is reduced by 1")
    public void analystVerifiesFailureCountReduced(String oldCount) throws Exception {
        if (oldCount.contains("$")) {
            oldCount = oldCount.substring(oldCount.indexOf("$") + 1);
            oldCount = getCaseData(oldCount);
        }

        String newCount = getActionFailureCountFromDB();
        int newCountInt = Integer.parseInt(newCount);
        Logger.info("Actual count : "+newCountInt);
        int oldCountInt;

        Logger.info("Count before manual resolve: "+oldCount);
        oldCountInt = Integer.parseInt(oldCount);
        int expectedCount = oldCountInt -1 ; // After manually resolving one case, the count should reduce


        Assert.assertEquals(newCountInt, expectedCount, "Action failure count is not as expected");
        Logger.info("Count before and after manual resolve is verified");


    }


    @Then("Analyst verifies action failure total count {string} is reduced by 1")
    public void analystVerifiesFailureCountReducedInApi(String totalcount) throws Exception {
        if (totalcount.contains("$")) {
            totalcount = totalcount.substring(totalcount.indexOf("$") + 1);
            totalcount = getCaseData(totalcount);
            Logger.info("get case data total count :"+totalcount);
        }

        String newCount = CommonFunctions.getTagValue(apiResponse, "actionFailureMetrics.totalCases");
        int newCountInt = Integer.parseInt(newCount);
        Logger.info("Actual count : "+newCountInt);
        int oldCountInt;

        Logger.info("Count before manual resolve: "+totalcount);
        oldCountInt = Integer.parseInt(totalcount);
        int expectedCount = oldCountInt -1 ; // After manually resolving one case, the count should reduce


        Assert.assertEquals(newCountInt, expectedCount, "Action failure count is not as expected");
        Logger.info("Count before and after manual resolve is verified");


    }

    @And("Analyst searches with correlation id {string} in the open search logs")
    public void analystEntersTextInSearchbar(String correlationId){

        if (correlationId.contains("$")) {
            correlationId = correlationId.substring(correlationId.indexOf("$") + 1);
            correlationId = getCaseData(correlationId);
            Logger.info("Correlation Id is : "+correlationId);

        }

        String text = "wu.correlation_id:'"+correlationId+"'";
        Actions action = new Actions(BaseTestSetup.webDriver);
        action.moveToElement(openSearchPage.getSearchBar()).click().perform();
        openSearchPage.getSearchBar().sendKeys(text);
        Logger.info("Analyst entered text in search bar : "+text);
        openSearchPage.getSearchBar().sendKeys(Keys.ENTER);
    }

    @And("Analyst selects {string} filter")
    public void selectFilterOpenSearch(String option){
        openSearchPage.getFilterOption(option).click();
        Logger.info("Analyst has selected filter : "+option);
    }

    @Then("Analyst validates text {string} in logs")
    public void validateTextInLogs(String expText){

        APICommonSteps apiCommonSteps = new APICommonSteps();
        String Failurecount = getCaseData("Failurecount"); // example : $76
        String actText = openSearchPage.getCountTextFromLogs().getText();
        expText = expText.replace("$Failurecount", Failurecount);
        Logger.info("Actual text from open search logs : "+actText);
        Assert.assertEquals(actText,expText, "Log text doesn't match");
        Logger.info("Analyst has verified log text and DB count");
    }

    public String getstatusForcaseId(String status, String action, String caseId) throws Exception {

        String query;

        query = "Select (CASE WHEN dispositionActions IS NOT MISSING\n"+
                 "THEN ARRAY act.status\n"+
                 "FOR act IN ARRAY_FLATTEN(ARRAY dispAct.actions FOR dispAct IN dispositionActions END, 1)\n"+
                  "WHEN act.name =  '" + action + "'\n"+
                  "END\n"+
                  "END) as failureActions from iWatchXCustomerJourney USE KEYS '"+caseId+"';\n";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        System.out.println("query result is "+result);
        if(result.equals("0 result")){
            dbResult=result;
        }
        else{
//            String[] arrayResult = result.split(":");
            dbResult =result;

        }
        return dbResult;
    }


    public String getActionFailureCountFromDB() throws Exception {

        String query;

        query = "SELECT COUNT(*) FROM iWatchXCustomerJourney \n" +
                "WHERE docType ='gsiCase'\n" +
                "AND tenant.pId = 'WU'\n" +
                "AND tenant.sId = 'CMT'\n" +
                "AND classification.businessGroup = 'GSI'\n"+
                "AND genreId = 'CJ'\n" +
                "AND caseRefNo IS NOT MISSING\n"+
                "AND dispositionActions IS NOT MISSING\n"+
                "AND ANY tier IN dispositionActions SATISFIES (\n"+
                " ANY action IN tier.actions SATISFIES (\n"+
                "action.status IN ['F','A']    AND action.name IN ['Release','Move to Refund Queue','Cancel','Move to CallBack Queue','Move to Escalated Queue','Keep in Queue','Keep in Seizure Queue','Hop to Escalated Queue','Profile Update','Account Update']\n"+
                 "          ) END\n"+
                  "     ) END";

        String result = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        System.out.println("query result is "+result);
        if(result.equals("0 result")){
            dbResult=result;
        }
        else{
            String[] arrayResult = result.split(":");
            dbResult =arrayResult[1];
            dbResult= dbResult.substring(0,dbResult.length()-1);
        }
        return dbResult;

    }
    @Then("Analyst get count of {string} from DB for {string} for {string}")
    public void analystGetCountOfFromDBAFReviewType(String fieldName,String BG,String ReviewType) throws Exception {
        String param="",ReviewTypeParam="";

        switch (fieldName) {
            case "Last 24 Hours Cases":
                param = "-1,'day'";
                break;
            case "Last 7 Days Cases":
                param = "-7,'day'";
                break;
            case "Older Cases":
                param = "-90,'day'";
                break;

        }
        switch(ReviewType) {
            case "Receiver at Send":
                ReviewTypeParam = "RS";
                break;
            case "Sender at Send":
                ReviewTypeParam = "SS";
                break;
            case "Receiver at Pay":
                ReviewTypeParam = "RR";
                break;
            case "Sender at Pay":
                ReviewTypeParam = "SR";
                break;

        }
        String query="SELECT count(*) as COUNT FROM iWatchXCustomerJourney\n" +
                "WHERE docType ='"+BG.toLowerCase()+"Case' \n" +
                "AND hitSide.`value` = '"+ReviewTypeParam+"' \n" +
                "AND createdTimestamp >= DATE_ADD_STR(CLOCK_STR(),"+param+")    \n" +
                "                   AND tenant.pId = 'WU'\n" +
                "                   AND tenant.sId = 'CMT'\n" +
                "                   AND classification.businessGroup = '"+BG+"'\n" +
                "                   AND genreId = 'CJ'\n" +
                "                   AND caseRefNo IS NOT MISSING\n" +
                "                   AND dispositionActions IS NOT MISSING\n" +
                "                   AND ANY tier IN dispositionActions SATISFIES (\n" +
                "                           ANY action IN tier.actions SATISFIES (\n" +
                "                               action.status IN ['F','A']    AND action.name IN ['Release','Move to Refund Queue','Cancel','Move to CallBack Queue','Keep in Queue','Keep in Seizure Queue','Hop to Escalated Queue','Move to Escalated Queue','Keep in queue','Move to Callback Queue','Profile Update','Account Update','Publish Disposition To External System']\n" +
                "                           ) END\n" +
                "                       ) END;\n";
        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        int countVal = (int) CommonFunctions.getIntValueFromJSON("COUNT", dbResult);

        addCaseData("count", countVal);
        Logger.info("\"count\" = " + getCaseData("count") + " for "+fieldName);

    }

    @Then("Analyst get count from DB for {string} for RFW Widget for {string} in {string}")
    public void analystGetCountOfFromDBForForRFWWidget(String tier,String type, String BG) throws Exception {
        String query="";
        if(BG.equals("GSI")) {
            query = "WITH GSI_CASES as \n" +
                    "(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"GSI\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'SI.CON.CC','CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    ") \n" +
                    "SELECT (\n" +
                    "SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_EI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLANB;\n" +
                    "\n";
        }
        else if(BG.equals("BKYC")) {
            query = "WITH BKYC_CASES as (SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'bkycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"BKYC\" AND iwxcjbucket.genreId = $genre AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> '') \n" +
                    "SELECT (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLANB;\n";
        }

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        if(tier.equals("Standard Investigation")) {
            int countValGsiSISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_SI_SLAB", dbResult);
            int countValGsiSISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_SI_SLANB", dbResult);
            addCaseData("SISlab", countValGsiSISlab);
            addCaseData("SISlanb", countValGsiSISlanb);
            Logger.info("\"SISlab\" = " + getCaseData("SISlab"));
            Logger.info("\"SISlanb\" = " + getCaseData("SISlanb"));
        }
        else if(tier.equals("Enhanced Investigation")) {
            int countValGsiEISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_EI_SLAB", dbResult);
            int countValGsiEISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_EI_SLANB", dbResult);
            addCaseData("EISlab", countValGsiEISlab);
            addCaseData("EISlanb", countValGsiEISlanb);
            Logger.info("\"EISlab\" = " + getCaseData("EISlab"));
            Logger.info("\"EISlanb\" = " + getCaseData("EISlanb"));
        }
        else if(tier.equals("Advanced Investigation")) {
            int countValGsiAISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_AI_SLAB", dbResult);
            int countValGsiAISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_AI_SLANB", dbResult);
            addCaseData("AISlab", countValGsiAISlab);
            addCaseData("AISlanb", countValGsiAISlanb);
            Logger.info("\"AISlab\" = " + getCaseData("AISlab"));
            Logger.info("\"AISlanb\" = " + getCaseData("AISlanb"));
        }
        else {
            int countValGsiIASlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_IA_SLAB", dbResult);
            int countValGsiIASlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_IA_SLANB", dbResult);
            addCaseData("IASlab", countValGsiIASlab);
            addCaseData("IASlanb", countValGsiIASlanb);
            Logger.info("\"IASlab\" = " + getCaseData("IASlab"));
            Logger.info("\"IASlanb\" = " + getCaseData("IASlanb"));
        }
    }
    @Then("Analyst get count from DB for {string} for In Progress Widget for {string} in {string}")
    public void analystGetCountOfFromDBForForIPWidget(String tier,String type, String BG) throws Exception {
        String query="";
        if(BG.equals("GSI")) {
            query = "WITH GSI_CASES as \n" +
                    "(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"GSI\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'SI.CON.CC','CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    ") \n" +
                    "SELECT (\n" +
                    "SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_EI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLANB;\n" +
                    "\n";
        }
        else if(BG.equals("BKYC")) {
            query = "WITH BKYC_CASES as (SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'bkycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"BKYC\" AND iwxcjbucket.genreId = $genre AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> '') \n" +
                    "SELECT (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLANB;\n";
        }

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        if(tier.equals("Standard Investigation")) {
            int countValGsiSISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_SI_SLAB", dbResult);
            int countValGsiSISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_SI_SLANB", dbResult);
            addCaseData("SISlab", countValGsiSISlab);
            addCaseData("SISlanb", countValGsiSISlanb);
            Logger.info("\"SISlab\" = " + getCaseData("SISlab"));
            Logger.info("\"SISlanb\" = " + getCaseData("SISlanb"));
        }
        else if(tier.equals("Enhanced Investigation")) {
            int countValGsiEISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_EI_SLAB", dbResult);
            int countValGsiEISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_EI_SLANB", dbResult);
            addCaseData("EISlab", countValGsiEISlab);
            addCaseData("EISlanb", countValGsiEISlanb);
            Logger.info("\"EISlab\" = " + getCaseData("EISlab"));
            Logger.info("\"EISlanb\" = " + getCaseData("EISlanb"));
        }
        else if(tier.equals("Advanced Investigation")) {
            int countValGsiAISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_AI_SLAB", dbResult);
            int countValGsiAISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_AI_SLANB", dbResult);
            addCaseData("AISlab", countValGsiAISlab);
            addCaseData("AISlanb", countValGsiAISlanb);
            Logger.info("\"AISlab\" = " + getCaseData("AISlab"));
            Logger.info("\"AISlanb\" = " + getCaseData("AISlanb"));
        }
        else {
            int countValGsiIASlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_IA_SLAB", dbResult);
            int countValGsiIASlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_IA_SLANB", dbResult);
            addCaseData("IASlab", countValGsiIASlab);
            addCaseData("IASlanb", countValGsiIASlanb);
            Logger.info("\"IASlab\" = " + getCaseData("IASlab"));
            Logger.info("\"IASlanb\" = " + getCaseData("IASlanb"));
        }
    }
    @Then("Analyst get count from DB for {string} for Pending Info Widget for {string} in {string}")
    public void analystGetCountOfFromDBForForPIWidget(String tier,String type, String BG) throws Exception {
        String query="";
        if(BG.equals("GSI")) {
            query = "WITH GSI_CASES as \n" +
                    "(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"GSI\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'SI.CON.CC','CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    ") \n" +
                    "SELECT (\n" +
                    "SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_EI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLANB;\n" +
                    "\n";
        }
        else if(BG.equals("BKYC")) {
            query = "WITH BKYC_CASES as (SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'bkycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"BKYC\" AND iwxcjbucket.genreId = $genre AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> '') \n" +
                    "SELECT (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLANB;\n";
        }

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        if(tier.equals("Standard Investigation")) {
//            int countValGsiSISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_SI_SLAB", dbResult);
            int countValGsiSISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_SI_SLANB", dbResult);
//            addCaseData("SISlab", countValGsiSISlab);
            addCaseData("SISlanb", countValGsiSISlanb);
//            Logger.info("\"SISlab\" = " + getCaseData("SISlab"));
            Logger.info("\"SISlanb\" = " + getCaseData("SISlanb"));
        }
        else if(tier.equals("Enhanced Investigation")) {
//            int countValGsiEISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_EI_SLAB", dbResult);
            int countValGsiEISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_EI_SLANB", dbResult);
//            addCaseData("EISlab", countValGsiEISlab);
            addCaseData("EISlanb", countValGsiEISlanb);
//            Logger.info("\"EISlab\" = " + getCaseData("EISlab"));
            Logger.info("\"EISlanb\" = " + getCaseData("EISlanb"));
        }
        else if(tier.equals("Advanced Investigation")) {
//            int countValGsiAISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_AI_SLAB", dbResult);
            int countValGsiAISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_AI_SLANB", dbResult);
//            addCaseData("AISlab", countValGsiAISlab);
            addCaseData("AISlanb", countValGsiAISlanb);
//            Logger.info("\"AISlab\" = " + getCaseData("AISlab"));
            Logger.info("\"AISlanb\" = " + getCaseData("AISlanb"));
        }
        else {
            int countValGsiIASlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_IA_SLAB", dbResult);
            int countValGsiIASlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_IA_SLANB", dbResult);
            addCaseData("IASlab", countValGsiIASlab);
            addCaseData("IASlanb", countValGsiIASlanb);
            Logger.info("\"IASlab\" = " + getCaseData("IASlab"));
            Logger.info("\"IASlanb\" = " + getCaseData("IASlanb"));
        }
    }
    @Then("Analyst get count from DB for {string} for RFW Widget for {string} in {string} with Review Type {string}")
    public void analystGetCountOfFromDBForForRFWWidget(String tier,String type, String BG, String ReviewType) throws Exception {
        String query="",ReviewTypeParam="";
        switch(ReviewType) {
            case "Receiver at Send":
                ReviewTypeParam = "RS";
                break;
            case "Sender at Send":
                ReviewTypeParam = "SS";
                break;
            case "Receiver at Pay":
                ReviewTypeParam = "RR";
                break;
            case "Sender at Pay":
                ReviewTypeParam = "SR";
                break;
            case "Ongoing":
                ReviewTypeParam = "Ongoing";
                break;
            case "Onboarding":
                ReviewTypeParam = "Onboarding";
                break;

        }

        if(BG.equals("GSI")) {
            query = "WITH GSI_CASES as \n" +
                    "(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"GSI\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'SI.CON.CC','CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"') \n" +
                    "SELECT (\n" +
                    "SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_EI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLANB;\n" +
                    "\n";
        }
        else if(BG.equals("BKYC")) {
            query ="WITH BKYC_CASES as (SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'bkycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"BKYC\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"') \n" +
                    "SELECT (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLANB;";
        }
        else if(BG.equals("KYC")){
            query ="WITH KYC_CASES as(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'kycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"KYC\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"'\n" +
                    ")\n" +
                    "\n" +
                    "SELECT (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.ATP', 'SI.UI.PE', 'SI.UI.TO', 'SI.RFW.CA', 'SI.INV.TO', 'SI.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_SI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.ATP', 'SI.UI.PE', 'SI.UI.TO', 'SI.RFW.CA', 'SI.INV.TO', 'SI.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.USR.PE', 'EI.RFWE.ATP', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_EI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.USR.PE', 'EI.USR.TO', 'EI.RFWE.ATP', 'EI.UER.TO', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.TO', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_IA_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.TO', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_IA_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_PI_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_PI_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.UI.EP', 'SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_SI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.UI.EP', 'SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.USR.FA', 'EI.UER.EP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_EI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.USR.FA', 'EI.UER.EP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_IA_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_IA_SLANB;";
        }

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        if(tier.equals("Standard Investigation")) {
            int countValGsiSISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_SI_SLAB", dbResult);
            int countValGsiSISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_SI_SLANB", dbResult);
            addCaseData("SISlab", countValGsiSISlab);
            addCaseData("SISlanb", countValGsiSISlanb);
            Logger.info("\"SISlab\" = " + getCaseData("SISlab"));
            Logger.info("\"SISlanb\" = " + getCaseData("SISlanb"));
        }
        else if(tier.equals("Enhanced Investigation")) {
            int countValGsiEISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_EI_SLAB", dbResult);
            int countValGsiEISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_EI_SLANB", dbResult);
            addCaseData("EISlab", countValGsiEISlab);
            addCaseData("EISlanb", countValGsiEISlanb);
            Logger.info("\"EISlab\" = " + getCaseData("EISlab"));
            Logger.info("\"EISlanb\" = " + getCaseData("EISlanb"));
        }
        else if(tier.equals("Advanced Investigation")) {
            int countValGsiAISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_AI_SLAB", dbResult);
            int countValGsiAISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_AI_SLANB", dbResult);
            addCaseData("AISlab", countValGsiAISlab);
            addCaseData("AISlanb", countValGsiAISlanb);
            Logger.info("\"AISlab\" = " + getCaseData("AISlab"));
            Logger.info("\"AISlanb\" = " + getCaseData("AISlanb"));
        }
        else {
            int countValGsiIASlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_IA_SLAB", dbResult);
            int countValGsiIASlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_RFW_IA_SLANB", dbResult);
            addCaseData("IASlab", countValGsiIASlab);
            addCaseData("IASlanb", countValGsiIASlanb);
            Logger.info("\"IASlab\" = " + getCaseData("IASlab"));
            Logger.info("\"IASlanb\" = " + getCaseData("IASlanb"));
        }
    }
    @Then("Analyst get count from DB for {string} for Pending Info Widget for {string} in {string} with Review Type {string}")
    public void analystGetCountOfFromDBForForPendingInfoWidget(String tier,String type, String BG, String ReviewType) throws Exception {
        String query="",ReviewTypeParam="";
        switch(ReviewType) {
            case "Receiver at Send":
                ReviewTypeParam = "RS";
                break;
            case "Sender at Send":
                ReviewTypeParam = "SS";
                break;
            case "Receiver at Pay":
                ReviewTypeParam = "RR";
                break;
            case "Sender at Pay":
                ReviewTypeParam = "SR";
                break;
            case "Ongoing":
                ReviewTypeParam = "Ongoing";
                break;
            case "Onboarding":
                ReviewTypeParam = "Onboarding";
                break;

        }

        if(BG.equals("GSI")) {
            query = "WITH GSI_CASES as \n" +
                    "(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"GSI\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'SI.CON.CC','CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"') \n" +
                    "SELECT (\n" +
                    "SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_EI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLANB;\n" +
                    "\n";
        }
        else if(BG.equals("BKYC")) {
            query="WITH BKYC_CASES as (SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'bkycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"BKYC\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"') \n" +
                    "SELECT (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLANB;";
        }
        else if(BG.equals("KYC")){
            query ="WITH KYC_CASES as(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'kycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"KYC\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"'\n" +
                    ")\n" +
                    "\n" +
                    "SELECT (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.ATP', 'SI.UI.PE', 'SI.UI.TO', 'SI.RFW.CA', 'SI.INV.TO', 'SI.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_SI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.ATP', 'SI.UI.PE', 'SI.UI.TO', 'SI.RFW.CA', 'SI.INV.TO', 'SI.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.USR.PE', 'EI.RFWE.ATP', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_EI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.USR.PE', 'EI.USR.TO', 'EI.RFWE.ATP', 'EI.UER.TO', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.TO', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_IA_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.TO', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_IA_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_PI_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_PI_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.UI.EP', 'SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_SI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.UI.EP', 'SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.USR.FA', 'EI.UER.EP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_EI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.USR.FA', 'EI.UER.EP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_IA_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_IA_SLANB;";
        }

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        if(tier.equals("Standard Investigation")) {

            int countValGsiSISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_SI_SLANB", dbResult);
            addCaseData("SISlanb", countValGsiSISlanb);
            Logger.info("\"SISlanb\" = " + getCaseData("SISlanb"));
        }
        else if(tier.equals("Enhanced Investigation")) {
            int countValGsiEISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_EI_SLANB", dbResult);
            addCaseData("EISlanb", countValGsiEISlanb);
            Logger.info("\"EISlanb\" = " + getCaseData("EISlanb"));
        }
        else if(tier.equals("Advanced Investigation")) {
            int countValGsiAISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_AI_SLANB", dbResult);
            addCaseData("AISlanb", countValGsiAISlanb);
            Logger.info("\"AISlanb\" = " + getCaseData("AISlanb"));
        }
        else {
            int countValGsiIASlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_PI_IA_SLANB", dbResult);
            addCaseData("IASlanb", countValGsiIASlanb);
            Logger.info("\"IASlanb\" = " + getCaseData("IASlanb"));
        }
    }

    @Then("Analyst get count from DB for {string} for In Progress Widget for {string} in {string} with Review Type {string}")
    public void analystGetCountOfFromDBForForInProgressWidget(String tier,String type, String BG, String ReviewType) throws Exception {
        String query="",ReviewTypeParam="";
        switch(ReviewType) {
            case "Receiver at Send":
                ReviewTypeParam = "RS";
                break;
            case "Sender at Send":
                ReviewTypeParam = "SS";
                break;
            case "Receiver at Pay":
                ReviewTypeParam = "RR";
                break;
            case "Sender at Pay":
                ReviewTypeParam = "SR";
                break;
            case "Ongoing":
                ReviewTypeParam = "Ongoing";
                break;
            case "Onboarding":
                ReviewTypeParam = "Onboarding";
                break;

        }

        if(BG.equals("GSI")) {
            query = "WITH GSI_CASES as \n" +
                    "(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'gsiCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"GSI\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'SI.CON.CC','CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"') \n" +
                    "SELECT (\n" +
                    "SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PE', 'SI.INV.TO', 'SI.RFW.AP', 'SI.RFW.CA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PE', 'EI.INV.TO', 'EI.RFW.AP', 'EI.RFWA.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PE', 'AI.INV.TO', 'AI.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.PE', 'IA.INV.TO', 'IA.RFW.AP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_RFW_IA_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_EI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_PI_AI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_SI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_EI_SLANB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLAB,\n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['AI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_AI_SLANB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLAB, \n" +
                    " (SELECT RAW Count(*) from GSI_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_GSI_IP_IA_SLANB;\n" +
                    "\n";
        }
        else if(BG.equals("BKYC")) {
            query = "WITH BKYC_CASES as (SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'bkycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"BKYC\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"') \n" +
                    "SELECT (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.CA', 'SI.INV.PE', 'SI.INV.TO'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.RFWE.ATP', 'EI.USR.PE', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_RFW_IA_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_PI_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_SI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.EP', 'EI.USR.FA'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_EI_SLANB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLAB, (SELECT RAW Count(*) from BKYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_BKYC_IP_IA_SLANB;";
        }
        else if(BG.equals("KYC")){
            query ="WITH KYC_CASES as(SELECT iwxcjbucket.workflow.status.id as statusId, iwxcjbucket.workflow.targetTimestamp as ts FROM iWatchXCustomerJourney as iwxcjbucket WHERE iwxcjbucket.docType = 'kycCase' AND iwxcjbucket.tenant.pId = \"WU\" AND iwxcjbucket.tenant.sId = \"CMT\" AND iwxcjbucket.classification.businessGroup = \"KYC\" AND iwxcjbucket.genreId = \"CJ\" AND iwxcjbucket.caseRefNo IS NOT NULL AND iwxcjbucket.caseRefNo <> '' AND iwxcjbucket.workflow.status.id NOT IN [ 'CA.CON.CC' ] AND iwxcjbucket.workflow.targetTimestamp <> ''\n" +
                    "AND hitSide.`value` = '"+ReviewTypeParam+"'\n" +
                    ")\n" +
                    "SELECT (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.ATP', 'SI.UI.PE', 'SI.UI.TO', 'SI.RFW.CA', 'SI.INV.TO', 'SI.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_SI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.RFW.ATP', 'SI.UI.PE', 'SI.UI.TO', 'SI.RFW.CA', 'SI.INV.TO', 'SI.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.USR.PE', 'EI.RFWE.ATP', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_EI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.RFWS.ATP', 'EI.USR.PE', 'EI.USR.TO', 'EI.RFWE.ATP', 'EI.UER.TO', 'EI.UER.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.TO', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_IA_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.RFW.CA', 'IA.INV.TO', 'IA.INV.PE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_RFW_IA_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.INV.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_PI_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.UER.PI'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_PI_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.UI.EP', 'SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_SI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['SI.UI.EP', 'SI.INV.EE'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_SI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.USR.FA', 'EI.UER.EP'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_EI_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['EI.USR.FA', 'EI.UER.EP'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_EI_SLANB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) < STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_IA_SLAB, (SELECT RAW Count(*) from KYC_CASES AS iwxbucket WHERE iwxbucket.statusId IN ['IA.INV.RW'] AND STR_TO_MILLIS(iwxbucket.ts) >= STR_TO_MILLIS(CLOCK_LOCAL()))[0] AS WU_CMT_CJ_KYC_IP_IA_SLANB;";
        }

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        dbResult = queryResult;
        Logger.info("Query Result : " + queryResult);
        if(tier.equals("Standard Investigation")) {
            int countValGsiSISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_SI_SLAB", dbResult);
            int countValGsiSISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_SI_SLANB", dbResult);
            addCaseData("SISlab", countValGsiSISlab);
            addCaseData("SISlanb", countValGsiSISlanb);
            Logger.info("\"SISlab\" = " + getCaseData("SISlab"));
            Logger.info("\"SISlanb\" = " + getCaseData("SISlanb"));
        }
        else if(tier.equals("Enhanced Investigation")) {
            int countValGsiEISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_EI_SLAB", dbResult);
            int countValGsiEISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_EI_SLANB", dbResult);
            addCaseData("EISlab", countValGsiEISlab);
            addCaseData("EISlanb", countValGsiEISlanb);
            Logger.info("\"EISlab\" = " + getCaseData("EISlab"));
            Logger.info("\"EISlanb\" = " + getCaseData("EISlanb"));
        }
        else if(tier.equals("Advanced Investigation")) {
            int countValGsiAISlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_AI_SLAB", dbResult);
            int countValGsiAISlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_AI_SLANB", dbResult);
            addCaseData("AISlab", countValGsiAISlab);
            addCaseData("AISlanb", countValGsiAISlanb);
            Logger.info("\"AISlab\" = " + getCaseData("AISlab"));
            Logger.info("\"AISlanb\" = " + getCaseData("AISlanb"));
        }
        else {
            int countValGsiIASlab = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_IA_SLAB", dbResult);
            int countValGsiIASlanb = (int) CommonFunctions.getIntValueFromJSON("WU_CMT_CJ_"+BG+"_IP_IA_SLANB", dbResult);
            addCaseData("IASlab", countValGsiIASlab);
            addCaseData("IASlanb", countValGsiIASlanb);
            Logger.info("\"IASlab\" = " + getCaseData("IASlab"));
            Logger.info("\"IASlanb\" = " + getCaseData("IASlanb"));
        }
    }

    @Given("User hits the refresh API")
    public void userHitsTheRefreshAPI() {
        userHasHeader("RefreshMetric");
        givenUserHasBlankInputJSON();
        headerMap.put("x-wu-bizgrp","GSI");
        whenUserCallsTheAPI("RefreshMetric", "PUT");
        thenUserVerifiedAPIResponseStatusCode("200");
        headerMap.put("x-wu-bizgrp","BKYC");
        whenUserCallsTheAPI("RefreshMetric", "PUT");
        thenUserVerifiedAPIResponseStatusCode("200");
        headerMap.put("x-wu-bizgrp","KYC");
        whenUserCallsTheAPI("RefreshMetric", "PUT");
        thenUserVerifiedAPIResponseStatusCode("200");
    }

    @Given("User hits the action failure refresh API")
    public void userHitsTheActionFailureRefreshAPI() {
        userHasHeader("AFRefreshMetric");
        givenUserHasBlankInputJSON();
        headerMap.put("x-wu-bizgrp","GSI");
        whenUserCallsTheAPI("AFRefreshMetric", "PUT");
        thenUserVerifiedAPIResponseStatusCode("200");
        headerMap.put("x-wu-bizgrp","BKYC");
        whenUserCallsTheAPI("AFRefreshMetric", "PUT");
        thenUserVerifiedAPIResponseStatusCode("200");
        headerMap.put("x-wu-bizgrp","KYC");
        whenUserCallsTheAPI("AFRefreshMetric", "PUT");
        thenUserVerifiedAPIResponseStatusCode("200");
    }
}





