package com.wu.stepdefinitions.Pharos.Interdictions;


//import com.couchbase.client.core.annotations.InterfaceAudience;
import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.UICommonPage;
import com.wu.utils.AutProperties;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UICommonSteps {

    UICommonPage uiCommonPage = new UICommonPage();


       @Given("Analyst launch the Pharos application on browser")
       public void analystLaunchesThePharosApplication()  throws InterruptedException{
           String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
           String url = CommonFunctions.readFile(fileName, "appURL");
          // BaseTestSetup.setupBrowser("Chrome", url);
           BaseTestSetup.setupBrowser(AutProperties.autProperties.getProperty("default.browser"), url);
           Thread.sleep(2000);
           Logger.info("Launch application \"%s\" on \"%s\" browser", url,AutProperties.autProperties.getProperty("default.browser"));
    }

    @And("Analyst enters userID and Clicks on Submit in okta")
    public void analystEntersUserId() {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserName = CommonFunctions.readFile(fileName, "oktaUserName");
        uiCommonPage.entersUIdAndSubmit(oktaUserName);

    }

    @Then("Analyst perform OKTA sign in")
    public void analystPerformOktaSignIn() throws InterruptedException {
        Thread.sleep(1000);
        uiCommonPage.entersUidAndPwdForOktaSignIn();
        Thread.sleep(1000);
        Logger.info("Analysts Successfully sign into OKTA");
    }

    @And("Analyst closes Pharos application on browser")
    public void userClosesTheIWatchXApplication() throws InterruptedException {
        BaseTestSetup.closeBrowser();
        Thread.sleep(2000);
        Logger.info("Analyst closes Pharos application on browser");
    }

    @And("Analyst enters userID with {string} role and Clicks on Submit in okta")
    public void analystEntersSIUserId(String role) {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String oktaUserName ;

        oktaUserName = CommonFunctions.readFile(fileName, "oktaUserName_"+role);
        uiCommonPage.entersUIdAndSubmit(oktaUserName);

    }

    @Then("Analyst perform OKTA sign in with {string} role")
    public void analystPerformOktaSignInRole(String role) throws InterruptedException {
        Thread.sleep(1000);
        uiCommonPage.entersUidAndPwdForOktaSignInRole(role);
        Thread.sleep(1000);
        Logger.info("Analysts Successfully sign into OKTA");
    }

    @And("Analyst prints {string} in the logs")
    public void analystPrintsInLogs(String msg){
        Logger.info("-------["+msg+"]------");
    }

    @Given("Analyst launches the oktasandbox on browser")
    public void analystLaunchesOpensearchURL()  throws InterruptedException{
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String url = CommonFunctions.readFile(fileName, "oktasandbox");
        // BaseTestSetup.setupBrowser("Chrome", url);
        BaseTestSetup.setupBrowser(AutProperties.autProperties.getProperty("default.browser"), url);
        Thread.sleep(2000);
        Logger.info("Launch oktasandbox \"%s\" on \"%s\" browser", url,AutProperties.autProperties.getProperty("default.browser"));
    }

    @Given("Analyst launch the DBView application on browser")
    public void analystLaunchesTheDBViewApplication()  throws InterruptedException{
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String url = CommonFunctions.readFile(fileName, "DBViewappURL");
        BaseTestSetup.setupBrowser(AutProperties.autProperties.getProperty("default.browser"), url);
        Thread.sleep(2000);
        Logger.info("Launch application \"%s\" on \"%s\" browser", url,AutProperties.autProperties.getProperty("default.browser"));
    }

    @And("Analyst closes DBView application on browser")
    public void userClosesTheDBVIewApplication() throws InterruptedException {
        BaseTestSetup.closeBrowser();
        Thread.sleep(2000);
        Logger.info("Analyst closes DBView application on browser");
    }

}
