package com.wu.stepdefinitions.iWatchX;

import com.wu.api.util.common.CommonFunctions;
import com.wu.api.util.common.CouchBaseUtility;
import com.wu.base.logger.Logger;
import com.wu.utils.AutProperties;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;

import java.io.IOException;

import static com.wu.api.util.common.CouchBaseUtility.executeCBQuery;

public class DBQueries {

//
//    @When("DBResult = query Profile Attachment for subjectId = {string}")
//    public void dbQueryForPAT(String subjectId) throws Exception {
//        if (subjectId.contains("$")) {
//            String value = subjectId.substring(subjectId.indexOf("$") + 1);
//            String valueToBeReplace = Serenity.getCurrentSession().get(value).toString();
//            subjectId = subjectId.replace("$" + value, valueToBeReplace);
//        }
//        String query = "SELECT *\n" +
//                "FROM ProfileAttachment\n" +
//                "WHERE docType='profileAttachment'\n" +
//                "    AND subject.id='" + subjectId + "' order by createdTimestamp desc";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//
//    }
//
//    @When("DBResult = query Profile Attachment for caseRefNo = {string}")
//    public void dbQueryForPATwithCaseRefNo(String caseRefNo) throws Exception {
//        if (caseRefNo.contains("$")) {
//            String value = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
//            String valueToBeReplace = Serenity.getCurrentSession().get(value).toString();
//            caseRefNo = caseRefNo.replace("$" + value, valueToBeReplace);
//        }
//        String query = "SELECT *\n" +
//                "FROM ProfileAttachment\n" +
//                "WHERE docType='profileAttachment'\n" +
//                "    AND caseRefNo='" + caseRefNo + "' order by createdTimestamp desc";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//
//    }
//
//    @When("DBResult = query for Compliance Visibility - Single Find with caseId = {string}")
//    public void dbQueryForCaseStatusComplianceVisibility(String caseId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            caseId = caseId.substring(caseId.indexOf("$") + 1);
//            caseId = Serenity.getCurrentSession().get(caseId).toString();
//        }
//        query = "SELECT META().id AS caseId,\n" +
//                "       gsiCase.workflow.status.tier,\n" +
//                "       gsiCase.workflow.status.stage,\n" +
//                "       gsiCase.workflow.status.subprocess,\n" +
//                "       gsiCase.workflow.status.id,\n" +
//                "       gsiCase.modifiedTimestamp,\n" +
//                "       gsiCase.caseRefNo AS caseRefNo,\n" +
//                "       gsiCase.classification.businessGroup,\n" +
//                "       gsiCase.disposition AS disposition,\n" +
//                "       gsiCase.subject.id AS subjectId,\n" +
//                "       gsiCase.createdTimestamp\n" +
//                "FROM `iWatchXCustomerJourney` AS gsiCase USE KEYS '" + caseId + "'";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Compliance Visibility - Multi Find with refId = {string}, type = {string}")
//    public void dbQueryForCaseListComplianceVisibility(String refId, String type) throws Exception {
//        String query;
//        if (refId.contains("$")) {
//            refId = refId.substring(refId.indexOf("$") + 1);
//            refId = Serenity.getCurrentSession().get(refId).toString();
//        }
//        query = "SELECT META(gsicase).id AS caseId,\n" +
//                "       gsicase.workflow.status.tier,\n" +
//                "       gsicase.workflow.status.stage,\n" +
//                "       gsicase.workflow.status.subprocess,\n" +
//                "       gsicase.workflow.status.id,\n" +
//                "       gsicase.modifiedTimestamp,\n" +
//                "       gsicase.caseRefNo AS caseRefNo,\n" +
//                "       gsicase.caseType AS caseType,\n" +
//                "       gsicase.classification.businessGroup,\n" +
//                "       gsicase.disposition AS disposition,\n" +
//                "       subject.subjectId,\n" +
//                "       subject.name.fullName,\n" +
//                "       gsicase.createdTimestamp\n" +
//                "FROM iWatchXCustomerJourney activity\n" +
//                "    JOIN iWatchXCustomerJourney gsicase ON gsicase.activityId = META(activity).id\n" +
//                "LET subject = (FIRST c FOR c IN activity.parties WHEN c.subjectId = gsicase.subject.id END)\n" +
//                "WHERE activity.docType = 'activity'\n" +
//                "    AND gsicase.docType = 'gsiCase'\n" +
//                "    AND activity.refId = '" + refId + "'\n" +
//                "    AND activity.type.`value`='" + type + "'";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//
//    @When("DBResult = query for Conversations with caseId = {string}")
//    public void dbQueryForConversationSearchWithCaseId(String caseId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            caseId = caseId.substring(caseId.indexOf("$") + 1);
//            caseId = Serenity.getCurrentSession().get(caseId).toString();
//        }
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.caseId='" + caseId + "'\n" +
//                "ORDER BY Conversations.createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Conversations with subjectId = {string}")
//    public void dbQueryForConversationSearchWithSubjectId(String subjectId) throws Exception {
//        String query;
//        if (subjectId.contains("$")) {
//            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
//            subjectId = Serenity.getCurrentSession().get(subjectId).toString();
//        }
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.subjectId=[\"" + subjectId + "\"]\n" +
//                "AND Conversations.caseId IS NOT MISSING\n" +
//                "ORDER BY Conversations.createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Conversations with refId = {string}")
//    public void dbQueryForConversationSearchWithRefId(String refId) throws Exception {
//        String query;
//        if (refId.contains("$")) {
//            refId = refId.substring(refId.indexOf("$") + 1);
//            refId = Serenity.getCurrentSession().get(refId).toString();
//        }
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.refId=[\"" + refId + "\"]\n" +
//                "AND Conversations.caseId is not missing\n" +
//                "ORDER BY Conversations.createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Conversations with caseId = {string} AND subjectId = {string}")
//    public void dbQueryForConversationSearchWithcaseIdORsubjectId(String caseId, String subjectId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            caseId = caseId.substring(caseId.indexOf("$") + 1);
//            caseId = Serenity.getCurrentSession().get(caseId).toString();
//        }
//        if (subjectId.contains("$")) {
//            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
//            subjectId = Serenity.getCurrentSession().get(subjectId).toString();
//        }
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.caseId = '" + caseId + "'\n" +
//                "    AND Conversations.subjectId=['" + subjectId + "']\n" +
//                "ORDER BY Conversations.createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Conversations with caseId = {string} AND refId = {string}")
//    public void dbQueryForConversationSearchWithcaseIdORrefId(String caseId, String refId) throws Exception {
//        String query;
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.caseId = '" + caseId + "'\n" +
//                "    OR Conversations.refId=['" + refId + "']\n" +
//                "ORDER BY Conversations.createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Conversations with subjectId = {string} OR refId = {string}")
//    public void dbQueryForConversationSearchWithsubjectIdORrefId(String subjectId, String refId) throws Exception {
//        String query;
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.subjectId[0] = '" + subjectId + "'\n" +
//                "    OR Conversations.refId[0]='" + refId + "'\n" +
//                "ORDER BY Conversations.createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Conversations with subjectId = {string} OR refId = {string} OR caseId = {string}")
//    public void dbQueryForConversationSearchWithsubjectIdORrefIdOrcaseId(String subjectId, String refId, String caseId) throws Exception {
//        String query;
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.subjectId[0] = '" + subjectId + "'\n" +
//                "    OR Conversations.refId[0]='" + refId + "'\n" +
//                "    OR Conversations.caseId='" + caseId + "'\n" +
//                "ORDER BY Conversations.createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for SaveConversations with caseId = {string}")
//    public void dbQueryForSaveConversationSearchWithcaseId(String caseId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            caseId = caseId.substring(caseId.indexOf("$") + 1);
//            caseId = Serenity.getCurrentSession().get(caseId).toString();
//        }
//        query = "SELECT META(Conversations).id,\n" +
//                "       Conversations.analyst AS analyst,\n" +
//                "       Conversations.caseId AS caseId,\n" +
//                "       Conversations.text AS text,\n" +
//                "       Conversations.subjectId AS subjectId,\n" +
//                "       Conversations.refId AS refId,\n" +
//                "       Conversations.visibility AS visibility,\n" +
//                "       Conversations.createdTimestamp AS createdTimestamp,\n" +
//                "       Conversations.genreId AS genreId,\n" +
//                "       Conversations.docType AS docType\n" +
//                "FROM Conversations AS Conversations\n" +
//                "WHERE Conversations.docType='conversation'\n" +
//                "    AND Conversations.caseId='" + caseId + "'\n" +
//                "ORDER BY Conversations.createdTimestamp DESC LIMIT 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//
//    @When("DBResult = query for Audit - Audit as createdTimestamp {string} with caseId = {string}")
//    public void dbQueryForAudit(String createdTimestamp , String caseId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            caseId = caseId.substring(caseId.indexOf("$") + 1);
//            caseId = Serenity.getCurrentSession().get(caseId).toString();
//        }
//        if (createdTimestamp.contains("$")) {
//            createdTimestamp = createdTimestamp.substring(createdTimestamp.indexOf("$") + 1);
//            createdTimestamp = Serenity.getCurrentSession().get(createdTimestamp).toString();
//        }
//        query = "SELECT audit \n" +
//                "FROM iWatchXCustomerJourney AS CJ\n" +
//                "UNNEST audits AS audit\n" +
//                "WHERE CJ.docType = 'audit'\n" +
//                "AND CJ.caseId ='" + caseId + "'\n" +
//                "And audit.createdTimestamp='" + createdTimestamp + "'\n" +
//                "LIMIT 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for getAudit - getAudit with caseId = {string}")
//    public void dbQueryForgetAudit(String caseId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            caseId = caseId.substring(caseId.indexOf("$") + 1);
//            caseId = Serenity.getCurrentSession().get(caseId).toString();
//        }
//        query = "SELECT result.audits\n" +
//                "FROM iWatchXCustomerJourney AS result\n" +
//                "WHERE caseId = '" + caseId + "'\n" +
//                "    AND docType = \"audit\"";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for casedesposition - case desposition with caseId = {string}")
//    public void dbQueryForgetDisposition(String caseId) throws Exception {
//        String query;
//        query = "SELECT gsicase.disposition AS disposition\n" +
//                "FROM `iWatchXCustomerJourney` AS gsicase\n" +
//                "WHERE META(gsicase).id = '" + caseId + "'";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for workmode")
//    public void dbQueryForgetworkmode(String caseId) throws Exception {
//        String query;
//        query = "SELECT META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType='gsiCase'\n" +
//                "    AND docRetrieve.tenant= {'pId': 'WU', 'sId': 'CMT'}\n" +
//                "    AND docRetrieve.classification.businessGroup= 'GSI'\n" +
//                "    AND docRetrieve.classification.invGroup='INTERDICTION'\n" +
//                "    AND docRetrieve.workflow.status.id IN ['SI.RFW.CA','SI.INV.PE']\n" +
//                "    AND docRetrieve.workflow.targetTimestamp > CLOCK_STR()\n" +
//                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
//                "         hitSide,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for Viewmode with caseId = {string}")
//    public void dbQueryForgetviewmode(String caseId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            caseId = caseId.substring(caseId.indexOf("$") + 1);
//            caseId = Serenity.getCurrentSession().get(caseId).toString();
//        }
//        query = "SELECT META(`case`).id AS caseId,\n" +
//                "       META(activity).id AS activityId,\n" +
//                "       META(hits).id AS hitsId,\n" +
//                "       *\n" +
//                "FROM iWatchXCustomerJourney `case` USE KEYS '"+caseId+"'\n" +
//                "    JOIN iWatchXCustomerJourney activity ON `case`.activityId = META(activity).id\n" +
//                "INNER JOIN iWatchXCustomerJourney hits ON hits.caseId = META(`case`).id\n" +
//                "    AND hits.docType='hits';";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for intrim with refId = {string}")
//    public void dbQueryForgetintrim(String refId) throws Exception {
//        String query;
//        query = "SELECT META(gsicase).id AS caseId\n" +
//                "FROM `iWatchXCustomerJourney` gsicase\n" +
//                "JOIN `iWatchXCustomerJourney` activity ON gsicase.activityId = META(activity).id\n" +
//                "WHERE activity.refId='" + refId + "'";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//
//    }
//
//    @When("DBResult = query for Workflow with caseId = {string}")
//    public void dbQueryForgetworkflow(String caseId) throws Exception {
//        String query;
//        if (caseId.contains("$")) {
//            String value = caseId.substring(caseId.indexOf("$") + 1);
//            String valueToBeReplace = Serenity.getCurrentSession().get(value).toString();
//            caseId = caseId.replace("$" + value, valueToBeReplace);
//        }
//        query = "SELECT workflow.status.id,\n" +
//                "       workflow.status.phase,\n" +
//                "       workflow.status.stage,\n" +
//                "       workflow.status.subprocess\n" +
//                "FROM iWatchXCustomerJourney\n" +
//                "WHERE docType = 'gsiCase'\n" +
//                "    AND META().id ='" + caseId + "' AND caseRefNo IS NOT MISSING";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//
//    public void dbQueryForCaseBasicDetails(String caseId) throws Exception {
//        String query;
//        query = "SELECT META(gsicase).id AS caseId,\n" +
//                "       activity.refId AS refId,\n" +
//                "       gsicase.subject.id AS subjectId,\n" +
//                "       gsicase.caseRefNo\n" +
//                "FROM `iWatchXCustomerJourney` AS gsicase USE KEYS \"" + caseId + "\"\n" +
//                "    JOIN `iWatchXCustomerJourney` AS activity ON gsicase.activityId = META(activity).id";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    public String dbQueryForGSISLAcaseIds() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\",\"SI.INV.PE\",\"SI.INV.TO\"]\n" +
//                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
//                "         docRetrieve.hitSide.`index`,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info(queryResult);
//        if (queryResult.equals("0 result")) {
//            return "0 result";
//        } else
//            return (String) CommonFunctions.getValueFromJSON("$", "DBResult");
//    }
//
//    public String dbQueryForGSIRFWcaseId() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\"]\n" +
//                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
//                "         docRetrieve.hitSide.`index`,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1\n";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info(queryResult);
////        return queryResult;
//        if (queryResult.equals("0 result")) {
//            return "0 result";
//        } else
//            return (String) CommonFunctions.getValueFromJSON("$", "DBResult");
//    }
//
//    public String dbQueryForGSIRFWcaseid() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\"]\n" +
//                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
//                "         docRetrieve.hitSide.`index`,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1\n";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        return queryResult;
//    }
//
//    public String dbQueryForGSIEEcaseId() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.INV.EE\"]\n" +
////                "   AND docRetrieve.targetTimestamp IS NOT NULL\n" +
////                "    AND docRetrieve.targetTimestamp <> ''\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY \n" +
////                "docRetrieve.workflow.targetTimestamp,\n" +
//                "         docRetrieve.hitSide.`index`,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info(queryResult);
//        return queryResult;
//    }
//
//    public String dbQueryForGSISLAcaseId() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\",\"SI.INV.PE\",\"SI.INV.TO\"]\n" +
//                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
//                "         docRetrieve.hitSide.`index`,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1\n";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("queryResult = " + queryResult);
//        return queryResult;
//    }
//
//    public String dbQueryForAnyStatusCaseId() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType =\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\" \n" +
//                "    AND docRetrieve.tenant.pId = \"WU\" \n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY createdTimestamp DESC\n" +
//                "LIMIT 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info(queryResult);
////        return queryResult;
//        if (queryResult.equals("0 result")) {
//            return "0 result";
//        } else
//            return (String) CommonFunctions.getValueFromJSON("$", "DBResult");
//    }
//
//    public String dbQueryForGSIConcludedcaseId() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.CON.CC\"]\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY createdTimestamp DESC \n" +
//                "LIMIT 1\n";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info(queryResult);
////        return queryResult;
//        if (queryResult.equals("0 result")) {
//            return "0 result";
//        } else
//            return (String) CommonFunctions.getValueFromJSON("$", "DBResult");
//    }
//
//
//    @When("DBResult = query caseRetriever for caseId")
//    public void dbQueryForcaseRetriever() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.RFW.CA\",\"SI.INV.PE\",\"SI.INV.TO\"]\n" +
//                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
//                "         docRetrieve.hitSide.`index`,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//    @When("DBResult = query case details for caseId = {string}")
//    public void dbQueryForCaseDetails(String caseId) throws Exception {
//        if (caseId.contains("$")) {
//            String value = caseId.substring(caseId.indexOf("$") + 1);
//            String valueToBeReplace = Serenity.getCurrentSession().get(value).toString();
//            caseId = caseId.replace("$" + value, valueToBeReplace);
//        }
//        String query;
//        query = "SELECT  META().id,*\n" +
//                "FROM `iWatchXCustomerJourney`\n" +
//                "WHERE docType=\"gsiCase\"\n" +
//                "    AND META().id=\"" + caseId + "\"\n" +
//                "    AND caseRefNo IS NOT MISSING";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//
//    public String dbQueryForGSIhitsDoc(String caseId) throws Exception {
//        String query;
//        query = "SELECT  META().id,*\n" +
//                "FROM `iWatchXCustomerJourney`\n" +
//                "WHERE docType=\"hits\"\n" +
//                "    AND caseId=\"" + caseId + "\"";
//
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        return queryResult;
//    }
//
//    @When("DBResult = query for case Attachment for caseid={string}")
//    public String dbQueryForCaseAttachment(String caseId) throws Exception {
//        if (caseId.contains("$")) {
//            String value = caseId.substring(caseId.indexOf("$") + 1);
//            String valueToBeReplace = Serenity.getCurrentSession().get(value).toString();
//            caseId = caseId.replace("$" + value, valueToBeReplace);
//        }
//        String query;
//        query = "SELECT meta().id,*\n" +
//                "FROM iWatchXCustomerJourney\n" +
//                "WHERE\n" +
//                "caseId = '" + caseId + "'\n" +
//                "AND docType='caseAttachment'";
//
//
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        System.out.println(queryResult);
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        return queryResult;
//    }
//
//    public String dbQueryForGSIPIcaseId() throws Exception {
//        String query;
//        query = "SELECT RAW META().id\n" +
//                "FROM iWatchXCustomerJourney docRetrieve\n" +
//                "WHERE docRetrieve.docType=\"gsiCase\"\n" +
//                "    AND docRetrieve.tenant.sId = \"CMT\"\n" +
//                "    AND docRetrieve.tenant.pId = \"WU\"\n" +
//                "    AND docRetrieve.classification.businessGroup = \"GSI\"\n" +
//                "    AND docRetrieve.classification.invGroup =\"INTR\"\n" +
//                "    AND docRetrieve.genreId =\"CJ\"\n" +
//                "    AND docRetrieve.workflow.status.id IN [\"SI.INV.PI\"]\n" +
//                "    AND docRetrieve.workflow.targetTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.workflow.targetTimestamp <> ''\n" +
//                "    AND docRetrieve.createdTimestamp IS NOT NULL\n" +
//                "    AND docRetrieve.createdTimestamp <> ''\n" +
//                "    AND docRetrieve.hitSide.`index` IS NOT NULL\n" +
//                "    AND docRetrieve.hitSide.`index` <> ''\n" +
//                "    AND docRetrieve.caseRefNo IS NOT NULL\n" +
//                "    AND docRetrieve.caseRefNo <> ''\n" +
//                "ORDER BY docRetrieve.workflow.targetTimestamp,\n" +
//                "         docRetrieve.hitSide.`index`,\n" +
//                "         createdTimestamp\n" +
//                "LIMIT 1\n";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("queryResult = " + queryResult);
//        return queryResult;
//    }
//    @When("DBResult = query for ProfileAttachment with subjectId = {string} And Currenttime= {string}")
//    public void dbQueryForProfileAttachmentWithSubjectIdandtime(String subjectId,String Currenttime) throws Exception {
//        String query;
//        if (subjectId.contains("$")) {
//            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
//            subjectId = Serenity.getCurrentSession().get(subjectId).toString();
//        }
//        if (Currenttime.contains("$")) {
//            Currenttime = subjectId.substring(Currenttime.indexOf("$") + 1);
//            Currenttime = Serenity.getCurrentSession().get(Currenttime).toString();
//        }
//        query = "SELECT *\n" +
//                "FROM ProfileAttachment\n" +
//                "WHERE docType='profileAttachment'\n" +
//                "    AND subject.id='" + subjectId + "'\n" +
//                "ocr.issueDate='" + Currenttime + "'";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//    @When("DBResult = query for Interim with refId ={string}")
//    public void dbQueryForInterim(String refId) throws Exception {
//        String query;
//        query = "SELECT META().id AS caseId,\n" +
//                "       createdTimestamp\n" +
//                "FROM `iWatchXCustomerJourney`\n" +
//                "WHERE docType=\"activity\"\n" +
//                "    AND refId IS NOT MISSING\n" +
//                "    AND refId='"+CommonFunctions.readFile(CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName()),refId)+"'\n" +
//                "    ORDER BY createdTimestamp DESC Limit 1";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for ProfileAttachment with subjectId = {string} AND customerId={string}")
//    public void dbQueryForProfileAttachmentWithSubjectId(String subjectId, String customerId) throws Exception {
//        String query;
//        if (subjectId.contains("$")) {
//            subjectId = subjectId.substring(subjectId.indexOf("$") + 1);
//            subjectId = Serenity.getCurrentSession().get(subjectId).toString();
//        }
//        query = "SELECT *\n" +
//                "FROM ProfileAttachment\n" +
//                "WHERE docType='profileAttachment'\n" +
//                "    AND subject.id='" + subjectId + "'\n" +
//                "And customerId='" + customerId + "'\n" +
//                "ORDER BY createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//
//    @When("DBResult = query for ProfileAttachment with refId ={string} AND customerId={string}")
//    public void dbQueryForProfileAttachmentWithrefId(String refId, String customerId) throws Exception {
//        String query;
//        if (refId.contains("$")) {
//            refId = refId.substring(refId.indexOf("$") + 1);
//            refId = Serenity.getCurrentSession().get(refId).toString();
//        }
//        query = "SELECT *\n" +
//                "FROM ProfileAttachment\n" +
//                "WHERE docType='profileAttachment'\n" +
//                "    AND caseRefNo='" + refId + "'\n" +
//                "    AND subject.id IS NOT MISSING\n" +
//                "ORDER BY createdTimestamp DESC";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
//    @When("DBResult = query for invalid profileAttachment for caseRefNo ={string}")
//    public void dbQueryForinvalidprofileAttachment(String caseRefNo) throws Exception {
//        if (caseRefNo.contains("$")) {
//            String value = caseRefNo.substring(caseRefNo.indexOf("$") + 1);
//            String valueToBeReplace = Serenity.getCurrentSession().get(value).toString();
//            caseRefNo = caseRefNo.replace("$" + value, valueToBeReplace);
//        }
//        String query;
//        query = "SELECT *,\n" +
//                "       META().id\n" +
//                "FROM ProfileAttachment\n" +
//                "WHERE docType='invalidPAT'\n" +
//                "    AND caseRefNo='"+caseRefNo+"'\n" +
//                "    AND createdTimestamp IS NOT MISSING";
//        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
//        Serenity.getCurrentSession().put("DBResult", queryResult);
//        Logger.info("Query Result : " + queryResult);
//    }
}