package com.wu.stepdefinitions.Pharos.Sanctions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseAttachmentPage;
import com.wu.pages.Pharos.Interdictions.CaseDispositionControlPage;
import com.wu.pages.Pharos.Interdictions.CaseInvestigationPage;
import cucumber.api.java.en.Then;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class SanctionScreenLayoutSteps {
    CaseInvestigationPage caseInvestigationPage = new CaseInvestigationPage();
    CaseDispositionControlPage caseDispositionControlPage = new CaseDispositionControlPage();

    @Then("Verify info and constraint expansion")
    public void verifyInfoConstraint() throws InterruptedException {
        caseInvestigationPage.verifyInfoConstraintExpansionbutton();
        caseInvestigationPage.verifyDefaultExpansion();
        caseInvestigationPage.clickOnInfoExpansion();
      caseInvestigationPage.clickOnConstraintsExpansion();
      caseInvestigationPage.verifyInfoConstarintsFromDisplayFilter();
    }
@Then("Verify default disposition herirachy for Not Disposition and {string}")
    public void verifyNotDispositionHeirarchy(String disposition) throws InterruptedException {
        caseInvestigationPage.clickOnAllEntities();
        caseDispositionControlPage.userSelectsReason();
        caseInvestigationPage.clickOnFirstEntity();
        if(disposition.equalsIgnoreCase("Pending Info")){
            caseDispositionControlPage.userDispositionPendingInfo();
        }else if(disposition.equalsIgnoreCase("False Match")){
            caseDispositionControlPage.userDispositionFalseMatch();
        }else if(disposition.equalsIgnoreCase("Possible Match")){
            caseDispositionControlPage.userDispositionPossibleMatch();
        }
    }
    @Then("Verify Match bucket disabled in Sanction flow")
    public void verifyMatchBucketSanctions(){
        caseInvestigationPage.VerifyMatchBtnSanctionCase();
    }
    @Then("Verify Match bucket enabled in INTR flow")
    public void verifyMatchBucketINTR(){
        caseInvestigationPage.VerifyMatchBtnINTRCase();
    }
}
