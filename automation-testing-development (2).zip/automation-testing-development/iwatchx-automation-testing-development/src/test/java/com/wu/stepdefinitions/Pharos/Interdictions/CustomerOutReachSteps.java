package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CustomerOutReachPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.json.simple.parser.ParseException;

import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

public class CustomerOutReachSteps {

    CustomerOutReachPage customerOutReachPage = new CustomerOutReachPage();

    @When("Verify and click on Customer Outreach icon")
    public void userClicksOnCOIcon() throws InterruptedException {
        Thread.sleep(2000);
        customerOutReachPage.clickCustomerOutreachIcon();
        Logger.info("Icon verified and Clicks on customer outreach icon");
    }

    @Then("Customer Outreach panel should be opened")
    public void customerPanelShouldBeOpened() throws InterruptedException {
        customerOutReachPage.verifyPanelShouldOpen();
        Logger.info("Verified that Customer outreach panel has been opened");
    }


    @Then("title of the CO panel should be {string}")
    public void verifyCOPanelTitle(String title) throws InterruptedException {
        customerOutReachPage.verifyCOPanelTitle(title);
        Logger.info("Verified the Panel title as "+title);
    }

    @Then("Verify Customer outreach panel field components")
    public void verifyComponents() throws InterruptedException {
        customerOutReachPage.getCaseRefValueField();
        customerOutReachPage.getUploadValueField();
        Logger.info("Verified the fields inside Panel");
    }
    @Then("Fetch and Verify Case Ref number and URL")
    public void verifyComponentsValues()throws InterruptedException {
        customerOutReachPage.validateCaseRefValue();
        customerOutReachPage.validateUploadLinkValue();
        Logger.info("Verified the fields inside Panel");

    }

    @Then("Verify Open DUT Url from clipboard")
    public void verifyClipboardComponentValue() throws IOException, UnsupportedFlavorException {
        customerOutReachPage.getClipboardItemFromOpenDUTURL();
        Logger.info("Verified the clipboard Content successfully");
    }
    @Then("Verify Case Ref number from clipboard")
    public void verifyClipboardCaseRefValue() throws InterruptedException, UnsupportedFlavorException, ParseException, Exception {
        customerOutReachPage.getClipboardItemFromCaseReference();
        Logger.info("Verified the clipboard Content successfully");
    }
    @Then("Analyst closes the Customer Outreach window")
    public void analystClosesCustomerOutreachTab() throws Exception {
        customerOutReachPage.closeCustomerOutreachBtn().click();
        Logger.info("Successfully closed Customer Outreach window");
    }
    @Then("Analyst Verify Case Ref number from DB {string}")
    public void analystVerifyCaseRef(String CaseRefNo) throws InterruptedException {
        if (CaseRefNo.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            CaseRefNo = CaseRefNo.substring(CaseRefNo.indexOf("$") + 1);
            CaseRefNo = (String) apiCommonSteps.getCaseData(CaseRefNo);
        }
        customerOutReachPage.ValidateCaseRefnofromDB(CaseRefNo);
        Logger.info("Verified the fields inside Panel");

    }
}
