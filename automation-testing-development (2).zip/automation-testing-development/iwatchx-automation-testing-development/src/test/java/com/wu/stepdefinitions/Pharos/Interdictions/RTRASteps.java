package com.wu.stepdefinitions.Pharos.Interdictions;
import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.DashboardPage;
import com.wu.pages.Pharos.Interdictions.RTRAPage;
import com.wu.utils.AutProperties;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RTRASteps {
    RTRAPage rtraPage=new RTRAPage();
    DashboardPage dashboardPage = new DashboardPage();

    @Given("Analyst launches RTRA application on browser")
    public void userLaunchesUnisysApplication() throws InterruptedException {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String url = CommonFunctions.readFile(fileName, "RTRAURL");
        String browserName = "Chrome";
        BaseTestSetup.setupBrowser("Chrome", url);
        Logger.info("Launch application \"%s\" on \"%s\" browser", url, browserName);
    }
    @Then("Analyst perform RTRA sign in with {string} environment")
    public void analystPerformRTRASignInenvironment(String environment) throws InterruptedException {
        Thread.sleep(1000);
        rtraPage.entersUidAndPwdForRTRASignInenvironment(environment);
        Thread.sleep(1000);
        Logger.info("Analysts Successfully sign into RTRA");
    }
    @When("Analyst Clicks on Transaction Viewer")
    public void analystClickOnTransactionViewer() throws InterruptedException {
        Thread.sleep(2000);
        rtraPage.clickOnTransactionViewer();
        Logger.info("Analyst Clicks on Transaction Viewer");
    }
    @When("Analyst Clicks on Entity Clearing")
    public void analystClickOnEntityClearing() throws InterruptedException {
        Thread.sleep(2000);
        rtraPage.MouseoverOnEntityClearing();
//        Thread.sleep(2000);
//        rtraPage.ClickOnEntityClearing();
        Thread.sleep(2000);
        rtraPage.ClickOnRevertEntityClearing();
        Logger.info("Analyst Clicks on Entity Clearing");
    }
    @And("Analyst enters GalacticID {string} in Search")
    public void analystEntersCaseId(String inputText) {
        if (inputText.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            inputText = inputText.substring(inputText.indexOf("$") + 1);
            inputText = (String) apiCommonSteps.getCaseData(inputText);
        }

        rtraPage.enterGalacticIDSearchTextBox(inputText);
        Logger.info("Analyst enters CaseId : " + inputText);
    }

    @When("Analyst Clicks on Entity Clearing Reasons")
    public void analystClickOnEntityClearingReasons() throws InterruptedException {
        Thread.sleep(2000);
        rtraPage.ClickOnEntityClearingReasons();
        Thread.sleep(2000);
        rtraPage.ClickOnRevertEntityClearingReasons();
        Logger.info("Analyst Clicks on Entity Clearing");
    }
    @When("Analyst Clicks on Entity Clearing Submit Button")
    public void analystClickOnEntityClearingSubmit() throws InterruptedException {
        Thread.sleep(2000);
        rtraPage.ClickOnEntityClearingsubmit();
        Thread.sleep(3000);
        rtraPage.ClickOnEntityClearingsubmitoption();
        Thread.sleep(3000);
    }
    @And("Analyst closes RTRA application on browser")
    public void userClosesTheRTRAApplication() throws InterruptedException {
        BaseTestSetup.closeBrowser();
        Thread.sleep(2000);
        Logger.info("Analyst closes Pharos application on browser");
    }
}

