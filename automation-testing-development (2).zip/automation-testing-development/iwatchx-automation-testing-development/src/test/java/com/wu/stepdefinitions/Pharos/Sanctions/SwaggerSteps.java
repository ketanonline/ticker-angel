package com.wu.stepdefinitions.Pharos.Sanctions;

import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.SwaggerPage;
import com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps;
import com.wu.utils.AutProperties;
import com.wu.utils.CommonUtils;
import cucumber.api.java.bs.A;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import com.wu.pages.Pharos.Interdictions.SwaggerPage.*;
import org.jsoup.Connection;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class SwaggerSteps {
    SwaggerPage swgPage = new SwaggerPage();
    APICommonSteps apiCommonSteps = new APICommonSteps();
    String updatedJson = apiCommonSteps.inputPayloadJSON;

    static Configuration config = Configuration.builder().jsonProvider(new JacksonJsonNodeJsonProvider())
            .mappingProvider(new JacksonMappingProvider()).build();

    @Given("User launches Swagger UI application for {string}")
    public void launchSwaggerApp(String api) throws InterruptedException {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String url = CommonFunctions.getSwaggerApiURL(api);
        System.out.println("***" + url);
        BaseTestSetup.setupBrowser("Chrome", url);
        Thread.sleep(2000);
        Logger.info("Launch application \"%s\" on \"%s\" browser", url, AutProperties.autProperties.getProperty("default.browser"));
    }

    @When("User clicks on {string} method")
    public void clickMethod(String methodName) throws InterruptedException {
        Thread.sleep(3000);
        if (methodName.contains("_")) {
            System.out.println("Entered _ block");
            swgPage.getMultipleMethodBtn(methodName).click();
        } else {
            swgPage.getMethodBtn(methodName).click();
        }
    }

    @And("User clicks on {string} button")
    public void clickButton(String btnName) {
        swgPage.clickButton(btnName).click();
    }

    @And("User enters the header parameters for {string} API with parameter {string}")
    public void enterHeaderParameters(String apiName, String caseid) throws InterruptedException {

        switch (apiName) {
            case "Audit_Get":
                String caseID = apiCommonSteps.getDynamicValueForVariable(caseid);
                swgPage.entersId().sendKeys(caseID);
                break;
            case "Attachment_DocRef":
                swgPage.entersDocRefNo().sendKeys(caseid);
                swgPage.enterPageNo().sendKeys("1");
                break;
            case "Attachment_profile":
                String caseID1 = apiCommonSteps.getDynamicValueForVariable(caseid);
                swgPage.enterCaseID().sendKeys(caseID1);
                break;
            default:
                Logger.info("API has default headers");
        }
        enterDefaultHeaders();
        Logger.info("Header for " + apiName + " entered");
    }


    @Then("User verifies the {string} success response")
    public void verifySuccessResponse(String expectedResponse) {
        String actualResponse = BaseTestSetup.webDriver.findElement(By.xpath("//tr[@class='response']/td[1]")).getText();
        Assert.assertEquals(actualResponse, expectedResponse, "User gets " + expectedResponse + " response");
    }

    @Then("User closes the Swagger UI")
    public void closeSwaggerUI() {
        BaseTestSetup.webDriver.quit();
    }

    @Then("User uploads the document {string}")
    public void uploadDocument(String fileName) throws InterruptedException {
        Thread.sleep(2000);
        BaseTestSetup.webDriver.findElement(By.xpath("//input[@type='file']")).sendKeys(new File(CommonUtils.getResourcePath("filestoupload") + File.separator + fileName).getAbsolutePath());
//        WebElement element = BaseTestSetup.webDriver.findElement(By.className("wu-files-input"));
//        element.sendKeys(new File(CommonUtils.getResourcePath("filestoupload") + File.separator + fileName).getAbsolutePath());
        Thread.sleep(2000);
//        Robot robot = new Robot();
//        robot.keyPress(KeyEvent.VK_ESCAPE);
//        robot.keyRelease(KeyEvent.VK_ESCAPE);
        Thread.sleep(1000);
    }

    @And("User enters profileID {string}")
    public void enterProfileIDValue(String subjectID) {
        String subID = apiCommonSteps.getDynamicValueForVariable(subjectID);
        swgPage.enterProfileID().sendKeys(subID);
    }

    public void enterDefaultHeaders() throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions actions = new Actions(webDriver);
        int uid = ThreadLocalRandom.current().nextInt();
        swgPage.entersTenantPrimaryID().sendKeys("WU");
        actions.moveToElement(swgPage.entersTenantPrimaryID()).click().build().perform();
        Thread.sleep(2000);
        swgPage.entersSecondaryID().sendKeys("CMT");
        actions.moveToElement(swgPage.entersSecondaryID()).click().build().perform();
        Thread.sleep(2000);
        swgPage.entersGenre().sendKeys("CJ");
        swgPage.entersBussGroup().sendKeys("GSI");
        swgPage.entersInvesGroup().sendKeys("INTR");
        swgPage.entersUserId().sendKeys("4521");
        swgPage.entersEmail().sendKeys("ravi@wu.com");
        swgPage.enterUserName().sendKeys("ravi kapoor");
        swgPage.entersCorrelationId().sendKeys(String.valueOf(uid));
    }

    @And("User enters the header parameters for {string} API with JSON {string}")
    public void userEntersHeadersParametersForApiJson(String Header, String Json) throws InterruptedException {
        String caseid = null;
        switch (Header) {
            case "Audit_Get":
                String caseID = apiCommonSteps.getDynamicValueForVariable(caseid);
                swgPage.entersId().sendKeys(caseID);
                break;
            case "Attachment_DocRef":
                swgPage.entersDocRefNo().sendKeys(caseid);
                swgPage.enterPageNo().sendKeys("1");
                break;
            case "Attachment_profile":
                String caseID1 = apiCommonSteps.getDynamicValueForVariable(caseid);
                swgPage.enterCaseID().sendKeys(caseID1);
                break;
            default:
                Logger.info("API has default headers");
        }
        HeadersAndJson(Json);
        Logger.info("Header for " + Header + " entered");
    }

    private void HeadersAndJson(String json) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions actions = new Actions(webDriver);
        int uid = ThreadLocalRandom.current().nextInt();
        switch (json) {
            case "interimService":
                swgPage.entersTenantPrimaryID().sendKeys("WU");
                actions.moveToElement(swgPage.entersTenantPrimaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersSecondaryID().sendKeys("CMT");
                actions.moveToElement(swgPage.entersSecondaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersBussGroup().sendKeys("GSI");
                swgPage.entersInvesGroup().sendKeys("INTR");
                swgPage.entersUserId().sendKeys("4521");
                swgPage.entersEmail().sendKeys("ravi@wu.com");
                swgPage.enterUserName().sendKeys("ravi kapoor");
                swgPage.entersCorrelationId().sendKeys(String.valueOf(uid));
                Thread.sleep(3000);
                actions.moveToElement(swgPage.enterJson()).click().build().perform();
                Thread.sleep(1000);
                actions.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
                actions.sendKeys(Keys.DELETE).build().perform();
                Thread.sleep(1000);
                String intrimjson = "{\n" +
                        "  \"activityType\": {\n" +
                        "    \"id\": \"1\",\n" +
                        "    \"value\": \"Remittance\"\n" +
                        "  },\n" +
                        "  \"subject\": {\n" +
                        "    \"id\": \"3000000000011505689\",\n" +
                        "    \"type\": \"consumer\"\n" +
                        "  },\n" +
                        "  \"actTimestamp\": \"2022-06-30-01:08\",\n" +
                        "  \"activityRefNo\": \"2218183502458556\",\n" +
                        "  \"attemptId\": \"3400000000010841040\",\n" +
                        "  \"tranSurKey\": \"5000000000720100545\",\n" +
                        "  \"transactionSide\": \"S\",\n" +
                        "  \"hitSide\": \"S\",\n" +
                        "   \"riskLevel\": 1,\n" +
                        "  \"qualifiers\": [\n" +
                        "\n" +
                        "            \"SS\"\n" +
                        "\n" +
                        "        ]\n" +
                        " \n" +
                        "}";
                actions.moveToElement(swgPage.enterJson()).sendKeys(intrimjson).sendKeys(Keys.ENTER).build().perform();
                break;
            case "OrchCRNProfile":
                swgPage.entersTenantPrimaryID().sendKeys("WU");
                actions.moveToElement(swgPage.entersTenantPrimaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersSecondaryID().sendKeys("CMT");
                actions.moveToElement(swgPage.entersSecondaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersUserId().sendKeys("4521");
                swgPage.entersEmail().sendKeys("ravi@wu.com");
                swgPage.enterUserName().sendKeys("ravi kapoor");
                swgPage.entersCorrelationId().sendKeys(String.valueOf(uid));
                Thread.sleep(3000);
                actions.moveToElement(swgPage.enterJson()).click().build().perform();
                Thread.sleep(1000);
                actions.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
                actions.sendKeys(Keys.DELETE).build().perform();
                Thread.sleep(1000);
                String Pam = "{\n" +
                        "  \"caseRefNo\": \"CC21BU0622DT\",\n" +
                        "  \"customerId\": \"CC21BU0622DT\",\n" +
                        "  \"docRefNum\": \"OTXXXXCC407276748AE1\",\n" +
                        "  \"name\": \"CC21BW0623QW\",\n" +
                        "  \"size\": \"173KB\",\n" +
                        "  \"mime\": \"image/jpeg\",\n" +
                        "  \"type\": \"id\",\n" +
                        "  \"subType\": \"Personal Identity\",\n" +
                        "  \"validation\": {\n" +
                        "    \"status\": \"pass\",\n" +
                        "    \"refId\": \"12345\",\n" +
                        "    \"reason\": {\n" +
                        "      \"code\" : \"000\",\n" +
                        "      \"desc\" :\"000\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"verification\": {\n" +
                        "    \"status\": \"pass\",\n" +
                        "    \"refId\": \"12345\",\n" +
                        "    \"reason\": {\n" +
                        "      \"code\" : \"000\",\n" +
                        "      \"desc\" :\"000\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"source\": \"opendut\",\n" +
                        "  \"ocr\": {\n" +
                        "    \"id\": \"CC21BJ0218GY\",\n" +
                        "    \"issuingCountry\": \"DE\",\n" +
                        "    \"expDate\": \"01.07.2014\",\n" +
                        "    \"issueDate\": \"01.07.2009\",\n" +
                        "    \"dob\": \"12.08.1964\",\n" +
                        "    \"pob\": \"BERLIN\",\n" +
                        "    \"nameOnId\": \"CC21AW0318GA\",\n" +
                        "    \"issuingAuthority\": \"DE\"\n" +
                        "  }\n" +
                        "}";
                actions.moveToElement(swgPage.enterJson()).sendKeys(Pam).sendKeys(Keys.ENTER).build().perform();
            case "WorkFlowMetricsPost":
                swgPage.entersTenantPrimaryID().sendKeys("WU");
                actions.moveToElement(swgPage.entersTenantPrimaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersSecondaryID().sendKeys("CMT");
                actions.moveToElement(swgPage.entersSecondaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersUserId().sendKeys("4521");
                swgPage.entersEmail().sendKeys("ravi@wu.com");
                swgPage.enterUserName().sendKeys("ravi kapoor");
                swgPage.entersCorrelationId().sendKeys(String.valueOf(uid));
                Thread.sleep(3000);
                actions.moveToElement(swgPage.enterJson()).click().build().perform();
                Thread.sleep(1000);
                actions.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
                actions.sendKeys(Keys.DELETE).build().perform();
                Thread.sleep(1000);
                String WorkFlowMetricsPost = "{\n" +
                        "  \"caseMetricsUpdateActions\": [\n" +
                        "    {\n" +
                        "      \"tier\": \"string\",\n" +
                        "      \"panel\": \"string\",\n" +
                        "      \"group\": \"string\",\n" +
                        "      \"operation\": \"INCR\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}";
                actions.moveToElement(swgPage.enterJson()).sendKeys(WorkFlowMetricsPost).sendKeys(Keys.ENTER).build().perform();
            case "CJcaseController":
                swgPage.entersTenantPrimaryID().sendKeys("WU");
                actions.moveToElement(swgPage.entersTenantPrimaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersSecondaryID().sendKeys("CMT");
                actions.moveToElement(swgPage.entersSecondaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersUserId().sendKeys("4521");
                swgPage.entersEmail().sendKeys("ravi@wu.com");
                swgPage.enterUserName().sendKeys("ravi kapoor");
                swgPage.entersCorrelationId().sendKeys(String.valueOf(uid));
                Thread.sleep(3000);
                actions.moveToElement(swgPage.enterJson()).click().build().perform();
                Thread.sleep(1000);
                actions.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
                actions.sendKeys(Keys.DELETE).build().perform();
                Thread.sleep(1000);
                String CJcaseController = "{\n" +
                        "  \"caseMetricsUpdateActions\": [\n" +
                        "    {\n" +
                        "      \"tier\": \"string\",\n" +
                        "      \"panel\": \"string\",\n" +
                        "      \"group\": \"string\",\n" +
                        "      \"operation\": \"INCR\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}";
                actions.moveToElement(swgPage.enterJson()).sendKeys(CJcaseController).sendKeys(Keys.ENTER).build().perform();
            case "CjccSwagger":
                swgPage.entersTenantPrimaryID().sendKeys("WU");
                actions.moveToElement(swgPage.entersTenantPrimaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersSecondaryID().sendKeys("CMT");
                actions.moveToElement(swgPage.entersSecondaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersUserId().sendKeys("4521");
                swgPage.entersEmail().sendKeys("ravi@wu.com");
                swgPage.enterUserName().sendKeys("ravi kapoor");
                swgPage.entersCorrelationId().sendKeys(String.valueOf(uid));
                Thread.sleep(3000);
                actions.moveToElement(swgPage.enterJson()).click().build().perform();
                Thread.sleep(1000);
                actions.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
                actions.sendKeys(Keys.DELETE).build().perform();
                Thread.sleep(1000);
                String CjccSwagger = "{\n" +
                        "  \"activity\" : {\n" +
                        "    \"parties\" : [ {\n" +
                        "      \"address\" : {\n" +
                        "        \"country\" : \"USA\",\n" +
                        "        \"zipCode\" : \"55001\",\n" +
                        "        \"city\" : \"CITY\",\n" +
                        "        \"state\" : \"MN\",\n" +
                        "        \"line3\" : null,\n" +
                        "        \"line2\" : null,\n" +
                        "        \"line1\" : \"ADDRESS\"\n" +
                        "      },\n" +
                        "      \"gender\" : \"\",\n" +
                        "      \"dateOfBirth\" : \"10/10/1993\",\n" +
                        "      \"bioIds\" : [ {\n" +
                        "        \"issuingState\" : null,\n" +
                        "        \"number\" : \"ASD12\",\n" +
                        "        \"expiryDate\" : null,\n" +
                        "        \"type\" : {\n" +
                        "          \"code\" : \"UNK\",\n" +
                        "          \"desc\" : \"UNK\"\n" +
                        "        },\n" +
                        "        \"issuer\" : \"\",\n" +
                        "        \"issuingCountry\" : \"UNITED STATES\",\n" +
                        "        \"issueDate\" : null,\n" +
                        "        \"primary\" : true\n" +
                        "      } ],\n" +
                        "      \"type\" : \"Sender\",\n" +
                        "      \"countryOfBirth\" : \"AFGHANISTAN\",\n" +
                        "      \"cityOfBirth\" : \"\",\n" +
                        "      \"subjectId\" : \"3000000000011231082\",\n" +
                        "      \"nationality\" : \"\",\n" +
                        "      \"contact\" : {\n" +
                        "        \"phones\" : [ {\n" +
                        "          \"type\" : null,\n" +
                        "          \"value\" : \"2013456789\"\n" +
                        "        }, {\n" +
                        "          \"type\" : null,\n" +
                        "          \"value\" : \"2013456789\"\n" +
                        "        } ],\n" +
                        "        \"email\" : \"\"\n" +
                        "      },\n" +
                        "      \"name\" : {\n" +
                        "        \"middle\" : null,\n" +
                        "        \"last\" : \"SAM\",\n" +
                        "        \"first\" : \"NAMAN\",\n" +
                        "        \"fullName\" : \"NAMAN SAM\",\n" +
                        "        \"aliases\" : null\n" +
                        "      },\n" +
                        "      \"category\" : \"Individual\"\n" +
                        "    }, {\n" +
                        "      \"address\" : {\n" +
                        "        \"country\" : \"USA\",\n" +
                        "        \"zipCode\" : \"\",\n" +
                        "        \"city\" : \"ALABAMA\",\n" +
                        "        \"state\" : \"AL\",\n" +
                        "        \"line3\" : null,\n" +
                        "        \"line2\" : null,\n" +
                        "        \"line1\" : \"\"\n" +
                        "      },\n" +
                        "      \"gender\" : null,\n" +
                        "      \"dateOfBirth\" : null,\n" +
                        "      \"bioIds\" : null,\n" +
                        "      \"type\" : \"Receiver\",\n" +
                        "      \"countryOfBirth\" : null,\n" +
                        "      \"cityOfBirth\" : null,\n" +
                        "      \"subjectId\" : null,\n" +
                        "      \"nationality\" : \"\",\n" +
                        "      \"contact\" : {\n" +
                        "        \"phones\" : null,\n" +
                        "        \"email\" : \"\"\n" +
                        "      },\n" +
                        "      \"name\" : {\n" +
                        "        \"middle\" : null,\n" +
                        "        \"last\" : \"SSV\",\n" +
                        "        \"first\" : \"SDFSD\",\n" +
                        "        \"fullName\" : \"SDFSD SSV\",\n" +
                        "        \"aliases\" : null\n" +
                        "      },\n" +
                        "      \"category\" : \"Individual\"\n" +
                        "    } ],\n" +
                        "    \"attributes\" : [ {\n" +
                        "      \"name\" : \"Product\",\n" +
                        "      \"value\" : \"QC\",\n" +
                        "      \"desc\" : \"Quick Cash\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Send Brand\",\n" +
                        "      \"value\" : \"WU\",\n" +
                        "      \"desc\" : \"Send Brand\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Funds In\",\n" +
                        "      \"value\" : \"EB\",\n" +
                        "      \"desc\" : \"Offline Bank Transfer\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Recording Channel\",\n" +
                        "      \"value\" : \"RP\",\n" +
                        "      \"desc\" : \"Retail Partner\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Intended Pay Channel\",\n" +
                        "      \"value\" : \"AG\",\n" +
                        "      \"desc\" : \"Agent\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Intended Funds Out\",\n" +
                        "      \"value\" : \"CA\",\n" +
                        "      \"desc\" : \"Cash\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Sending Agent Account Number\",\n" +
                        "      \"value\" : null,\n" +
                        "      \"desc\" : \"Sending Agent Account Number\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Paying Agent Account Number\",\n" +
                        "      \"value\" : null,\n" +
                        "      \"desc\" : \"Paying Agent Account Number\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Pay Brand\",\n" +
                        "      \"value\" : \"\",\n" +
                        "      \"desc\" : \"Pay Brand\"\n" +
                        "    } ],\n" +
                        "    \"actTimestamp\" : \"2021-07-20T03:32:00Z\",\n" +
                        "    \"refId\" : \"2120187081886098\",\n" +
                        "    \"type\" : {\n" +
                        "      \"id\" : 1,\n" +
                        "      \"value\" : \"Remitance KDF1\"\n" +
                        "    },\n" +
                        "    \"info\" : {\n" +
                        "      \"amount\" : {\n" +
                        "        \"currency\" : \"USD\",\n" +
                        "        \"value\" : null\n" +
                        "      },\n" +
                        "      \"destination\" : {\n" +
                        "        \"country\" : {\n" +
                        "          \"name\" : \"United States of America\",\n" +
                        "          \"code\" : \"USA\"\n" +
                        "        },\n" +
                        "        \"state\" : {\n" +
                        "          \"name\" : null,\n" +
                        "          \"code\" : \"CA\"\n" +
                        "        }\n" +
                        "      },\n" +
                        "      \"source\" : {\n" +
                        "        \"country\" : {\n" +
                        "          \"name\" : \"United States of America\",\n" +
                        "          \"code\" : \"USA\"\n" +
                        "        },\n" +
                        "        \"state\" : {\n" +
                        "          \"name\" : null,\n" +
                        "          \"code\" : \"NJ\"\n" +
                        "        }\n" +
                        "      }\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"hitsInfo\" : {\n" +
                        "    \"entities\" : [ {\n" +
                        "      \"addresses\" : [ \"3343 WOODVIEW LAKE ROAD ALIASES: NAMAN, SAALIM WEST BLOOMFIELD, MI 48323, UNITED STATES\" ],\n" +
                        "      \"aliases\" : null,\n" +
                        "      \"city\" : \"WEST BLOOMFIELD\",\n" +
                        "      \"listSource\" : {\n" +
                        "        \"code\" : \"11\",\n" +
                        "        \"desc\" : \"US TREASURY DEPT\"\n" +
                        "      },\n" +
                        "      \"phones\" : null,\n" +
                        "      \"constraints\" : [ {\n" +
                        "        \"type\" : \"markers\",\n" +
                        "        \"value\" : \"\"\n" +
                        "      } ],\n" +
                        "      \"hitDetails\" : [ {\n" +
                        "        \"score\" : 100.0,\n" +
                        "        \"subjectAttribute\" : null,\n" +
                        "        \"entityAttribute\" : \"name\",\n" +
                        "        \"algo\" : \"GNR\"\n" +
                        "      } ],\n" +
                        "      \"dob\" : null,\n" +
                        "      \"name\" : \"NAMAN, SAM\",\n" +
                        "      \"listType\" : \"OFAC\",\n" +
                        "      \"entityIds\" : null,\n" +
                        "      \"id\" : \"2000004245\",\n" +
                        "      \"category\" : {\n" +
                        "        \"name\" : \"   \",\n" +
                        "        \"id\" : 0\n" +
                        "      },\n" +
                        "      \"hitType\" : \"SENDER\",\n" +
                        "      \"info\" : \"NAMAN, SAM 3343 WOODVIEW LAKE ROAD ALIASES: NAMAN, SAALIM WEST BLOOMFIELD, MI 48323, UNITED STATES AFF: IRAQ2 OriginalSource: OFAC Aliases: NAMAN, SAALIM OriginalID: 8390 ALIASQUALITY: STRONG P_ID: 616                                       \"\n" +
                        "    }, {\n" +
                        "      \"addresses\" : [ \"5903 HARPER ROAD ALIASES: NAMAN, SAALIM SOLON, OH, UNITED STATES\" ],\n" +
                        "      \"aliases\" : null,\n" +
                        "      \"city\" : \"SOLON\",\n" +
                        "      \"listSource\" : {\n" +
                        "        \"code\" : \"11\",\n" +
                        "        \"desc\" : \"US TREASURY DEPT\"\n" +
                        "      },\n" +
                        "      \"phones\" : null,\n" +
                        "      \"constraints\" : [ {\n" +
                        "        \"type\" : \"markers\",\n" +
                        "        \"value\" : \"\"\n" +
                        "      } ],\n" +
                        "      \"hitDetails\" : [ {\n" +
                        "        \"score\" : 100.0,\n" +
                        "        \"subjectAttribute\" : null,\n" +
                        "        \"entityAttribute\" : \"name\",\n" +
                        "        \"algo\" : \"GNR\"\n" +
                        "      } ],\n" +
                        "      \"dob\" : null,\n" +
                        "      \"name\" : \"NAMAN, SAM\",\n" +
                        "      \"listType\" : \"OFAC\",\n" +
                        "      \"entityIds\" : null,\n" +
                        "      \"id\" : \"2000004246\",\n" +
                        "      \"category\" : {\n" +
                        "        \"name\" : \"   \",\n" +
                        "        \"id\" : 0\n" +
                        "      },\n" +
                        "      \"hitType\" : \"SENDER\",\n" +
                        "      \"info\" : \"NAMAN, SAM 5903 HARPER ROAD ALIASES: NAMAN, SAALIM SOLON, OH, UNITED STATES AFF: IRAQ2 OriginalSource: OFAC Aliases: NAMAN, SAALIM OriginalID: 8390 ALIASQUALITY: STRONG P_ID: 616                                                              \"\n" +
                        "    } ]\n" +
                        "  },\n" +
                        "  \"case\" : {\n" +
                        "    \"subject\" : {\n" +
                        "      \"id\" : \"3000000000011231082\",\n" +
                        "      \"type\" : \"consumer\"\n" +
                        "    },\n" +
                        "    \"hitSide\" : {\n" +
                        "      \"value\" : \"SS\",\n" +
                        "      \"index\" : 200\n" +
                        "    }\n" +
                        "  }\n" +
                        "}";
                actions.moveToElement(swgPage.enterJson()).sendKeys(CjccSwagger).sendKeys(Keys.ENTER).build().perform();
            case "casecreator_controller":
                swgPage.entersTenantPrimaryID().sendKeys("WU");
                actions.moveToElement(swgPage.entersTenantPrimaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersSecondaryID().sendKeys("CMT");
                actions.moveToElement(swgPage.entersSecondaryID()).click().build().perform();
                Thread.sleep(2000);
                swgPage.entersUserId().sendKeys("4521");
                swgPage.entersEmail().sendKeys("ravi@wu.com");
                swgPage.enterUserName().sendKeys("ravi kapoor");
                swgPage.entersCorrelationId().sendKeys(String.valueOf(uid));
                Thread.sleep(3000);
                actions.moveToElement(swgPage.enterJson()).click().build().perform();
                Thread.sleep(1000);
                actions.keyDown(Keys.CONTROL).sendKeys("A").keyUp(Keys.CONTROL).perform();
                actions.sendKeys(Keys.DELETE).build().perform();
                Thread.sleep(1000);
                String casecreatorcontroller = "{\n" +
                        "  \"activity\" : {\n" +
                        "    \"parties\" : [ {\n" +
                        "      \"address\" : {\n" +
                        "        \"country\" : \"USA\",\n" +
                        "        \"zipCode\" : \"55001\",\n" +
                        "        \"city\" : \"CITY\",\n" +
                        "        \"state\" : \"MN\",\n" +
                        "        \"line3\" : null,\n" +
                        "        \"line2\" : null,\n" +
                        "        \"line1\" : \"ADDRESS\"\n" +
                        "      },\n" +
                        "      \"gender\" : \"\",\n" +
                        "      \"dateOfBirth\" : \"10/10/1993\",\n" +
                        "      \"bioIds\" : [ {\n" +
                        "        \"issuingState\" : null,\n" +
                        "        \"number\" : \"ASD12\",\n" +
                        "        \"expiryDate\" : null,\n" +
                        "        \"type\" : {\n" +
                        "          \"code\" : \"UNK\",\n" +
                        "          \"desc\" : \"UNK\"\n" +
                        "        },\n" +
                        "        \"issuer\" : \"\",\n" +
                        "        \"issuingCountry\" : \"UNITED STATES\",\n" +
                        "        \"issueDate\" : null,\n" +
                        "        \"primary\" : true\n" +
                        "      } ],\n" +
                        "      \"type\" : \"Sender\",\n" +
                        "      \"countryOfBirth\" : \"AFGHANISTAN\",\n" +
                        "      \"cityOfBirth\" : \"\",\n" +
                        "      \"subjectId\" : \"3000000000011231082\",\n" +
                        "      \"nationality\" : \"\",\n" +
                        "      \"contact\" : {\n" +
                        "        \"phones\" : [ {\n" +
                        "          \"type\" : null,\n" +
                        "          \"value\" : \"2013456789\"\n" +
                        "        }, {\n" +
                        "          \"type\" : null,\n" +
                        "          \"value\" : \"2013456789\"\n" +
                        "        } ],\n" +
                        "        \"email\" : \"\"\n" +
                        "      },\n" +
                        "      \"name\" : {\n" +
                        "        \"middle\" : null,\n" +
                        "        \"last\" : \"SAM\",\n" +
                        "        \"first\" : \"NAMAN\",\n" +
                        "        \"fullName\" : \"NAMAN SAM\",\n" +
                        "        \"aliases\" : null\n" +
                        "      },\n" +
                        "      \"category\" : \"Individual\"\n" +
                        "    }, {\n" +
                        "      \"address\" : {\n" +
                        "        \"country\" : \"USA\",\n" +
                        "        \"zipCode\" : \"\",\n" +
                        "        \"city\" : \"ALABAMA\",\n" +
                        "        \"state\" : \"AL\",\n" +
                        "        \"line3\" : null,\n" +
                        "        \"line2\" : null,\n" +
                        "        \"line1\" : \"\"\n" +
                        "      },\n" +
                        "      \"gender\" : null,\n" +
                        "      \"dateOfBirth\" : null,\n" +
                        "      \"bioIds\" : null,\n" +
                        "      \"type\" : \"Receiver\",\n" +
                        "      \"countryOfBirth\" : null,\n" +
                        "      \"cityOfBirth\" : null,\n" +
                        "      \"subjectId\" : null,\n" +
                        "      \"nationality\" : \"\",\n" +
                        "      \"contact\" : {\n" +
                        "        \"phones\" : null,\n" +
                        "        \"email\" : \"\"\n" +
                        "      },\n" +
                        "      \"name\" : {\n" +
                        "        \"middle\" : null,\n" +
                        "        \"last\" : \"SSV\",\n" +
                        "        \"first\" : \"SDFSD\",\n" +
                        "        \"fullName\" : \"SDFSD SSV\",\n" +
                        "        \"aliases\" : null\n" +
                        "      },\n" +
                        "      \"category\" : \"Individual\"\n" +
                        "    } ],\n" +
                        "    \"attributes\" : [ {\n" +
                        "      \"name\" : \"Product\",\n" +
                        "      \"value\" : \"QC\",\n" +
                        "      \"desc\" : \"Quick Cash\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Send Brand\",\n" +
                        "      \"value\" : \"WU\",\n" +
                        "      \"desc\" : \"Send Brand\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Funds In\",\n" +
                        "      \"value\" : \"EB\",\n" +
                        "      \"desc\" : \"Offline Bank Transfer\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Recording Channel\",\n" +
                        "      \"value\" : \"RP\",\n" +
                        "      \"desc\" : \"Retail Partner\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Intended Pay Channel\",\n" +
                        "      \"value\" : \"AG\",\n" +
                        "      \"desc\" : \"Agent\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Intended Funds Out\",\n" +
                        "      \"value\" : \"CA\",\n" +
                        "      \"desc\" : \"Cash\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Sending Agent Account Number\",\n" +
                        "      \"value\" : null,\n" +
                        "      \"desc\" : \"Sending Agent Account Number\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Paying Agent Account Number\",\n" +
                        "      \"value\" : null,\n" +
                        "      \"desc\" : \"Paying Agent Account Number\"\n" +
                        "    }, {\n" +
                        "      \"name\" : \"Pay Brand\",\n" +
                        "      \"value\" : \"\",\n" +
                        "      \"desc\" : \"Pay Brand\"\n" +
                        "    } ],\n" +
                        "    \"actTimestamp\" : \"2021-07-20T03:32:00Z\",\n" +
                        "    \"refId\" : \"2120187081886098\",\n" +
                        "    \"type\" : {\n" +
                        "      \"id\" : 1,\n" +
                        "      \"value\" : \"Remitance KDF1\"\n" +
                        "    },\n" +
                        "    \"info\" : {\n" +
                        "      \"amount\" : {\n" +
                        "        \"currency\" : \"USD\",\n" +
                        "        \"value\" : null\n" +
                        "      },\n" +
                        "      \"destination\" : {\n" +
                        "        \"country\" : {\n" +
                        "          \"name\" : \"United States of America\",\n" +
                        "          \"code\" : \"USA\"\n" +
                        "        },\n" +
                        "        \"state\" : {\n" +
                        "          \"name\" : null,\n" +
                        "          \"code\" : \"CA\"\n" +
                        "        }\n" +
                        "      },\n" +
                        "      \"source\" : {\n" +
                        "        \"country\" : {\n" +
                        "          \"name\" : \"United States of America\",\n" +
                        "          \"code\" : \"USA\"\n" +
                        "        },\n" +
                        "        \"state\" : {\n" +
                        "          \"name\" : null,\n" +
                        "          \"code\" : \"NJ\"\n" +
                        "        }\n" +
                        "      }\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"hitsInfo\" : {\n" +
                        "    \"entities\" : [ {\n" +
                        "      \"addresses\" : [ \"3343 WOODVIEW LAKE ROAD ALIASES: NAMAN, SAALIM WEST BLOOMFIELD, MI 48323, UNITED STATES\" ],\n" +
                        "      \"aliases\" : null,\n" +
                        "      \"city\" : \"WEST BLOOMFIELD\",\n" +
                        "      \"listSource\" : {\n" +
                        "        \"code\" : \"11\",\n" +
                        "        \"desc\" : \"US TREASURY DEPT\"\n" +
                        "      },\n" +
                        "      \"phones\" : null,\n" +
                        "      \"constraints\" : [ {\n" +
                        "        \"type\" : \"markers\",\n" +
                        "        \"value\" : \"\"\n" +
                        "      } ],\n" +
                        "      \"hitDetails\" : [ {\n" +
                        "        \"score\" : 100.0,\n" +
                        "        \"subjectAttribute\" : null,\n" +
                        "        \"entityAttribute\" : \"name\",\n" +
                        "        \"algo\" : \"GNR\"\n" +
                        "      } ],\n" +
                        "      \"dob\" : null,\n" +
                        "      \"name\" : \"NAMAN, SAM\",\n" +
                        "      \"listType\" : \"OFAC\",\n" +
                        "      \"entityIds\" : null,\n" +
                        "      \"id\" : \"2000004245\",\n" +
                        "      \"category\" : {\n" +
                        "        \"name\" : \"   \",\n" +
                        "        \"id\" : 0\n" +
                        "      },\n" +
                        "      \"hitType\" : \"SENDER\",\n" +
                        "      \"info\" : \"NAMAN, SAM 3343 WOODVIEW LAKE ROAD ALIASES: NAMAN, SAALIM WEST BLOOMFIELD, MI 48323, UNITED STATES AFF: IRAQ2 OriginalSource: OFAC Aliases: NAMAN, SAALIM OriginalID: 8390 ALIASQUALITY: STRONG P_ID: 616                                       \"\n" +
                        "    }, {\n" +
                        "      \"addresses\" : [ \"5903 HARPER ROAD ALIASES: NAMAN, SAALIM SOLON, OH, UNITED STATES\" ],\n" +
                        "      \"aliases\" : null,\n" +
                        "      \"city\" : \"SOLON\",\n" +
                        "      \"listSource\" : {\n" +
                        "        \"code\" : \"11\",\n" +
                        "        \"desc\" : \"US TREASURY DEPT\"\n" +
                        "      },\n" +
                        "      \"phones\" : null,\n" +
                        "      \"constraints\" : [ {\n" +
                        "        \"type\" : \"markers\",\n" +
                        "        \"value\" : \"\"\n" +
                        "      } ],\n" +
                        "      \"hitDetails\" : [ {\n" +
                        "        \"score\" : 100.0,\n" +
                        "        \"subjectAttribute\" : null,\n" +
                        "        \"entityAttribute\" : \"name\",\n" +
                        "        \"algo\" : \"GNR\"\n" +
                        "      } ],\n" +
                        "      \"dob\" : null,\n" +
                        "      \"name\" : \"NAMAN, SAM\",\n" +
                        "      \"listType\" : \"OFAC\",\n" +
                        "      \"entityIds\" : null,\n" +
                        "      \"id\" : \"2000004246\",\n" +
                        "      \"category\" : {\n" +
                        "        \"name\" : \"   \",\n" +
                        "        \"id\" : 0\n" +
                        "      },\n" +
                        "      \"hitType\" : \"SENDER\",\n" +
                        "      \"info\" : \"NAMAN, SAM 5903 HARPER ROAD ALIASES: NAMAN, SAALIM SOLON, OH, UNITED STATES AFF: IRAQ2 OriginalSource: OFAC Aliases: NAMAN, SAALIM OriginalID: 8390 ALIASQUALITY: STRONG P_ID: 616                                                              \"\n" +
                        "    } ]\n" +
                        "  },\n" +
                        "  \"case\" : {\n" +
                        "    \"subject\" : {\n" +
                        "      \"id\" : \"3000000000011231082\",\n" +
                        "      \"type\" : \"consumer\"\n" +
                        "    },\n" +
                        "    \"hitSide\" : {\n" +
                        "      \"value\" : \"SS\",\n" +
                        "      \"index\" : 200\n" +
                        "    }\n" +
                        "  }\n" +
                        "}";
                actions.moveToElement(swgPage.enterJson()).sendKeys(casecreatorcontroller).sendKeys(Keys.ENTER).build().perform();
        }
    }
}
