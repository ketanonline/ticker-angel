package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseDispositionControlPage;
import com.wu.pages.Pharos.Interdictions.DashboardPage;
import com.wu.pages.Pharos.Interdictions.EntityDispositionPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.Arrays;
import java.util.List;

import static com.wu.report.AllureReportManager.addScreenshotToAllureReport;
import static org.hamcrest.MatcherAssert.assertThat;

public class CaseDispositionControlsSteps {

    CaseDispositionControlPage caseDispositionControlPage = new CaseDispositionControlPage();
    EntityDispositionPage entityDispositionPage = new EntityDispositionPage();


    @When("Analyst disposes entity under Pending Info")
    public void analystDisposesEntityToPI() throws InterruptedException {

        caseDispositionControlPage.getBucketWithEntities();
        entityDispositionPage.clickOnAllEntities();
        caseDispositionControlPage.userSelectsReason();
        caseDispositionControlPage.userDispositionPendingInfo();
        Logger.info("Analyst disposes entity under Pending Info");

    }

    @When("Analyst disposes entity under Match")
    public void analystDisposesEntityToMatch() throws InterruptedException {
        caseDispositionControlPage.getBucketWithEntities();
        entityDispositionPage.clickOnAllEntities();
        caseDispositionControlPage.userSelectsReason();
        caseDispositionControlPage.userDispositionMatch();
        Logger.info("Analyst disposes entity under Match");

    }

    @When("Analyst disposes entity under False Match")
    public void analystDisposesEntityToFalseMatch() throws InterruptedException {

        caseDispositionControlPage.getBucketWithEntities();
        entityDispositionPage.clickOnAllEntities();
        caseDispositionControlPage.userSelectsReason();
        caseDispositionControlPage.userDispositionFalseMatch();
        Logger.info("Analyst disposes entity under Match");

    }

    @When("Analyst disposes entity under Possible Match")
    public void analystDisposesEntityToPossibleMatch() throws InterruptedException {

        caseDispositionControlPage.getBucketWithEntities();
        entityDispositionPage.clickOnAllEntities();
        caseDispositionControlPage.userSelectsReason();
        caseDispositionControlPage.userDispositionPossibleMatch();
        Logger.info("Analyst disposes entity under Possible Match");

    }

    @When("Analyst Verifies the disposition dropdown with overidden values for Match")
    public void analystVerifiesDispositionValues() throws InterruptedException {
        caseDispositionControlPage.clickDispositionDropDown();
        caseDispositionControlPage.verifiesInterimDispositionforMatch();
        Logger.info("Analyst Verifies the disposition dropdown with overidden values for Match");
    }

    @When("Analyst Verifies the disposition dropdown with overidden values for False Match")
    public void analystVerifiesFalseMatchDispositionValues() throws InterruptedException {
        caseDispositionControlPage.clickDispositionDropDown();
        caseDispositionControlPage.verifiesInterimDispositionforFMatch();
        Logger.info("Analyst Verifies the disposition dropdown with overidden values for False Match");
    }

    @When("Analyst Verifies the disposition dropdown with overidden values for Possible Match")
    public void analystVerifiesPossMatchDispositionValues() throws InterruptedException {
        caseDispositionControlPage.clickDispositionDropDown();
        caseDispositionControlPage.verifiesInterimDispositionforPMatch();
        Logger.info("Analyst Verifies the disposition dropdown with overidden values for Possible Match");
    }

    @When("Analyst Verifies the disposition dropdown with overidden values for Pending Info")
    public void analystVerifiesPIDispositionValues() throws InterruptedException {
        caseDispositionControlPage.clickDispositionDropDown();
        caseDispositionControlPage.verifiesInterimDispositionforPI();
        Logger.info("Analyst Verifies the disposition dropdown with overidden values for Pending Info");
    }

    @When("Analyst prefer interim disposition")
    public void analystDoneInterimDisposition() throws InterruptedException {
        caseDispositionControlPage.selectPendingInfoDispositionDropDown();
        Logger.info("Analyst prefer interim disposition");
    }

    @When("Analyst clicks on submit for final disposition")
    public void analystDoneFinalDisposition() throws InterruptedException {
        caseDispositionControlPage.getFinalCaseSubmitBtn().click();
        Logger.info("Analyst clicks on submit for final disposition");
    }

    @Then("Analyst verifies the {string} dropdown values")
    public void verifyReasonDropdownValues(String drpdwnName) throws Exception {
        try {
            Thread.sleep(2000);
            WebElement dropdown = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='" + drpdwnName.toLowerCase() + "']"));
            List<WebElement> options;

            dropdown.isDisplayed();
            Thread.sleep(2000);
            dropdown.click();
            Thread.sleep(2000);
            if (drpdwnName.equalsIgnoreCase("Reason")) {
                options = BaseTestSetup.webDriver.findElements(By.xpath("//div[@id='mat-select-8-panel']/mat-option"));
            } else if (drpdwnName.equalsIgnoreCase("Action")) {
                options = BaseTestSetup.webDriver.findElements(By.xpath("//div[@id='dispositionAction-panel']/mat-option"));
            } else {
                options = BaseTestSetup.webDriver.findElements(By.xpath("//div[@id='mat-select-4-panel']/mat-option"));
            }
            for (int i = 0; i < options.size(); i++) {
                String Item = options.get(i).getText().trim();
                Logger.info("The " + drpdwnName + "dropdown has value as : " + Item);
            }
        } catch (Exception e) {
            Logger.error("Failed to verify " + drpdwnName + " dropdown values ");
        }
    }

    @When("Analyst clicks on Submit Tab")
    public void analystClickOnSubmitTab() {
        entityDispositionPage.clickOnSubmitTab();
        Logger.info("Analyst clicks on Submit Tab");
    }

    @When("Analyst selects value {string} in Disposition")
    public void analystSelectsDisposition(String disposition) throws Exception {
        entityDispositionPage.selectDisposition(disposition);
        Logger.info("Analyst selects value " + disposition + " in Disposition");

    }

    @Then("Analyst verifies the {string} dropdown default value as {string}")
    public void verifyDefaultValue(String dropdownName, String defaultValue) throws Exception {
        try {
            Thread.sleep(3000);
            WebElement dropdown = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='" + dropdownName.toLowerCase() + "']"));
            String actualDefaultValue = dropdown.getText();

            if (actualDefaultValue.equalsIgnoreCase(defaultValue)) {
                Logger.info("Default value of " + dropdownName + " dropdown has been verified and the value is - " + defaultValue);
            } else {
                Logger.error("Default value of " + dropdownName + " dropdown has been verified and the value is not - " + defaultValue);
            }
            Assert.assertEquals(actualDefaultValue,defaultValue,"Default value of " + dropdownName + " dropdown has been verified and the value is - " + defaultValue);
        } catch (Exception e) {
            Logger.error("Failed to verify the default value of " + dropdownName + " dropdown ");
        }
    }

    @When("Analyst selects value {string} in Reason")
    public void analystSelectsReason(String reason) throws Exception {
        entityDispositionPage.selectReason(reason);
        Logger.info("Analyst selects value " + reason + " in Reason");
    }

    @Then("Analyst verifies Case Disposition panel is disabled")
    public void verifyCaseDispositionPanelDisabled() {
        try {
            Boolean disposition = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='disposition']")).isEnabled();
            Boolean action = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='action']")).isEnabled();
            Boolean reason = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='reason']")).isEnabled();
            Boolean submitBtn = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-form-field-div']/div/button")).isEnabled();

            if (!(disposition && action && reason && submitBtn)) {
                Logger.info("Case Disposition panel is disabled as the Entity/Entities have not been disposed to any Bucket");
            } else {
                Logger.error("Case Disposition panel is enabled before the Entity/Entities have been disposed to any Bucket");
            }
        } catch (Exception e) {
            Logger.error("Failed to verify the Case disposition panel");
        }
    }


    public void analystSeesActionWorkFlowRes(String actionWfResult) throws Exception {
        caseDispositionControlPage.validateCTMAck_WithoutCheck(actionWfResult);
        addScreenshotToAllureReport("Action WorkFlow");
    }


    public void analystSelectsAction(String action) throws Exception {
        caseDispositionControlPage.selectAction(action);
        Logger.info("Analyst selects value " + action + " in Action");
    }

    @When("Analyst select Pend dropdown and value as {string}")
    public void userSelectsGenre(String option) throws InterruptedException {
        caseDispositionControlPage.clickPendToggleBtn();
        caseDispositionControlPage.selectPendDropdown(option);
    }

    @When("Analyst select Pend Duration  dropdown and value as {string}")
    public void userSelectsPendType(String option) throws InterruptedException {
        caseDispositionControlPage.selectPendDurationDropdown(option);
    }

    @When("Analyst clicks on Pend button")
    public void userClicksPend() throws InterruptedException {
        caseDispositionControlPage.clickPendBtn();
    }

    @Then("Analyst verifies fab icon after pend action")
    public void verifyFabIcon() throws Exception {
        caseDispositionControlPage.verifyfabicon();
        Logger.info("Verified Fab icon successfully");
    }

    @Then("Analyst verifies Submit action after a pend action")
    public void verifySubmitAfterPend() throws Exception {
        caseDispositionControlPage.verifySubmitDisabledAfterPend();
        Logger.info("Verified Submit action after a pend action successfully");
    }

    @Then("Analyst verifies the due date after pend action")
    public void verifyDueDate() throws Exception {
        caseDispositionControlPage.verifyDueDate();
        Logger.info("Verified due date successfully");
    }

    @Then("Analyst enters pended case for case retrival validation")
    public void analystEnterPendedCase() throws Exception {
        DashboardPage dashboardPage = new DashboardPage();
        dashboardPage.entersCaseId(Serenity.getCurrentSession().get("caseId").toString());
        Thread.sleep(2000);
        dashboardPage.clickOnSearchButton();
        Thread.sleep(2000);
        //dashboardPage.verifySearchGridCaseID(Serenity.getCurrentSession().get("caseId").toString());
        Logger.info("Succesfully validated the case retrieval");
        Assert.assertTrue(dashboardPage.getWorkButton().isDisplayed());//validating work mode for pended case SUPERNOVA-13803
        dashboardPage.clickViewBtn();
    }

    @When("Analyst Validated CTM Ack for action Workflow CBQ {string}")
    public void analystValidatedCTMAck_CBQ(String ackWF) {
        caseDispositionControlPage.validateCTMAck_CBQ(ackWF);
        Logger.info("Analyst Validated CTM Ack for action Workflow");
    }

    @When("Analyst performs pend on the case")
    public void analystPerformsPend() throws Exception {
      caseDispositionControlPage.clickOnPendTab();
        caseDispositionControlPage.selectReason("Too Late To Call (TLTC)");
        caseDispositionControlPage.selectDuration("1");
        Thread.sleep(2000);
        caseDispositionControlPage.clickOnPendButton();
        Logger.info("Analyst performs pend on the case");
    }

    @When("Analyst clicks on Pend Tab")
    public void analystClicksOnPendTab() throws InterruptedException {
        Thread.sleep(2000);
        caseDispositionControlPage.MouseOverOnPendTad();
        caseDispositionControlPage.ClicksOnPentab();
        Thread.sleep(2000);

    }
    @Then("Analyst verifies Pend case workflow timeline")
    public void analystVerifiesPendCaseWorkFlowInCaseHeader() throws Exception {
        caseDispositionControlPage.verifiesPendCaseWorkFlow();
    }
    @When("Analyst Validated CTM Ack for entity clearing warning action Workflow {string}")
    public void analystValidatedCTMAck_WarnEntityClearing(String ackWF) throws Exception {
        caseDispositionControlPage.validateCTMAck_WarningEntityClearing(ackWF);
        Logger.info("Analyst Validated CTM Ack for action Workflow");
        addScreenshotToAllureReport("CTM Action Interface");
    }

    @When("Analyst Validated CTM Ack for entity clearing action Workflow {string}")
    public void analystValidatedCTMAck_EntityClearing(String ackWF) throws Exception {
        caseDispositionControlPage.validateCTMAck_GreenEntityClearing(ackWF);
        Logger.info("Analyst Validated CTM Ack for action Workflow");
        addScreenshotToAllureReport("CTM Action Interface");
    }

    @When("Reason should have {string} option selected")
    public void validateCaseReason(String reason) {
        caseDispositionControlPage.validateReason(reason);
        Logger.info("Reason is Validated");
    }

    @Then("Analyst verifies workflow timeline for CNA")
    public void analystVerifiesWorkFlowInCaseHeader_CNA() throws Exception {
        caseDispositionControlPage.verifiesWorkFlow_CNA();
    }
    @Then("Analyst verifies Get case workflow timeline")
    public void analystVerifiesGetCaseWorkFlowInCaseHeader()throws Exception {
        caseDispositionControlPage.verifiesGetCaseWorkFlow();
    }
    @When("Analyst Clicks to scrollDown Audit page {string}")
    public void analystClickToAcessScrollAudit(String actual) throws InterruptedException {
        caseDispositionControlPage.verifiesClickToAcessScrollAudit(actual);
    }
    @Then("Analyst verifies the Action dropdown values for {string}")
    public void verifyActionDropdownValues(String disposition) throws Exception {
        WebElement dropdown = BaseTestSetup.webDriver.findElement(By.xpath("//mat-select[@formcontrolname='action']"));
        List<String> bucket = null;
        if (disposition.equals("Approved")) {
            bucket = Arrays.asList("Release Funds", "Return Funds", "Cancel Funds", "Return Funds (Owned)", "Return Funds (Online)");
        } else if (disposition.equals("Declined")) {
            bucket = Arrays.asList("Return Funds", "Cancel Funds", "Return Funds (Owned)", "Seize Funds (Owned)", "Return Funds (Online)", "Seize Funds (Online)");
        } else if (disposition.equals("Not Set")) {
            bucket = Arrays.asList("Return Funds", "Cancel Funds", "Return Funds (Owned)", "Return Funds (Online)");
        } else {
            bucket = Arrays.asList("Hold Funds");
        }
        System.out.println(bucket);
        System.out.println(bucket.size());
        dropdown.isDisplayed();
        Thread.sleep(2000);
        dropdown.click();

        for (int i = 1; i <= bucket.size(); i++) {
            Thread.sleep(1000);
            System.out.println("i=" + i);
            WebElement option = BaseTestSetup.webDriver.findElement(By.xpath("//div[@id='dispositionAction-panel']/mat-option[" + i + "]/span"));
            System.out.println("Option" + option.getText());
            System.out.println("Bucket" + bucket.get(i - 1));
            assertThat("Action Dropdown value verified ", option.getText().equalsIgnoreCase(bucket.get(i - 1)));
        }
    }
    @When("Analyst verifies the StandardInvestigator Reason dropdown values for {string}")
    public void verifyStandardInvestigationReasonDropdownValues(String Reason)throws InterruptedException {
        if (Reason.equals("Collecting Customer Info (CCI)")) {
            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.findElement(By.xpath("//div/mat-option[1]/span[contains(text(),'" + Reason + "')]")).click();
            Thread.sleep(2000);
            Logger.info("Analyst verifies the StandardInvestigator Reason dropdown values for " + Reason + "");
        } else {
            if (Reason.equals("Collecting Agent Info (CAI)")) {
                WebDriver webDriver = BaseTestSetup.webDriver;
                webDriver.findElement(By.xpath("//div/mat-option[2]/span[contains(text(),'" + Reason + "')]")).click();
                Thread.sleep(2000);
                Logger.info("Analyst verifies the StandardInvestigator Reason dropdown values for " + Reason + "");
            } else {
                if (Reason.equals("Customer Allowed (OKC)")) {
                    WebDriver webDriver = BaseTestSetup.webDriver;
                    webDriver.findElement(By.xpath("//div/mat-option[1]/span[contains(text(),'" + Reason + "')]")).click();
                    Thread.sleep(2000);
                    Logger.info("Analyst verifies the StandardInvestigator Reason dropdown values for " + Reason + "");
                } else {
                    if (Reason.equals("Money Not Collected (MNC)")) {
                        WebDriver webDriver = BaseTestSetup.webDriver;
                        webDriver.findElement(By.xpath("//div/mat-option[2]/span[contains(text(),'" + Reason + "')]")).click();
                        Thread.sleep(2000);
                        Logger.info("Analyst verifies the StandardInvestigator Reason dropdown values for " + Reason + "");
                    } else {
                        if (Reason.equals("Customer Changed Mind (CCM)")) {
                            WebDriver webDriver = BaseTestSetup.webDriver;
                            webDriver.findElement(By.xpath("//div/mat-option[1]/span[contains(text(),'" + Reason + "')]")).click();
                            Thread.sleep(2000);
                            Logger.info("Analyst verifies the StandardInvestigator Reason dropdown values for " + Reason + "");
                        }
                    }
                }
            }
        }
    }
}
