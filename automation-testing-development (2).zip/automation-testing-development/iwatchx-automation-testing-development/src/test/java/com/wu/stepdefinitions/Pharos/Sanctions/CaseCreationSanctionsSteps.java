package com.wu.stepdefinitions.Pharos.Sanctions;

import com.wu.api.util.common.CouchBaseUtility;
import com.wu.api.util.common.CreateCase;
import com.wu.base.logger.Logger;
import com.wu.stepdefinitions.Pharos.Interdictions.*;
import cucumber.api.java.en.Given;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import static org.hamcrest.MatcherAssert.assertThat;

public class CaseCreationSanctionsSteps {

    CreateCaseSteps caseSteps = new CreateCaseSteps();
    public String getSanctionsCaseIdforGivenMTCN(String mtcn16) throws InterruptedException, Exception {
        String query;
        Map<String, List<String>> data = null;
        query = "SELECT parties[0].caseIds[0] AS caseId\n" +
                "FROM iWatchXCustomerJourney\n" +
                "WHERE docType = 'activity'\n" +
                "    AND refId = \"" + mtcn16 + "\"\n" +
                "ORDER BY createdTimestamp\n" +
                "LIMIT 1";

        int caseCreateWait = 20;
        int timeTaken = 0;
        Thread.sleep(10000);
        while (caseCreateWait > 0) {
            data = CouchBaseUtility.executeCouchBaseQuery(query);
            if (data.size() == 0) {
                Thread.sleep(2000);
                timeTaken += 2;
                caseCreateWait--;
                if (caseCreateWait == 0) {
                    Logger.info("Case is not created in couchbase, waited " + timeTaken + "sec!");
                    return "";
                }
                Logger.info("Waiting for case to be created in CouchBase, Time taken: " + timeTaken + " sec");
                data.clear();
            } else {
                return data.get("caseId").toString().replace("[", "").replace("]", "");
            }

        }
        return data.get("caseId").toString().replace("[", "").replace("]", "");
    }

    @Given("Analyst creates {string} case for Sanctions WU Digital Sender side and caseId saved in {string}")
    public void givenUserCreatesCaseForWUDigitalSenderSide(String caseLevel,String caseId) throws Exception {
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
        }

        CreateCase caseCreation = new CreateCase();
        int noOfDigitalSingleEntities = 18;
        int count = 0;
        String mtcn10 = "";
        String mtcn16 = "";

        do {
            if(caseLevel.equalsIgnoreCase("L1")) {
            mtcn16 = caseCreation.createDigitalMTCNUsingGWforSenderCase("L1_Digital_WU_Sanctions_SingleEntity", 1, noOfDigitalSingleEntities);
        }else{
            mtcn16 = caseCreation.createDigitalMTCNUsingGWforSenderCase("L2_Digital_WU_Sanctions_SingleEntity", 1, noOfDigitalSingleEntities);
        }
            count++;
        } while (mtcn16 == "" && count < noOfDigitalSingleEntities+1);
        caseSteps.isCaseIdGenerated(mtcn16,caseId);
    }

    @Given("Analyst creates {string} case for Sanctions WU Retail Sender side and caseId saved in {string}")
    public void givenUserCreatesCaseForWURetailSanctionsSenderSide(String caseLevel, String caseId) throws Exception {
        CreateCase caseCreation = new CreateCase();
        int noOfRetailSingleEntities = 18;
        int count = 0;
        String mtcn10 = "";
        String mtcn16 = "";

        do {
            if(caseLevel.equalsIgnoreCase("L1")) {
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("L1_WU_Sanctions_SingleEntity", 1, noOfRetailSingleEntities);
            }else if (caseLevel.equalsIgnoreCase("L2")){
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("L2_WU_Sanctions_SingleEntity", 1, noOfRetailSingleEntities);
            }else if(caseLevel.equalsIgnoreCase("L3")){
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("L3_WU_Sanctions_SingleEntity", 1, noOfRetailSingleEntities);
            }else if((caseLevel.equalsIgnoreCase("PR_SANC_SANC"))){
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("Deferred_WU_Intr_Intr", 1, noOfRetailSingleEntities);
            }
            count++;
        } while (mtcn16 == "" && count < noOfRetailSingleEntities+1);
        caseSteps.isCaseIdGenerated(mtcn16,caseId);
    }

    @Given("Analyst creates WU Sanctions Sender case {string}")
    public void givenUserCreatesWUgsiCaseSenderSide(String caseId) throws ClassNotFoundException, SQLException, InterruptedException, Exception {
        CreateCase caseCreation = new CreateCase();
        int noOfRetailSingleEntities = 18;
        int noOfDigitalSingleEntities = 18;
        int count = 0;
        String mtcn10 = "";
        String mtcn16 = "";

        /* Will try to first create an Retail MTCN with random entity and when that fails
        will try retail with each entity in order
        If entire retail fails we will go for Digital
        Will try to first create a digital MTCN with random entity and when that fails
        will try digital with each entity in order*/

        do {
            mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("WU_GSI_SingleEntity",count, noOfRetailSingleEntities);
            count++;
        } while (mtcn16 == "" && count < noOfRetailSingleEntities+1);
        if(mtcn16 == ""){
            do {
                mtcn16 = caseCreation.createDigitalMTCNUsingGWforSenderCase("Digital_GSI_SingleEntity", count, noOfDigitalSingleEntities);
                count++;
            } while (mtcn16 == "" && count < noOfRetailSingleEntities+1);
        }
        caseSteps.isCaseIdGenerated(mtcn16,caseId);

    }
    @Given("Analyst creates {string} case for Dual Hit Retail Sender side and caseId saved in {string}")
    public void givenUserCreatesCaseForWURetailDualHitSenderSide(String caseLevel, String caseId) throws Exception {
        CreateCase caseCreation = new CreateCase();
        int noOfRetailSingleEntities = 1;
        int count = 0;
        String mtcn10 = "";
        String mtcn16 = "";

        do {
            if(caseLevel.equalsIgnoreCase("L1")) {
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("DualHitCases", 1, noOfRetailSingleEntities);
            }else if (caseLevel.equalsIgnoreCase("L2")){
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("L2_DualHitCases", 1, noOfRetailSingleEntities);
            }else{
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide("L3_DualHitCases", 1, noOfRetailSingleEntities);
            }
            count++;
        } while (mtcn16 == "" && count < noOfRetailSingleEntities+1);
        caseSteps.isCaseIdGenerated(mtcn16,caseId);
    }
    @Given("Analyst creates {string} case for Dual Hit Digital Sender side and caseId saved in {string}")
    public void givenUserCreatesCaseForDualHitDigitalSenderSide(String caseLevel,String caseId) throws Exception {
        if (caseId.contains("$")) {
            caseId = caseId.substring(caseId.indexOf("$") + 1);
        }

        CreateCase caseCreation = new CreateCase();
        int noOfDigitalSingleEntities = 1;
        int count = 0;
        String mtcn10 = "";
        String mtcn16 = "";

        do {
            if(caseLevel.equalsIgnoreCase("L1")) {
                mtcn16 = caseCreation.createDigitalMTCNUsingGWforSenderCase("L1_DualHit_Digital_SingleEntity", 1, noOfDigitalSingleEntities);
            }else if(caseLevel.equalsIgnoreCase("L2")){
                mtcn16 = caseCreation.createDigitalMTCNUsingGWforSenderCase("L2_DualHit_Digital_SingleEntity", 1, noOfDigitalSingleEntities);
            }else{
                mtcn16 = caseCreation.createDigitalMTCNUsingGWforSenderCase("L3_DualHit_Digital_SingleEntity", 1, noOfDigitalSingleEntities);
            }
            count++;
        } while (mtcn16 == "" && count < noOfDigitalSingleEntities+1);
        caseSteps.isCaseIdGenerated(mtcn16,caseId);
    }
}



