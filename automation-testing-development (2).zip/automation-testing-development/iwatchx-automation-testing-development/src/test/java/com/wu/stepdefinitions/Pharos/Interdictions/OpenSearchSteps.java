package com.wu.stepdefinitions.Pharos.Interdictions;


//import com.couchbase.client.core.annotations.InterfaceAudience;
import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.OpenSearchPage;
import com.wu.pages.Pharos.Interdictions.UICommonPage;
import com.wu.utils.AutProperties;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;

public class OpenSearchSteps {

    OpenSearchPage openSearchPage = new OpenSearchPage();
    APICommonSteps apiCommonSteps = new APICommonSteps();

    @And("Analyst clicks on opensearch tile")
    public void analystClicksOnOpensearchTile(){
        openSearchPage.getOpensearchTile().click();
    }

    @And("Analyst switches to opensearch tab in the browser")
    public void analystSwitchesToOpensearchTab(){
        openSearchPage.switchToSecondTab();
    }

    @And("Analyst selects compliance option")
    public void analystSelectsComplianceOption() throws InterruptedException {
        openSearchPage.getCustomDropdown().click();
        Logger.info("Analyst clicks on the opensearch custom dropdown");
        openSearchPage.getComplianceOption().click();
        Logger.info("Analyst selects compliance option");
        openSearchPage.getConfirmButton().click();
        Logger.info("Analyst clicks on confirm button");
        Thread.sleep(5000);

    }

    @And("Analyst clicks on menu and opens logs")
    public void analystOpensLogs() throws InterruptedException {
        openSearchPage.getOpensearchMenu().click();
        Logger.info("Analyst click on menu icon");
        openSearchPage.getDiscoverLink().click();
        Logger.info("Analyst clicks on discover option");
        openSearchPage.getDiscoverDropDown().click();
        Logger.info("Analyst clicks on menu drop down");
        Thread.sleep(1000);

        if(AutProperties.getExecutionEnvironment()=="QA") {
            openSearchPage.getFilterSearch().sendKeys("compliance-iwatchx-qa-*");
            openSearchPage.getFilterSearch().sendKeys(Keys.ENTER);
//            openSearchPage.getLogsQA().click();
            Logger.info("Analyst opens QA Logs");
        }
        else{
            openSearchPage.getLogsUAT().click();
            openSearchPage.getFilterSearch().sendKeys("compliance-iwatchx-uat-*");
            openSearchPage.getFilterSearch().sendKeys(Keys.ENTER);

            Logger.info("Analyst opens UAT Logs");
        }

    }


}
