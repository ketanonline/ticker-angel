package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.FabIconLabellingPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.awt.*;
import java.util.List;

public class FabIconLabellingSteps {

    FabIconLabellingPage fabIconLabellingPage = new FabIconLabellingPage();

    @Then("Analyst verifies Shortcut Key labelling as {string}")
    public void verifyShortcutkeyLabel(String shortcut) throws InterruptedException {
        Assert.assertEquals(fabIconLabellingPage.getShortcutIconLabel().getText(),shortcut);
        Logger.info("Analysts Verified Short cut label from Fab icon list");
    }
    @Then("Analyst verifies Attachment list labelling as {string}")
    public void verifyAttachmentLabel(String attach) throws InterruptedException {
        Assert.assertEquals(fabIconLabellingPage.getAttachmentIconLabel().getText(),attach);
        Logger.info("Analysts Verified Attachment label from Fab icon list");
    }
    @Then("Analyst verifies Customer outreach tab labelling as {string}")
    public void verifyCustomerOutreachLabel(String cust) throws InterruptedException {
        Assert.assertEquals(fabIconLabellingPage.getCustomerOutreachIconLabel().getText(),cust);
        Logger.info("Analysts Verified Customer outreach label from Fab icon list");
    }
    @Then("Analyst verifies Audit log labelling as {string}")
    public void verifyAuditLogLabel(String aud) throws InterruptedException {
        Assert.assertEquals(fabIconLabellingPage.getAuditIconLabel().getText(),aud);
        Logger.info("Analysts Verified Audit log label from Fab icon list");
    }
    @Then("Analyst verifies Stop icon labelling as {string}")
    public void verifyStopIconLabel(String stop) throws InterruptedException {
        Assert.assertEquals(fabIconLabellingPage.getStopIconLabel().getText(),stop);
        Logger.info("Analysts Verified Stop icon label from Fab icon list");
    }

    @Then("Analyst verifies Stop icon not present in + symbol")
    public void analystVerifiesStopIconNotPresentInSymbol() {
        List<WebElement> allIcons= fabIconLabellingPage.getAllIcons();
        int count=0;
        for(WebElement icon:allIcons){
            if(icon.getText()=="Stop"){
                count++;
            }

        }
        Assert.assertTrue(count==0,"Stop icon not present inside + icon");
        Logger.info("Stop icon not present inside + icon");
    }

    @Then("Analyst closes the fab menu")
    public void analystClosesTheFabMenu() {
        fabIconLabellingPage.getCrossIcon().click();
        Logger.info("User clicked on X icon");
    }

    @Then("Analyst validates if expander menu panel is present in expanded format")
    public void analystValidatesExpandrMenu() throws InterruptedException {
        Assert.assertTrue(fabIconLabellingPage.getMenuPanel().isDisplayed(),"Menu panel is not present");
        Logger.info("Analyst has validated the Menu panel");

        Thread.sleep(2000);
        String expanderStatus = fabIconLabellingPage.getExpanderStatus().getText();
        Assert.assertEquals(expanderStatus,"keyboard_arrow_right","Menu panel is not in expanded form");
        Logger.info("Analyst has validated that the menu is in expanded form");

    }

    @And("Analyst clicks on {string} button in the menu panel")
    public void analystClicksOnMenuButton(String button) throws InterruptedException {
        Thread.sleep(1000);
        Logger.info("Button : "+button);
        fabIconLabellingPage.getButtonFromMenu(button).click();
        Logger.info("Analyst has clicked on button : "+button);
    }

    @And("Analyst validates if triggering info panel is opened")
    public void analystValidatesTriggInfoPanel() throws InterruptedException {
        Thread.sleep(1000);
        Assert.assertTrue(fabIconLabellingPage.getTrigPanel().isDisplayed(), "Triggering info panel is not opened");
        Logger.info("Analyst has validated triggering info panel");
    }

    @And("Analyst closes the panel")
    public void analystClosesPanel() throws InterruptedException {
        Thread.sleep(1000);
        fabIconLabellingPage.getPanelClose().click();
        Logger.info("Analyst has closed the panel");
    }

    @And("Analyst clicks on collapse button")
    public void analystClicksOnCollapse(){
        fabIconLabellingPage.getCollapseButton().click();
        Logger.info("Analyst has clicked on collapse button");

    }

    @And("Analyst validates if menu is collapsed")
    public void analystValidatesMenuCollapse(){
        String arrow = fabIconLabellingPage.getCollapseButton().getText();
        Assert.assertTrue(arrow.contains("left"),"Menu is not collapsed");
        Logger.info("Analyst has validated that expander menu is collapsed");
    }

    @And("Analyst clicks on help icon")
    public void analystClicksOnHelpIcon(){
        fabIconLabellingPage.getHelpIcon().click();
        Logger.info("Analyst has clicked on help icon");
    }

    @And("Analyst validates the Shortcuts panel")
    public void analystValidatesHelpPanel(){
        Assert.assertTrue(fabIconLabellingPage.getShortcutsWindow().isDisplayed(),"Shortcuts panels is not opened");
        Logger.info("Analyst has validated shortcuts panel by clicking on help icon");
    }


    @And("Analyst validates if the menu expander is draggable")
    public void analystValidatesMenuDraggable() throws InterruptedException, AWTException {
        String arrow = fabIconLabellingPage.getCollapseButton().getText();
        fabIconLabellingPage.dragExpanderMenuValidation();
        Thread.sleep(5000);
        String arrowNew =fabIconLabellingPage.getCollapseButton().getText();
        Assert.assertNotEquals(arrow,arrowNew,"Menu Drag failed");//if menu is successfully dragged, menu will collapse. Hence, this validation
        Logger.info("Analyst has dragged the expander menu successfully.");
    }
}
