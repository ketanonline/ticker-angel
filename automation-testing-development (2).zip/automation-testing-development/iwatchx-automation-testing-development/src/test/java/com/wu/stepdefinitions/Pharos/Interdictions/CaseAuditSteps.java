package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseAuditPage;
import cucumber.api.java.en.Then;
import org.testng.Assert;

public class CaseAuditSteps {


    CaseAuditPage caseAuditPage = new CaseAuditPage();

    @Then("{string} should be present in Phase Description of Audit Log")
    public void thenStandardInvestShouldBeDisplayedInAuditLog(String phaseName) throws InterruptedException{
        String actualPhase = caseAuditPage.getPhaseInAuditLog();
        System.out.println(actualPhase);
        phaseName="Case moved to "+phaseName;
        Assert.assertEquals(actualPhase,phaseName,phaseName+" is not present in Phase Description of Audit Log");
        Logger.info(phaseName+" is present in Phase Description of Audit Log");
    }
}
