package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import com.wu.pages.Pharos.Interdictions.UnisysPage;
import com.wu.utils.AutProperties;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.serenitybdd.core.Serenity;
import org.hamcrest.Matchers;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static com.wu.report.AllureReportManager.addScreenshotToAllureReport;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.hamcrest.MatcherAssert.assertThat;

public class UnisysSteps extends BasePage {

    UnisysPage unisysPage = new UnisysPage();

    @And("Analyst launches Unisys application on browser")
    public void userLaunchesUnisysApplication() throws InterruptedException {
        String fileName = CommonFunctions.getFullPath(AutProperties.getExecutionEnvironmentConfigFileName());
        String url = CommonFunctions.readFile(fileName, "unisysURL");
        String browserName = "Chrome";
        BaseTestSetup.setupBrowser("Chrome", url);
        Logger.info("Launch application \"%s\" on \"%s\" browser", url, browserName);
    }

    @And("Analyst logs in to Unisys")
    public void userLogsInToUnisys() throws InterruptedException {
        unisysPage.getOperatorIDbox().sendKeys("677");
        unisysPage.getPasswordBox().sendKeys("Spider08?");
        unisysPage.getSiteBox().sendKeys("BGT");
        unisysPage.getOkButton().click();
        Logger.info("Analyst logs in to Unisys");
    }

    @And("Analyst waits for Unisys page to load")
    public void analystWaitsForPageToOpen() throws InterruptedException{
        Logger.info("Analyst waits for Unisys Home page to load");
        Thread.sleep(5000);
    }

    @And("Analyst clicks on Money Transfer Utility link")
    public void analystClicksOnMTUtility() throws InterruptedException{
        unisysPage.getMTUtilityLink().click();
        Logger.info("Analyst clicks on Money Transfer Utility link");
        Thread.sleep(5000);
    }

    @And("Analyst searches with MTCN {string}")
    public void analystSearchesWithMTCN(String MTCN) throws InterruptedException{
        if (MTCN.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            MTCN = MTCN.substring(MTCN.indexOf("$") + 1);
            MTCN=(String) apiCommonSteps.getCaseData("refId");
        }
        unisysPage.getControlnumberBox().sendKeys(MTCN);
        unisysPage.getSearchBtn().click();
        Logger.info("Analyst searches with MTCN \"" + MTCN + "\"" );
        Thread.sleep(5000);
    }

    @And("Analyst searches with associated MTCN")
    public void analystSearchesWithAssociatedMTCN() throws InterruptedException{
        String MTCN10digit = ConversationSteps.mtcnVal.substring(6);
        System.out.println(MTCN10digit);
        unisysPage.getControlnumberBox().sendKeys(MTCN10digit);
        unisysPage.getSearchBtn().click();
        Logger.info("Analyst searches with MTCN \"" + MTCN10digit + "\"" );
        Thread.sleep(5000);
    }


    @And("Analyst clicks on MTCN DATA button")
    public void analystsClicksOnMTCNDataBtn() throws InterruptedException{
        unisysPage.getMTCNDataBtn().click();
        Logger.info("Analyst clicks on MTCN DATA button" );
        Thread.sleep(5000);
    }

    @And("Analyst clicks on MTCN DETAILS button")
    public void analystsClicksOnMTCNDetailsBtn() throws InterruptedException{
        unisysPage.getMTCNDetailsBtn().click();
        Logger.info("Analyst clicks on MTCN DETAILS button" );
        Thread.sleep(5000);
    }

    @And("Analyst clicks on COMMENT button")
    public void analystsClicksOnCommentBtn() throws InterruptedException{
        unisysPage.getCommentBtn().click();
        Logger.info("Analyst clicks on COMMENT button" );
        Thread.sleep(5000);
    }

    @And("Analyst clicks on QUEUE button")
    public void analystsClicksOnQueueBtn() throws InterruptedException{
        unisysPage.getQueueBtn().click();
        Logger.info("Analyst clicks on QUEUE button" );
        Thread.sleep(5000);
    }

    @And("Analyst verifies {string} queue is present")
    public void analystsVerifiesQueueName(String queueName) throws InterruptedException{
        String ActQueueName= unisysPage.getQueueName().getAttribute("innerHTML");
        ActQueueName=ActQueueName.replace("&nbsp;","").trim();
        if(ActQueueName.equals(queueName))
            Logger.info("Expected Queue Name is present in Unisys: "+ActQueueName );
        else
            Logger.error("Mismatch in Queue Name \n Expected Queue Name in Unisys: "+queueName +"\n Actual Queue Name : "+ActQueueName);
        assertThat("Expected Queue Name is present in Unisys", ActQueueName.equals(queueName));
    }

    @And("Analyst verifies {string} transaction status is present")
    public void analystsVerifiesTRanStatus(String status) throws InterruptedException{
        String ActStatus= unisysPage.getTranStatus().getAttribute("innerHTML");
        ActStatus=ActStatus.replace("&nbsp;","").trim();
        if(ActStatus.equals(status))
            Logger.info("Expected transaction status is present in Unisys: "+ActStatus );
        else
            Logger.error("Mismatch in transaction status \n Expected transaction status in Unisys: "+status +"\n Actual transaction status : "+ActStatus);
        assertThat("Expected transaction status is present in Unisys", ActStatus.equals(status));
    }


    @And("Analyst verifies that latest comment is {string}")
    public void analystVerifiesthatLatestCommentIs(String comment){
        assertThat("Latest comment validation :",
                unisysPage.getLatestComment(),
                Matchers.equalTo(comment));
    }

    @And("Analyst verifies {string} comment is present")
    public void analystVerifiesCommentIsPresent(String expComment) {
        Boolean isCommentPresent = FALSE;
        int commentPresent = 0;
        expComment=expComment.replace("//","/");
        List<String> commentList = unisysPage.getAllComments();

        ArrayList<String> commentParts = new ArrayList<>();
        for (int i = 0; i <= expComment.length() / 69; i++) {
            commentParts.add(expComment.substring(i * 69,Math.min((i+1)*69,expComment.length())));
            System.out.println(commentParts);
        }
        for (String commentPart : commentParts) {
            for (String comment : commentList) {
                System.out.println(commentPart);
                System.out.println(comment);
                if (comment.equals(commentPart)) {
                    commentPresent++;
                    break;
                }
            }

        }
        addScreenshotToAllureReport("CTM comments");
        assertThat("Check if the comment is Present :", commentPresent, Matchers.equalTo(commentParts.size()));

    }

    @And("Analyst verifies iWatchX Conversation is present in Unisys")
    public void analystVerifiesCommentIsPresent(){
        Boolean isCommentPresent=FALSE;
        List<String> commentList=unisysPage.getAllComments();
        for (String comment:commentList) {
            if(comment.equals(ConversationSteps.convData.toUpperCase().replaceAll("\n",""))) {
                isCommentPresent = TRUE;
                Logger.info("Conversation in iWatchX = \n" + ConversationSteps.convData);
                Logger.info("Comment in CTM          = \n" + comment);
                break ;
            }
        }
        addScreenshotToAllureReport("CTM Conversation Comment");
        assertThat("Check if the Conversation is Present :", isCommentPresent, Matchers.equalTo(TRUE));
    }

    @And("Analyst verifies iWatchX Conversation is not present in Unisys")
    public void analystVerifiesCommentIsNotPresent(){
        Boolean isCommentPresent=FALSE;
        List<String> commentList=unisysPage.getAllComments();
        for (String comment:commentList) {
            if(comment.equals(ConversationSteps.convData.toUpperCase().replaceAll("\n",""))) {
                isCommentPresent = TRUE;
                break ;
            }
        }
        assertThat("Check that the Conversation is Not Present :", isCommentPresent, Matchers.equalTo(FALSE));
    }

    @And("Analyst verifies {string} cancel transaction status is present")
    public void analystsVerifiesTRanStatus_Cancel(String status) throws InterruptedException{
        String ActStatus= unisysPage.getTranStatus_Cancel().getAttribute("innerHTML");
        ActStatus=ActStatus.replace("&nbsp;","").trim();
        if(ActStatus.equals(status))
            Logger.info("Expected transaction status is present in Unisys: "+ActStatus );
        else
            Logger.error("Mismatch in transaction status \n Expected transaction status in Unisys: "+status +"\n Actual transaction status : "+ActStatus);
        assertThat("Expected transaction status is present in Unisys", ActStatus.equals(status));
    }

    @And("Analyst gets queue name and saves in  {string}")
    public void analystsGetsQueueName(String finQueueName) throws InterruptedException{
        String ActQueueName= unisysPage.getQueueName().getAttribute("innerHTML");
        ActQueueName=ActQueueName.replace("&nbsp;","").trim();
        Logger.info("Queue Name retrieve from Unisys: "+ActQueueName );
        if(finQueueName.contains("$")) finQueueName=finQueueName.substring(finQueueName.indexOf("$") + 1);
        Serenity.getCurrentSession().put(finQueueName, ActQueueName);
    }

    @Then("Analyst verifies Case Creation comment is present for {string} side {string}")
    public void analystValidatesCaseCreationComment(String hitSide,String caseID)throws java.lang.Exception {
        String caseRefNum = Serenity.getCurrentSession().get("caseRefNum").toString();
        String createdDate = Serenity.getCurrentSession().get("createdDate").toString();
        String createdTimeStamp = Serenity.getCurrentSession().get("createdTimeStamp").toString();

        List<WebElement> commentList = unisysPage.getCommentsTable();
        int rows_count = commentList.size();
        if (caseID.contains("$")) {
            caseID = caseID.substring(caseID.indexOf("$") + 1);
            caseID=(String) Serenity.getCurrentSession().get(caseID);
        }
        caseID=caseID.toUpperCase();
        boolean bflag=false;
//        String expDEsc="IWATCHX GSI CASE "+caseID+" WITH REF#";
//        String expDEsc1=caseRefNum+" CREATED ON "+createdDate+" "+createdTimeStamp+":\\d\\d"+" FOR "+hitSide+" REVIEW";
        String actDEsc = null,actDEsc1= null;
        String expDEsc="CMP GSI CASE WITH REF#:"+caseRefNum+" CREATED "+createdDate+" "+createdTimeStamp+":\\d\\d";
        String expDEsc1="CASE ID "+caseID+" - "+hitSide;
        for (int i =1;i<=rows_count;i++) {
            WebElement ele =browserElementLocator.findElementByXpath("//table[@class='ESAtable' and @id='results']/tbody/tr["+i+"]/td[1]");
            actDEsc = ele.getText().trim();
            actDEsc=actDEsc.replace("&nbsp;","").trim();
            if (actDEsc.contains(caseRefNum))
            {
                if( actDEsc.matches(expDEsc)) {
                    WebElement ele1 =browserElementLocator.findElementByXpath("//table[@class='ESAtable' and @id='results']/tbody/tr["+(i+2)+"]/td[1]");
                    actDEsc1 = ele1.getText().trim();
                    actDEsc1=actDEsc1.replace("&nbsp;","").trim();
                    assertThat("Case creation comment is validated", actDEsc1.equals(expDEsc1));
                    bflag = true;
                    expDEsc1=actDEsc1;
                    break;
                }
            }
        }
        if( bflag)
            Logger.info("Expected Case Creation comment is displayed : "+actDEsc+"\n"+actDEsc1);
        else
            Logger.error("Expected Case Creation comment is not displayed.");
    }

}
