package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.api.util.common.CommonFunctions;
import com.wu.api.util.common.CouchBaseUtility;
import com.wu.api.util.common.CreateCase;
import com.wu.api.util.common.RequestJsonCreator;
import com.wu.base.logger.Logger;

import com.wu.utils.AutProperties;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;

import org.hamcrest.Matchers;
import org.json.JSONObject;
import org.testng.internal.InvokeMethodRunnable;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

import static com.wu.api.util.common.CommonFunctions.getFullPath;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class CreateCaseSteps {
    public static Boolean isMTCNcreated = FALSE;
    public static Boolean isCaseIdCreated = FALSE;


    APICommonSteps apiCommonSteps = new APICommonSteps();

    public Boolean isCaseIdGenerated(String mtcn16, String caseIdVar) throws Exception {
        String mtcn10;
        if (caseIdVar.contains("$")) {
            caseIdVar = caseIdVar.substring(caseIdVar.indexOf("$") + 1);
        }
        Logger.info("MTCN16  = " + mtcn16);
        apiCommonSteps.addCaseData("MTCN16", mtcn16);
        apiCommonSteps.addCaseData("refId", mtcn16);

        mtcn10 = mtcn16.substring(6, 16).trim();
        apiCommonSteps.addCaseData("MTCN10", mtcn10);
        Logger.info("MTCN10 = " + apiCommonSteps.getCaseData("MTCN10"));

        String caseID = "";
        caseID = getGSICaseIdforGivenMTCN(mtcn16);

//        assertThat("Verify if CaseID generated", !(caseID.equals("")));

        if (caseID == "") {
            Logger.info("Case ID not found for this MTCN. Creating a new MTCN");
            return FALSE;
        }
        apiCommonSteps.addCaseData(caseIdVar, caseID);
        return TRUE;
    }

    public String getGSICaseIdforGivenMTCN(String mtcn16) throws InterruptedException, Exception {
        CouchBaseUtility.bucket = null;
        CouchBaseUtility.closeBucket();
        String query;
        String caseId = "";
        Map<String, List<String>> data = null;
        query = "SELECT parties[0].caseIds[0] AS caseId, parties[0].subjectId\n" +
                "FROM iWatchXCustomerJourney\n" +
                "WHERE docType = 'activity'\n" +
                "    AND refId = \"" + mtcn16 + "\"\n" +
                "ORDER BY createdTimestamp\n" +
                "LIMIT 1";

        int caseCreateWait = 20;
        int timeTaken = 0;
        Thread.sleep(10000);
        while (caseCreateWait > 0) {
            data = CouchBaseUtility.executeCouchBaseQuery(query);
            if (data.size() == 0) {
                Thread.sleep(2000);
                timeTaken += 2;
                caseCreateWait--;
                if (caseCreateWait == 0) {
                    Logger.info("Case is not created in couchbase, waited " + timeTaken + "sec!");
                    return caseId;
                }
                Logger.info("Waiting for case to be created in CouchBase, Time taken: " + timeTaken + " sec");
                data.clear();
            } else {
                apiCommonSteps.addCaseData("subjectId", data.get("subjectId").toString().replace("[", "").replace("]", ""));
                return data.get("caseId").toString().replace("[", "").replace("]", "");
            }
        }
        return caseId;
    }

    @Given("User creates case for WU Digital Sender side and caseId saved in {string}")
    public void givenUserCreatesCaseForWUDigitalSenderSide(String caseIdVar) throws IOException, InterruptedException, ClassNotFoundException, SQLException {
        if (caseIdVar.contains("$")) {
            caseIdVar = caseIdVar.substring(caseIdVar.indexOf("$") + 1);
        }
        CreateCase caseCreation = new CreateCase();
        int totalNumberOfEntities = 18;
        int entityNo = 0;
        String fileName = "Digital_GSI_SingleEntity";
        Boolean isMTCNcreated = FALSE;
        Boolean isCaseIdCreated = FALSE;

        String mtcn10 = "";
        String mtcn16 = "";
        String caseId = "";

        /* Will try to first create an MTCN with random entity and when that fails
        will try Digital with each entity in order  */

        String currentConfigFile = AutProperties.getExecutionEnvironmentConfigFileName();
        try {
            if (!AutProperties.getExecutionEnvironment().equals("QA")) {
                AutProperties.setEnvConfigFile("qa_config.properties");
            }
            do {
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide(fileName, entityNo, totalNumberOfEntities);
                if (mtcn16 != "") {
                    isMTCNcreated = TRUE;
                    if (isCaseIdGenerated(mtcn16, caseIdVar)) {
                        isCaseIdCreated = TRUE;
                        caseId = apiCommonSteps.getCaseData(caseIdVar);
                        Logger.info("Case ID =" + caseId);
                        break;
                    }
                }
                entityNo++;
            } while (entityNo < (totalNumberOfEntities + 1));

            if (!AutProperties.getExecutionEnvironment().equals("QA")) {
                getActivityStatusData(mtcn16);
                AutProperties.setEnvConfigFile(currentConfigFile);
                interimOrchestratorCallForCaseCreation();
                addActivityStatus();
                if (isCaseIdGenerated(mtcn16, caseIdVar)) {
                    isCaseIdCreated = TRUE;
                    caseId = apiCommonSteps.getCaseData(caseIdVar);
                    Logger.info("Case ID =" + caseId);
                }
            }
        } catch (Exception ex) {
        } finally {
            AutProperties.setEnvConfigFile(currentConfigFile);
        }
        assertThat("Verify if MTCN is generated", isMTCNcreated, equalTo(TRUE));
        assertThat("Verify if CaseID is generated", isCaseIdCreated, equalTo(TRUE));
    }

    public Object getActivityStatusData(String mtcn16) throws InterruptedException, Exception {
        CouchBaseUtility.bucket = null;
        CouchBaseUtility.closeBucket();
        String query;
        Map<String, List<String>> data = null;
        query = "SELECT * \n" +
                "FROM ActivityStatus\n" +
                "WHERE docType = 'actStatus'\n" +
                "    AND refId = \"" + mtcn16 + "\"\n" +
                "ORDER BY createdTimestamp\n" +
                "LIMIT 1";
        int activityStatusWait = 20;
        int timeTaken = 0;
        Thread.sleep(10000);
        while (activityStatusWait > 0) {
            data = CouchBaseUtility.executeCouchBaseQuery(query);
            if (data.size() == 0) {
                Thread.sleep(2000);
                timeTaken += 2;
                activityStatusWait--;
                if (activityStatusWait == 0) {
                    Logger.info("Case is not created in couchbase, waited " + timeTaken + "sec!");
                    return 0;
                }
                Logger.info("Waiting for case to be created in CouchBase, Time taken: " + timeTaken + " sec");
                data.clear();
            } else {
                apiCommonSteps.addCaseData("attemptId", data.get("ActivityStatus.attemptId").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("attemptTimestamp", data.get("ActivityStatus.attemptTimestamp").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("createdTimestamp", data.get("ActivityStatus.createdTimestamp").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("docType", data.get("ActivityStatus.docType").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("gsiCaseCreated", data.get("ActivityStatus.gsiCaseCreated").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("refId", data.get("ActivityStatus.refId").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("qName", data.get("ActivityStatus.qName").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("shrtRefId", data.get("ActivityStatus.shrtRefId").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("txnState", data.get("ActivityStatus.txnState").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("txnStatus", data.get("ActivityStatus.txnStatus").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("txnSurKey", data.get("ActivityStatus.txnSurKey").toString().replace("[", "").replace("]", ""));
                apiCommonSteps.addCaseData("txnTimestamp", data.get("ActivityStatus.txnTimestamp").toString().replace("[", "").replace("]", ""));
                return 1;
            }
        }
        return 1;
    }

    public void interimOrchestratorCallForCaseCreation() throws Exception {
        apiCommonSteps.givenUserHasInputJSON("interimService");
        apiCommonSteps.userHasHeader("interimService");
        apiCommonSteps.whenUserUpdatesInputJSON("activityRefNo", apiCommonSteps.getCaseData("refId"));
        apiCommonSteps.whenUserUpdatesInputJSON("attemptId", apiCommonSteps.getCaseData("attemptId"));
        apiCommonSteps.whenUserUpdatesInputJSON("tranSurKey", apiCommonSteps.getCaseData("txnSurKey"));
        apiCommonSteps.whenUserUpdatesInputJSON("transactionSide", "S");
        apiCommonSteps.whenUserUpdatesInputJSON("hitSide", "S");
        apiCommonSteps.whenUserUpdatesInputJSON("subject.id", apiCommonSteps.getCaseData("subjectId"));
        apiCommonSteps.whenUserCallsTheAPI("interimService", "POST");
    }

    public void addActivityStatus() throws Exception {
        apiCommonSteps.givenUserHasInputJSON("activityStatus");
        apiCommonSteps.userHasHeader("activityStatus");
        apiCommonSteps.whenUserUpdatesInputJSON("TRNS_SUR_KEY", apiCommonSteps.getCaseData("txnSurKey"));
        apiCommonSteps.whenUserUpdatesInputJSON("MTCN16", apiCommonSteps.getCaseData("refId"));
        apiCommonSteps.whenUserUpdatesInputJSON("MTCN", apiCommonSteps.getCaseData("shrtRefId"));
        apiCommonSteps.whenUserUpdatesInputJSON("ATTEMPTID", apiCommonSteps.getCaseData("attemptId"));
        apiCommonSteps.whenUserUpdatesInputJSON("QUE_NAME", "BRIDPFC");
        apiCommonSteps.whenUserUpdatesInputJSON("TRANSACTIONSTATE", apiCommonSteps.getCaseData("txnState"));
        apiCommonSteps.whenUserUpdatesInputJSON("GSI_CASE_CREATED", apiCommonSteps.getCaseData("gsiCaseCreated"));
        apiCommonSteps.whenUserUpdatesInputJSON("STATUS", apiCommonSteps.getCaseData("txnStatus"));
        apiCommonSteps.whenUserCallsTheAPI("activityStatus", "POST");
    }

    @Given("User creates case for WU Retail Sender side and caseId saved in {string}")
    public void givenUserCreatesCaseForWURetailSenderSide(String caseIdVar) throws Exception {
        if (caseIdVar.contains("$")) {
            caseIdVar = caseIdVar.substring(caseIdVar.indexOf("$") + 1);
        }
        CreateCase caseCreation = new CreateCase();

        int totalNumberOfEntities = 18;
        int entityNo = 1;
        String fileName = "WU_GSI_SingleEntity";
        Boolean isMTCNcreated = FALSE;
        Boolean isCaseIdCreated = FALSE;

        String mtcn10 = "";
        String mtcn16 = "";
        String caseId = "";

        /* Will try to first create an MTCN with random entity and when that fails
        will try retail with each entity in order  */

        String currentConfigFile = AutProperties.getExecutionEnvironmentConfigFileName();
        try {
            if (AutProperties.getExecutionEnvironment().equals("DEV")) {
                AutProperties.setEnvConfigFile("qa_config.properties");
            }
            do {
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide(fileName, entityNo, totalNumberOfEntities);
                if (mtcn16 != "") {
                    isMTCNcreated = TRUE;
                    if (isCaseIdGenerated(mtcn16, caseIdVar)) {
                        isCaseIdCreated = TRUE;
                        caseId = apiCommonSteps.getCaseData(caseIdVar);
                        Logger.info("Case ID =" + caseId);
                        break;
                    }
                }
                entityNo++;
            } while (entityNo < (totalNumberOfEntities + 1));

            if (AutProperties.getExecutionEnvironment().equals("DEV")) {
                getActivityStatusData(mtcn16);
                AutProperties.setEnvConfigFile(currentConfigFile);
                interimOrchestratorCallForCaseCreation();
                addActivityStatus();
                if (isCaseIdGenerated(mtcn16, caseIdVar)) {
                    isCaseIdCreated = TRUE;
                    caseId = apiCommonSteps.getCaseData(caseIdVar);
                    Logger.info("Case ID =" + caseId);
                }
            }
        } catch (Exception ex) {
        } finally {
            AutProperties.setEnvConfigFile(currentConfigFile);
        }
        assertThat("Verify if MTCN is generated", isMTCNcreated, equalTo(TRUE));
        assertThat("Verify if CaseID is generated", isCaseIdCreated, equalTo(TRUE));
        userWaitsForCaseIdToMoveToRFW(caseId);
    }


    @Given("User creates GSI INTR Sender WU case {string}")
    public void givenUserCreatesWUgsiCaseSenderSide(String caseIdVar) throws ClassNotFoundException, SQLException, InterruptedException, Exception {
        if (caseIdVar.contains("$")) {
            caseIdVar = caseIdVar.substring(caseIdVar.indexOf("$") + 1);
        }
        CreateCase caseCreation = new CreateCase();
        int totalNumberOfEntities_Retail = 18;
        int entityNo_Retail = 0;
        String fileName_Retail = "WU_GSI_SingleEntity";

        int totalNumberOfEntities_Digital = 18;
        int entityNo_Digital = 0;
        String fileName_Digital = "Digital_GSI_SingleEntity";

        Boolean isMTCNcreated = FALSE;
        Boolean isCaseIdCreated = FALSE;

        String mtcn10 = "";
        String mtcn16 = "";
        String caseId = "";

  /* Will try to first create an Retail MTCN with random entity and when that fails
        will try retail with each entity in order
        If entire retail fails we will go for Digital
        Will try to first create a digital MTCN with random entity and when that fails
        will try digital with each entity in order*/

        do {
            mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide(fileName_Retail, entityNo_Retail, totalNumberOfEntities_Retail);
            if (mtcn16 != "") {
                isMTCNcreated = TRUE;
                if (isCaseIdGenerated(mtcn16, caseIdVar)) {
                    isCaseIdCreated = TRUE;
                    caseId = apiCommonSteps.getCaseData(caseIdVar);
                    Logger.info("Case ID =" + caseId);
                    break;
                }
            }
            entityNo_Retail++;
        } while (entityNo_Retail < (totalNumberOfEntities_Retail + 1));

        if (caseId == "") {
            do {
                mtcn16 = caseCreation.createAISRetailMTCNUsingGWforGSISenderSide(fileName_Digital, entityNo_Digital, totalNumberOfEntities_Digital);
                if (mtcn16 != "") {
                    isMTCNcreated = TRUE;
                    if (isCaseIdGenerated(mtcn16, caseIdVar)) {
                        isCaseIdCreated = TRUE;
                        caseId = apiCommonSteps.getCaseData(caseIdVar);
                        Logger.info("Case ID =" + caseId);
                        break;
                    }
                }
                entityNo_Digital++;
            } while (entityNo_Digital < (totalNumberOfEntities_Digital + 1));
        }
        assertThat("Verify if MTCN is generated", isMTCNcreated, equalTo(TRUE));
        assertThat("Verify if CaseID is generated", isCaseIdCreated, equalTo(TRUE));
        userWaitsForCaseIdToMoveToRFW(caseId);


    }

    @When("User waits for case {string} to move to RFW")
    public void userWaitsForCaseIdToMoveToRFW(String caseId) throws Exception {
        apiCommonSteps.dbQueryForgetworkflow(caseId);
        String wfStatusId = (String) CommonFunctions.getValueFromJSON("id", APICommonSteps.dbResult);

        int RFWwait = 20;
        int timeTaken = 0;
        Thread.sleep(10000);
        while (RFWwait > 0) {
            apiCommonSteps.dbQueryForgetworkflow(caseId);
            wfStatusId = (String) CommonFunctions.getValueFromJSON("id", APICommonSteps.dbResult);
            System.out.println("wfStatusId = " + wfStatusId);
            if (!(wfStatusId.trim().equalsIgnoreCase(("SI.RFW.CA")))) {
                Thread.sleep(2000);
                timeTaken += 2;
                RFWwait--;
                if (RFWwait == 0) {
                    Logger.info("Case is not in RFW state, waited for " + timeTaken + "sec!");
                }
                Logger.info("Case is not in RFW state, Time taken: " + timeTaken + " sec" + "Status ID =" + wfStatusId);
            } else {
                Logger.info("Case is in RFW state");
                break;
            }
        }
        assertThat("Case is in RFW state", wfStatusId, (equalTo("SI.RFW.AP")));
    }
}



