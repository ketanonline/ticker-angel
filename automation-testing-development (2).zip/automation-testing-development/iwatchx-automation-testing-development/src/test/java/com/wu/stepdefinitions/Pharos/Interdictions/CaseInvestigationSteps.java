package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseInvestigationPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import net.serenitybdd.core.Serenity;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.List;
import java.util.stream.Collectors;

import static com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps.getCaseData;

public class CaseInvestigationSteps {

    CaseInvestigationPage caseInvestigationPage = new CaseInvestigationPage();

    int actFailurecount=0;
    @When("Analyst sends {string} keys on Entities")
    public void analystSendsKeysOnEntities(String keys) {


        Actions actions = new Actions(BaseTestSetup.webDriver);

        switch (keys) {
            case "Alt+S":
                actions.keyDown(Keys.ALT).sendKeys("s").keyUp(Keys.ALT).perform();
                break;
            case "Alt+R":
                actions.keyDown(Keys.ALT).sendKeys("r").keyUp(Keys.ALT).perform();
                break;
            case "Alt+T":
                actions.keyDown(Keys.ALT).sendKeys("t").keyUp(Keys.ALT).perform();
                break;
            case "Alt+D":
                actions.keyDown(Keys.ALT).sendKeys("d").keyUp(Keys.ALT).perform();
                break;
            case "Alt+C":
                actions.keyDown(Keys.ALT).sendKeys("c").keyUp(Keys.ALT).perform();
                break;
            case "Alt+F":
                actions.keyDown(Keys.ALT).sendKeys("f").keyUp(Keys.ALT).perform();
                break;
            case "Alt+I":
                actions.keyDown(Keys.ALT).sendKeys("i").keyUp(Keys.ALT).perform();
                break;
            case "Alt+N":
                actions.keyDown(Keys.ALT).sendKeys("n").keyUp(Keys.ALT).perform();
                break;
            case "Alt+M":
                actions.keyDown(Keys.ALT).sendKeys("m").keyUp(Keys.ALT).perform();
                break;
            case "Alt+G":
                actions.keyDown(Keys.ALT).sendKeys("g").keyUp(Keys.ALT).perform();
                break;
            case "Alt+P":
                actions.keyDown(Keys.ALT).sendKeys("p").keyUp(Keys.ALT).perform();
                break;
            case "Alt+Z":
                actions.keyDown(Keys.ALT).sendKeys("z").keyUp(Keys.ALT).perform();
                break;
            case "Shift+D":
                actions.keyDown(Keys.SHIFT).sendKeys("d").keyUp(Keys.SHIFT).perform();
                break;
            case "Shift+C":
                actions.keyDown(Keys.SHIFT).sendKeys("c").keyUp(Keys.SHIFT).perform();
                break;
            case "Shift+I":
                actions.keyDown(Keys.SHIFT).sendKeys("i").keyUp(Keys.SHIFT).perform();
                break;
            case "Shift+N":
                actions.keyDown(Keys.SHIFT).sendKeys("n").keyUp(Keys.SHIFT).perform();
                break;
        }

        Logger.info("Analyst sends " + keys + " on selected Entity");
    }

    @When("Analyst Clicks on all the Entities")
    public void analystClickOnAllEntities() {
        caseInvestigationPage.clickOnAllEntities();
        Logger.info("Analyst Clicks on all the Entities");
    }

    @And("Analyst Clicks on Reasons button")
    public void analystClicksOnReasonsButton() {
        caseInvestigationPage.clickOnReasonsButton();
        Logger.info("Analyst Clicks on Reasons button");
    }

    @And("Analyst verifies the list of Reasons displayed")
    public void analystVerifesListOfReasons(DataTable reasons) {

        List<String> reasonsList = reasons.asList(String.class);
        boolean res = caseInvestigationPage.listOfReasonsDisplayed(reasonsList);
        Logger.info("List of Reasons displayed verified");
        Assert.assertTrue(res, "Test Passed and Reasons are displayed as expected");
    }

    @When("Disposition should have {string} option selected")
    public void validateCaseDisposition(String Disposition) throws InterruptedException {
        Thread.sleep(3000);
        caseInvestigationPage.validateDisposition(Disposition);
        Logger.info("Disposition is Validated");
    }

    @When("Analyst Clicks on Submit Button")
    public void analystClickOnDispositionSubmit() throws InterruptedException {
        Thread.sleep(2000);
        caseInvestigationPage.clickOnDispositionSubmit();
        Logger.info("Analyst Clicks on Submit Button");
        Thread.sleep(2000);
    }

    @And("Analyst should be able to see {string} message on the screen")
    public void analystShouldBeAbleToSeeConfirmationMessageOnScreen(String msg) {
        caseInvestigationPage.verifyConfirmationMsg();
    }

    @When("Analyst clicks on + symbol")
    public void analystClickOnPlusSymbol() throws InterruptedException {
        Thread.sleep(3000);
        caseInvestigationPage.clickOnPlusSymbol();
        Logger.info("Analyst Clicks on + Symbol");
        Thread.sleep(1000);
    }

    @When("Analyst clicks on Audit Log symbol")
    public void analystClickOnAuditLogSymbol() throws InterruptedException {
        caseInvestigationPage.clickOnAuditLogSymbol();
        Logger.info("Analyst Clicks on Audit Log symbol");
    }
    @When("Analyst clicks on Audit Log symbol for Action Failure Widget")
    public void analystClickOnAuditLogSymbolActFailure() throws InterruptedException {
        int DbCount = Integer.parseInt(getCaseData("count"));
        if(DbCount > 0) {
            Thread.sleep(5000);
            caseInvestigationPage.clickOnAuditLogSymbol();
            Logger.info("Analyst Clicks on Audit Log symbol");
        }
    }

    @Then("Analyst validates {string} description in Audit Log")
    public void analystValidatesAutoDisAuditLog(String expAuditDEsc) throws Exception {
//        if (expAuditDEsc.equals("Case moved to Completed") || expAuditDEsc.equals("Case moved to Concluded")) {
            caseInvestigationPage.validateAuditLog(expAuditDEsc);
//            Thread.sleep(1000);
//            caseInvestigationPage.validateactAuditlog();
//            Thread.sleep(1000);
//        }
    }

    @Then("Analyst validates description in Audit Log for Action Failure Widget")
    public void analystValidatesAutoDisAuditLogForActionFailure() throws Exception {
//        if (expAuditDEsc.equals("Case moved to Completed") || expAuditDEsc.equals("Case moved to Concluded")) {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0){
            BaseTestSetup.webDriver.findElement(By.id("mat-input-14")).sendKeys("Failed");
                int count = Integer.parseInt(getCaseData("actFailureCount"));
            for(int i=0;i<count;i++) {
                String key = "actFailure" + Integer.toString(i);
                String AuditLogEntry = "Failed Action " + getCaseData(key) + " manually resolved.";
                caseInvestigationPage.validateAuditLogActionFailure(AuditLogEntry);
                Thread.sleep(1000);
                caseInvestigationPage.validateactAuditlog();
                //            Thread.sleep(1000);
            }
        }
//        }
    }

    @And("Analyst validates if audit log window is opened")
    public void analystValidatesAuditWindow(){
        Assert.assertTrue(caseInvestigationPage.getAuditTable().isDisplayed(), "Audit window is not opened");
        Logger.info("Analyst has validated the audit log window");
    }

    @Then("Analyst validates {string} description in Audit Log is not present")
    public void analystValidatesAuditLogNotPresent(String expAuditDEsc) throws Exception {
        caseInvestigationPage.validateAuditLogNotPresent(expAuditDEsc);
    }

    @And("Analyst saves 10 digit mtcn in {string}")
    public void Savemtcn(String mtcn) {
        if (mtcn.contains("$")) {
            mtcn = mtcn.substring(mtcn.indexOf("$") + 1);
        }

        Serenity.getCurrentSession().put(mtcn, caseInvestigationPage.getMTCN().substring(6));
    }
    @And("Analyst closes audit log")
    public void analystClosesAuditLog() throws InterruptedException {
        caseInvestigationPage.closeAuditLog();
        Logger.info("Analyst closes audit log");
    }

    @Then("Analyst verifies if Submit button is disabled")
    public void verifySubmitButtonDisabled(){
        Boolean submitBtn =caseInvestigationPage.getDispositionSubmitButton().isEnabled();
        if(submitBtn.equals(false)){
            Logger.info("Submit button is disabled");
        }else{
            Logger.error("Submit button is enabled");
        }
    }
    @When("Analyst Clicks on Notification Button")
    public void analystClicksOnNotificationButton() throws InterruptedException {
        Thread.sleep(2000);
        caseInvestigationPage.clickonNotificationButton();
        Logger.info("Analyst Clicks on Notification Button");
    }
    @When("Analyst Clicks to scrollDown Audit page")
    public void analystClickToAcessScrollAudit() throws InterruptedException {
        Thread.sleep(2000);
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement Audit=webDriver.findElement(By.xpath("//app-audit[1]/div[1]/div[2]/table[1]/tbody[1]/tr[last()]/td[3]"));
        je.executeScript("arguments[0].scrollIntoView(true);",Audit);
        Logger.info("Analyst Clicks to access  scroll");
    }
    @When("Analyst is highligthing the particular {string}")
    public void analystIsHighligthParticular(String stage) throws Exception{
        if (stage.equals("RFW")) {
            Thread.sleep(2000);
            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            JavascriptExecutor je = (JavascriptExecutor) webDriver;
            WebElement element = webDriver.findElement(By.xpath("//body[1]/div[1]/app[1]/vertical-layout-1[1]/main[1]/div[1]/div[1]/div[1]/content[1]/app-gsi-sanction-case-management[1]/app-case-management[1]/div[1]/div[1]/app-header-information[1]/mat-card[1]/mat-card-title[1]/mat-expansion-panel[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/p[1]"));
            je.executeScript("arguments[0].style.border='3px solid red'", element);

            Logger.info("Analyst is highligthing the particular "+stage);
        }else {
            if (stage.equals("pend")){
                Thread.sleep(2000);
                WebDriver webDriver = BaseTestSetup.webDriver;
                webDriver.manage().window().maximize();
                JavascriptExecutor je = (JavascriptExecutor) webDriver;
                WebElement element = webDriver.findElement(By.xpath("//app-header-information[1]/mat-card[1]/mat-card-title[1]/mat-expansion-panel[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[2]/div[1]/div[2]/p[1]"));
                je.executeScript("arguments[0].style.border='3px solid red'", element);

                Logger.info("Analyst is highligthing1 the particular "+stage);

            } else {
                if (stage.equals("pend re-elevation")) {
                    Thread.sleep(2000);
                    WebDriver webDriver = BaseTestSetup.webDriver;
                    webDriver.manage().window().maximize();
                    JavascriptExecutor je = (JavascriptExecutor) webDriver;
                    WebElement element = webDriver.findElement(By.xpath("//app-header-information[1]/mat-card[1]/mat-card-title[1]/mat-expansion-panel[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[2]/div[1]/div[3]/p[last()]"));
                    je.executeScript("arguments[0].style.border='3px solid red'", element);

                    Logger.info("Analyst is highligthing1 the particular " + stage);
                } else {
                    if (stage.equals("Audit")) {
                        Thread.sleep(2000);
                        WebDriver webDriver = BaseTestSetup.webDriver;
                        webDriver.manage().window().maximize();
                        JavascriptExecutor je = (JavascriptExecutor) webDriver;
                        WebElement element = webDriver.findElement(By.xpath("//app-audit[1]/div[1]/div[2]/table[1]/tbody[1]/tr[last()]/td[3]"));
                        je.executeScript("arguments[0].style.border='3px solid red'", element);

                        Logger.info("Analyst is highligthing1 the particular " + stage);
                    }
                }
            }
        }
    }
    @When("Analyst is highligthing the particular area")
    public void analystIsHighligth1Particular() throws Exception{
        Thread.sleep(2000);
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement element= webDriver.findElement(By.xpath("//app-header-information[1]/mat-card[1]/mat-card-title[1]/mat-expansion-panel[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[2]/div[1]/div[2]/p[1]"));
        je.executeScript("arguments[0].style.border='3px solid red'",element);

        Logger.info("Analyst is highligthing1 the particular area");
    }
    @And("Analyst clicks on select {string} Tab")
    public void analystClicksOnSelectArrowTab(String Arrow) throws InterruptedException {
        Thread.sleep(2000);
        if (Arrow.equals("ACTION")) {
            caseInvestigationPage.clickOnActionArrow();
            Thread.sleep(4000);
        } else {
            if (Arrow.equals("Reason")){
                caseInvestigationPage.clickOnReasonArrow();
                Thread.sleep(4000);
            }
            else {
                if (Arrow.equals("Critical")) {
                    caseInvestigationPage.clickOnCriticalArrow();
                    Thread.sleep(4000);
                }
                else {
                    if (Arrow.equals("IA Reason")) {
                        caseInvestigationPage.clickOnIAReasonArrow();
                        Thread.sleep(4000);
                    }
                }
            }
        }
    }
    @When("Analyst Highligthed elements in  Audit page {string}")
    public void analystClickToAcessScrollAudit(String element) throws InterruptedException {
        Thread.sleep(2000);
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        WebElement Audit = webDriver.findElement(By.xpath("//tbody/tr/td[contains(text(),'" + element + "')]"));
        je.executeScript("arguments[0].scrollIntoView(true);", Audit);
        Logger.info("Analyst Highligthed elements in  Audit page "+element+"");
    }
    @Then("Analyst search with {string} in Audit Log")
    public void analystSearchWithElementInAuditLog(String element) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.findElement(By.xpath("//div[@class='wu-audit-header']/mat-form-field//input")).click();
        webDriver.findElement(By.xpath("//div[@class='wu-audit-header']/mat-form-field//input")).sendKeys("" + element + "");
        Thread.sleep(2000);
        webDriver.manage().window().maximize();
        Thread.sleep(2000);
        List<WebElement> elementList = webDriver.findElements(By.xpath("//tr/td[last()-1]"));
        String finalelement = element;
        List<WebElement> FilteredList = elementList.stream().filter(s -> s.getText().contains("'" + finalelement + "'")).collect(Collectors.toList());
        Logger.info("Originalresult" + elementList + "filteredlist" + FilteredList);
    }
    @When("Analyst Clicks on Summary Button")
    public void analystClicksOnSummaryButton() throws InterruptedException {
        Thread.sleep(2000);
        caseInvestigationPage.clickOnSummarySubmit();
        Logger.info("Analyst Clicks on Summary Button");
        Thread.sleep(2000);

    }
    @When("Analyst Clicks on toggle button {string}")
    public void analystClicksOnToggleButton(String Toggle){
        WebDriver webDriver=BaseTestSetup.webDriver;
        Actions actions=new Actions(webDriver);
        WebElement togglebutton= webDriver.findElement(By.xpath("//button/span/span/u[contains(text(),'"+Toggle+"')]"));        actions.moveToElement(togglebutton).click().build().perform();
    }
    @Then("Anayst Validates Auditlog  TimeStampcreation")
    public void analystValidatesAuditLogTimeStampCreation() throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        String act = webDriver.findElement(By.xpath("//tr/td[last()]")).getText();
        Logger.info("'" + act + "'");
        webDriver.findElement(By.xpath("//thead/tr[1]/th[6]/div[1]/div[2]/div[1]")).click();
        webDriver.findElement(By.xpath("//thead/tr[1]/th[6]/div[1]/div[2]/div[1]")).click();
        Thread.sleep(2000);
        webDriver.manage().window().maximize();
        List<WebElement> elementList = webDriver.findElements(By.xpath("//tr/td[last()]"));
        List<String> originalList = elementList.stream().map(s -> s.getText()).collect(Collectors.toList());
        List<String> Sortedlist = originalList.stream().sorted().collect(Collectors.toList());
        Logger.info("Original list" + originalList);
        Logger.info("sorted list" + Sortedlist);
//        Assert.assertTrue(originalList.equals(Sortedlist));
        Logger.info("Analyst Verify Details In Entities" + Sortedlist);

    }

    @Then("Analyst unselects {string} checkbox")
    public void analystUnselectcheckbox(String typeName) throws InterruptedException {
        caseInvestigationPage.unselectCheckbox(typeName);
        Logger.info("Analyst unselected " +typeName+" casetype checkbox");
    }

    @Then("Analyst selects {string} checkbox")
    public void analystSelectcheckbox(String typeName) throws InterruptedException {
        caseInvestigationPage.selectCheckbox(typeName);
        Logger.info("Analyst selected " +typeName+" casetype checkbox");
    }

    @Then("Analyst manually resolved all failures")
    public void analystManuallyResolvedAllFailures() throws InterruptedException {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if (DbCount > 0) {
            List<WebElement> actFailure = caseInvestigationPage.getAllActionFailure();
            actFailurecount = actFailure.size();
            APICommonSteps apiCommonSteps = new APICommonSteps();
            apiCommonSteps.addCaseData("actFailureCount",actFailurecount);

            for (int i=0;i<actFailurecount;i++) {
                Thread.sleep(4000);
                String actFailurName = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[@class='mat-icon notranslate lh-20 wu-action-workflow-icon material-icons-outlined wu-cursor-pointer wu-anchor-link mat-icon-no-color ng-star-inserted'])["+(i+1)+"]//following-sibling::span")).getText();
                Actions actions = new Actions(BaseTestSetup.webDriver);
                actions.moveToElement(actFailure.get(i)).click().perform();
//                actFailure.get(i).click();
                Thread.sleep(3000);
                BaseTestSetup.webDriver.findElement(By.linkText("Yes")).click();
//                validatesToaster("Manual resolution has successfully updated in the system");
//                Logger.info("Analyst validate error message toaster ");
                String key = "actFailure"+Integer.toString(i);
                apiCommonSteps.addCaseData(key,actFailurName);

            }
            Logger.info("Analyst manually resolved all failures");
        }
    }

    private void validatesToaster(String toaster) {
        try {

            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            webDriver.navigate().refresh();
            JavascriptExecutor je = (JavascriptExecutor) webDriver;
            WebElement Dashboarddft = webDriver.findElement(By.xpath("//div/simple-snack-bar/span[contains(text(),'" + toaster + "')]"));
            je.executeScript("arguments[0].style.border='3px solid red'", Dashboarddft);
            Thread.sleep(500);
            String errormsg = Dashboarddft.getText();
            Assert.assertEquals(errormsg, toaster);
        } catch (Exception e) {
        Logger.info(e.getMessage());
        }
    }

    @And("Analyst verifies count of manually resolved features")
    public void analystVerifiesCountOfManuallyResolvedFeatures() {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if (DbCount > 0) {
            int actFailureResolvedCount = caseInvestigationPage.getAllActionFailureResolved().size();
            Assert.assertEquals(actFailurecount, actFailureResolvedCount, "Count of Failure and Failure Resolved matched.");
            Logger.info("Analyst verifies count of manually resolved features");
        }
    }

    @Then("Analyst verifies the Case Id as {string} in Case Header")
    public void analystVerifiesTheCaseIdAs(String ExpectedcaseId) throws InterruptedException {
        Thread.sleep(2000);
        String ActualCaseId = caseInvestigationPage.getHeaderCaseId().getText();
        Assert.assertEquals(ActualCaseId,ExpectedcaseId,"Verified the case id in case header");
    }
    @Then("Analyst verifies the caseRefNo in case Header")
    public void analystVerifiesTheCaseRefNo() throws InterruptedException {
        Thread.sleep(2000);
        String expectedCaseRefNo = getCaseData("caseRefNo");
        String ActualCaseRefNo = caseInvestigationPage.getCaseRefNo().getText();
        Assert.assertEquals(ActualCaseRefNo,expectedCaseRefNo,"Verified the case Ref no in case header");
    }
    @Then("Analyst verifies the Triggering Info in case Header")
    public void analystVerifiesTheTriggeringInfo() throws InterruptedException {
        Thread.sleep(2000);
        String expectedtrgInfo = getCaseData("trgInfo");
        String ActualtrgInfo = caseInvestigationPage.getTrgInfo().getText();
        Assert.assertEquals(ActualtrgInfo,expectedtrgInfo,"Verified the case triggering info in case header");
    }
}
