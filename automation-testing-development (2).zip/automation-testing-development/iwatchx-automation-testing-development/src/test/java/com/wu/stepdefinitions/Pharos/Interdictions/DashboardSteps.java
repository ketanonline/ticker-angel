package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.DashboardPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import net.serenitybdd.core.Serenity;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import sun.rmi.runtime.Log;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps.getCaseData;
import static org.hamcrest.MatcherAssert.assertThat;

public class DashboardSteps {
    DashboardPage dashboardPage = new DashboardPage();

    @Then("Analyst clicks on total count in RFW")
    public void analystclicksontotalcountinRFW() {
        DashboardPage.ClickOnTotalCountInRFW();
    }

    @And("Analyst enters Case Id {string} in Search")
    public void analystEntersCaseId(String inputText) {
        if (inputText.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            inputText = inputText.substring(inputText.indexOf("$") + 1);
            inputText = (String) getCaseData(inputText);
        }
        dashboardPage.enterCaseIdInSearchTextBox(inputText);
        Logger.info("Analyst enters CaseId : " + inputText);
    }

    @When("Analyst clicks on Search button on Case Retrieval")
    public void analystClicksOnSearchButton() throws InterruptedException {
        dashboardPage.clickOnSearchButton();
        Logger.info("Analyst clicks on Search button on Case Retrieval Button");
    }

    @Then("Analyst verifies {string} stage in Case Retrieval page")
    public void analystVerifiesCaseStageOnCaseRetrievalPage(String stage) {
        dashboardPage.validateCaseStage(stage);
    }

    @Then("Analyst verifies {string} disposition in Case Retrieval page")
    public void analystVerifiesCaseDisposition(String disposition) throws Exception {
        dashboardPage.validateCaseDisposition(disposition);
        Logger.info("Disposition displayed in UI is validated :" + disposition);
    }

    @Then("Analyst verifies {string} Tier in Case Retrieval page")
    public void analystVerifiesCaseTier(String tier) throws Exception {
        dashboardPage.validateCaseTier(tier);
        Logger.info("Disposition displayed in UI is validated :" + tier);
    }

    @When("Analyst clicks on Work Case button")
    public void clickOnWorkCaseButton() throws InterruptedException {
        dashboardPage.getWorkButton().click();
      //  dashboardPage.clickOnCaseActionButton("Work Case");
        Logger.info("Clicks on Work Case button");
    }

    @When("Analyst clicks on View Case button")
    public void clickOnViewCaseButton() throws InterruptedException {

            dashboardPage.clickOnCaseActionButton("View Case");
            Logger.info("Clicks on View Case button");

    }



    @When("Analyst saves CaseRefNo from Dashboard Page")
    public void saveCaseRefNo() throws InterruptedException {
        Thread.sleep(3000);
        APICommonSteps apiCommonSteps = new APICommonSteps();
        String caseRefNo = dashboardPage.getCaseRefNum().getText();
        apiCommonSteps.addCaseData("caseRefNo",caseRefNo);
        Logger.info("Analyst saves CaseRefNo from Dashboard Page");

    }
    @When("Analyst saves Triggering Info from Dashboard Page")
    public void saveTriggeringInfo() throws InterruptedException {
        APICommonSteps apiCommonSteps = new APICommonSteps();
        String trgInfo = dashboardPage.saveTriggeringPurpose().getText();
        apiCommonSteps.addCaseData("trgInfo",trgInfo);
        Logger.info("Analyst saves trgInfo from Dashboard Page");

    }
    @When("Analyst clicks on View Case button for Action Failure Widget")
    public void clickOnViewCaseButtonActionFailure() throws InterruptedException {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if (DbCount > 0) {
            dashboardPage.clickOnCaseActionButton("View Case");
            Logger.info("Analyst has clicked on view case");
        }
    }

    @When("Analyst clicks on {string} link")
    public void clickOnButton(String linkName) throws InterruptedException {
        dashboardPage.clickOnLink(linkName);
        Thread.sleep(2000);
        Logger.info("Clicks on LInk: " + linkName);
    }

    @Then("Analyst verifies view only label")
    public void userVerifiesSearchGrid() {
        dashboardPage.verifyViewOnlyLabel();
        Logger.info("Successfully verified view only indication at investigation screen ");
    }

    @Then("Analyst clicks on MyQueue")
    public void clicksMyQueue() throws Exception {
        dashboardPage.clickMyQueue();
    }

    @When("Analyst fetches the CaseID from dashboard results")
    public void fetchesCaseId() throws Exception {
        String caseID = dashboardPage.getCaseId().getText();
        Serenity.getCurrentSession().put("caseId", caseID);
    }

    @Then("Analyst verifies search result")
    public void analystVerifiesSearchResults() {
        if (dashboardPage.analystGetCaseIDSearchResults(Serenity.getCurrentSession().get("caseId").toString()) == null) {
            Logger.info(("Analyst didnt not found a case result with the given case id"));
        } else {
            Logger.info("Analyst found the case details in dashboard with the given case id :" + dashboardPage.analystGetCaseIDSearchResults(Serenity.getCurrentSession().get("caseId").toString()));
        }
    }

    @Then("Analyst verifies mode of visibility of work icon")
    public void analystVerifiesWorkIconModeOfVisibility() {
        dashboardPage.verifyAnalystVisibilityForWorkIcon();
        Logger.info("Successfully validated the work mode icon visibility with Analyst presence in UI");
        Assert.assertTrue(dashboardPage.getWorkCaseIcons(), "Verified my queue for work mode icon visibility for all availabe cases");
    }

    @Then("Analyst verifies the Search Grid details")
    public void analystVerifiesSearchGridResult() {
        dashboardPage.verifySearchGridFields();
        Logger.info("Successfully verified all the fields in Search grid");
        Logger.info("Successfully verified the order fields in Search grid");
    }

    @When("Analyst verifies Search Panel")
    public void userVerifiesSearchPanel() {
        dashboardPage.verifySearchPanel();
    }
    @When("Analyst verifies Action Failure widget presence")
    public void userVerifiesActionFailureWidgetPresence() {
        dashboardPage.verifyActionFailureWidget();
        Logger.info("User verifies the presence of action failure widget");
    }

    @And("Analyst enters Case ID and MTCN")
    public void analystEntersCaseIdAndMTCN() throws InterruptedException {
        dashboardPage.entersCaseId(Serenity.getCurrentSession().get("caseId").toString());
        dashboardPage.enterMTCNWithoutClearing(Serenity.getCurrentSession().get("MTCN").toString());
    }

    @And("Analyst enters MTCN")
    public void userEntersMTCN() throws InterruptedException {
        dashboardPage.entersMTCN(Serenity.getCurrentSession().get("MTCN").toString());
    }

    @Then("Analyst clicks on Reset button")
    public void ResetButtonClick() throws InterruptedException {
        dashboardPage.verifyResetOptionFunctionality();
        Logger.info("Analysts Clicks on Reset button and validates the data has been reset or not");
    }

    @And("Analyst enters Invalid CaseID")
    public void userEntersInvalidCaseID() throws InterruptedException {
        dashboardPage.entersCaseId("2@sdh@bdhhhq132376u57657vc");
        dashboardPage.clickGetCaseBtn();
    }

    @And("Analyst enters Invalid MTCN")
    public void userEntersInvalidMTCN() throws InterruptedException {
        dashboardPage.entersMTCN("2@sdh@bdhhhq132376u57657vc");
        dashboardPage.clickGetCaseBtn();
    }

    @Then("Analyst verifies invalid MTCN Message {string}")
    public void verifyErrorMessage(String message) throws InterruptedException {
        dashboardPage.validateErrorMessageMTCN(message);
        Logger.info("Analyst verifies the error messsage on invalid MTCN");
    }

    @Then("Analyst verifies invalid CaseId Message {string}")
    public void verifyCaseIdErrorMessage(String message) throws InterruptedException {
        dashboardPage.validateErrorMessageCaseId(message);
        Logger.info("Analyst verifies the error messsage on invalid Case ID");
    }

    @Then("Analyst verifies invalid Case Ref Message1 {string}")
    public void verifyErrorMessageCaseRef1(String message) throws InterruptedException {
        dashboardPage.validateErrorMessageCaseRef1(message);
        Logger.info("Analyst verifies the error messsage on invalid Case ref : " + message);
    }

    @Then("Analyst verifies invalid Case Ref Message2 {string}")
    public void verifyErrorMessageCaseRef2(String message) throws InterruptedException {
        dashboardPage.validateErrorMessageCaseRef2(message);
        Logger.info("Analyst verifies the error messsage on invalid Case ref : " + message);
    }

    @Then("Analyst verifies invalid Case Ref Message3 {string}")
    public void verifyErrorMessageCaseRef3(String message) throws InterruptedException {
        dashboardPage.validateErrorMessageCaseRef3(message);
        Logger.info("Analyst verifies the error messsage on invalid Case ref : " + message);
    }

    @Then("Analyst enters {string} caseId")
    public void entersCaseId(String caseId) throws Exception {
        dashboardPage.entersCaseId(caseId);
        Logger.info("Analysts enters case Id: " + caseId);
    }

    @Then("Verifies the autoredaction of CaseID string {string}")
    public void verifyCaseIDStringAutoredaction(String caseid) {
        dashboardPage.verifiesAutoRedactioCaseIDField(caseid);
    }

    @And("Analyst enters CaseID with Upper case {string}")
    public void analystEntersUpperCaseId(String inputText) {
        if (inputText.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            inputText = inputText.substring(inputText.indexOf("$") + 1);
            inputText = (String) getCaseData(inputText);
        }
        String caseIDUpper = inputText.toUpperCase();
        dashboardPage.entersCaseId(caseIDUpper);
    }

    @And("Analyst enters CaseID with Lower case {string}")
    public void analystEnterslowerCaseId(String inputText) {
        if (inputText.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            inputText = inputText.substring(inputText.indexOf("$") + 1);
            inputText = (String) getCaseData(inputText);
        }
        String caseIDLower = inputText.toLowerCase();
        dashboardPage.entersCaseId(caseIDLower);
    }

    @Then("Analyst verifies the error message {string}")
    public void caseSearchErrorMsg(String msg) throws Exception {
        String tstValue = dashboardPage.getToaster().getAttribute("innerHTML");
        System.out.println(tstValue);

        if (tstValue.contains(msg))
            Logger.info("Case retrieval failed");
        else
            Logger.info("case retrieval success:" + tstValue);
    }

    @Then("Analyst verifies {string} tab is displayed in left navigation panel")
    public void analystVerifiesTabIsDisplayed(String tabName) throws Exception {
        String actTabName = dashboardPage.getButton(tabName).getText().trim();
        assertThat("The Following tab is displayed in menu: ", actTabName.equals(tabName));
        Logger.info("The Following tab is displayed in menu: " + actTabName);
    }

    @Then("Analyst verifies {string} tab is not displayed in left navigation panel")
    public void analystVerifiesTabIsNotDisplayed(String tabName) throws Exception {
        org.junit.Assert.assertEquals(0, BaseTestSetup.webDriver.findElements(By.xpath("//span[contains(text(),'\"+tabName+\"')]")).size());
        Logger.info("The Following tab is not displayed in menu: " + tabName);
    }

    @Then("Verify Pharos logo changes")
    public void analystVerifiesPharosLogo() throws Exception {
        boolean isPresent = dashboardPage.getPharosLogoIcon().isDisplayed();
        assertThat("Pharos logo icon validation ", isPresent);
        Logger.info("Pharos logo icon validation " + isPresent);
    }

    @Then("Verify Employee name displayed at hamburger section")
    public void employeeDetailsDashboard() throws Exception {
        boolean isPresent = dashboardPage.getEmpName().isDisplayed();
        String name = dashboardPage.getEmpName().getText();
        assertThat("Verified the Employee name at hamburger section", isPresent);
        Logger.info("Verified the Employee name at hamburger section " + isPresent);
        Logger.info("Verified the Employee name as : " + name);
    }

    @Then("Verify Employee ID displayed at hamburger section")
    public void employeeIDDashboard() throws Exception {
        boolean isPresent = dashboardPage.getEmpId().isDisplayed();
        String id = dashboardPage.getEmpId().getText();
        assertThat("Verified the Employee ID at hamburger section", isPresent);
        Logger.info("Verified the Employee ID at hamburger section " + isPresent);
        Logger.info("Verified the Employee ID as : " + id);
    }

    @When("Verify Dashboard label in launching screen")
    public void verifyDashboard() throws InterruptedException {
        dashboardPage.verifyHamburgerMenuDashboardOption();
        Logger.info("Analyst verified Dashboard option from launching screen");
    }

    @When("Analyst select Genre dropdown and value as {string}")
    public void userSelectsGenre(String option) throws InterruptedException {
        Thread.sleep(2000);
        dashboardPage.selectGenreDropdown(option);
    }

    @When("Analyst select case type dropdown and value as {string}")
    public void userSelectsCaseType(String option) {
        dashboardPage.selectCaseTypeDropdown(option);
    }

    @When("GetCase panel should be opened with title {string}")
    public void getCasePanelShouldBeOpened(String title) throws InterruptedException {
        dashboardPage.verifyGetCasePanelTitle(title);
    }

    @When("Analyst click on Get Case button")
    public void userClicksGetCaseBtn() throws InterruptedException {
        dashboardPage.clickGetCaseBtn();
    }

    @Then("Analyst retrieves Case Reference Number and Creation Timestamp from dashboard")
    public void analystRetrievesCaseRefNo() throws Exception {
        String value = dashboardPage.getCaseReferenceNumAndTimeStamp();
        String[] arrValue = value.split("&");
        Serenity.getCurrentSession().put("caseRefNum", arrValue[0]);
        String[] ts = arrValue[1].split(",");
        String[] date = ts[0].split(" ");
        if (date[1].length() == 1)
            date[1] = "0" + date[1];
        date[0] = date[0].toUpperCase();
        String finDate = date[1] + "-" + date[0] + "-" + date[2];
        Serenity.getCurrentSession().put("createdDate", finDate);

        String[] creatTs = ts[1].split(" ");
        String finTS = creatTs[1];
        Serenity.getCurrentSession().put("createdTimeStamp", finTS);

        String input = finTS;
        DateFormat df = new SimpleDateFormat("hh:mm");
        DateFormat outputformat = new SimpleDateFormat("HH:mm");
        Date dates = null;
        String output = null;
        try {
            dates = df.parse(input);
            output = outputformat.format(dates);
            System.out.println(output);
        } catch (ParseException pe) {
            pe.printStackTrace();
        }
        finTS = output;
        Serenity.getCurrentSession().put("createdTimeStamp", finTS);
        Serenity.getCurrentSession().put("MTCN", arrValue[2]);
    }

    @And("Below values should be displayed in the Investigativefocus Dropdown")
    public void valuesDisplayedInTheInvsFocusDropdown(DataTable type) throws InterruptedException {
        dashboardPage.selectInvestigationFocusDropdown();
        Thread.sleep(2000);
        List<String> typeValuesList = type.asList(String.class);
        boolean res = dashboardPage.invsFocusDropDownValidation(typeValuesList);
        System.out.println("*********" + res);
        Assert.assertTrue(res, "TestPassed and drop down values are displayed as expected");
        dashboardPage.selectInvestigationFocus("Sanctions");
    }

    @Then("Analyst select Investigation Focus dropdown and value as {string}")
    public void analystSelectInvestigationFocusDropdownAndValueAs(String option) {
        System.out.println("Investigation Focus box selection");
        dashboardPage.selectInvestigationFocusDropdown();
        dashboardPage.selectInvestigationFocus(option);
        Logger.info("Analyst selects Investigation Focus dropdown with value Interdiction");
    }

    @Then("Analyst select Tier dropdown and value as {string}")
    public void analystSelectTierDropdownAndValueAs(String option) throws InterruptedException {
        System.out.println("Tier box selection");
        dashboardPage.selectTierDropdown(option);
//        dashboardPage.selectTier(option);
        Logger.info("Analyst selects Tier dropdown with value Standard Investigation");
    }

    @Then("Analyst verifies RFW widget on dashboard screen with title {string}")
    public void analystVerifiesRFWWidgetOnDashboardScreen(String title) throws InterruptedException {
        dashboardPage.verifyRFWtitle(title);
        System.out.println("RFW title verified");

    }

    @Then("analyst verifies Standard Investigation tier on RFW widget with title {string}")
    public void analystVerifiesStandardInvestigationtier(String title) throws InterruptedException {
        dashboardPage.verifyStandardInvestigationtitle(title);
        System.out.println("Standard Investigation title verified");
    }

    @Then("analyst verifies Enhanced Investigation tier on RFW widget with title {string}")
    public void analystVerifiesEnhancedInvestigationtier(String title) throws InterruptedException {
        dashboardPage.verifyEnhancedInvestigationtitle(title);
        System.out.println("Enhanced Investigation title verified");
    }

    @Then("analyst verifies Advanced Investigation tier on RFW widget with title {string}")
    public void analystVerifiesAdvancedInvestigationtier(String title) throws InterruptedException {
        dashboardPage.verifyAdvancedInvestigationtitle(title);
        System.out.println("Advanced Investigation title verified");
    }

    @Then("Analyst verifies case pull functionality for Standard Investigation on RFW Widget")
    public void analystVerifiesStandardInvestigationCasePull(String title) throws InterruptedException {
        dashboardPage.verifyStandardInvestigationCasepullButton();
        System.out.println("Standard investigation case pull button is enabled");
    }

    @Then("Analyst clicks on Work for Sanctions case from pulled cases")
    public void clickOnWorkPulledCase() {
        WebElement btnWork = BaseTestSetup.webDriver.findElement(By.xpath("//table//tbody/tr[1]/td[11]/span/button[2]"));
        if (btnWork.isDisplayed()) {
            btnWork.click();
            Logger.info("Clicked on work on case button");
        } else {
            Logger.error("Work option not available for pulled case");
        }
    }

    @When("Analyst selects Tier dropdown and value as {string}")
    public void userSelectsTier(String option) throws Exception {
        dashboardPage.selectTierDropdown(option);
    }

    @When("Analyst Clicks {string} keys to add reasons on Entities")
    public void analystClickskeystoaddreasonsonEntities(String tokens) {
        String[] listOfKeys = tokens.split(",");
        for (int i = 0; i < listOfKeys.length; i++) {
            String keys = listOfKeys[i];

            int key1 = 0, key2 = 0;
            key1 = 18;
            switch (keys) {
                case "Shift+A":
                    key1 = 16;
                    key2 = 65;
                    break;
                case "Shift+B":
                    key1 = 16;
                    key2 = 66;
                    break;
                case "Shift+C":
                    key1 = 16;
                    key2 = 67;
                    break;
                case "Shift+D":
                    key1 = 16;
                    key2 = 68;
                    break;
                case "Shift+E":
                    key1 = 16;
                    key2 = 69;
                    break;
                case "Shift+G":
                    key1 = 16;
                    key2 = 70;
                    break;
                case "Shift+I":
                    key1 = 16;
                    key2 = 71;
                    break;
                case "Shift+J":
                    key1 = 16;
                    key2 = 72;
                    break;
            }
            try {
                Robot robot = new Robot();
                robot.keyPress(key1);
                Thread.sleep(3000);
                robot.keyPress(key2);
                robot.keyRelease(key1);
                robot.keyRelease(key2);

                Logger.info("Analyst sends " + keys + " on selected Entity");
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    @Then("Analyst clicks on {string} Icon")
    public void analystclicksonIcon(String Expand) {
        DashboardPage.ClickOnIcon(Expand);

    }

    //    @Then("Analyst clicks on {string} link from RFW widget")
//    public void analystclicksonlinkfromRFWwidget(String tier) {
//        DashboardPage.clicksTierLink(tier);
//    }
    @Then("Analyst clicks on sorting for creation timestamp")
    public void analystclicksonsortingforcreationtimestamp() {
        DashboardPage.ClickOnSorting();
    }

    @Then("Analyst clicks on the filters in the grid")
    public void analystclicksonthefiltersinthegrid() throws InterruptedException {
        DashboardPage.ClicksOnFilters();
    }

    @And("Analyst verifies the title of the side column is {string}")
    public void analystVerifiesSideColumn(String columnName){
        DashboardPage.verifySideColumnTitle(columnName);
        Logger.info("Title of the side column is verified");
    }

    @And("Analyst clicks on the review type filter")
    public void analystClicksOnReviewTypeFilter(){
        DashboardPage.clickOnReviewTypeFilter();
    }

    @And("Analyst should be able to click on all filter options of review type column")
    public void analystVerifiesAllFilterOptionsOfReviewType() throws InterruptedException {
        dashboardPage.verifyAllFilterOptionsOfReviewType();

    }

    @Then("Analyst verifies GID and sorting for Due date in case grid list")
    public void analystverifiesGIDAndSortingForDueDate() throws InterruptedException {
        DashboardPage.ClickOnSortings();
    }

    @Then("Analyst clicks on Close button in the grid")
    public void analystclicksonClosebuttoninthegrid() {
        DashboardPage.ClickOnClose();
    }

    @Then("Analyst verifies {string} in the header of SI grid")
    public void verifyGridHeader(String HeaderName) throws Exception {

        Boolean ele = dashboardPage.getGridHeader(HeaderName).isDisplayed();
        if (ele) {
            Logger.info("Column header :" + HeaderName + " is displayed");
        } else {
            Logger.error("Column header :" + HeaderName + " is not displayed");
        }
    }
    @Then("Analyst verifies {string} in the header after checking the cases for {string} in {string}")
    public void verifyGridHeaderAfterChckingCases(String HeaderName, String fieldName,String type) throws Exception {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB") ) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB") ) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB") ) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Boolean ele = dashboardPage.getGridHeader(HeaderName).isDisplayed();
            if (ele) {
                Logger.info("Column header :" + HeaderName + " is displayed");
            } else {
                Logger.error("Column header :" + HeaderName + " is not displayed");
            }
        }
        else{
            Logger.info("Cases are not there for User clicks on Widget " +fieldName +" "  +type);
        }
    }
    @Then("Analyst verifies {string} in the header of SI grid is not present")
    public void verifyGridHeaderNotPresent(String HeaderName) throws Exception {

        int ele = dashboardPage.getGridHeaderSize(HeaderName).size();

            Assert.assertTrue(ele==0,"Column header :" + HeaderName + " is displayed");
            Logger.info("Column header :" + HeaderName + " is displayed");

    }
    @Then("Analyst verifies {string} in the header is not present after checking the cases for {string} in {string}")
    public void verifyGridHeaderNotPresentAfterCheckingCases(String HeaderName ,String fieldName,String type) throws Exception {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB") ) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB") ) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB") ) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            int ele = dashboardPage.getGridHeaderSize(HeaderName).size();

            Assert.assertTrue(ele == 0, "Column header :" + HeaderName + " is not displayed");
            Logger.info("Column header :" + HeaderName + " is not displayed");
        }
        else{
            Logger.info("Cases are not there for User clicks on Pending Info Widget " +fieldName +" "  +type);
        }
    }
    @Then("Analyst clicks on Tier dropdown")
    public void analystclicksTierDropdown() throws Exception {
        dashboardPage.selectTierbox();
    }

    @Then("Analyst clicks on Tier dropdown and value as {string}")
    public void analystclicksTierDropdown(String option) throws Exception {
        dashboardPage.selectTierbox(option);
    }

    @Then("Analyst verifies GetCase button is disabled")
    public void analystVerifiesGetCaseButton() {
        dashboardPage.verifyGetCaseBtn();
    }

    @Then("Analyst should receive toast message")
    public void analystShouldReceiveToastMessage() {
        String tstValue = dashboardPage.getmyqueueToaster().getAttribute("innerHTML");
        System.out.println(tstValue);
        if (tstValue.contains("Unable to get my queue. Please retry."))
            Logger.info("Unable to get myqueue message appeared");
        else
            Logger.info("message not appeared" + tstValue);
    }

    @And("Analyst enters MTCN {string} in Search")
    public void analystEntersMTCN(String inputText) {
        if (inputText.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            inputText = inputText.substring(inputText.indexOf("$") + 1);
            inputText = (String) getCaseData(inputText);
        }
        dashboardPage.enterMTCNInSearchTextBox(inputText);
        Logger.info("Analyst enters MTCN : " + inputText);
    }


    @Then("Analyst verifies mode of visibility of view icon")
    public void analystVerifiesviewIconModeOfVisibility() {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0) {
            dashboardPage.verifyAnalystVisibilityForviewIcon();
            Logger.info("Successfully validated the view mode icon visibility");
        }
    }

    @Then("Analyst clicks on CLTR F button and enters text")
    public void analystclicksonCLTRFbuttonandenterstext() {
        try {
            Thread.sleep(5000);
            dashboardPage.ctrlF();
            Thread.sleep(5000);
        } catch (Exception e) {

        }

    }

    public void ctrlF() {
        //Actions action = new Actions(BaseTestSetup.webDriver);
        //action.keyDown(Keys.CONTROL).sendKeys("f").keyUp(Keys.CONTROL).build().perform();
        try {
            //Create Robot class
            Robot rb = new Robot();
            rb.keyPress(KeyEvent.VK_CONTROL);
            //Thread.sleep(1000);
            rb.keyPress(KeyEvent.VK_F);
            rb.keyRelease(KeyEvent.VK_F);
            rb.keyRelease(KeyEvent.VK_CONTROL);
            Thread.sleep(1000);
            rb.keyPress(KeyEvent.VK_I);
            rb.keyRelease(KeyEvent.VK_I);
            rb.keyPress(KeyEvent.VK_D);
            rb.keyRelease(KeyEvent.VK_D);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }


    @Then("Analyst validates the step after expansion")
    public void analystvalidatesthestepafterexpansion() {
        dashboardPage.getinfotext();
    }

    @When("Analyst Verify PartyActivity Information")
    public void analystVerifyPartyActivityInformation() {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        List<WebElement> elementList = webDriver.findElements(By.xpath("//app-transaction-hit-details[1]/div[1]"));
        List<String> originalList = elementList.stream().map(s -> s.getText()).collect(Collectors.toList());
        List<String> Sortedlist = originalList.stream().sorted().collect(Collectors.toList());
        Assert.assertTrue(originalList.equals(Sortedlist));
        Logger.info("Analyst Verify PartyActivity Information" + originalList);
    }

    @When("Analyst Verify Details In Entities {string}")
    public void analystVerifyDetailsInEntities(String Entity) {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        List<WebElement> elementList = webDriver.findElements(By.xpath("//app-hit-" + Entity));
        List<String> originalList = elementList.stream().map(s -> s.getText()).collect(Collectors.toList());
        List<String> Sortedlist = originalList.stream().sorted().collect(Collectors.toList());
        Assert.assertTrue(originalList.equals(Sortedlist));
        Logger.info("Analyst Verify Details In Entities" + originalList);

    }

    @And("Analyst verifies elements Present Search Grid {string}")
    public void analystVerifiesActSearchGridDetails(String caseId) {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        List<WebElement> elementList = webDriver.findElements(By.xpath("//tbody/tr[1]"));
        List<String> originalList = elementList.stream().map(s -> s.getText()).collect(Collectors.toList());
        String finalCaseId = caseId;
        List<String> genericvalues = elementList.stream().filter(s -> s.getText().contains("'" + finalCaseId + "'")).map(s -> getgenericvalues(s)).collect(Collectors.toList());
        genericvalues.forEach(a -> System.out.println(a));
        Logger.info("Analyst Verify Details In Entities" + originalList);

    }

    private static String getgenericvalues(WebElement s) {
        String generic = s.findElement(By.xpath("following-sibling::td[1]"));
        return generic;
    }

    @Then("Analyst verifies Stage Search Grid {string}")
    public void analystVerifiesStageSearchGrid(String Stage) {
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        List<WebElement> elementList = webDriver.findElements(By.xpath("//tbody/tr[1]"));
        List<String> originalList = elementList.stream().map(s -> s.getText()).collect(Collectors.toList());
        List<String> StageValue = elementList.stream().filter(s -> s.getText().contains("'" + Stage + "'")).map(s -> getStage(s)).collect(Collectors.toList());
        StageValue.forEach(a -> System.out.println(a));
        Assert.assertFalse(originalList.isEmpty(),"No search is found for the result");
//        Logger.info("Analyst Verify Details In Entities" + originalList);

    }

    private static String getStage(WebElement s) {
        String valueofStage = s.findElement(By.xpath("following-sibling::td[1]"));
        return valueofStage;
    }

    @And("Analyst enters CaseRefNo {string} in Search")
    public void analystEntersCaseRefNo(String inputText) {
        if (inputText.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            inputText = inputText.substring(inputText.indexOf("$") + 1);
            inputText = (String) getCaseData(inputText);
        }
        dashboardPage.enterCaseRefNoInSearchTextBox(inputText);
        Logger.info("Analyst enters CaseRefNo : " + inputText);
    }

    @Then("Analyst verifies if Work button is {string}")
    public void analystVerifyWorkbuttonPresentOrNot(String presentNotPresent) {
            List<WebElement> workBtn = BaseTestSetup.webDriver.findElements(By.xpath("//mat-icon[contains(text(),'work_outline')]"));
            //Boolean workBtnIsPresent = workBtn.isDisplayed();
            System.out.println("*****" + presentNotPresent);
            if (presentNotPresent.equalsIgnoreCase("present")) {
                System.out.println("Entered present block");
                if (workBtn.size() > 0) {
                    Logger.info("Work button is present for Pre-tier cases");
                } else {
                    Logger.error("Work button is not present for Pre-tier cases");
                    Assert.assertEquals(true, false, "Work button is not present");
                }
            } else {
                System.out.println("Entered not present block");
                if (workBtn.size() == 0) {
                    Logger.info("Work button is not present for Pre-tier cases");

                } else {
                    Logger.error("Work button is present for Pre-tier cases");
                    Assert.assertEquals(true, false, "Work button is present");
                }
            }
        }
    @Then("Analyst verifies if Work button with {string} is {string}")
    public void analystVerifyWorkbuttonPresentOrNot( String inputText , String presentNotPresent) {
        if (inputText.contains("$")) {
            APICommonSteps apiCommonSteps = new APICommonSteps();
            inputText = inputText.substring(inputText.indexOf("$") + 1);
            inputText = (String) getCaseData(inputText);
        }
        WebElement workBtn = BaseTestSetup.webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard//tr[td[contains(text(),'"+inputText+"')]]//mat-icon[contains(text(),'work_outline')]"));
        //Boolean workBtnIsPresent = workBtn.isDisplayed();
        System.out.println("*****" + presentNotPresent);
        if (presentNotPresent.equalsIgnoreCase("present")) {
            System.out.println("Entered present block");
            if (workBtn.isDisplayed()) {
                Logger.info("Work button is present for Pre-tier cases");
            } else {
                Logger.error("Work button is not present for Pre-tier cases");
                Assert.assertEquals(true,false,"Work button is not present"); //To fail the test
            }
        } else {
            System.out.println("Entered not present block");
            System.out.println(workBtn.isDisplayed());
            if (workBtn.isDisplayed()) {
                Logger.error("Work button is present for Pre-tier cases");
                Assert.assertEquals(true,false,"Work button is present");

            } else {
                Logger.info("Work button is not present for Pre-tier cases");
            }
        }
    }


    @Then("Analyst Clicks on Reminttance button")
    public void analystclicksonRemittance() throws InterruptedException {
        dashboardPage.selectanalystclicksonRemittance();
        dashboardPage.selectanalystclicksonRemittancedropdown();
    }

    @When("Analyst select Activity type dropdown and value as {string}")
    public void userSelectsActivityType(String option) throws InterruptedException {
        dashboardPage.selectActivityTypeDropdown(option);
    }

    @When("Analyst Validates Widget Creationtimestamp")
    public void analystValidatesWidgetCreationtimestamp() throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        String Actwidget = webDriver.findElement(By.xpath("//tbody/tr[1]/td[4]")).getText();
        Logger.info("before sorting timestamp'" + Actwidget + "'");
        Thread.sleep(2000);
        webDriver.manage().window().maximize();
        WebElement Timestampbutton = webDriver.findElement(By.xpath("//div[contains(text(),'Creation Timestamp')]"));
        Actions actions = new Actions(webDriver);
        actions.moveToElement(Timestampbutton).click().build().perform();
        String ExpWidget = webDriver.findElement(By.xpath("//tbody/tr[1]/td[4]")).getText();
        Logger.info("before sorting timestamp'" + ExpWidget + "'");
        Assert.assertNotEquals(Actwidget, ExpWidget, "shorting of widget timestamp is not working");
        Thread.sleep(4000);
    }

    @Then("Analyst Verifies CasId {string} is present in Dashboardwidget")
    public void analystVerifiesCaseIdPresentinDashboard(String caseId) {
        if (caseId.contains("$")) caseId = caseId.substring(caseId.indexOf("$") + 1);
        caseId = getCaseData(caseId).toString();
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        List<WebElement> elementList = webDriver.findElements(By.xpath("//table[1]"));
        List<String> originalList = elementList.stream().map(s -> s.getText()).collect(Collectors.toList());
        List<String> StageValue;
        do {
            List<WebElement> elementList1 = webDriver.findElements(By.xpath("//table[1]"));
            String finalCaseId = caseId;
            StageValue = elementList1.stream().filter(s -> s.getText().contains("'" + finalCaseId + "'")).map(s -> get1Stage(s)).collect(Collectors.toList());
            StageValue.forEach(a -> System.out.println(a));
            Logger.info("Gsi case present in the 100 Records in Dashboard this " + StageValue + "");
            Assert.assertEquals(caseId, finalCaseId, "Gsi case not present in 100 Records in Dashboard");
            if (StageValue.size() > 1) {
                webDriver.findElement(By.xpath("//*[@aria-label='Next page']")).click();
            }
        } while (StageValue.size() > 1);


    }

    private static String get1Stage(WebElement s) {
        String valueofStage1 = s.findElement(By.xpath("following-sibling::td[1]"));
        return valueofStage1;
    }

    @Then("Analyst click InvestigationFocus seaching with {string} and Stage as {string}")
    public void analystClickInvestigationFocusSearchingWith(String Invgrp, String Focus) throws InterruptedException {
        try {
            WebDriver webDriver = BaseTestSetup.webDriver;
            Actions actions = new Actions(webDriver);
            WebElement Filtericon = webDriver.findElement(By.xpath("//thead/tr[1]/th[5]/div[1]/mat-icon[1]"));
            Filtericon.click();
            Thread.sleep(2000);
            WebElement Searchopt = webDriver.findElement(By.xpath("//*[@id='mat-input-5'][@data-placeholder='Search']"));
            actions.moveToElement(Searchopt).click().sendKeys("" + Invgrp + "").build().perform();
            Thread.sleep(2000);
            WebElement selectopt = webDriver.findElement(By.xpath("//span[contains(text(),'" + Invgrp + "')]"));
            actions.moveToElement(selectopt).click().build().perform();
            Thread.sleep(2000);
            actions.moveToElement(Filtericon).click().build().perform();
            WebElement Filtericon1 = webDriver.findElement(By.xpath("//thead/tr[1]/th[6]/div[1]/mat-icon[1]"));
            Filtericon1.click();
            Thread.sleep(2000);
            WebElement Searchopt1 = webDriver.findElement(By.xpath("//*[@id='mat-input-6'][@data-placeholder='Search']"));
            actions.moveToElement(Searchopt1).click().sendKeys("" + Focus + "").build().perform();
            Thread.sleep(2000);
            WebElement selectopt1 = webDriver.findElement(By.xpath("//span[contains(text(),'" + Focus + "')]"));
            actions.moveToElement(selectopt1).click().build().perform();
            Thread.sleep(2000);
            actions.moveToElement(Filtericon1).click().build().perform();
            Logger.info("Analyst click InvestigationFocus seaching with "+Invgrp+" and Stage as "+Focus+"");
        } catch (Exception e) {

        }

    }
    @When("Analyst clicks on DashBoard Work Case button")
    public void clickOnDashboadWorkCaseButton() throws InterruptedException {
        dashboardPage.clickOnDashboardActionButton();
        Logger.info("clicks on DashBoard Work Case button");
    }
    @Then("Analyst verifies {string} as analystname in Case Retrieval page for Role {string}")
    public void analystVerifiesAnalystnameOnCaseRetrievalPage(String Analyst,String Role) throws Exception {
        dashboardPage.ValidatesAnalystname(Analyst,Role);
    }
    @When("Analyst clicks on SettingsPage")
    public void clickOnSettingPage() throws InterruptedException {
        dashboardPage.clickonSettingPage();
        Thread.sleep(2000);
        Logger.info("Analyst clicks on SettingPage");
    }
    @Then("Analyst Clicks on setting tab genre as {string} business group as {string}")
    public void analystClicksonSettingTabgenreandBussinessgroup(String Genre, String bggroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        webDriver.manage().window().maximize();
        WebElement arrow=webDriver.findElement(By.cssSelector(".mat-select-arrow.ng-tns-c104-15"));
        act.moveToElement(arrow).click().build().perform();
        Thread.sleep(1000);
        webDriver.findElement(By.xpath("//mat-option/span[contains(text(),'" + Genre + "')]")).click();
        Thread.sleep(2000);
        webDriver.findElement(By.xpath("//div[@class='mat-select-arrow ng-tns-c104-17']")).click();
        Thread.sleep(2000);
//        List<WebElement> Businessgroupelements = webDriver.findElements(By.xpath("//*[@id='cdk-overlay-2']"));
//        String listelements = String.valueOf(Businessgroupelements.size());
//        for (int i = 1; i <= Businessgroupelements.size(); i++) {
//
//            String elemnents = Businessgroupelements.get(i).getText().trim();
//            if (elemnents.contains("BKYC") && (elemnents.contains("GSI"))) {
//                Logger.info("Business drop down contains BKYC or GSI GROUP ");
//            } else {
//                Logger.info("Failed due Business drop down has missing value");
//
//            }
//            Assert.assertTrue(!listelements.isEmpty());
//        }
        WebElement Businessgroup = webDriver.findElement(By.xpath("//mat-option[@role='option']/span[contains(text(),'" + bggroup + "')]"));
        act.moveToElement(Businessgroup).click().build().perform();
        String actualbg = Businessgroup.getText();
        Thread.sleep(2000);
        Assert.assertEquals(actualbg, bggroup);
        Logger.info("Analyst Clicks on setting tab genre as " + Genre + " business group as " + bggroup + "");
    }

    @Then("Analyst Clicks on setting tab genre as {string} Unable to select business group as {string} for supervisor role")
    public void analystUnableTOSELectBusinessgroupForSupervisor(String Genre, String bggroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        webDriver.manage().window().maximize();
        WebElement element = webDriver.findElement(By.xpath("//a/span[contains(text(),'Settings')]"));
        act.moveToElement(element).click().build().perform();
        Thread.sleep(2000);
        webDriver.findElement(By.xpath("//div[@class='mat-select-trigger ng-tns-c104-15']")).click();
        Thread.sleep(1000);
        webDriver.findElement(By.xpath("//mat-option/span[contains(text(),'" + Genre + "')]")).click();
        Thread.sleep(2000);
        List<WebElement> Businessgroupdropdown = webDriver.findElements(By.xpath("//div[@class='mat-form-field-infix ng-tns-c102-17']"));
        try {

            int elemenlist = Businessgroupdropdown.size();

            boolean bflag = true;
            for (int i = 1; i <= elemenlist; i++) {
                WebElement ele = webDriver.findElement(By.xpath("//mat-option[@role='option']/span[contains(text(),'" + bggroup + "')]"));
                String actDEsc = ele.getText().trim();
                WebElement GSIbg = webDriver.findElement(By.xpath("//mat-option[@role='option']/span[contains(text(),'GSI')]"));
                String GSI = GSIbg.getText().trim();
                if (actDEsc.isEmpty()) {
                    bflag = false;
                    break;
                }
            }
            Assert.assertTrue(bflag, "Businessgroup elements present in the Busiinessgroup");
        } catch (Exception e) {

        }

        Logger.info("Analyst Clicks on setting tab genre as " + Genre + " Unable to select business group as " + bggroup + " for supervisor role");

    }

    @Then("Analyst Clicks on setting tab genre as {string} Unable to select business group as {string} for InvestigatorViewer role")
    public void analystUnableTOSELectBusinessgroupForInvestigatorViewer(String Genre, String bggroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        webDriver.manage().window().maximize();
        WebElement element = webDriver.findElement(By.xpath("//a/span[contains(text(),'Settings')]"));
        act.moveToElement(element).click().build().perform();
        Thread.sleep(2000);
        webDriver.findElement(By.xpath("//div[@class='mat-select-trigger ng-tns-c104-15']")).click();
        Thread.sleep(1000);
        webDriver.findElement(By.xpath("//mat-option/span[contains(text(),'" + Genre + "')]")).click();
        Thread.sleep(2000);
        List<WebElement> Businessgroupdropdown = webDriver.findElements(By.xpath("//div[@class='mat-select-arrow ng-tns-c104-18']"));
        try {

            for (int i = 1; i <= Businessgroupdropdown.size(); i++)
                if (Businessgroupdropdown.isEmpty()) {
                    Logger.info("Businessgroupdrop didnt have any value");
                    System.out.println(Businessgroupdropdown.get(i).getText());
                } else {
                    Logger.info("failed due to Businessgroupdrop having values");
                }


        } catch (Exception e) {

        }
        Logger.info("Analyst Clicks on setting tab genre as " + Genre + " Unable to select business group as " + bggroup + " for supervisor role");

    }

    @When("Analyst Verifies Business group as {string} from DashBoard page")
    public void analystVerifiesBusinessGroupas(String Businessgroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        webDriver.manage().window().maximize();
        WebElement actbggroup = webDriver.findElement(By.xpath("//div[@id='mat-select-value-13']/span/span[contains(text(),'" + Businessgroup + "')]"));
        String actbg = actbggroup.getText();
        je.executeScript("arguments[0].style.border='5px solid red'", actbggroup);
        Thread.sleep(2000);
        Assert.assertEquals(Businessgroup, actbg);
        Logger.info("Dashbaord Business group " + Businessgroup + "matched with the Saved business group" + actbg + "");
    }

    @When("Analyst Validates all avaliable business groups getting displayed in dashboard page with Viewerrole {string}")
    public void analystValidatesBusinessGroupas(String Businessgroup) throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        Actions act = new Actions(webDriver);
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
        webDriver.manage().window().maximize();
        webDriver.findElement(By.xpath("//*[@id='mat-select-0']/div")).click();
        Thread.sleep(1000);
        try {
            List<WebElement> TotalBG = webDriver.findElements(By.xpath("//div[@role='listbox']/mat-option"));
            for (int i = 1; i <= TotalBG.size(); i++) {
                String actualbg = TotalBG.get(i).getText();
                Logger.info("Business group is " + actualbg);
                if (actualbg.equalsIgnoreCase(Businessgroup)) {
                    WebElement bg = webDriver.findElement(By.xpath("//span[@class='mat-option-text'][contains(text(),'" + Businessgroup + "')]"));
                    bg.click();
                    je.executeScript("arguments[0].style.border='5px solid red'", bg);
                    Thread.sleep(3000);
                    Logger.info("expected business group is matchs" + actualbg + "");
                } else {
                    Logger.info("expected business group is not matchs" + actualbg + "");
                }

            }
        } catch (Exception ex) {

        }
    }


    @When("Analyst Clicks on setting page Submit Button")
    public void analystClicksSettingSubmitButton() {
        dashboardPage.analystclickonsettingsubmitbutton1();
    }

    @When("Analyst Select Business group as {string} from DashBoard page")
    public void analystSelectsBusinessGroupas(String Businessgroup) throws InterruptedException {
        dashboardPage.analystSelectsBusinessGrp(Businessgroup);
        Logger.info("Analyst has selected "+Businessgroup+" in the dashboard");
    }

    @Then("Analyst Validates Data is getting displayed Rfw widget with Viewer role as Businessgroup {string}")
    public void analystValidatesDataIsgetttingDisplayedas(String Businessgroup) throws InterruptedException {
        dashboardPage.analystvalidatesBgDatafromRfwWidget(Businessgroup);
    }

    @Then("Analyst Validates Data is getting displayed on Rfw widget as Businessgroup {string}")
    public void analystValidatesDataIsgetttingDisplayedon(String Businessgroup) throws InterruptedException {
        dashboardPage.analystvalidatesBgDataonRfwWidget(Businessgroup);
    }


    @Then("Analyst Validates Pending info widget for Businessgroup {string}")
    public void analystValidatesPendinginfowidgetfor(String Businessgroup) throws InterruptedException {
        dashboardPage.analystvalidatesPendinginfoWidget(Businessgroup);
    }

    @And("Analyst validates the In progress widget")
    public void AnalystValidatesInProgressWidget(){
        dashboardPage.analystValidatesInProgressWidget();
        Logger.info("Analyst has validated in progress panel");
    }

    @And("Analyst verifies that in progress panel should get incremented by 1 when Analyst works on a case for {string}")
    public void AnalystVerifiesInprogressPaneShouldGetIncremented(String tier) throws InterruptedException {
        dashboardPage.analystValidatesInProgressCountIncrement(tier);
    }

    @And("Analyst validates that SI breached count from {string} is matching with UI count")
    public void analystValidatesSIBCountwithDB(String dbResult){
        if (dbResult.contains("$")) {
            dbResult = dbResult.substring(dbResult.indexOf("$") + 1);
        }
        Logger.info("result is --- "+dbResult);
    }

    @Then("Analyst Validates Data is getting displayed Rfw widget with Supervisor role as Businessgroup {string}")
    public void analystValidatesDataIsgetttingDisplayedasSupervisor(String Businessgroup) throws InterruptedException {
        dashboardPage.analystvalidatesBgDatafromRfwWidgetSupervisor(Businessgroup);
    }
    @Then("Analyst Validates Rfw Widget Casecount is displaying in Dashboard Page")
    public void analystValidatesRfwWidgetCasecountIsDisplaying(){
        dashboardPage.analystValidatesRfwCasecount();
    }

    @Then("Analyst Validates Pending info Casecount is displaying in Dashboard Page")
    public void analystValidatesPendingInfoWidgetCasecountIsDisplaying(){
        dashboardPage.analystValidatesPendingInfoCasecount();
    }
    @When("Analyst validate error message toaster as {string}")
    public void validatesToasterMessageAs(String Toaster) throws InterruptedException {
        dashboardPage.ValidatesToaster(Toaster);
        Logger.info("Analyst validate error message toaster as " + Toaster + "");

    }

    @Then("Analyst validate Dashboard page does not contain error message")
    public void validatesToasterMessageANot() throws InterruptedException {
        dashboardPage.ValidatesNotToaster();
        Logger.info("Analyst validate Dashboard page doesnt contain error message");
    }
    @When("Analyst Validate RFW Widget is empty for not set value")
    public void validateRfwWidgetForNotsetValue() {
        dashboardPage.validateEmptyRfwWidget();
        Logger.info("Analyst Validate RFW Widget is empty for not set value");
    }
    @When("Analyst get the error for CRN {string}")
    public void analystGetError(String errormsg) throws InterruptedException {

        dashboardPage.getErrorTextforCRN(errormsg);
    }

    @And("Analyst verifies linked cases for the MTCN {string} in the grid")
    public void verifySRandRRWithMtcn(String mtcn) throws InterruptedException {

        dashboardPage.openFirstCaseInViewMode();
        Thread.sleep(3000); //wait for the case to open
        String hitText1 = dashboardPage.getHitText();
        Logger.info("First case is : "+hitText1);

        dashboardPage.getDashboardLink().click();
        dashboardPage.enterMTCNInSearchTextBox(mtcn);
        dashboardPage.clickOnSearchButton();

        dashboardPage.openSecondCaseInViewMode();
        Thread.sleep(3000);
        String hitText2 = dashboardPage.getHitText();
        Logger.info("Second case is :"+hitText2);


        if(hitText1.equalsIgnoreCase("Receiver At Receive Side")){
            Assert.assertTrue(hitText2.equalsIgnoreCase("Sender At Receive Side"),"SR Case is not present");
            Logger.info("Both SR and RR cases are present for the given MTCN : "+mtcn);

        }
        else if(hitText1.equalsIgnoreCase("Sender At Receive Side")){
            Assert.assertTrue(hitText2.equalsIgnoreCase("Receiver At Receive Side"),"RR Case is not present");
            Logger.info("Both SR and RR cases are present for the given MTCN : "+mtcn);
        }
        Logger.info("Analyst has verified SR and RR cases.");
    }


    @And("Analyst verifies link icon in both the cases for {string}")
    public void analystVerifiesLinkIcon(String mtcn) throws InterruptedException {
        dashboardPage.openFirstCaseInViewMode();
        Thread.sleep(3000);
        Logger.info("Analyst opens first case");
        Assert.assertTrue(dashboardPage.getLinkIcon().isDisplayed(),"Link icon is not present");
        dashboardPage.getLinkIcon().click();
        Thread.sleep(3000);
        Logger.info("Analyst clicks on link icon");
        Logger.info("Link icon verified.");


        dashboardPage.getDashboardLink().click();
        dashboardPage.enterMTCNInSearchTextBox(mtcn);
        dashboardPage.clickOnSearchButton();

        dashboardPage.openSecondCaseInViewMode();
        Logger.info("Analyst opens second case");
        Thread.sleep(3000);
        Assert.assertTrue(dashboardPage.getLinkIcon().isDisplayed(),"Link icon is not present");
        dashboardPage.getLinkIcon().click();
        Thread.sleep(3000);

        Logger.info("Analyst clicks on link icon");
        Logger.info("Link icon verified in the second case.");


    }

    @And("Analyst clicks on link icon")
    public void analystClicksOnLinkIcon(){
        dashboardPage.getLinkIcon().click();
        Logger.info("Analyst has clicked on link icon");
    }

    @Then("Analyst validates case screen is opened")
    public void analystValidatesCaseScreen(){
        Assert.assertTrue(dashboardPage.getCaseScreenTitle().isDisplayed(),"Case screen is not present");
        Logger.info("Case screen is validated");
    }

    @Then("Analyst validates disposition {string} in the case screen")
    public void analystValidatesDispositionInCasescreen(String disposition){
        String ActualDisposition = dashboardPage.getDispositionCasescreen().getText();
        Logger.info("Actual disposition :"+ActualDisposition);
        Assert.assertTrue(ActualDisposition.contains(disposition),"Disposition is not as expected");
        Logger.info("Disposition is validated in the case screen : "+disposition);
    }

    @Then("Analyst validates action {string} in the case screen")
    public void analystValidatesActionInCasescreen(String action){
        String actualAction = dashboardPage.getActionCasescreen().getText();
        Logger.info("Actual action from case screen : "+actualAction);
        Assert.assertTrue(actualAction.equalsIgnoreCase(action),"Action in case screen is not as expected");
        Logger.info("Action is case screen is validated : "+action);
    }

    @Then("Analyst validates action status as {string}")
    public void analystValidatesActionStatus(String actionStatus){
        String actualActionStatus = dashboardPage.getActionStatus().getText();
        Logger.info("Actual action status : "+actualActionStatus);
        String ExpectedActionStatus = "check"+ actionStatus;

        actualActionStatus = actualActionStatus.replaceAll(" ","");
        actualActionStatus = actualActionStatus.replaceAll("\\R", "").trim();

        ExpectedActionStatus = ExpectedActionStatus.replaceAll(" ","");
        ExpectedActionStatus = ExpectedActionStatus.replaceAll("\\R", "").trim();
        Logger.info("Expected action status : "+ExpectedActionStatus);
        Assert.assertTrue(actualActionStatus.equalsIgnoreCase(ExpectedActionStatus), "Action status is not as expected");
        Logger.info("Action status is validated in case screen:"+actualActionStatus);

    }



    @Then("Analyst verifies Get Case widget is not present")
    public void analystVerifiesGetCaseWidgetIsNotPresent() {
        Assert.assertTrue(dashboardPage.getGetCaseWidgetCount()==0,"Get Case widget does not exist");
        Logger.info("Verifying the existence of Get Case Widget");
    }

    @And("Analyst selects {string} in BusinessGroup dropdown")
    public void analystSelectsInBusinessGroupDropdown(String BG) throws InterruptedException {
        dashboardPage.analystSelectsBusinessGrpDropdown(BG);
        Logger.info("Analyst selects " +BG+" in business group dropdown");
    }

    @And("Analyst selects {string} in InvestigationFocus dropdown")
    public void analystSelectsInInvestigationFocusDropdown(String IF) {
        dashboardPage.analystSelectsInvestigationFocusDropdown(IF);
        Logger.info("Analyst selects " +IF+" in business group dropdown");
    }

    @Then("Analyst verifies search result title as {string} for {string} for DataCaseFilter")
    public void analystVerifiesSearchResultTitleAs(String expectedTitle,String tierName) {
        if (tierName.equalsIgnoreCase("Standard Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-flex-width-15 ml-12 wu-btn-clickable wu-case-count']")).size() > 0) {
            String actualTitle = dashboardPage.getSearchGridTitleText();
            Assert.assertEquals(actualTitle, expectedTitle, "Verifying the title of Search Result table as" + expectedTitle);
            Logger.info("Verifying the title of Search Result table as" + expectedTitle);
        }
        else if (tierName.equalsIgnoreCase("Enhanced Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[2]/div[1]/div[2]")).size()>0) {
            String actualTitle = dashboardPage.getSearchGridTitleText();
            Assert.assertEquals(actualTitle, expectedTitle, "Verifying the title of Search Result table as" + expectedTitle);
            Logger.info("Verifying the title of Search Result table as" + expectedTitle);
        }
        else if(tierName.equalsIgnoreCase("Advanced Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[3]/div[1]/div[2]")).size()>0){
            String actualTitle = dashboardPage.getSearchGridTitleText();
            Assert.assertEquals(actualTitle, expectedTitle, "Verifying the title of Search Result table as" + expectedTitle);
            Logger.info("Verifying the title of Search Result table as" + expectedTitle);
        }
        else if(tierName.equalsIgnoreCase("Investigation Approver") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[4]/div[1]/div[2]")).size()>0){
            String actualTitle = dashboardPage.getSearchGridTitleText();
            Assert.assertEquals(actualTitle, expectedTitle, "Verifying the title of Search Result table as" + expectedTitle);
            Logger.info("Verifying the title of Search Result table as" + expectedTitle);
        }
        else {
            Logger.info("Cases are not present to perform required action");
        }
    }

    @Then("Analyst clicks on Stop Icon")
    public void analystClicksOnStopIcon() {
        dashboardPage.getStopButton().click();
    }

    @Then("Analyst verifies Stop icon is disabled")
    public void analystVerifiesStopIconIsDisabled() {
        Assert.assertFalse(dashboardPage.getStopButton().isEnabled(),"Stop icon is disabled");
    }

    @Then("Analyst verifies the count for {string}")
    public void analystVerifiesTheCountFor(String fieldName) {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0) {
//            String count = dashboardPage.getActionFailureTypeCasesCount(fieldName).getText();
            int count = Integer.parseInt(dashboardPage.getActionFailureTypeCasesCount(fieldName).getText());
            Logger.info("Count for " + fieldName + " is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
        else {
//            int count =dashboardPage.getActionFailureTypeCasesCountSize(fieldName).size();
            int count = BaseTestSetup.webDriver.findElements(By.xpath("(//span[text()='"+fieldName+"']//parent::div//parent::div)[1]//div[@class='mat-chip-ripple']//parent::mat-chip")).size();
            Logger.info("Count for " + fieldName + " is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
    }

    @Then("Analyst verifies the count for {string} for RFW Widget for {string} in {string}")
    public void analystVerifiesTheCountForRFWWidget(String fieldName, String type,String BG) throws InterruptedException {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB")) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB")) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB")) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
            DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Actions actions=new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(dashboardPage.getRFWTypeCasesCount(fieldName,type)).perform();
            Thread.sleep(3000);
            String test = BaseTestSetup.webDriver.findElement(By.xpath("//*[contains(@class,'mat-tooltip-panel-above')]")).getText();
            int count = Integer.parseInt(BaseTestSetup.webDriver.findElement(By.xpath("//*[contains(@class,'mat-tooltip-panel-above')]")).getText());
            Logger.info("Count for " + fieldName + " in UI is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
        else{
            int count =0;
            if(type.equals("SLANB")) {
                count = BaseTestSetup.webDriver.findElements(By.xpath("(//p[text()='" + fieldName + "'])[1]//parent::div//preceding-sibling::div//div[@class='mat-tooltip-trigger wu-rfw-cases-sla wu-btn-clickable wu-flex-grow-shirk ng-star-inserted']")).size();
            }
            else{
                count = BaseTestSetup.webDriver.findElements(By.xpath("(//p[text()='" + fieldName + "'])[1]//parent::div//preceding-sibling::div//div[contains(@class,'wu-rfw-cases-sla-breached')]")).size();
            }
            Logger.info("Count for " + fieldName + " is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
    }
    @Then("Analyst fetches the case for {string} for RFW Widget for {string} in {string}")
    public void analystFetchesCaseForRFWWidget(String fieldName, String type,String BG) throws InterruptedException {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB") ) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB") ) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB") ) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Actions actions=new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(dashboardPage.getRFWTypeCasesCount(fieldName,type)).click().perform();
            Thread.sleep(3000);

            Logger.info("User clicks on RFW Widget " +fieldName +" " +BG + " " +type);
        }
        else{
            Logger.info("Cases are not there for User clicks on RFW Widget " +fieldName +" " +BG + " " +type);
        }
    }

    @Then("Analyst fetches the case for {string} for Pending Info Widget for {string} in {string}")
    public void analystFetchesCaseForPIWidget(String fieldName, String type,String BG) throws InterruptedException {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB") ) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB") ) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB") ) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Actions actions=new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(dashboardPage.getPendingInfoTypeCasesCount(fieldName,type)).click().perform();
            Thread.sleep(3000);

            Logger.info("User clicks on Pending Info Widget " +fieldName +" " +BG + " " +type);
        }
        else{
            Logger.info("Cases are not there for User clicks on Pending Info Widget " +fieldName +" " +BG + " " +type);
        }
    }
    @Then("Analyst fetches the case for {string} for In Progress Widget for {string} in {string}")
    public void analystFetchesCaseForIPWidget(String fieldName, String type,String BG) throws InterruptedException {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB") ) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB") ) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB") ) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Actions actions=new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(dashboardPage.getInProgressTypeCasesCount(fieldName,type)).click().perform();
            Thread.sleep(3000);

            Logger.info("User clicks on IP Widget " +fieldName +" " +BG + " " +type);
        }
        else{
            Logger.info("Cases are not there for User clicks on IP Widget " +fieldName +" " +BG + " " +type);
        }
    }
    @Then("Analyst verifies the count for {string} for Pending Info Widget for {string} in {string}")
    public void analystVerifiesTheCountForPendingInfoWidget(String fieldName, String type,String BG) throws InterruptedException {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB")) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB")) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB")) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Actions actions=new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(dashboardPage.getPendingInfoTypeCasesCount(fieldName,type)).perform();
            Thread.sleep(3000);
            String test = BaseTestSetup.webDriver.findElement(By.xpath("//*[contains(@class,'mat-tooltip-panel-above')]")).getText();
            int count = Integer.parseInt(BaseTestSetup.webDriver.findElement(By.xpath("//*[contains(@class,'mat-tooltip-panel-above')]")).getText());
            Logger.info("Count for " + fieldName + " in UI is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
        else {
         int count=0;
            if(type.equals("SLAB")) {
                 count = BaseTestSetup.webDriver.findElements(By.xpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'wu-rfw-cases-sla-breached')]")).size();
            }
            else{
                count = BaseTestSetup.webDriver.findElements(By.xpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'mat-tooltip-trigger wu-rfw-cases-sla wu-btn-clickable wu-flex-grow-shirk wu-bar-graph-border-radius ng-star-inserted')]")).size();
            }
            Logger.info("Count for " + fieldName + " is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
    }

    @Then("Analyst verifies the count for {string} for In Progress Widget for {string} in {string}")
    public void analystVerifiesTheCountForInProgressWidget(String fieldName, String type,String BG) throws InterruptedException {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB")) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB")) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB")) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Actions actions=new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(dashboardPage.getInProgressTypeCasesCount(fieldName,type)).perform();
            Thread.sleep(3000);
            String test = BaseTestSetup.webDriver.findElement(By.xpath("//*[contains(@class,'mat-tooltip-panel-above')]")).getText();
            int count = Integer.parseInt(BaseTestSetup.webDriver.findElement(By.xpath("//*[contains(@class,'mat-tooltip-panel-above')]")).getText());
            Logger.info("Count for " + fieldName + " in UI is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
        else{
            int count =0;
            if(type.equals("SLANB")) {
                count = BaseTestSetup.webDriver.findElements(By.xpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'mat-tooltip-trigger wu-rfw-cases-sla wu-btn-clickable wu-flex-grow-shirk wu-bar-graph-border-radius ng-star-inserted')]")).size();
            }
            else{
                count = BaseTestSetup.webDriver.findElements(By.xpath("(//p[text()='" + fieldName + "'])[2]//parent::div//preceding-sibling::div//div[contains(@class,'wu-rfw-cases-sla-breached')]")).size();
            }
            Logger.info("Count for " + fieldName + " is " + count);
            Assert.assertEquals(DbCount,count,"Count in UI and DB matches for " +fieldName);
            Logger.info("Count in UI and DB matches for " +fieldName);
        }
    }


    @Then("Analyst clicks the count for {string}")
    public void analystClicksTheCountFor(String fieldName) {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0) {
            dashboardPage.getActionFailureTypeCasesCount(fieldName).click();
            Logger.info("Analyst clicks the count for " + fieldName);
        }
        else {
            Logger.info("There are no cases present for " +fieldName);
        }
    }

    @Then("Analyst verifies view button is enable")
    public void analystVerifiesViewButtonIsEnable() {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0) {
            Assert.assertTrue(dashboardPage.getAnalystValueForviewIcon().isDisplayed(), "Analyst verifies view button is enable");
            Logger.info("Successfully validated the view mode icon visibility");
        }
    }

    @And("Analyst selects {string} in Review Type dropdown")
    public void analystSelectsInReviewTypeDropdown(String ReviewType) throws InterruptedException {
        dashboardPage.analystSelectsReviewTypeDropdown(ReviewType);
        Logger.info("Analyst selects " +ReviewType+" in review type dropdown");
    }
}





