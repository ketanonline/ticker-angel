package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.DBView.CommentPage;
import com.wu.pages.DBView.LandingPage;
import com.wu.pages.DBView.MoneyTransferDatabaseUtilityPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.jsoup.Connection;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;


public class DBViewSteps {
    LandingPage landingPage = new LandingPage();
    MoneyTransferDatabaseUtilityPage moneyTransferDatabaseUtilityPage = new MoneyTransferDatabaseUtilityPage();
    CommentPage commentPage = new CommentPage();


    @And("Analyst clicks on {string} Button")
    public void analystClicksOnButton(String btnName) {
        landingPage.getButton(btnName).click();
        Logger.info("Analyst clicked on Button" +btnName);
    }

    @And("Analyst enters MTCN in Control Number")
    public void analystEntersInCOntrolNumber() {
        moneyTransferDatabaseUtilityPage.setControlNumber();
        Logger.info("Analyst enters MTCN in control number");

    }

    @And("Analyst clicks on Search button in DataBaseUtility page")
    public void analystClicksOnSearchButtonInDataBaseUtilityPage() throws InterruptedException {
        moneyTransferDatabaseUtilityPage.getSearchButton().click();
        Logger.info("Analyst clicks on Search button in DataBaseUtility page");
    }

    @And("Analyst clicks on MTCN Details button")
    public void userClicksOnMTCNDetailsButton() {
        moneyTransferDatabaseUtilityPage.getMTCNDetailsButton().click();
        Logger.info("Analyst clicks on MTCN Details button");
    }

    @Then("Analyst Verifies the status as WC")
    public void userVerifiesTheStatusAsWC() {
       String actualText= moneyTransferDatabaseUtilityPage.getStatus().getText();
       System.out.println("Actual Text " +actualText);
       String expectedText="Status:WC";
        System.out.println("Actual Text" +expectedText);
        Assert.assertEquals(actualText,expectedText);
        Logger.info("Analyst Verifies the status as WC");
    }

    @And("Analyst clicks on QUEUE button in DataBaseUtility page")
    public void analystClicksOnQUEUEButtonInDataBaseUtilityPage() {
        moneyTransferDatabaseUtilityPage.getQueueButton().click();
        Logger.info("Analyst clicks on QUEUE button in DataBaseUtility page");
    }
    @And("Analyst clicks on COMMENT button in DataBaseUtility page")
    public void analystClicksOnCOMMENTButtonInDataBaseUtilityPage() {
        moneyTransferDatabaseUtilityPage.getCommentButton().click();
        Logger.info("Analyst clicks on COMMENT button in DataBaseUtility page");
    }
    @And("Analyst verifies the notification NO QUEUE RECORD FOUND.")
    public void analystVerifiesTheNotificationNOQUEUERECORDFOUND() {
        String actualText=moneyTransferDatabaseUtilityPage.getNotification().getText();
        System.out.println("Actual Text " +actualText);
        String expectedText="NO QUEUE RECORD FOUND.";
        System.out.println("Actual Text" +expectedText);
        Assert.assertEquals(actualText,expectedText);
        Logger.info("Analyst verifies the notification NO QUEUE RECORD FOUND.");
    }

    @And("Analyst verifies the text AAOID as {string}")
    public void analystVerifiesTheTextAAOIDAs(String str) {

        String actualText=moneyTransferDatabaseUtilityPage.getAAOIDValueCARERGSI().getText();
        System.out.println("Actual Text " +actualText);
        System.out.println("Expected Text" +str);
        Assert.assertEquals(actualText,str);


        Logger.info("Analyst verifies the AAOID value.");
    }

    @And("Analyst enters {string} in Comment Section")
    public void analystEntersInCommentSection(String comments) {
        commentPage.getCommentTextbox().click();
        commentPage.getCommentTextbox().sendKeys(comments);
        commentPage.getCommentTextbox().sendKeys(Keys.ENTER);

        Logger.info("Analyst enters comments for filtering");
    }

    @Then("Analyst verifies the results exist in Comment Table")
    public void analystVerifiesTheResultsExistInCommentTable() throws InterruptedException {
        Thread.sleep(3000);
        int tableResults = BaseTestSetup.webDriver.findElements(By.xpath("//*[@row-index='0']")).size();
        Assert.assertTrue(tableResults>0,"Results in comment table doesn't exist");
        Logger.info("Verified results in comment table");
    }
}
