package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import com.wu.pages.Pharos.Interdictions.CaseAttachmentPage;
import com.wu.pages.Pharos.Interdictions.CaseViewModePage;
import com.wu.pages.Pharos.Interdictions.DashboardPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import net.serenitybdd.core.Serenity;
import org.openqa.selenium.By;
import org.testng.Assert;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class CaseViewModeSteps extends BasePage {


    CaseViewModePage caseViewModePage = new CaseViewModePage();
    DashboardPage dashboardPage = new DashboardPage();


    @Then("Analyst verifies case submission")
    public void analystVerifiesCaseSubmit() {
        caseViewModePage.verifyCaseSubmit();
        Logger.info("Successfully verified Final Case is disabled to submit disposition");
    }

    @Then("Analyst verifies case disposition area is restricted")
    public void analystVerifiesCaseDispositionSection() {
        caseViewModePage.verifyCaseDispositionDisabled();
        Logger.info("Successfully verified Case disposition is disabled in VIEW only mode ");
    }

    @Then("Analyst verifies entity access and scroll")
    public void analystVerifiesEntityAccess() throws Exception {
        caseViewModePage.verifyScroll();
        Logger.info("Successfully verified Entity access and scroll in VIEW only mode ");
    }

    @Then("Analyst verifies case header display")
    public void analystVerifiesCaseHeader() throws Exception {
        caseViewModePage.verifyCaseHeaderExpansion();
        Logger.info("Successfully verified Case Header Display in VIEW only mode ");
    }

    @Then("Analyst verifies the time zone conversion at {string}")
    public void verifyTimeZone(String panelName) throws InterruptedException, ParseException {
        SimpleDateFormat istDf = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mma z");
        SimpleDateFormat etDf = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mma");
        TimeZone etTimeZone = TimeZone.getTimeZone("America/New_York");
        etDf.setTimeZone(etTimeZone);
        Date currentDate = new Date();
        Calendar currentTime = Calendar.getInstance();
        Logger.info("Current IST Time : " + istDf.format(currentDate.getTime()));
        Logger.info("EST/EDT Time : " + etDf.format(currentDate.getTime()));
        String actaualESTExcrated = etDf.format(currentDate.getTime()).substring(14, 21).replaceAll("\\s", "");
        Logger.info("Actual EST Time extracted " + etDf.format(currentDate.getTime()).substring(14, 21).replaceAll("\\s", ""));
        CaseAttachmentPage caseAttachmentPage = new CaseAttachmentPage();
        switch (panelName) {
            case "Conversation":
                browserElements.clickElementAfterFocus(BaseTestSetup.webDriver.findElement(By.xpath("//mat-icon[contains(text(),'send')]")));
                Thread.sleep(5000);
                BaseTestSetup.webDriver.findElement(By.xpath("//app-conversation//following::a")).click();
                Thread.sleep(5000);
                String conversationtime = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-comments-container']//following::div[@class='mat-card-header-text'])[1]")).getText();
                Logger.info("Timezone for conversation functionality verified and passed");
                break;
            case "Attachment":
                Thread.sleep(2000);

                caseAttachmentPage.expandFirstAttachment();
                String time = caseAttachmentPage.getAttachmentTimeFieldFromPanel();
                String ESTPaneltime = time.substring(13, 21);
                String extractedESTPaneltime = ESTPaneltime.replaceAll("\\s", "");
                Logger.info("Timedisplayed at Attachment panel is : " + extractedESTPaneltime);
                Assert.assertEquals(actaualESTExcrated, extractedESTPaneltime, "Timezone for attachment functionality verified and passed");
                Logger.info("Timezone for attachment functionality verified and passed");
                break;
            case "PendCase":
                Thread.sleep(2000);
                caseAttachmentPage.expandFirstAttachment();
                String duedate = caseAttachmentPage.getDueDate().getText();
                String extracteddueDatetime = duedate.substring(19, 28).replaceAll("\\s", "");
                Logger.info("Duedate displayed is : " + extracteddueDatetime);
                Assert.assertEquals(actaualESTExcrated, extracteddueDatetime, "Successfully verified the due date with the pend duration");
                Logger.info("Successfully verified the due date with the pend duration");
        }
    }

    @And("Save 10 digit mtcn in {string}")
    public void Savemtcn(String mtcn) {
        if (mtcn.contains("$")) {
            mtcn = mtcn.substring(mtcn.indexOf("$") + 1);
        }

        Serenity.getCurrentSession().put(mtcn, dashboardPage.getmtcn().substring(6));
    }

    @And("Save caseID in {string}")
    public void SavecaseId(String CaseID) {
        if (CaseID.contains("$")) {
            CaseID = CaseID.substring(CaseID.indexOf("$") + 1);
        }
        Serenity.getCurrentSession().put(CaseID, dashboardPage.getCaseID());
        Logger.info("Successfully captured CaseID and displayed");

    }

}
