package com.wu.stepdefinitions.Pharos.DualHits;

import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseDispositionControlPage;
import cucumber.api.java.en.Then;
import org.testng.Assert;

public class SummarySteps {

    CaseDispositionControlPage caseDispoPg = new CaseDispositionControlPage();

    @Then("Analyst verifies Summary for {string} as {string}")
    public void summaryVerification(String invGrp , String expectedSummaryValue){
        String actualSummaryValue=caseDispoPg.getSummaryValue(invGrp).getText();
        Assert.assertEquals(actualSummaryValue,expectedSummaryValue,"Summary Values has been modified");
        Logger.info("Summary value has not been modified for -"+invGrp);
    }


}
