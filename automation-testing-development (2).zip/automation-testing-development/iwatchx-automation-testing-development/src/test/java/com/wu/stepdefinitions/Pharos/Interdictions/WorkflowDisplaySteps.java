package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.EntityDispositionPage;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

public class WorkflowDisplaySteps {

    public String currPhase;

    @Then("Analyst verifies the Workflow as {string}")
    public void verifyWorkflow(String workflowStage) throws Exception {
        try {
            Thread.sleep(2000);
            WebElement eWorkflow = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-workflow-node']/div/p[contains(text(),'" + workflowStage + "')]"));
            String actualWFValue = eWorkflow.getText();
            if (actualWFValue.contains(workflowStage)) {
                Logger.info("Verified the workflow as :" + actualWFValue);
            } else {
                Logger.error("Workflow is not as expected" + actualWFValue);
            }
        } catch (Exception e) {
            Logger.error("Failed to verify Workflow as :" + workflowStage);
        }
    }

    @Then("Analyst clicks on the Header expansion arrow")
    public void clickOnHeaderExpansion() throws Exception {
        try {
            WebElement arrowIcon = BaseTestSetup.webDriver.findElement(By.xpath("//mat-expansion-panel-header[starts-with(@id,'mat-expansion-panel-header')]/span[2]"));
            ((JavascriptExecutor) BaseTestSetup.webDriver).executeScript("arguments[0].scrollIntoView(true);", arrowIcon);
            Thread.sleep(2000);

            arrowIcon.click();
        } catch (Exception e) {
            Logger.error("Failed to click on Header expansion arrow");
        }
    }

    @Then("Analyst verifies the current phase of the case")
    public void verifyCurrentPhase() {
        try {
            String fullWorkflow = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-workflow-node']")).getText();
            if (fullWorkflow.contains(currPhase)) {
                Logger.info("Current Phase has been successfully validated as :" + currPhase);
            } else {
                Logger.error("Current phase has not been verified");
            }
        } catch (Exception e) {
            Logger.error("Failed to verify current phase of the case");
        }
    }

    @Then("Analyst verifies the Phase as {string}")
    public void verifyPhase(String phase) {
        try {
            WebElement ePhase = BaseTestSetup.webDriver.findElement(By.xpath("//div[contains(text(),'" + phase + "')]"));
            String actualPhaseValue = ePhase.getText();
            if (actualPhaseValue.equalsIgnoreCase(phase)) {
                Logger.info("Successfully verified the Phase as : " + actualPhaseValue);
            } else {
                Logger.error("Phase verified but is not as per the expected Phase");
            }
        } catch (Exception e) {
            Logger.error("Failed to verify the Phase as :" + phase);
        }
    }

    @Then("Analyst verifies the Workflow Sub-Process as {string}")
    public void verifyWorkflowSubprocess(String subprocess) throws Exception {
        try {
            Thread.sleep(3000);
            WebElement eWorkflowSubprocess = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-workflow-node']/div//p[contains(text(),'" + subprocess + "')]"));
            String actualWFSubValue = eWorkflowSubprocess.getText();
            if (subprocess.equalsIgnoreCase("Pend ")) {
                subprocess = "Pend";
            }
            if (actualWFSubValue.contains(subprocess)) {
                Logger.info("Verified the workflow as :" + actualWFSubValue);
            } else {
                Logger.error("Workflow is not as expected" + actualWFSubValue);
            }
        } catch (Exception e) {
            Logger.error("Failed to verify Workflow Sub-process as :" + subprocess);
        }
    }

    @Then("Analyst verifies the stage in Dashboard page")
    public void verifyStageOnDashboard() {
        try {
            EntityDispositionPage ePage = new EntityDispositionPage();
            currPhase = BaseTestSetup.webDriver.findElement(By.xpath("//table[@class='mat-table cdk-table ng-star-inserted']/tbody/tr/td[6]")).getText();
        } catch (Exception e) {
            Logger.error("Failed to verify the stage in Dashboard page");
        }
    }


}
