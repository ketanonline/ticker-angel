package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.api.util.common.CouchBaseUtility;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CaseUIFinalAdjustmentsSteps {
    @Then("Analyst verifies the abbreviation of the {string} agent country {string}")
    public void validatesAbbrevationOfSendingPayingCountry(String paySendSide, String countryCode) throws Exception {
        String value = null;
        try {

            if (paySendSide.equalsIgnoreCase("Sending")) {
                WebElement sendingSideValue = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1])[1]"));
                value = sendingSideValue.getText();

            } else {
                WebElement payingSideValue = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1])[2]"));
                value = payingSideValue.getText();
            }
            String[] CountryStateValue = value.split(",");
            String Country = CountryStateValue[0].trim();

            if (Country.equals(countryCode)) {
                Logger.info("The" + paySendSide + "side country code is successfully validated as :" + Country);
            } else {
                Logger.error("The " + paySendSide + " side country code is not successfully validated as :" + Country);
            }
        } catch (Exception e) {
            Logger.error("Country code for " + paySendSide + " side is not visible on the black ribbon");
        }
    }

    @Then("Analyst verifies the {string} agent state for {string} transactions")
    public void validatesAbbreviationOfSendingPayingState(String paySendSide, String country) throws Exception {
        String value = null;
        try {
            if (paySendSide.equalsIgnoreCase("Sending")) {
                WebElement sendingSideValue = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1]/span)[1]"));
                value = sendingSideValue.getText();

                if (value != null) {
                    Logger.info("Send side State is clearly visible as" + value + " for " + country + " transaction");
                } else {
                    Logger.error("Send side State is not visible on the black ribbon for " + country + " transaction");
                }
            } else {
                WebElement payingSideValue = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1]/span)[2]"));
                value = payingSideValue.getText();

                if (value != null) {
                    Logger.info("Pay side State is clearly visible as " + value + " for " + country + " transaction");
                } else {
                    Logger.error("Pay side State is not visible on the black ribbon for " + country + " transaction");
                }
            }
        } catch (Exception e) {
            Logger.error("State " + paySendSide + " is not visible on the black ribbon for " + country + " transaction");
        }
    }

    @Then("Analyst verifies the tooltip for Country {string} on {string} side")
    public void tooltipVerificationOnSendingSide(String country ,String side) throws InterruptedException {
        try {
            String toolTipTextCountry;
            Actions actions = new Actions(BaseTestSetup.webDriver);
            if(side.equalsIgnoreCase("sending")) {
                actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1])[1]"))).perform();
                Thread.sleep(60);

                WebElement tooltip = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[@class='wu-span-2'])[1]"));
                String toolTipText = tooltip.getText();
                toolTipTextCountry = toolTipText.trim();
            }else{
                actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1])[2]"))).perform();
                Thread.sleep(60);

                WebElement tooltip = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[@class='wu-span-2'])[2]"));
                String toolTipText = tooltip.getText();
                toolTipTextCountry = toolTipText.trim();
            }

            if (toolTipTextCountry.equalsIgnoreCase(country)) {
                Logger.info("Tooltip/Mouseover of the Country on sending side shows full Country Name");
            } else {
                Logger.error("Tooltip/Mouseover of the Country on sending side does not show full Country Name");
            }
        } catch (Exception e) {
            Logger.error("Analyst is unable to verify the tooltip/mouseover for Country on Sending ");
        }
    }

    @Then("Analyst verifies the tooltip for Country {string} on payee side")
    public void tooltipVerificationOnPayeeSide(String country) throws InterruptedException {
        try {
            Actions actions = new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1])[2]"))).perform();
            Thread.sleep(60);

            WebElement tooltip = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[@class='span-2'])[2]"));
            String toolTipText = tooltip.getText();
            String toolTipTextCountry = toolTipText.trim();

            if (toolTipTextCountry.equalsIgnoreCase(country)) {
                Logger.info("Tooltip/Mouseover of the Country on payee side shows full Country Name");
            } else {
                Logger.error("Tooltip/Mouseover of the Country on payee side does not show full Country Name");
            }
        } catch (Exception e) {
            Logger.error("Analyst is unable to verify the tooltip/mouseover for Country on Payee side ");
        }
    }

    @When("DBResult query {string}")
    public void dbQuery(String query) throws Exception {

        String queryResult = CouchBaseUtility.executeCouchBaseQueryReturnResultInJSON(query.trim());
        Logger.info("Query Result : " + queryResult);
    }

    @Then("Analyst verifies the amount on UI with {string} format")
    public void amountVerificationOnUI(String separator) throws Exception {
        WebElement amountin = BaseTestSetup.webDriver.findElement(By.xpath("//p[contains(text(),'USD')]"));
        String amountinUSD=amountin.getText();
        String amountinUSDString = amountinUSD.toString();
        String amount = amountinUSDString.replaceAll("USD", "");

        amount = amount.trim();

        if(separator.equalsIgnoreCase(",")){
            if (amount.contains(",")) {
                String[] amountSplit = amount.split(",");
                int value = amountSplit[1].length();
                //int value1 = amountSplit[2].length();
                if(value==3){
                    Logger.info("Amount is verified on UI and the format is comma after" +value+ " digit");
                }else{
                    Logger.error("Amount is verified on UI and the format is comma after" +value+ " digit");
                }
            }
        }else{
            String [] amountSplit = amount.split("\\.");

            int value = amountSplit[1].length();
            if(value==1){
                amountSplit[1].equalsIgnoreCase("0");
                Logger.info("Amount is verified on UI and the format is " +value+ " digits after decimal and it is  -" +amountSplit[1]);
            }else if(value==2) {
                Logger.info("Amount is verified on UI and the format is " +value+ " digits after decimal");
            }else{
                Logger.error("Amount is verified on UI and the format is not " +value+ " digits after decimal");
            }
        }
    }

    @Then("Analyst verifies the tooltip for Country {string} on sending side")
    public void tooltipVerificationOnSendingSide(String country) throws InterruptedException {
        try {
            Actions actions = new Actions(BaseTestSetup.webDriver);
            actions.moveToElement(BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[1])[1]"))).perform();
            Thread.sleep(60);

            WebElement tooltip = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-country-flag']/span[@class='span-2'])[1]"));
            String toolTipText = tooltip.getText();
            String toolTipTextCountry = toolTipText.trim();

            if (toolTipTextCountry.equalsIgnoreCase(country)) {
                Logger.info("Tooltip/Mouseover of the Country on sending side shows full Country Name");
            } else {
                Logger.error("Tooltip/Mouseover of the Country on sending side does not show full Country Name");
            }
        } catch (Exception e) {
            Logger.error("Analyst is unable to verify the tooltip/mouseover for Country on Sending ");
        }
    }


    @Then("Analyst verifies the amount on the UI")
    public void amountOnUI(){
        WebElement amountin = BaseTestSetup.webDriver.findElement(By.xpath("//p[contains(text(),'USD')]"));
        String amountinUSD=amountin.getText();
        String amount =null;
        amount = amountinUSD.replaceAll("USD", "");

        if (amount.contains(".")) {
            ConversationSteps.convData = amount;
        }else {
            ConversationSteps.convData = amount.concat(".0");
        }
    }

    @Then("Analyst verifies the Black ribbon for {string} side case for {string} Brand")
    public void verifyBlackRibbonforBrand(String side , String brand){
        try {
            String sideBrand = null;

            String caseType = BaseTestSetup.webDriver.findElement(By.xpath("//div[contains(text(),'Party Activity Information')]/following::p[1]")).getText();
            if (caseType.contains("Sender")) {
                Logger.info("Case is sender side case");
                WebElement senderBrand = BaseTestSetup.webDriver.findElement(By.xpath("//h2[@mattooltipclass='wu-tooltip-primary']"));
                sideBrand = senderBrand.getText();
                System.out.println("*****" +sideBrand);
            } else {
                Logger.info("Case is Receiver side case");
                WebElement receiverBrand = BaseTestSetup.webDriver.findElement(By.xpath("(//h2[@class='wu-brand-name'])[2]"));
                sideBrand = receiverBrand.getText();
            }
            if (side.equalsIgnoreCase("Receiver")) {
                Logger.info("Black ribbon has been verified for - " + side + " side case and the Brand is -" + sideBrand);
            } else {
                Logger.info("Black ribbon has been verified for - " + side + " side case and the Brand is -" + sideBrand);
            }

            ConversationSteps.convData = sideBrand;
        }catch(Exception e){
            Logger.error("Failed to verify -" +side+ " side case for " +brand+ " brand");
        }
    }

    @Then("Analyst verifies the Black ribbon for {string}")
    public void verifyBlackRibbon(String attribute){

        try {
            WebElement attributeValue;
            if (attribute.equalsIgnoreCase("Recording Channel")) {
                attributeValue = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='ng-star-inserted']/mat-icon[contains(text(),'keyboard')]/following::p[1]"));
            } else if(attribute.equalsIgnoreCase("Sending Agent Account number")){
                attributeValue = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='ng-star-inserted']/mat-icon[contains(text(),'keyboard')]/preceding::div[1]"));
            }else if(attribute.equalsIgnoreCase("Paying Agent Account number")){
                attributeValue = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='ng-star-inserted']/mat-icon[contains(text(),'payments')]/following::p[1]/following::div[1]"));
            } else if (attribute.equalsIgnoreCase("Funds In")) {
                attributeValue = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='ng-star-inserted']/mat-icon[contains(text(),'south_west')]/following::p[1]"));
            } else if (attribute.equalsIgnoreCase("Product")) {
                attributeValue = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='ng-star-inserted']/mat-icon[contains(text(),'storefront')]/following::p[1]"));
            } else if (attribute.equalsIgnoreCase("Intended Funds Out")) {
                attributeValue = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='ng-star-inserted']/mat-icon[contains(text(),'north_east')]/following::p[1]"));
            } else {
                attributeValue = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='ng-star-inserted']/mat-icon[contains(text(),'payments')]/following::p[1]"));
            }
            String value = attributeValue.getText();
            ConversationSteps.convData = value;

            Logger.info("Analyst verifies the value on Black ribbon for - " + attribute + " as -" + value);
        }catch(Exception e){
            Logger.error("Failed to verify " +attribute+ " value on Black ribbon");
        }
    }

    @Then("Analyst verifies the order of the data displayed on Black Ribbon")
    public void verifyOrderOnBlackRibbon() throws  Exception{
        try{
            String caseType = BaseTestSetup.webDriver.findElement(By.xpath("//div[contains(text(),'Party Activity Information')]/following::p[1]")).getText();
            if (caseType.contains("Receiver")) {
                Logger.info("Case is a Receiver side case and therefore Product attribute will not be present on Black Ribbon");
            }
            List<String> attributes = new ArrayList<>();

            attributes.add("Sending Country and Sender name");
            attributes.add("Sending Country and Sender name");
            attributes.add("Sender Brand");
            attributes.add("Agent Account");
            attributes.add("Recording Channel");
            attributes.add("Funds In");
            attributes.add("MTCN");
            attributes.add("Amount");
            attributes.add("Intended Funds out");
            attributes.add("Intended Pay channel");
            attributes.add("Agent account");
            attributes.add("Pay Brand");
            attributes.add("Payee Name and Country");

            for (int i=1 ; i<=12 ; i++) {

                WebElement xpathBlackRibbon = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-subject-card-content']/div)[" + i + "]"));
                String blackRValue = xpathBlackRibbon.getText();
                Logger.info("Element " +i+ " on the Black Ribbon is - " +attributes.get(i)+ " with Icon and value as -  "+blackRValue);

                if(i==12){
                    Logger.info("All elements are present on the Black ribbon");
                }
            }
        }catch(Exception e){
            Logger.error("Some elements are missing from the Black ribbon or are not in order");
        }
    }

    @And("Analyst verifies Black ribbon elements")
    public void analystVerifiesBlackribbonElements() throws InterruptedException {
        WebDriver webDriver = BaseTestSetup.webDriver;
        JavascriptExecutor js = (JavascriptExecutor) webDriver;
        List<WebElement> elements = webDriver.findElements(By.xpath("//mat-card-content[1]/div[1]/div"));
        for (int i = 1; i <= 11; i++) {
            WebElement a = webDriver.findElement(By.xpath("//mat-card-content[1]/div[1]/div[" + i + "]"));
            Actions element = new Actions(webDriver);
            element.moveToElement(a).doubleClick();
            Thread.sleep(3000);
            String actelement = webDriver.findElement(By.xpath("//mat-card-content[1]/div[1]/div[" + i + "]")).getText();
            Logger.info("Analyst verifies Black ribbon elements" + actelement + "");
        }
        Logger.info("Analyst verifies Black ribbon elements");
    }

    @When("Analyst Verifies Partnership Indicator as {string}")
    public void analystVerifiesPartnershipIndicator(String Partnership) {
        WebDriver webDriver = BaseTestSetup.webDriver;
        WebElement a = webDriver.findElement(By.xpath("//mat-card-content[1]/div[1]/div[7]"));
        Actions actions = new Actions(webDriver);
        actions.moveToElement(a).build().perform();
        actions.click();
        String actelement = webDriver.findElement(By.xpath("//mat-card-content[1]/div[1]/div[7]")).getText();
        String[] VAR2 = actelement.split("join_inner");
        String expected = VAR2[1];
        Logger.info("Analyst Verifies Partnership Indicator as " + expected + "");
    }
}
