package com.wu.stepdefinitions.Pharos.Sanctions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseInvestigationPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import org.jsoup.Connection;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import java.awt.*;
import java.util.List;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static com.wu.report.AllureReportManager.addScreenshotToAllureReport;

public class GetCase {

    @When("Analyst verifies yellow button from RFW widget with {string} role")
    public void verifyYelloButtonRFWWidget(String role) throws Exception {
        WebElement btnSI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[1]"));
        WebElement btnEI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[2]"));
        WebElement btnAI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[3]"));
        Thread.sleep(3000);
        if (role.equalsIgnoreCase("SI")) {
            Boolean btn = btnSI.isEnabled();
            System.out.println("******" + btn);
            if (btn.equals(true)) {
                Logger.info("SI yellow button from RFW widget is enabled");
            } else {
                Logger.error("Yellow button from RFW widget is disabled for SI role");
            }
        } else if (role.equalsIgnoreCase("EI")) {
            Boolean btn = btnEI.isEnabled();
            if (btn.equals(true)) {
                Logger.info("EI yellow button from RFW widget is enabled");
            } else {
                Logger.error("Yellow button from RFW widget is disabled for EI role");
            }
        } else {
            Boolean btn = btnAI.isEnabled();
            if (btn.equals(true)) {
                Logger.info("AI yellow button from RFW widget is enabled");
            } else {
                Logger.error("Yellow button from RFW widget is disabled for AI role");
            }
        }
    }

    @Then("Analyst clicks on yellow button to work on that case for {string} role")
    public void clickYellowbtnRFWWidget(String rolebtn) {
        WebElement btnSI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[1]"));
        WebElement btnEI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[2]"));
        WebElement btnAI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[3]"));
        if (rolebtn.equals("SI")) {
            btnSI.click();
        } else if (rolebtn.equals("EI")) {
            btnEI.click();
        } else {
            btnAI.click();
        }
        Logger.info("Clicked on yellow button for " + rolebtn + " from RFW widget");
    }

    @Then("Analyst clicks on {string} link from RFW widget")
    public void clicksTierLink(String tier) {
        WebElement tierLink = BaseTestSetup.webDriver.findElement(By.xpath("//p[contains(text(),'" + tier + "')]"));
        ((JavascriptExecutor) BaseTestSetup.webDriver).executeScript("arguments[0].scrollIntoView(true);", tierLink);
        tierLink.click();
        Logger.info("Clicked on the " + tier + " tier link");
    }

    @Then("Analyst verifies if cases are pulled for {string}")
    public void verifyCasePull(String tier) throws Exception {
        Thread.sleep(3000);
        WebElement tierTable = BaseTestSetup.webDriver.findElement(By.xpath("//mat-card-title[contains(text(),'" + tier + "')]"));
        WebElement firstCase = BaseTestSetup.webDriver.findElement(By.xpath("//table//tbody/tr[1]"));

        if (tierTable.isDisplayed() && firstCase.isDisplayed()) {
            Logger.info("Case pull for " + tier + "is successful");
        } else {
            Logger.error("Case pull has not retrieved any cases for " + tier + "tier");
        }

    }

    @Then("Analyst clicks on Work for Sanctions case")
    public void clickWorkonSanctionsCase() {
        WebElement workSanctionsCaseLink = BaseTestSetup.webDriver.findElement(By.xpath(""));

    }

    @Then("Analyst verifies default record count for {string}")
    public void verifyDefaultRecordCount(String tier) {
        //WebElement tierTable = BaseTestSetup.webDriver.findElement(By.xpath("//mat-card-title[contains(text(),'"+tier+"')]"));
        List<WebElement> totalCases = BaseTestSetup.webDriver.findElements(By.xpath("//table[@class='mat-table cdk-table mat-sort ng-star-inserted']/tbody/tr"));
        int defaultCount = totalCases.size();
        if (defaultCount == 10) {
            Logger.info("Default record Count for " + tier + " is " + defaultCount);
        } else {
            Logger.error("Default record Count for " + tier + " is " + defaultCount + " and is not 10");
        }

    }

    @Then("Analyst clicks {string} button")
    public void clickNextPreviousButtn(String btnName) {
        WebElement btn = BaseTestSetup.webDriver.findElement(By.xpath("(//button[@aria-label='" + btnName + "']/span)[1]"));
        ((JavascriptExecutor) BaseTestSetup.webDriver).executeScript("arguments[0].scrollIntoView(true);", btn);
        btn.click();
        Logger.info("Successfully clicked on " + btnName + " button");
    }

    @When("Analyst Moving Mouse over on Graph {string}")
    public void analystMovingMouseOveronGraph(String Graph) throws InterruptedException {
        if (Graph.equals("Standard Investigation")) {
            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            WebElement element = webDriver.findElement(By.xpath("//mat-card-content[1]/div[1]/div[1]/div[1]/div[1]/div[1]"));
            Actions act = new Actions(webDriver);
            act.moveToElement(element).perform();
            act.moveToElement(element).click();
            Thread.sleep(3000);
        } else {
            if (Graph.equals("Enhanced Investigation")) {
                WebDriver webDriver = BaseTestSetup.webDriver;
                webDriver.manage().window().maximize();
                WebElement element = webDriver.findElement(By.xpath("//mat-card-content[1]/div[2]/div[1]/div[1]/div[1]/div[1]"));
                Actions act = new Actions(webDriver);
                act.moveToElement(element).perform();
                Thread.sleep(3000);
            } else {
                if (Graph.equals("Advanced Investigation")) {
                    WebDriver webDriver = BaseTestSetup.webDriver;
                    webDriver.manage().window().maximize();
                    WebElement element = webDriver.findElement(By.xpath("//mat-card-content[1]/div[3]/div[1]/div[1]/div[1]/div[1]"));
                    Actions act = new Actions(webDriver);
                    act.moveToElement(element).perform();
                    Thread.sleep(3000);
                }
            }
        }
    }


    @Then("Analyst verifies yellow button of RFW widget with {string} tier")
    public void verifyYelloButton(String tier) throws Exception {
        WebElement btnSI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[1]"));
        WebElement btnEI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[2]"));
        WebElement btnAI = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[3]"));
        WebElement btnIA = BaseTestSetup.webDriver.findElement(By.xpath("(//mat-icon[contains(text(),'label_important')])[4]"));
        Thread.sleep(3000);
        if (tier.equalsIgnoreCase("SI")) {
            Boolean btn = btnSI.isEnabled();
            System.out.println("******" + btn);
            if (btn.equals(true)) {
                Logger.info("Yellow button from RFW widget is disabled for SI role");
            } else {
                Logger.error("SI yellow button from RFW widget is enabled");
            }
        } else if (tier.equalsIgnoreCase("EI")) {
            Boolean btn = btnEI.isEnabled();
            if (btn.equals(true)) {
                Logger.error("Yellow button from RFW widget is disabled for EI role");

            } else {
                Logger.info("EI yellow button from RFW widget is enabled");

            }
        } else if (tier.equalsIgnoreCase("AI")) {
            Boolean btn = btnAI.isEnabled();
            if (btn.equals(true)) {
                Logger.error("Yellow button from RFW widget is disabled for AI role");

            } else {
                Logger.info("AI yellow button from RFW widget is enabled");

            }
        } else {
            Boolean btn = btnIA.isEnabled();
            System.out.println("******" + btn);
            if (btn.equals(true)) {
                Logger.error("Yellow button from RFW widget is disabled for IA role");

            } else {
                Logger.info("IA yellow button from RFW widget is enabled");

            }

        }
    }
    @When("Analyst verifying the red color over on Graph {string}")
    public void analystMovingMouseOverRedonGraph(String Graph)throws InterruptedException {
        if (Graph.equals("Standard Investigation")) {
            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            WebElement element = webDriver.findElement(By.xpath("//app-dashboard[1]/div[1]/div[3]/app-dashboard-widget[1]/div[1]/mat-card[1]/mat-card-content[1]/div[1]/div[1]/div[1]/div[1]/div[1]"));
            element.getText();
            Actions act = new Actions(webDriver);
            act.moveToElement(element).perform();
            Thread.sleep(3000);
        }else{
            if (Graph.equals("Enhanced Investigation")){
                WebDriver webDriver = BaseTestSetup.webDriver;
                webDriver.manage().window().maximize();
                WebElement element = webDriver.findElement(By.xpath("//app-dashboard[1]/div[1]/div[3]/app-dashboard-widget[1]/div[1]/mat-card[1]/mat-card-content[1]/div[2]/div[1]/div[1]/div[1]/div[2]"));
                element.getText();
                Actions act = new Actions(webDriver);
                act.moveToElement(element).perform();
                Thread.sleep(3000);
            }else {
                if (Graph.equals("Advanced Investigation")){
                    WebDriver webDriver = BaseTestSetup.webDriver;
                    webDriver.manage().window().maximize();
                    WebElement element = webDriver.findElement(By.xpath("//app-dashboard[1]/div[1]/div[3]/app-dashboard-widget[1]/div[1]/mat-card[1]/mat-card-content[1]/div[3]/div[1]/div[1]/div[1]/div[2]"));
                    element.getText();
                    Actions act = new Actions(webDriver);
                    act.moveToElement(element).perform();
                    Thread.sleep(3000);
                }else {
                    if (Graph.equals("Investigation Approval")){
                        WebDriver webDriver = BaseTestSetup.webDriver;
                        webDriver.manage().window().maximize();
                        WebElement element = webDriver.findElement(By.xpath("//mat-card[1]/mat-card-content[1]/div[4]/div[1]/div[1]/div[1]/div[2]"));
                        element.getText();
                        Actions act = new Actions(webDriver);
                        act.moveToElement(element).perform();
                        Thread.sleep(3000);{

                        }}
                }
            }
        }
    }
    @When("Analyst verifying the green color over on Graph {string}")
    public void analystMovingMouseOverGreenonGraph(String Graph)throws InterruptedException {
        if (Graph.equals("Standard Investigation")) {
            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[1]/div[1]/div[1]/div/div[1]"));
            element.getText();
            Actions act = new Actions(webDriver);
            act.moveToElement(element).perform();
            Thread.sleep(3000);
        }else{
            if (Graph.equals("Enhanced Investigation")){
                WebDriver webDriver = BaseTestSetup.webDriver;
                webDriver.manage().window().maximize();
                WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[3]/div[1]/div[1]/div/div[1]"));
                element.getText();
                Actions act = new Actions(webDriver);
                act.moveToElement(element).perform();
                Thread.sleep(3000);
            }else {
                if (Graph.equals("Advanced Investigation")){
                    WebDriver webDriver = BaseTestSetup.webDriver;
                    webDriver.manage().window().maximize();
                    WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[3]/div[1]/div[1]/div/div[1]"));
                    element.getText();
                    Actions act = new Actions(webDriver);
                    act.moveToElement(element).perform();
                    Thread.sleep(3000);
                }else {
                    if (Graph.equals("Investigation Approval")){
                        WebDriver webDriver = BaseTestSetup.webDriver;
                        webDriver.manage().window().maximize();
                        WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[1]/div[1]/div[1]/div/div[1]"));
                        element.getText();
                        Actions act = new Actions(webDriver);
                        act.moveToElement(element).perform();
                        Thread.sleep(3000);{

                        }}
                }
            }
        }
    }

    @When("Analyst verifying the count on green color by plus one {string}")
    public void analystMovingMouseOverGreenColoronGraph(String Graph)throws InterruptedException {
        if (Graph.equals("Standard Investigation")) {
            WebDriver webDriver = BaseTestSetup.webDriver;
            webDriver.manage().window().maximize();
            WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[1]/div[1]/div[1]/div/div[1]"));
            element.getText();
            Actions act = new Actions(webDriver);
            act.moveToElement(element).perform();
            Thread.sleep(3000);
        }else{
            if (Graph.equals("Enhanced Investigation")){
                WebDriver webDriver = BaseTestSetup.webDriver;
                webDriver.manage().window().maximize();
                WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[3]/div[1]/div[1]/div/div[1]"));
                element.getText();
                Actions act = new Actions(webDriver);
                act.moveToElement(element).perform();
                Thread.sleep(3000);
            }else {
                if (Graph.equals("Advanced Investigation")){
                    WebDriver webDriver = BaseTestSetup.webDriver;
                    webDriver.manage().window().maximize();
                    WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[3]/div[1]/div[1]/div/div[1]"));
                    element.getText();
                    Actions act = new Actions(webDriver);
                    act.moveToElement(element).perform();
                    Thread.sleep(3000);
                }else {
                    if (Graph.equals("Investigation Approval")){
                        WebDriver webDriver = BaseTestSetup.webDriver;
                        webDriver.manage().window().maximize();
                        WebElement element = webDriver.findElement(By.xpath("//*[@id=\"container-3\"]/content/app-dashboard/div/div[3]/app-dashboard-widget[1]/div/mat-card/mat-card-content/div[1]/div[1]/div[1]/div/div[1]"));
                        element.getText();
                        Actions act = new Actions(webDriver);
                        act.moveToElement(element).perform();
                        Thread.sleep(3000);{

                        }}
                }
            }
        }
    }
}