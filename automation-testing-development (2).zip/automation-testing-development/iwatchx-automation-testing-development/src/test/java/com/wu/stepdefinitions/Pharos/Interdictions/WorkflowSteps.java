package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.logger.Logger;
import com.wu.pages.BasePage;
import com.wu.pages.Pharos.Interdictions.CaseDispositionControlPage;
import com.wu.pages.Pharos.Interdictions.CaseInvestigationPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.WebElement;

import java.util.List;

import static com.wu.report.AllureReportManager.addScreenshotToAllureReport;

public class WorkflowSteps extends BasePage {

    CaseDispositionControlPage caseDispositionControlPage = new CaseDispositionControlPage();

    @Then("Analyst validates {string} description in Audit Log with who as {string}")
    public void analystValidatesAutoDisAuditLog(String expAuditDEsc,String whoValue)throws Exception {
        CaseInvestigationPage caseInvestigationPage = new CaseInvestigationPage();
        List<WebElement> auditRows = caseInvestigationPage.getAuditTabletr();
        int rows_count = auditRows.size();
        int entityRow=0;
        boolean bflag=false;
        boolean bflag1=false;
        for (int i =1;i<=rows_count;i++) {
            WebElement ele =browserElementLocator.findElementByXpath("//table[@class='mat-table cdk-table mat-sort']/tbody/tr["+i+"]/td[3]");
            String actDEsc = ele.getText().trim();
            if (expAuditDEsc.equalsIgnoreCase(actDEsc))
            {
                bflag=true;
                entityRow=i;
                WebElement ele1 = browserElementLocator.findElementByXpath("//table[@class='mat-table cdk-table mat-sort']/tbody/tr["+entityRow+"]/td[5]");
                String entityValue = ele1.getText().trim();
                if (entityValue.equalsIgnoreCase(whoValue)) {
                    bflag1=true;
                    break;
                }
            }
        }
        if( bflag) {
            Logger.info("Expected audit message is displayed : " + expAuditDEsc);
            if (bflag1) {
                Logger.info("Expected "+expAuditDEsc+" is updated by "+whoValue);
            } else
                Logger.error("Expected "+expAuditDEsc+" is not updated by "+whoValue);
        }
        else
            Logger.error("Expected audit message is not displayed.");
    }

    @When("Analyst Validated CTM Ack for action Workflow when invalid value in txn {string}")
    public void analystValidatedCTMAck_InvalidValue(String ackWF) {
        caseDispositionControlPage.validateCTMAck_WithClose(ackWF);
        Logger.info("Analyst Validated CTM Ack for action Workflow");
    }

    @Then("Analyst verifies workflow timeline")
    public void analystVerifiesWorkFlowInCaseHeader()throws Exception {
        caseDispositionControlPage.verifiesWorkFlow();
    }

    @Then("Analyst verifies workflow timeline for Pending Info")
    public void analystVerifiesWorkFlowInCaseHeader_PI()throws Exception {
        caseDispositionControlPage.verifiesWorkFlow_PI();
    }

    @Then("Analyst validates tier {string} in CTM Ack action")
    public void analystValidatesPrevTierATCM(String tier){
        caseDispositionControlPage.validateTierInCTM(tier);
    }

    @When("Analyst Validated CTM Ack for action Workflow {string}")
    public void analystValidatedCTMAck(String ackWF) throws Exception {
        caseDispositionControlPage.validateCTMAck(ackWF);
        Logger.info("Analyst Validated CTM Ack for action Workflow");
        addScreenshotToAllureReport("CTM Action Interface");
    }

    @When("Analyst Validates that CTM Ack for action Workflow has {string} for {string} Tier")
    public void analystValidatesCTMForTier(String expCTM, String tier){
        String actCTM;
        if(tier.equalsIgnoreCase("SI")){
            actCTM = caseDispositionControlPage.getSICTMText();
            caseDispositionControlPage.validateCTMActionTimeline(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("EI")){
            actCTM = caseDispositionControlPage.getEICTMText();
            caseDispositionControlPage.validateCTMActionTimeline(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("AI")){
            actCTM = caseDispositionControlPage.getAICTMText();
            caseDispositionControlPage.validateCTMActionTimeline(actCTM,expCTM);
        }
        else{
            actCTM = caseDispositionControlPage.getIACTMText();
            caseDispositionControlPage.validateCTMActionTimeline(actCTM,expCTM);
        }
    }

    @When("Analyst Validates that CTM Ack for action Workflow has {string} for {string} Tier without green ticks")
    public void analystValidatesCTMForTierWithoutGreenTick(String expCTM, String tier){
        String actCTM;
        if(tier.equalsIgnoreCase("SI")){
            actCTM = caseDispositionControlPage.getSICTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithoutTick(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("EI")){
            actCTM = caseDispositionControlPage.getEICTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithoutTick(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("AI")){
            actCTM = caseDispositionControlPage.getAICTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithoutTick(actCTM,expCTM);
        }
        else{
            actCTM = caseDispositionControlPage.getIACTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithoutTick(actCTM,expCTM);
        }
    }

    @When("Analyst Validates that CTM Ack for action Workflow has {string} for {string} Tier with ticks")
    public void analystValidatesCTMForTierWithTicks(String expCTM, String tier){
        String actCTM;
        if(tier.equalsIgnoreCase("SI")){
            actCTM = caseDispositionControlPage.getSICTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithTick(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("EI")){
            actCTM = caseDispositionControlPage.getEICTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithTick(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("AI")){
            actCTM = caseDispositionControlPage.getAICTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithTick(actCTM,expCTM);
        }
        else{
            actCTM = caseDispositionControlPage.getIACTMText();
            caseDispositionControlPage.validateCTMActionTimelineWithTick(actCTM,expCTM);
        }
    }

    @When("Analyst Validates that CTM Ack for action Workflow has {string} for {string} Tier on hold")
    public void analystValidatesCTMForTierOnHold(String expCTM, String tier){
        String actCTM;
        if(tier.equalsIgnoreCase("SI")){
            actCTM = caseDispositionControlPage.getSICTMText();
            caseDispositionControlPage.validateCTMActionTimelineOnHold(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("EI")){
            actCTM = caseDispositionControlPage.getEICTMText();
            caseDispositionControlPage.validateCTMActionTimelineOnHold(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("AI")){
            actCTM = caseDispositionControlPage.getAICTMText();
            caseDispositionControlPage.validateCTMActionTimelineOnHold(actCTM,expCTM);
        }
        else{
            actCTM = caseDispositionControlPage.getIACTMText();
            caseDispositionControlPage.validateCTMActionTimelineOnHold(actCTM,expCTM);
        }
    }



    @When("Analyst Validates that CTM Ack for action Workflow has {string} without green ticks")
    public void analystValidatesCTMWithoutGreenTick(String expCTM){
        String actCTM;

        actCTM = caseDispositionControlPage.getSICTMText(); //Method name has SI but gives first action timeline text
        caseDispositionControlPage.validateCTMActionTimelineWithoutTick(actCTM,expCTM);

    }

    @When("Analyst Validates that CTM Ack for action Workflow has overriden with {string} for {string} Tier")
    public void analystValidatesCTMOveriddenForTierWith(String expCTM, String tier){
        String actCTM;
        if(tier.equalsIgnoreCase("SI")){
            actCTM = caseDispositionControlPage.getSICTMText();
            caseDispositionControlPage.validateCTMActionTimelineOverride(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("EI")){
            actCTM = caseDispositionControlPage.getEICTMText();
            caseDispositionControlPage.validateCTMActionTimelineOverride(actCTM,expCTM);
        }
        else if(tier.equalsIgnoreCase("AI")){
            actCTM = caseDispositionControlPage.getAICTMText();
            caseDispositionControlPage.validateCTMActionTimelineOverride(actCTM,expCTM);
        }
        else{
            actCTM = caseDispositionControlPage.getIACTMText();
            caseDispositionControlPage.validateCTMActionTimelineOverride(actCTM,expCTM);
        }
    }



    @When("Analyst Validated CTM Ack text for action Workflow {string}")
    public void analystValidatedCTMAcktext(String ackWF) throws Exception {
        caseDispositionControlPage.validateCTMAckOnlytext(ackWF);
        Logger.info("Analyst Validated CTM Ack text for action Workflow");
        addScreenshotToAllureReport("CTM text Action Interface");
    }


    @Then("Analyst verifies workflow timeline for Pend")
    public void analystVerifiesWorkFlowInCaseHeader_Pend()throws Exception {
        caseDispositionControlPage.verifiesWorkFlow_Pend();
    }

    @When("Analyst Validated CTM Ack for action Workflow {string} with action on hold")
    public void analystValidatedCTMAckNoAction(String ackWF) throws Exception {
        caseDispositionControlPage.validateCTMAckNoAction(ackWF);
        Logger.info("Analyst Validated CTM Ack for action Workflow");
        addScreenshotToAllureReport("CTM Action Interface");
    }
}
