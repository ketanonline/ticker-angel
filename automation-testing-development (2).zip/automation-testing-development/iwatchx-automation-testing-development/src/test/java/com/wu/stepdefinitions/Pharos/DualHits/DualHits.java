package com.wu.stepdefinitions.Pharos.DualHits;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseInvestigationPage;
import com.wu.pages.Pharos.Interdictions.DashboardPage;
import com.wu.pages.Pharos.Interdictions.EntityDispositionPage;
import cucumber.api.java.en.Then;
import gherkin.ast.DataTable;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.util.Arrays;
import java.util.List;

import static com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps.getCaseData;

public class DualHits {
    DashboardPage page = new DashboardPage();
    EntityDispositionPage dispoPge = new EntityDispositionPage();
    CaseInvestigationPage caseInvestigationPage = new CaseInvestigationPage();

    Actions actions = new Actions(BaseTestSetup.webDriver);
    List<String> listApplicable ;
    List<String> listNotApplicable ;

    @Then("Analyst verifies the Investigative focus as {string}")
    public void verifyInvestigativeFocus(String expectedInvFoc) {
        String actualInvFoc = page.getInvestigativeFocus().getText();
        Assert.assertEquals(expectedInvFoc, actualInvFoc, "Analyst successfully verified the Investigative Focus as :" + expectedInvFoc);
    }
    @Then("Analyst verifies the Investigative focus as {string} for tier {string}")
    public void verifyInvestigativeFocusforTier(String expectedInvFoc,String tierName) {
        if (tierName.equalsIgnoreCase("Standard Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-flex-width-15 ml-12 wu-btn-clickable wu-case-count']")).size()>0) {
            String actualInvFoc = page.getInvestigativeFocus().getText();
            Assert.assertEquals(expectedInvFoc, actualInvFoc, "Analyst successfully verified the Investigative Focus as :" + expectedInvFoc);
        }
        else if(tierName.equalsIgnoreCase("Enhanced Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[2]/div[1]/div[2]")).size()>0){
            String actualInvFoc = page.getInvestigativeFocus().getText();
            Assert.assertEquals(expectedInvFoc, actualInvFoc, "Analyst successfully verified the Investigative Focus as :" + expectedInvFoc);
        }
        else if(tierName.equalsIgnoreCase("Advanced Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[3]/div[1]/div[2]")).size()>0){
            String actualInvFoc = page.getInvestigativeFocus().getText();
            Assert.assertEquals(expectedInvFoc, actualInvFoc, "Analyst successfully verified the Investigative Focus as :" + expectedInvFoc);
        }
        else if(tierName.equalsIgnoreCase("Investigation Approver") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[4]/div[1]/div[2]")).size()>0){
            String actualInvFoc = page.getInvestigativeFocus().getText();
            Assert.assertEquals(expectedInvFoc, actualInvFoc, "Analyst successfully verified the Investigative Focus as :" + expectedInvFoc);
        }
        else {
            Logger.info("Cases are not present to perform required action");
        }
    }

    @Then("Analyst verifies the {string} filter checkbox functionality")
    public void verifyFilterBoxes(String InvFocus) {
        try {
            Assert.assertTrue(dispoPge.getFilterCheckboxes(InvFocus).isDisplayed(), "Unable to verify " + InvFocus + " filter checkbox");
            switch(InvFocus){
                case "Sanctions":
                    dispoPge.getFilterCheckboxes("Interdictions").click();
                    break;
                case "Interdictions":
                    dispoPge.getFilterCheckboxes("Sanctions").click();
                    break;
            }
            List<WebElement> entityCards = BaseTestSetup.webDriver.findElements(By.xpath("//app-hit-entity"));

            for (int i = 1; i <= entityCards.size(); i++) {
                if (InvFocus.equals("Sanctions")) {
                    Assert.assertTrue(BaseTestSetup.webDriver.findElement(By.xpath("(//mat-card-title[contains(text(),'" + InvFocus + "')])[" + i + "]")).isDisplayed(), "No Entity card is diplayed");
                } else {
                    Assert.assertTrue(BaseTestSetup.webDriver.findElement(By.xpath("(//mat-card-title[contains(text(),'INTR')])[" + i + "]")).isDisplayed(), "No Entity card is diplayed");
                }
            }
            switch(InvFocus){
                case "Sanctions":
                    dispoPge.getFilterCheckboxes("Interdictions").click();
                    break;
                case "Interdictions":
                    dispoPge.getFilterCheckboxes("Sanctions").click();
                    break;
            }

        } catch (Exception e) {
            Logger.error("No Entity card found");
        }
    }

    @Then("Analyst verifies the applicable entity reasons for {string} in SI Tier")
    public void verifyTierWiseReasonsForDualCases(String InvFocus) throws InterruptedException {

        if (InvFocus.equals("Sanctions")) {
            dispoPge.getFilterCheckboxes("Interdictions").click();
           listApplicable= Arrays.asList("d","i","p","g","s","n","a","t","b");
            listNotApplicable= Arrays.asList("c");
        } else {
            dispoPge.getFilterCheckboxes("Sanctions").click();
            listApplicable= Arrays.asList("d","i","c","n","a");
            listNotApplicable= Arrays.asList("p","g","s","t","b");
        }
        verifyApplicableReasons(InvFocus);
    }

    @Then("Analyst verifies the applicable entity reasons for {string} in EI Tier")
    public void verifyEITierWiseReasonsForDualCases(String InvFocus) throws InterruptedException {

        if (InvFocus.equals("Sanctions")) {
            dispoPge.getFilterCheckboxes("Interdictions").click();
            listApplicable= Arrays.asList("d","i","p","g","s","n","a","o","e","t","x","b","j");
            listNotApplicable= Arrays.asList("c","y","v");
        } else {
            dispoPge.getFilterCheckboxes("Sanctions").click();
            listApplicable= Arrays.asList("d","i","c","n","a");
            listNotApplicable= Arrays.asList("p","g","y","s","o","e","t","b","j","v","b");
        }
        verifyApplicableReasons(InvFocus);
    }

    @Then("Analyst verifies the applicable entity reasons for {string} in AI Tier")
    public void verifyAITierWiseReasonsForDualCases(String InvFocus) throws InterruptedException {

        if (InvFocus.equals("Sanctions")) {
            dispoPge.getFilterCheckboxes("Interdictions").click();
            listApplicable= Arrays.asList("d","i","p","g","s","n","a","o","e","t","x","b","j");
            listNotApplicable= Arrays.asList("c","y","v");
        } else {
            dispoPge.getFilterCheckboxes("Sanctions").click();
            listApplicable= Arrays.asList("d","i","c","n","a");
            listNotApplicable= Arrays.asList("p","g","y","s","o","e","t","b","x","j","v","b");
        }
        verifyApplicableReasons(InvFocus);
    }

    public void verifyApplicableReasons(String InvFocus) throws InterruptedException {
        Thread.sleep(2000);
        caseInvestigationPage.clickOnAllEntities();
        for(int i =0;i<listApplicable.size();i++) {
            actions.keyDown(Keys.SHIFT).sendKeys(listApplicable.get(i)).keyUp(Keys.ALT).perform();
            String errorMessage = caseInvestigationPage.getToaster().getAttribute("innerHTML");
            Assert.assertFalse(errorMessage.contains("Please correct entity reasons. Entity Type "+InvFocus+" disallows reason"),"Failed to add reason");
            Logger.info("Analyst is able to select - Shift+" +listApplicable.get(i)+ " reason");
        }
        for(int i =0;i<listNotApplicable.size();i++) {
            actions.keyDown(Keys.SHIFT).sendKeys(listNotApplicable.get(i)).keyUp(Keys.ALT).perform();
            Thread.sleep(3000);
            String errorMessage = BaseTestSetup.webDriver.findElement(By.xpath("//simple-snack-bar/span[contains(text(),'Please correct entity reasons. Entity Type Interdictions disallows reason')]")).getAttribute("innerHTML");
            Assert.assertTrue(errorMessage.contains("Please correct entity reasons. Entity Type "+InvFocus+" disallows reason"),"Failed to add reason");
            Thread.sleep(2000);
            Logger.info("Analyst is not able to select - Shift+" +listNotApplicable.get(i)+ " reason");
        }
        Thread.sleep(2000);
        caseInvestigationPage.clickOnAllEntities();
    }
    @Then("Analyst checks the Sanctions filter checkbox")
    public void checkSanctionsFileter(){
        dispoPge.getFilterCheckboxes("Interdictions").click();
    }
    @Then("Analyst checks the Interdictions filter checkbox")
    public void checkInterdictionFileter(){
        dispoPge.getFilterCheckboxes("Sanctions").click();
    }
    @Then("Analyst verifies INTR entities allow Match Disposition")
    public void verifyMatchDispositionINTR() {
        String matchEntities = dispoPge.getMatchEntities().getAttribute("innerHTML");
        Assert.assertFalse(matchEntities.equalsIgnoreCase("0"), "Unable to put INTR entities in Match bucket ");
    }

    @Then("Analyst verifies the toaster message disallowing Match bucket for Sanctions")
    public void toasterMessageSANCMatchBucket(){
        String errorToasterMsg = dispoPge.getErrorToasterMsg().getAttribute("innerHTML");
        Assert.assertTrue(errorToasterMsg.contains("Sanctions entities are not allowed to be moved to Match bucket in Standard Investigation Tier"),"Toaster message displayed");
    }

    @Then("Analyst verifies Action dropdown values for IA Tier")
    public void verifyDropdown(DataTable reasons){
//        List<String> reasonsList = reasons.asList(String.class);
//        boolean res = caseInvestigationPage.listOfReasonsDisplayed(reasonsList);
//        Logger.info("List of Reasons displayed verified");
//        Assert.assertTrue(res, "Test Passed and Reasons are displayed as expected");
    }

    @Then("Analyst verifies the triggerring purpose as {string}")
    public void analystVerifiesTheTriggerringPurposeAs(String expectedTrgPurpose) {
         Assert.assertTrue(page.getTriggeringPurpose(expectedTrgPurpose).isDisplayed(),"Verifies the Triggering Purpose");
        }

    @Then("Analyst verifies the triggerring purpose as {string} for tier {string}")
    public void analystVerifiesTheTriggerringPurposeAsTierName(String expectedTrgPurpose,String tierName) {
        if(tierName.equalsIgnoreCase("Standard Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-flex-width-15 ml-12 wu-btn-clickable wu-case-count']")).size()>0){
        Assert.assertTrue(page.getTriggeringPurpose(expectedTrgPurpose).isDisplayed(),"Verifies the Triggering Purpose");
        }
        else if(tierName.equalsIgnoreCase("Enhanced Investigation") && BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[2]/div[1]/div[2]")).size()>0) {
            Assert.assertTrue(page.getTriggeringPurpose(expectedTrgPurpose).isDisplayed(),"Verifies the Triggering Purpose");
        }
        else{
            Logger.info("Cases are not present to perform required action");
        }

    }

    @Then("Analyst verifies the Review Type as Third Party At Send")
    public void analystVerifiesTheReviewTypeAsThirdPartyAtSend() {
        if (BaseTestSetup.webDriver.findElements(By.xpath("//mat-card/mat-card-content/div[2]/div[1]/div[2]")).size() > 0) {
            Assert.assertTrue(page.getReviewType("Third Party At Send").isDisplayed(),"Verifies the Review Type as Third Party At SEnd");
        } else {
        Logger.info("Case with third party at Send Does not exist");
        }
    }

    @Then("Analyst verifies the Review Type for {string} for {string} in {string} with Review Type {string}")
    public void analystVerifiesTheReviewType(String fieldName,String type,String BG,String ReviewType) {
        int DbCount=0;
        String getData="";
        if(fieldName.equals("Standard Investigation") && type.equals("SLAB")) {
            getData = "SISlab";
        }
        else if(fieldName.equals("Standard Investigation") && type.equals("SLANB")) {
            getData = "SISlanb";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLAB")) {
            getData = "EISlab";
        }
        else if(fieldName.equals("Enhanced Investigation") && type.equals("SLANB")) {
            getData = "EISlanb";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLAB")) {
            getData = "AISlab";
        }
        else if(fieldName.equals("Advanced Investigation") && type.equals("SLANB")) {
            getData = "AISlanb";
        }
        else if(fieldName.equals("Approver") && type.equals("SLAB")) {
            getData = "IASlab";
        }
        else if(fieldName.equals("Approver") && type.equals("SLANB")) {
            getData = "IASlanb";
        }
        else{
            Assert.assertTrue(0>1,"Field Name is invalid. Please recheck.");
            Logger.info("Field Name is invalid. Please recheck.") ;
        }
        DbCount= Integer.parseInt(getCaseData(getData));

        if(DbCount > 0) {
            Assert.assertTrue(page.getReviewType(ReviewType).isDisplayed(),"Verifies the Review Type");
        } else {
            Logger.info("Case  Does not exist");
        }
    }


    @Then("Analyst verifies the heading Third Party At Send at case Information Page")
    public void analystVerifiesTheHeadingThirdPartyAtSendAtCaseInformationPage() {
        String headingText = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-heading-text wu-capitalize']")).getText();
        Assert.assertEquals(headingText,"Third Party At Send","Analyst verifies the text Third Party At Send in heading");
        Logger.info("Analyst verifies the text Third Party At Send in heading");
    }

    @Then("Analyst verifies the failure column in Cases Table")
    public void analystVerifiesTheFailureColumnInCasesTable() throws InterruptedException {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0) {
            Thread.sleep(3000);
            int count = BaseTestSetup.webDriver.findElements(By.xpath("//th[text()='Failure']")).size();
            Assert.assertTrue(count > 0, "Failure Header exists in cases table.");
            Logger.info("Failure Header exists in cases table.");
        }
    }
    @Then("Analyst verifies caseId in the header is not present in action failure widget grid")
    public void analystVerifiesRemovalOfCaseIdInCasesTable() throws InterruptedException {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0) {
            Thread.sleep(3000);
            int count = page.getGridHeaderSize("Case Id").size();
            Assert.assertTrue(count == 0, "Case Id does not exists in cases table.");
            Logger.info("Case Id does not exists in cases table.");
        }
    }

    @Then("Analyst verifies action failure Review Type for {string} in {string} with Review Type {string}")
    public void analystVerifiesActionFailureReviewTypeForInWithReviewType(String fieldName, String BG, String reviewType) {
        int DbCount = Integer.parseInt(getCaseData("count"));

        if(DbCount > 0) {

            page.getActionFailureTypeCasesCount(fieldName).click();
            Logger.info("User clicks on Action Failure Widget " +fieldName +" " +BG + " " +reviewType);
            Assert.assertTrue(page.getReviewType(reviewType).isDisplayed(),"Verifies the Review Type");

        }
        else {
//            int count =dashboardPage.getActionFailureTypeCasesCountSize(fieldName).size();
            Logger.info("Cases are not there for User clicks on Action Failure Widget " +fieldName +" " +BG + " " +reviewType);
        }
    }
}