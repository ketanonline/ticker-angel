package com.wu.stepdefinitions;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;
import com.wu.base.BaseTestSetup;
import com.wu.base.jiraintegration.JiraServices;
import com.wu.base.logger.Logger;
import com.wu.base.recorder.ScreenRecordingManager;
import com.wu.report.AllureReportManager;
import com.wu.utils.AutProperties;
import com.wu.utils.CommonUtils;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

import java.awt.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

public class CucumberBase {
    public static String jira;
    public static String scenarioName;
    public ScreenRecordingManager screenRecorder = new ScreenRecordingManager();
    private boolean isAppStarted = false;

    @Before("@UI")
    public void cucumberBefore() throws IOException, AWTException {

        Logger.info("-------------------------Starting " + AutProperties.getAppName() + " Session---------------------------------");
        if (null != AutProperties.getAppName()) {
            BaseTestSetup.setupWindowsApplication(AutProperties.getAppName());
        }else if(null != AutProperties.autProperties.getProperty("browser.name")){
            BaseTestSetup.setupBrowser();
        }
        isAppStarted = true;
        screenRecorder.startRecording();
    }

    @After("@UI")
    public void cucumberAfter(Scenario scenario) {
        System.out.println("Inside cucumber after");
        screenRecorder.isTestFailed = scenario.isFailed();
        if (scenario.isFailed()) {
            Logger.debug("Scenario Failed: adding screenshot to report");
            AllureReportManager.addScreenshotToAllureReport(scenario.getName());
        }
        screenRecorder.stopRecording();
        if (isAppStarted) {
            if (null != AutProperties.getAppName()) {
                BaseTestSetup.shutDownApplication(AutProperties.getAppName());
            }else if(null != AutProperties.autProperties.getProperty("default.browser")){
                BaseTestSetup.closeBrowserSession();
            }

            isAppStarted = false;
        }
    }

    @Before(order = 1)
    public void setup(Scenario scenario) {
        Logger.info("====================== Executing: " + scenario.getName() + " ================================");
        scenarioName = (scenarioName = "") + scenario.getName().replaceAll("\"", "");
        screenRecorder.testName = (screenRecorder.testName = "") + scenarioName;

        if (AutProperties.getIsToUpdateJira()) {
            Collection<String> collection = scenario.getSourceTagNames();
            String[] tags = collection.toString().replaceAll("\\[|\\]", "").split("@");
            jira = "";
            for (String tag : tags) {
                if (tag.toLowerCase().contains("jira::")) {
                    jira = (jira + tag.split("::")[1].trim()).trim();
                }
            }
            Logger.info("Jira's:" + jira + " status will be updated on execution of current Scenario: "
                    + scenarioName);
            Logger.info("Adding Jira's:" + jira + "to the execution cycle");
            JiraServices jiraServices = new JiraServices(AutProperties.getAut());
            String[] jiraTickets = jira.split(",");
            for (String jiraTicket : jiraTickets) {
                jiraServices.addTestToCycle(jiraTicket);
            }
        }
//        Serenity.getCurrentSession().put("AuthorizedUserNKeyValue", "");
//        Serenity.getCurrentSession().put("BeneficaryRemitterNKeyValue", "");
//        Serenity.getCurrentSession().put("ThirdPartyNKeyValue", "");
//        Serenity.getCurrentSession().put("ThirdPartySKey", "");
//        Serenity.getCurrentSession().put("SenderCustomerSKeyValue", "");
//        Serenity.getCurrentSession().put("SenderBankAccountSKey", "");
//        Serenity.getCurrentSession().put("BeneficiarySKeyValue", "");
//        Serenity.getCurrentSession().put("SenderBankAccountSKey", "");
//        Serenity.getCurrentSession().put("ThirdPartyAccountSKey", "");
//        Serenity.getCurrentSession().put("BeneficiarySKey", "");
//        Serenity.getCurrentSession().put("AuthorizedUserSKey", "");
//        Serenity.getCurrentSession().put("BeneficiarySKeyValue", "");
//        Serenity.getCurrentSession().put("ReceipentAccountSKey", "");
//        Serenity.getCurrentSession().put("SenderCustomerSKeyValue", "");
//        Serenity.getCurrentSession().put("BeneficiarySKeyValue", "");
//        Serenity.getCurrentSession().put("BranchNKeyValue", "");
//        Serenity.getCurrentSession().put("BranchCode", "");
//        Serenity.getCurrentSession().put("BranchSKeyValue", "");
//        Serenity.getCurrentSession().put("BeneficiaryRemitterSKey", "");
//        Serenity.getCurrentSession().put("PaymentSourcePlatformIDFieldValueIsBlank", false);
//        Serenity.getCurrentSession().put("goodBadPaymentFlag", false);
    }

    @After(order = 1)
    public void testDataCleanup(Scenario scenario) throws CsvException, Exception {
        // Write to CSV file which is open
        String csvFile = new File(CommonUtils.getResourcePath("testResult") + File.separator + "testResult.csv").getAbsolutePath();
        FileReader filereader = new FileReader(csvFile);
        CSVReader csvReader = new CSVReaderBuilder(filereader).withSkipLines(0).build();
        List<String[]> allRows = csvReader.readAll();

        String[] row = new String[7];
        row[0] = "";
        row[1] = scenario.getName();
        row[2] = scenario.getName();
        row[3] = "0";
        row[4] = "0";
        row[5] = "0";
        row[6] = "0";

        switch (scenario.getStatus())
        {
            case PASSED:
                row[5] = "1";
                break;
            case FAILED:
                row[3] = "1";
                break;
            case SKIPPED:
                row[6] = "1";
                break;
        }

        allRows.add(row);

        CSVWriter writer = new CSVWriter(new FileWriter(csvFile));
        writer.writeAll(allRows);

        writer.flush();


//        if (Serenity.getCurrentSession().containsKey("SenderCustomerSKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("Customer", Serenity.getCurrentSession().get("SenderCustomerSKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("BeneficiarySKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("Beneficary", Serenity.getCurrentSession().get("BeneficiarySKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("AuthorizedUserSKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("AuthorizedUser", Serenity.getCurrentSession().get("AuthorizedUserSKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("SenderCustomerBankAccountSKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("BankAccountDetail", Serenity.getCurrentSession().get("SenderCustomerBankAccountSKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("RecipientCustomerBankAccountSKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("BankAccountDetail", Serenity.getCurrentSession().get("RecipientCustomerBankAccountSKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("ThirdPartyBankAccountSKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("BankAccountDetail", Serenity.getCurrentSession().get("ThirdPartyBankAccountSKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("BeneficaryRemitterNKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("BeneficiaryRemitter", Serenity.getCurrentSession().get("BeneficaryRemitterNKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("BranchSKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("Branch", Serenity.getCurrentSession().get("BranchSKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("ThirdPartyRemitterSKeyValue")) {
//            CommonFunctions.RemoveDataFromSQLDB("ThirdParty", Serenity.getCurrentSession().get("ThirdPartyRemitterSKeyValue").toString());
//        }
//        if (Serenity.getCurrentSession().containsKey("OutgoingPaymentID")) {
//            CommonFunctions.RemoveDataFromSQLDB("Payment", Serenity.getCurrentSession().get("OutgoingPaymentID").toString());
//        }
//
//     /* if (Serenity.getCurrentSession().containsKey("CBActiveSession")){
//        if (Serenity.getCurrentSession().get("CBActiveSession").equals(true)){
//          CouchBaseUtility.couchbaseCluster.disconnect();
//          serenityrest.util.common.CouchBaseUtility.couchbaseBucket.close();
//        }
//      }*/
//        Serenity.getCurrentSession().put("CBActiveSession", "");
//        Serenity.getCurrentSession().put("CBEntityActiveSession", "");
//        Serenity.getCurrentSession().put("AuthorizedUserNKeyValue", "");
//        Serenity.getCurrentSession().put("BeneficaryRemitterNKeyValue", "");
//        Serenity.getCurrentSession().put("ThirdPartyNKeyValue", "");
//        Serenity.getCurrentSession().put("ThirdPartySKey", "");
//        Serenity.getCurrentSession().put("SenderCustomerSKeyValue", "");
//        Serenity.getCurrentSession().put("SenderBankAccountSKey", "");
//        Serenity.getCurrentSession().put("BeneficiarySKeyValue", "");
//        Serenity.getCurrentSession().put("SenderBankAccountSKey", "");
//        Serenity.getCurrentSession().put("ThirdPartyAccountSKey", "");
//        Serenity.getCurrentSession().put("BeneficiarySKey", "");
//        Serenity.getCurrentSession().put("AuthorizedUserSKey", "");
//        Serenity.getCurrentSession().put("BeneficiarySKeyValue", "");
//        Serenity.getCurrentSession().put("ReceipentAccountSKey", "");
//        Serenity.getCurrentSession().put("SenderCustomerSKeyValue", "");
//        Serenity.getCurrentSession().put("BeneficiarySKeyValue", "");
//        Serenity.getCurrentSession().put("BranchNKeyValue", "");
//        Serenity.getCurrentSession().put("BranchCode", "");
//        Serenity.getCurrentSession().put("BranchSKeyValue", "");
//        Serenity.getCurrentSession().put("BeneficiaryRemitterSKey", "");
//
        Logger.info("====================== End: " + scenario.getName() + " ================================");
    }
}
