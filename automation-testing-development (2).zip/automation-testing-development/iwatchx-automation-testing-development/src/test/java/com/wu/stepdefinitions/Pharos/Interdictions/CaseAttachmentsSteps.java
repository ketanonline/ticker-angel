package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.CaseAttachmentPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import java.awt.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.hamcrest.MatcherAssert.assertThat;

public class CaseAttachmentsSteps {

    public boolean attachmentOpened=TRUE;
    public String WhoFilterName;
    public int afterClearFilterValue;
    public int afterFilterValue;
    CaseAttachmentPage caseAttachmentPage = new CaseAttachmentPage();


    @When("Analyst clicks on Attachments icon")
    public void analystClicksOnAttachmentsIcon() throws InterruptedException {
        Thread.sleep(2000);
        caseAttachmentPage.clickOnAttachmentButton();
    }

    @Then("Analyst provides Type as {string}, Sub-Type as {string}, Visibility as {string} & Comments as {string}")
    public void analystProvidesTypeSubTypeAndComment(String type, String subType, String visibility, String comments) throws Exception {
        Thread.sleep(2000);
        caseAttachmentPage.selectAttachmentType(type);
        Thread.sleep(2000);
        caseAttachmentPage.selectAttachmentSubType(subType);
        Thread.sleep(2000);
//        caseAttachmentPage.selectVisibility(visibility);
//        Thread.sleep(2000);
        caseAttachmentPage.addComments(comments);
        caseAttachmentPage.getToggle();
        Logger.info("Analyst provided Attachment Type,Subt Type and Visibility");
        Logger.info("Analyst provided a comment for the attachment");
    }

    @Then("Analyst click on browse or Drop files to attach a file")
    public void analystClickOnBrowseFileOption() {
        caseAttachmentPage.clickUploadBrowseLink();
    }

    @Then("Analyst provides file name as {string}")
    public void documentShouldBeAdded(String fileName) throws InterruptedException, AWTException {
        caseAttachmentPage.uploadFile(fileName);
        Logger.info("Analyst successfully uploaded file : "+fileName);
    }

    @Then("Analyst clicks on the Upload button")
    public void userClickOnUploadButton() throws InterruptedException {
        caseAttachmentPage.clickOnUploadAttachmentButton();
        Logger.info("Analyst clicked on upload button and successfully uploaded the required file");
        Thread.sleep(3000);
    }

    @Then("{string} should be added to the top of the list")
    public void fileShouldBeAddedToTopOfTheList(String fileName) throws InterruptedException {
        caseAttachmentPage.verifyUploadedAttachment(fileName);
        Logger.info("Analyst verifies the latest uploaded attachment has been shown realtime in attachment panel");
        Logger.info("Analyst verifies the latest uploaded attachment has been shown at the top in the attachment panel");
    }

    @When("Analyst clicks on attachment link in attachment panel")
    public void whenUserClicksOnAttachmentLink() throws InterruptedException {
        caseAttachmentPage.userClicksOnAttachmentPanel();
    }

    @When("Analyst opens the attachment from profile view icon")
    public void whenUserClicksOnAttachmentLinkFromProfile() throws InterruptedException {
        caseAttachmentPage.userClicksOnAttachmentFromProfile();
    }


    @Then("Analyst opens all the attachments one by one")
    public void analystOpensAllTheAttcahments() throws InterruptedException {
        caseAttachmentPage.userClicksOnAllAttachments();
    }

    @Then("Analyst opens all the attachments one by one from profile")
    public void analystOpensAllTheAttcahmentsFromProfile() throws InterruptedException {
        caseAttachmentPage.userClicksOnAllProfileAttachments();
    }

    @Then("Analyst verifies minimize button of the attachment window")
    public void analystVerifiesMinimizeButtonOfTheAttachment() throws InterruptedException {
        caseAttachmentPage.userClicksOnMinimize();
    }

    @Then("Analyst verifies maximize button of the attachment window")
    public void analystVerifiesMaximizeButtonOfTheAttachment() throws InterruptedException {
        caseAttachmentPage.userClicksOnMaximize();
    }

    @Then("Analyst verifies zoom in button of the attachment")
    public void analystVerifiesZoominButtonOfTheAttachment() throws InterruptedException {
        caseAttachmentPage.userClicksOnZoomInButton();
    }

    @Then("Analyst verifies zoom out button of the attachment")
    public void analystVerifiesZoomoutButtonOfTheAttachment() throws InterruptedException {
        caseAttachmentPage.userClicksOnZoomOutButton();
    }

    @Then("Analyst verifies close button of the attachment")
    public void analystVerifiesCloseButtonOfTheAttachment() throws InterruptedException {
        caseAttachmentPage.userClicksOnCloseButton();
    }

        @Then("Upload button should be enabled")
    public void uploadButtonShouldBeEnabled() throws InterruptedException {
        caseAttachmentPage.verifyUploadBtnEnabled();
    }

    @Then("Attachment panel should be opened")
    public void attachmentPanelShouldBeOpened() throws InterruptedException {
        caseAttachmentPage.verifyAttachmentPanelShouldOpen("Attachments");
        caseAttachmentPage.getAttachmentPanelTitle();
        caseAttachmentPage.getUploadAttachmentPanelCloseButton();
    }

    @Then("Also New Upload form should be displayed")
    public void newUploadFormShouldBeDisplayed() throws InterruptedException {
        caseAttachmentPage.verifyUploadAttachmentPanelShouldOpen();
        Thread.sleep(2000);
        caseAttachmentPage.getNewUploadSectionCollapseArrow().click();
        Thread.sleep(2000);
        caseAttachmentPage.getNewUploadSectionExpandArrow().click();
        Thread.sleep(2000);
    }

    @And("Below values should be displayed in the Type Dropdown")
    public void valuesDisplayedInTheTypeDropdown(DataTable type) {
        List<String> typeValuesList = type.asList(String.class);
        boolean res = caseAttachmentPage.typeDropDownValidation(typeValuesList);
        Assert.assertTrue(res, "TestPassed and Type drop down values are displayed as expected");

    }

    @When("Analyst selects on {string} from type dropdown")
    public void analystSelectsOnFromTypeDropdown(String type) {
        caseAttachmentPage.selectTypeOnNewUplForm(type);
    }

    @And("Verify Attachment count")
    public void verifyAttachmentcount() {
        Logger.info("Attachment count is : "+caseAttachmentPage.getCountAttachment());
    }

    @Then("File should be uploaded successfully")
    public void fileShouldBeUploaded() throws Exception {
        String tstValue = caseAttachmentPage.getToaster().getAttribute("innerHTML");
        System.out.println(tstValue);
        if (tstValue.contains("File successfully uploaded!"))
            Logger.info("File uploaded successful message appeared");
        else
            Logger.info("File uploaded not successful:" + tstValue);
    }

    @When("Attachment should open")
    public void thenAttachmentShouldOpen() throws InterruptedException{
        try{int timer=0;
            //Thread.sleep(2000);
            while(!caseAttachmentPage.closeattachment().isDisplayed()){
                Thread.sleep(2000);
                timer++;
                if(timer>3) {
                    attachmentOpened=FALSE;
                    Logger.info("Attachment didnot open till 27 seconds");

                    break;
                }
            }
            boolean attFlag = caseAttachmentPage.getImage().isDisplayed();
            if(attFlag)
            {
                Logger.info("Attachment is opened");
            }
            else
                Logger.error("Attachment is not opening");
        }catch(Exception e){
            Logger.error("Failed to open the uploaded attachemnt");
        }
    }
    @When("Analyst closes Attachment")
    public void theAttachmentClosed() throws InterruptedException {
        if(attachmentOpened) {
            caseAttachmentPage.closeattachment().click();
            Thread.sleep(2000);
            Logger.info("Anayst closes Attachment");
        }
        else {
            try {
                Robot robot = new Robot();
                robot.keyPress(27);
                Thread.sleep(1000);
                robot.keyRelease(27);
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }

            Thread.sleep(2000);
            Logger.info("Attachment not opened");

        }
    }

    @And("Analyst validates if attachment panel is opened")
    public void analystValidatesAttachmentPanelIsOpned(){
        Assert.assertTrue(caseAttachmentPage.getAttachmentpanel().isDisplayed(),"Attachment panels is not opened");
        Logger.info("Analyst has validated attachment panel");
    }

    @When("Attachment Panel should be closed")
    public void thenAttachmentShouldClosed() throws InterruptedException {
        Thread.sleep(1000);
        caseAttachmentPage.getCloseAttachemetIcon().click();
        Logger.info("Attachment Panel should be closed");
    }

    @Then("Analyst clicks on Expand Icon")
    public void clickExpandIcon() {
        try {
            WebElement expandCollapseIcon = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]/mat-expansion-panel/mat-expansion-panel-header/span[2]"));
            expandCollapseIcon.click();
        } catch (Exception e) {
            Logger.error("Failed to click on Expand Icon");
        }
    }

    @Then("Analyst verifies if the document uploaded comes from Case")
    public void verifyDocumentSource() throws Exception {
        try {
            WebElement docType = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]/mat-expansion-panel/div/div/div/div/div[1]"));
            String docTypeText = docType.getText();

            if (docTypeText.equalsIgnoreCase("Case")) {
                Logger.info("Document uploaded has been verified to come from " + docTypeText);
            } else {
                Logger.error("Document uploaded has come from " + docTypeText + " and not from case");
            }
        } catch (Exception e) {
            Logger.error("Failed to verify source of the case");
        }
    }

    @Then("Analyst verifies the size of the Document and comment {string}")
    public void verifyDocumentSizeAndComment(String comment) throws Exception {
        try {
            WebElement docSize = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]/mat-expansion-panel/div/div/div/div/div[2]"));
            WebElement uploadComment = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]/mat-expansion-panel/div/div/div/div[2]"));

            String sizeOfDocument = docSize.getText();
            String uploadCommentText = uploadComment.getText();

            if (sizeOfDocument != null && uploadCommentText.equalsIgnoreCase(comment)) {
                Logger.info("Size of the document is - " + sizeOfDocument + " comment is verified as - " + uploadCommentText + " given while uploading");
            } else {
                Logger.error("Size of the document is null and comment is not verified as - " + comment + " given while uploading");
            }
        } catch (Exception e) {
            Logger.error("Failed to verify size of the Document and comment");
        }
    }
    @Then("Analyst verifies the uploader name and date")
    public void verifiesUploaderNameandDate() {
        try {
            WebElement name = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]/div[2]/span[1]"));
            WebElement date = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]/div[2]/span[2]"));
            String uploaderName = name.getText();
            String uploadedDate = date.getText();

            if (uploaderName != null && uploadedDate != null) {
                Logger.info("Uploader name is - " + uploaderName + " and date is - " + uploadedDate);
            } else {
                Logger.error("Uploader name or date is not displayed for the uploaded document");
            }
        } catch (Exception e) {
            Logger.error("Failed to verify uploader name and date");
        }
    }

    @Then("Analyst verifies the Typs and Sub-types in the filter")
    public void verifiesTypesSubTypesFilter() throws Exception {
        try {
            WebElement typebtn = BaseTestSetup.webDriver.findElement(By.xpath("(//div[contains(text(),'Type')])[1]"));
            typebtn.click();
            Thread.sleep(2000);

            List<WebElement> typeFilters = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-filter-scroll']//div[@class='mat-list-text']"));
            int typeFilterSize = typeFilters.size();

            if (typeFilterSize == 4) {
                Logger.info("Type Filter has 4 filters");

                for (WebElement e : typeFilters) {
                    Logger.info("Type filter can be used to filter on the basis of - " + e.getText());
                }
            } else {
                Logger.error("Type Filter has some filters missing");
            }

            WebElement subtypebtn = BaseTestSetup.webDriver.findElement(By.xpath("(//div[contains(text(),'Type')])[2]"));
            subtypebtn.click();

            Thread.sleep(2000);
            List<WebElement> subtypeFilters = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-filter-scroll']//div[@class='mat-list-text']"));

            int subtypeFilterSize = subtypeFilters.size();

            if (subtypeFilterSize == 26) {
                Logger.info("Sub-Type Filter has 26 filters");

                for (WebElement e : subtypeFilters) {
                    Logger.info("Sub-Type filter can be used to filter on the basis of - " + e.getText());
                }
            } else {
                Logger.error("Sub- Type Filter has some filters missing");
            }
        } catch (Exception e) {
            Logger.error("Failed to verify Filter Types and Sub-Types");
        }
    }

    @Then("Analyst selects Who filter")
    public void selectsFilter() throws Exception {

        WebElement whobtn = BaseTestSetup.webDriver.findElement(By.xpath("//span[contains(text(),'Who')]"));
        whobtn.click();
        Thread.sleep(2000);

        List<WebElement> whoFilters = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-filter-scroll']//div[@class='mat-list-text']"));
        int whoFilterSize = whoFilters.size();
        if (whoFilterSize > 0) {
            WebElement WhoFilter = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-filter-scroll']//div[@class='mat-list-text'])[1]"));
            WhoFilter.click();
            WhoFilterName = WhoFilter.getText();
            Logger.info("There are search results for the selected WHO filter");
        } else {
            Logger.error("There are no search results for the selected WHO filter");
        }
    }

    @Then("Analyst clicks on Apply button")
    public void clickApplyButton() {
        BaseTestSetup.webDriver.findElement(By.xpath("//span[contains(text(),'Apply')]")).click();
        Logger.info("Apply button clicked successfully");
    }

    @Then("Analyst verifies the filtered result for WHO filter")
    public void verifyFilteredResultforWHO() {
        try {
            List<WebElement> filterResult = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-attachment-view']/div"));
            WebElement clearFilter = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]"));
            int filterResultSize = filterResult.size();
            if (filterResultSize > 1 && clearFilter.getText().equalsIgnoreCase("No matches found..")) {
                Logger.info("No matches were found for the filter");
            } else {
                Logger.info("Matches were found for the filter");

                List<WebElement> afterFilter = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-attachment-view']/div"));
                afterFilterValue = afterFilter.size();
                WebElement expandCollapseIcon = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[2]/mat-expansion-panel/mat-expansion-panel-header/span[2]"));

                expandCollapseIcon.click();
                WebElement name = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-box ng-star-inserted']/div[2]/span[1]"));
                String uploaderName = name.getText();

                if (uploaderName.contains(WhoFilterName)) {
                    Logger.info("Analyst has successfully verified the filtered result on the basis of 'WHO' - " + WhoFilterName);
                } else {
                    Logger.error("Analyst has verified and the filtered result is not - " + WhoFilterName);
                }
            }
        } catch (Exception e) {
            Logger.error("Failed to verify filtered result for WHO filter");
        }
    }
    @Then("Analyst clicks the Clear Filter link and filters should be removed")
    public void verifiesClearFilterFunctionality() throws Exception {
        try {
            Thread.sleep(10000);
            BaseTestSetup.webDriver.findElement(By.xpath("//div[contains(text(),'Clear Filter')]")).click();
            Thread.sleep(3000);
            List<WebElement> afterClearFilter = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-attachment-view']/div"));
            afterClearFilterValue = afterClearFilter.size();

            if (afterClearFilterValue > afterFilterValue) {
                Logger.info("On clicking Clear filter , Filters have been removed");
            } else {
                Logger.error("On clicking Clear filter , Filters have not been removed");
            }
        } catch (Exception e) {
            Logger.error("Failed to clear the filter");
        }
    }

    @Then("Analyst selects filter {string} as {string}")
    public void selectFilter(String mainFilter, String subFilter) throws Exception {
        try {
            WebElement mFilter = BaseTestSetup.webDriver.findElement(By.xpath("(//div[contains(text(),'" + mainFilter + "')])[1]//preceding-sibling::div/mat-icon"));
            mFilter.click();
            Thread.sleep(2000);

            WebElement search = BaseTestSetup.webDriver.findElement(By.xpath("//input[@data-placeholder='Search']"));
            search.click();
            search.sendKeys(subFilter);

            Thread.sleep(2000);
//            WebElement sFilter = BaseTestSetup.webDriver.findElement(By.xpath("//span[contains(text(),'Third Party At Send')]"));
            //span[contains(text(),'Third Party At Send')]
            WebElement sFilter = BaseTestSetup.webDriver.findElement(By.xpath("//span[contains(text(),'" + subFilter + "')]"));
            sFilter.click();
//            Actions actions = new Actions(BaseTestSetup.webDriver);
//            actions.moveToElement(sFilter).click();
            search.clear();
            Thread.sleep(2000);
            BaseTestSetup.webDriver.findElement(By.tagName("html")).click();
            Logger.info("Analyst selects Main filter as - " + mainFilter + " and Sub filter as - " + subFilter);
        } catch (Exception e) {
            Logger.error("Failed to select filter- " + mainFilter + " as :" + subFilter);
        }
    }

    @Then("Analyst verifies the filtered result")
    public void verifyFilteredResult() throws Exception {
        try {
            List<WebElement> filterResult = BaseTestSetup.webDriver.findElements(By.xpath("//div[@class='wu-attachment-view']/div"));
            WebElement clearFilter = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[1]"));
            int filterResultSize = filterResult.size();
            if (filterResultSize > 1 && clearFilter.getText().equalsIgnoreCase("No matches found..")) {
                Logger.info("No matches were found for the filter");
            } else {
                Logger.info("Matches were found for the filter and User was successfully able to filter");

            }
            Thread.sleep(3000);
            WebElement expandCollapseIcon = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[2]/mat-expansion-panel/mat-expansion-panel-header/span[2]"));

            expandCollapseIcon.click();
            WebElement filteredValue1 = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-attachment-box ng-star-inserted']//mat-panel-title//span[1])[1]"));
            String filteredMainFilterValue = filteredValue1.getText();

            WebElement filteredValue2 = BaseTestSetup.webDriver.findElement(By.xpath("(//div[@class='wu-attachment-box ng-star-inserted']//mat-panel-title//span[2])[1]"));
            String filteredSubFilterValue = filteredValue2.getText();

            Logger.info("Filtered value is correctly displayed - Main Filter as -" + filteredMainFilterValue + " and Sub-filter as - " + filteredSubFilterValue);
        } catch (Exception e) {
            Logger.error("Failed to verify Filtered result");
        }
    }

    @Then("Analyst selects Date filter")
    public void selectsDateFilter() throws Exception {

        WebElement whobtn = BaseTestSetup.webDriver.findElement(By.xpath("//span[contains(text(),'Date')]"));
        whobtn.click();
        Thread.sleep(2000);
        Logger.info("Date filter has been selected");

    }

    @Then("Analyst verifies the Date filtered result")
    public void verifyDateFilterResults(){

        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
        Date date = new Date();
        String date1= dateFormat.format(date);
        Logger.info("Current date is -" +date1);
        String [] currDate = date1.split("/");

        WebElement expandCollapseIcon = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-view']/div[2]/mat-expansion-panel/mat-expansion-panel-header/span[2]"));
        expandCollapseIcon.click();

        String filteredDate = BaseTestSetup.webDriver.findElement(By.xpath("//div[@class='wu-attachment-box ng-star-inserted']/div[2]/span[2]")).getText();
        String [] dateSplit = filteredDate.split(" ");

        if(currDate[1].equalsIgnoreCase(dateSplit[1])){
            Logger.info("Date filter has been applied successfully");
        }else{
            Logger.error("Date filter has not been applied");
        }
    }
    @And("Below values should be displayed in the SubType Dropdown")
    public void valuesDisplayedInTheSubTypeDropdown(DataTable subType) {
        List<String> subTypeValuesList = subType.asList(String.class);
        boolean res = caseAttachmentPage.subTypeDropDownValidation(subTypeValuesList);
        Assert.assertTrue(res, "TestPassed and Type drop down values are displayed as expected");

    }

    @And("Below values should be displayed in the Visibility Dropdown")
    public void valuesDisplayedInTheVisibilityDropdown(DataTable visibility) {
        List<String> visibilityValuesList = visibility.asList(String.class);
        boolean res = caseAttachmentPage.visibilityDropDownValidation(visibilityValuesList);
        Assert.assertTrue(res, "TestPassed and Type drop down values are displayed as expected");

    }

    @Then("Analyst should get an error messsage {string}")
    public void errorMessage(String errorMsg) throws Exception {
        // String tstValue = caseAttachmentPage.getToaster().getAttribute("innerHTML");
        Thread.sleep(1000);
        String tstValue = BaseTestSetup.webDriver.findElement(By.xpath("//simple-snack-bar/span[contains(text(),'" + errorMsg + "')]")).getText();
        System.out.println(tstValue);
        assertThat("Error message - " + errorMsg + "has been displayed", tstValue.contains(errorMsg));
        Logger.info("Error message has been displayed -" + tstValue);
        Thread.sleep(10000);
    }

    @And("Analyst clicks on profile view icon")
    public void profileViewIcon() throws Exception {
        caseAttachmentPage.getProfileViewIcon();
        Logger.info("Profile View Icon should be clicked");
    }

    @Then("Analyst verifies if Profile Attachment is {string}")
    public void analystVerifyProfileAttachmentIsPresentOrNot(String presentNotPresent) {
        caseAttachmentPage.analystVerifyProfileAttachmentIsPresentOrNot(presentNotPresent);
    }

    @Then("Analyst validates {string} message in Attachment screen")
    public void analystValidatesErrorMessageInAttachmentScreen(String msg){
        caseAttachmentPage.verifyErrorMessage(msg);
    }

    @Then("Analyst should be able to see {string} toaster message")
    public void analystShouldBeAbleToSeeErrorToaster(String msgtoaster){
        caseAttachmentPage.verifyErrorToasterMessage(msgtoaster);
    }
}
