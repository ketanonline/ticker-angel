package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.PartyActivityInformationPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PartyActivityInformationSteps {

    PartyActivityInformationPage partyActivityInformationPage = new PartyActivityInformationPage();

    @When("Verify ID Country in party activity Info")
    public void userClicksOnCOIcon() {
        String idCountry = partyActivityInformationPage.getIDCountry();
        Logger.info("ID Country verified and data retreived as : " + idCountry);
    }

    @Then("Verify Zip code for reiciever side transaction in party activity Info")
    public void verifyZipReciever() {
        partyActivityInformationPage.clickMore();
        String zip = partyActivityInformationPage.getZipCodeText();
        Logger.info("Zip code verified and data retreived as : " + zip);
    }

    @Then("Verify Email address in party activity Info")
    public void customerPanelShouldBeOpened() {
        String email = partyActivityInformationPage.getEmail();
        Logger.info("Email address verified and data retreived as : " + email);
    }

    @Then("Verify Address line in party activity Info")
    public void verifyAddressLine() {
        String line = partyActivityInformationPage.getAddressLine();
        Logger.info("Address Line verified and data retreived as : " + line);
    }

    @Then("Verify account number sender side")
    public void verifyAccount() throws InterruptedException {
        String an=partyActivityInformationPage.getAccountNumberSender().getText();
        Logger.info("Account number verified and data retreived as : "+an);
    }

    @Then("Verify postal code for sender side transaction in party activity Info")
    public void verifyPostalcodeSenderSide() throws InterruptedException {
        partyActivityInformationPage.clickMore();
        String zip=partyActivityInformationPage.getZipcodetext();
        Logger.info("Postal code verified and data retreived as : "+zip);
    }
}
