package com.wu.stepdefinitions.Pharos.Sanctions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.pages.Pharos.Interdictions.DashboardPage;
import com.wu.stepdefinitions.Pharos.Interdictions.APICommonSteps;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import net.serenitybdd.core.Serenity;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import java.awt.*;


import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;


public class DashboardSteps {

    DashboardPage dashboardPage = new DashboardPage();


    @And("Analyst verifies the Readiness Check on Dashboard page")
    public void analystVerifiesReadinessCheck() {
        WebElement status = BaseTestSetup.webDriver.findElement(By.xpath("//td[contains(text(),'Readiness Check')]"));
        if (status.getText().equalsIgnoreCase("Readiness Check")) {
            Logger.info("Analyst verified the status of the case as Readiness Check for Pre tier cases on Dashboard page");
        } else {
            Logger.error("Analyst failed to verify status as - Readiness check for Pre-tier cases");
        }
    }

//    @Then("Analyst verifies if Work button is {string}")
//     public void analystVerifyWorkbuttonPresentOrNot(String presentNotPresent){
//    WebElement workBtn = BaseTestSetup.webDriver.findElement(By.xpath("//mat-icon[contains(text(),'work_outline')]"));
//    //Boolean workBtnIsPresent = workBtn.isDisplayed();
//        System.out.println("*****" +presentNotPresent);
//        if(presentNotPresent.equalsIgnoreCase("present")){
//            System.out.println("Entered present block");
//            if(workBtn.isDisplayed()){
//            Logger.info("Work button is present for Pre-tier cases");
//        } else{
//        Logger.error("Work button is not present for Pre-tier cases");
//    }
//        }else{
//            System.out.println("Entered not present block");
//            System.out.println(workBtn.isDisplayed());
//            if(workBtn.isDisplayed()){
//                Logger.error("Work button is present for Pre-tier cases");
//            } else{
//                Logger.info("Work button is not present for Pre-tier cases");
//            }
//        }
//    }

}
