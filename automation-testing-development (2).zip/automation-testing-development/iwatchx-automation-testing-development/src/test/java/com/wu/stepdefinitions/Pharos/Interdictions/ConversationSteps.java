package com.wu.stepdefinitions.Pharos.Interdictions;

import com.wu.api.util.common.CommonFunctions;
import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import com.wu.base.selenium.BrowserElementLocator;
import com.wu.pages.Pharos.Interdictions.ConversationPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.TimeZone;

import static org.hamcrest.MatcherAssert.assertThat;

public class ConversationSteps {

    public static String convData;
    public static String convTime;
    public static String convDate;
    public String partyIDVal;
    public static String mtcnVal;
    public Instant instant;
    ConversationPage conversationPage = new ConversationPage();
    private BrowserElementLocator browserElementLocator;



    @When("Analyst sees the conversation box in the investigation screen")
    public void analystSeesConversationBox() {
        conversationPage.verifyConversationFooter();
        Logger.info("Analyst sees Conversation Footer");
    }

    @And("Analyst enters {string} text in conversation panel")
    public void analystEntersTheTextInConversationBox(String inputText) {
        conversationPage.enterTextInConversationBox(inputText);
        Logger.info("Analyst enters text in Conversation Footer");
    }

    @And("Analyst closes the Conversation Panel")
    public void analystClosesConversationPanel(){
        conversationPage.closeConversationPanel();
        Logger.info(" Analyst closes the Conversation Panel");
    }

    @And("Clicks on arrow mark image to submit")
    public void analystClickOnArrowButtonToSubmit() {
        instant = Instant.now();

        SimpleDateFormat etDf = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mma 'ET'");
        TimeZone etTimeZone = TimeZone.getTimeZone("America/New_York");
        etDf.setTimeZone( etTimeZone );
        Date currentDate = new Date();
        convTime=etDf.format(currentDate.getTime());
        String[] arrTime=convTime.split(" ");
        convTime=arrTime[2];
        String convDate1=arrTime[0];
        convDate=convDate1;

        conversationPage.clickOnArrowMarkButton();
        Logger.info("Analyst clicks send button");
        Logger.info("Analyst clicks send button");
    }

    @And("Analyst should be able to see {string} message should appear on the screen")
    public void analystShouldBeAbleToSeeConfirmationMessageOnScreen(String msg)  {
        conversationPage.verifyConfirmationMsg();
    }

    @When("Analysts clicks on View All link")
    public void analystClickOnViewAllLink() throws InterruptedException {
        Thread.sleep(5000);
        conversationPage.clickOnViewAllLink();
        Logger.info("Analyst clicks View All link");
    }

    @Then("Conversation Panel should be opened")
    public void thenConversationPanelShouldOpen() throws InterruptedException {
        Thread.sleep(3000);
        conversationPage.verifyConversationPanelShouldOpen();
        Logger.info("Conversation Panel is opened");
    }

    @Then("{string} should be displayed on Conversation Panel")
    public void thenCommentShouldBeDisplayedInConversationPanel(String comment) throws InterruptedException {
        Thread.sleep(3000);
        String actualComment = conversationPage.getConversationComment();
        System.out.println(actualComment);
        Assert.assertEquals(actualComment,comment,"Entered message is not displayed in Conversation Panel");
        Logger.info("Entered message appearred in Conversation Panel: "+ comment);
    }

    @And("Analyst enters 300 chars text in conversation panel")
    public void analystEntersTheTextWith300CharInConversationBox() {
        convData= CommonFunctions.randomString(300);
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters 300 chars text in Conversation Footer");
    }

    @Then("300 chars text should be displayed on Conversation Panel")
    public void thenCommentShouldBeDisplayedInConversationPanelWith300Chars() {
        String actualComment = conversationPage.getConversationComment();
        Assert.assertEquals(actualComment,convData,"Entered message is not displayed in Conversation Panel");
        Logger.info("Entered message appearred in Conversation Panel: "+ convData);
    }

    @And("Analyst Clicks on Privacy level dropdown and selects {string}")
    public void analystSelectsPrivacyLevel(String level) {
        conversationPage.clickOnPrivacyLevel(level);
        Logger.info("Analyst selects privacy level '"+level+"'");
    }

    @When("Auto suggest popup menu for MTCN and PartyId should be displayed")
    public void analystSeesPopupMenu() {
        conversationPage.verifyPopupMenu();
    }

    @When("DBResult = execute conversation query with caseid {string}")
    public void executeDBQuery(String caseId) throws Exception {
        if (caseId.contains("$")) {
            String value = caseId.substring(caseId.indexOf("$") + 1);
            String valueToBeReplace = "'" + Serenity.getCurrentSession().get(value).toString() + "'";
            caseId = caseId.replace("$" + value, valueToBeReplace);
        }

        String query="select * from Conversations where docType='conversation' and caseId='"+caseId+"' and text='";
        query=query+convData+"'";
        System.out.println(query);
        APICommonSteps apiCommonSteps = new APICommonSteps();
        apiCommonSteps.whenUserExecutesDatabaseQuery(query);
    }

    @When("User verifies {string} with {string}")
    public void validateDBResponse(String cbQueryResult, String fieldName) throws IOException{
        String ExpData=convData;
        APICommonSteps apiCommonSteps = new APICommonSteps();
//        apiCommonSteps.whenUserVerfiesCouchbaseDataWithExpResult(cbQueryResult,fieldName,ExpData);
    }

    @And("Analyst wait for case to open")
    public void analystsWaitForCaseToOpen() throws InterruptedException{
        Logger.info("Analyst wait for case to open");
        Thread.sleep(5000);
    }

    @When("DBResult = execute conversation query with caseid {string} and timestamp")
    public void executeDBQueryConv(String caseId) throws Exception {
        String query="select * from Conversations where docType='conversation' and caseId='"+caseId+"' and createdTimestamp like'";
        String currUTCTime= instant.toString();
        int index = currUTCTime.lastIndexOf(":");
        String finString = currUTCTime.substring(0, index);
        query=query+finString+"%'";
        System.out.println(query);
        APICommonSteps apiCommonSteps = new APICommonSteps();
        apiCommonSteps.whenUserExecutesDatabaseQuery(query);
    }

    @When("Analyst verifies {string} with {string} as {string}")
    public void validateDBResponsePrivacyLevel(String cbQueryResult, String fieldName,String ExpData) throws InterruptedException,IOException{
        Logger.info("User verifies DB Response with " + cbQueryResult + " as per " + ExpData );
        if (cbQueryResult.contains("$")) {
            cbQueryResult = cbQueryResult.substring(cbQueryResult.indexOf("$") + 1);
        }
        Object val1 = ExpData;
        Object val2 = CommonFunctions.getValueFromJSON(fieldName, cbQueryResult);
        System.out.println(val1);
        System.out.println(val2);
        assertThat("DB response validation :", val1.equals(val2.toString()));
    }

    @Then("Not Hashtagged {string} should be displayed on Conversation Panel")
    public void thenCommentShouldBeDisplayedInConversationPanelWithoutHashTagging(String comment) throws InterruptedException{
        Thread.sleep(5000);
        String actualComment = conversationPage.getHashTaggedConversationComment();
        System.out.println(actualComment);
        if(actualComment.contains("<strong><font color=\"#2196f3\">#"+comment+"</font></strong>"))
        {
            Logger.info("Entered value is hashtagged in Conversation Panel");
        }
        else
            Logger.info("Entered value is not hashtagged in Conversation Panel");  //pass stmt
    }

    @When("Analyst gathers PartyID and MTCN")
    public void analystSavesPartyIDAndMTCN() {
        partyIDVal=conversationPage.getPartyIDValue();
        mtcnVal=conversationPage.getMTCNValue();
        System.out.println(partyIDVal);
        System.out.println(mtcnVal);
        Logger.info("Analyst gathers PartyID and MTCN");
    }

    @And("Analyst enters partyID and MTCN in conversation panel")
    public void analystEntersPartyIdAndMTCNInConversationBox() throws InterruptedException{
        convData= "#"+partyIDVal+" #"+mtcnVal+" ";
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters partyID and MTCN in conversation panel");
    }

    @Then("Hashtagged ConversationText should be displayed on Conversation Panel")
    public void thenHashTaggedCommentShouldBeDisplayedInConversationPanel() throws InterruptedException{
        Thread.sleep(5000);
        String actualComment = conversationPage.getHashTaggedConversationComment();
        System.out.println(actualComment);
        if(actualComment.contains("<strong><font color=\"#2196f3\">#"+partyIDVal+"</font></strong>"))
        {
            Logger.info("Entered PartyID is hashtagged in Conversation Panel");
        }
        else
            Logger.info("Entered PartyID is not hashtagged in Conversation Panel");
        if(actualComment.contains("<strong><font color=\"#2196f3\">#"+mtcnVal+"</font></strong>"))
        {
            Logger.info("Entered MTCN is hashtagged in Conversation Panel");
        }
        else
            Logger.info("Entered MTCN is not hashtagged in Conversation Panel");
    }

    @And("Analyst enters {string} and {string} in conversation panel")
    public void analystEntersHashtagAndMsgInConversationBox(String hashEle,String msg) throws InterruptedException{
        convData="";
        if(hashEle.contains("MTCN"))
        {
            convData+="#"+mtcnVal+" ";
        }
        if(hashEle.contains("partyID"))
        {
            convData+="#"+partyIDVal+" ";
        }
        convData+=msg;
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters "+hashEle+" and "+msg+" in conversation panel");
    }

    @When("Analyst clicks on the filter icon")
    public void analystClickOnFilterIcon() {
        conversationPage.clickOnFilter();
        Logger.info("Analyst clicks on Filter icon");
    }

    @When("Select the MTCN in MTCN filter")
    public void analystSelectMTCNFilter() {
        conversationPage.clickOnMTCNFilter();
        Logger.info("Analyst clicks on MTCN Filter");
    }

    @When("Click on Apply")
    public void analystClicksApplyButton() {
        conversationPage.clickOnApplyButton();
        Logger.info("Analyst clicks on Apply Button");
    }

    @Then("Entered ConversationText should be displayed on Conversation Panel")
    public void thenEnteredCommentShouldBeDisplayedInConversationPanel() throws InterruptedException{
        String actualComment = conversationPage.getConversationComment();
        System.out.println(actualComment);
        Assert.assertEquals(actualComment,convData,"Entered message is not displayed in Conversation Panel");
        Logger.info("Entered message appearred in Conversation Panel: "+ convData);
    }

    @When("Select the Subject ID in Subject filter")
    public void analystSelectSenderSubjectFilter() {
        conversationPage.clickOnSubjectFilter();
        Logger.info("Analyst clicks on Subject Filter");
    }

    @When("Unselect the Case ID in Case filter")
    public void analystUnSelectCaseIdFilter() {
        conversationPage.clickOnCaseIdFilter();
        Logger.info("Analyst clicks on CaseId Filter");
    }

    @Then("Analyst verifies MTCN in conversation footer is 16 digits")
    public void analystVerifiesMTCN_ConvFooter()throws Exception {
        if( mtcnVal.length()==16)
            Logger.info("MTCN displayed in conversation footer is 16 digits : "+mtcnVal);
        else
            Logger.error("MTCN displayed in conversation footer is not 16 digits:"+mtcnVal);
    }

    @Then("Analyst verifies MTCN in conversation panel is 16 digits")
    public void analystVerifiesMTCN_ConvPanel()throws Exception {
        String actMTCN = conversationPage.getMTCN_ConversationPanel().getText().trim();
        if( actMTCN.length()==16)
            Logger.info("MTCN displayed in conversation panel is 16 digits : "+actMTCN);
        else
            Logger.error("MTCN displayed in conversation panel is not 16 digits:"+actMTCN);
    }

    @Then("{string} message is displayed")
    public void thenCommentShouldNotBeDisplayedInConversationPanel(String comment) throws InterruptedException{
        Thread.sleep(5000);
        String actualComment = conversationPage.getComment();
        System.out.println(actualComment);
        Assert.assertEquals(actualComment,comment,"No information available message is not displayed");
        Logger.info("No information available message is displayed");
    }

    @And("Analyst enters 1002 chars text in conversation panel")
    public void analystEntersTheTextWith302CharInConversationBox() throws InterruptedException{
        convData= CommonFunctions.randomString(1002);
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters 302 chars text in Conversation Footer");
        String appData=conversationPage.getTextInConversationBox();
        convData=convData.substring(0,1000);
        System.out.println("Expected : "+convData);
        System.out.println("Actual : "+appData);
        assertThat("Entered Conversation Text is validated", convData.equals(appData));
        Logger.info("Application accepted only 300 chars text in Conversation Footer");
    }

    @When("Click on Cancel")
    public void analystClicksCancelButton() {
        conversationPage.clickOnCancelButton();
        Logger.info("Analyst clicks on Cancel Button");
    }

    @When("Analyst clicks on Clear Filter")
    public void analystClicksClearFilter() {
        conversationPage.clickOnClearFilter();
        Logger.info("Analyst clicks on Clear Filter");
    }

    @And("Analyst enters multiple hashtag elements in conversation panel")
    public void analystEntersHashTagElesInConversationBox() throws InterruptedException{
        convData= "#"+partyIDVal+" #"+mtcnVal+" #"+partyIDVal+" ";
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters multiple hashtag elements in conversation panel");
    }

    @Then("Analyst verifies {string} caseId is displayed on Conversation Panel")
    public void analystVerifiesCaseId_ConvPanel(String caseId)throws Exception {
        String actCaseId = conversationPage.getSubject_ConversationPanel().getText().trim();
        if( caseId.trim().equals(actCaseId))
            Logger.info("Analyst verifies caseId is displayed on  Conversation Panel : "+actCaseId);
        else
            Logger.error("Analyst verifies and confirms that caseId is not displayed on Conversation Panel:"+actCaseId);
    }

    @Then("Analyst verifies full subjectId is displayed on SubjectID Conversation Panel")
    public void analystVerifiesSubject_ConvPanel()throws Exception {
        String actSubject = conversationPage.getSubject_ConversationPanel().getText().trim();

        if( partyIDVal.trim().equals(actSubject))
            Logger.info("Analyst verifies full subjectId is displayed on SubjectID Conversation Panel : "+actSubject);
        else
            Logger.error("Analyst verifies full subjectId is not displayed on SubjectID Conversation Panel:"+actSubject);
    }
    @When("User should be able to see subjectID with label as PartyId")
    public void analystValidatesPartyIDLabel() {
        String partyIDLabel=conversationPage.getPartyIDLabel();
        if( partyIDLabel.trim().equals("Party ID"))
            Logger.info("User should be able to see subjectID with label as PartyId : "+partyIDLabel);
        else
            Logger.error("User should not be able to see subjectID with label as PartyId:"+partyIDLabel);

    }

    @When("Entered Conversation should have Analyst Name on Conversation Panel")
    public void retrieveAnalystName() {
        String analystName= conversationPage.getAnalystName();
        Logger.info("Retrieve analyst name from the iWatchX application : "+analystName);
        String actualName = conversationPage.getConversationAnalystName();
        Assert.assertEquals(actualName,analystName,"Entered message should have analyst Name displayed in Conversation Panel");
        Logger.info("Entered message should have analyst Name displayed in Conversation Panel: "+ actualName);
    }

    @When("Entered Conversation should have Date and Time on Conversation Panel")
    public void retrieveDateAndTime() throws java.text.ParseException {

        Date date1=new SimpleDateFormat("MM/dd/yyyy").parse(convDate);
        String strDateFormat = "MMM d yyyy";
        SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat);
        System.out.println(convDate);
        System.out.println(objSDF.format(date1));

        String expDateAndTime = objSDF.format(date1)+", " +convTime;
        String actualDateAndTime = conversationPage.getConversationDateAndTime();

        expDateAndTime=expDateAndTime.replaceAll(" ","");
        actualDateAndTime=actualDateAndTime.replaceAll(" ","");

        Assert.assertEquals(actualDateAndTime,expDateAndTime,"Entered message should have Date and Time displayed in Conversation Panel");
        Logger.info("Entered message should have Date and Time displayed in Conversation Panel: "+ actualDateAndTime);
    }

    @And("Analyst enters 20 chars text in conversation panel")
    public void analystEntersTheTextWith20CharInConversationBox() throws InterruptedException{
        convData= CommonFunctions.randomString(15);
        convData=convData+" @$4!";
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters 20 chars text in Conversation Footer");
    }

    @And("Character counter should be updated with {string} value")
    public void analystValidatesCharacterCounter(String num) {
        conversationPage.verifyCharacterCounter(num);
    }

    @And("Analyst enters {string} and random text in conversation panel")
    public void analystEntersHashtagAndMsgRandomTextInConversationBox(String hashEle) throws InterruptedException{
        convData="";
        if(hashEle.contains("MTCN"))
        {
            convData+="#"+mtcnVal+" ";
        }
        if(hashEle.contains("partyID"))
        {
            convData+="#"+partyIDVal+" ";
        }
        convData+=CommonFunctions.randomString(51);
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters \""+convData+ "\" in conversation panel");
    }



    @And("Analyst enters {string} text with multiple lines in conversation panel")
    public void analystEntersHashtagAndMultipleLinesRandomTextInConversationBox(String hashEle) throws InterruptedException{
        convData="";
        if(hashEle.contains("MTCN"))
        {
            convData+="#"+mtcnVal+" ";
        }
        if(hashEle.contains("partyID"))
        {
            convData+="#"+partyIDVal+" ";
        }
        convData+=CommonFunctions.randomString(5);
        convData+="\nText\n" +
                "In\n" +
                "4 lines1";
        conversationPage.enterTextInConversationBox(convData);
        Logger.info("Analyst enters \""+convData+ "\" in conversation panel");
    }
    @When("Analyst Clicks to scrollup to filtericon")
    public void analystClickToAcessScrollUpToScrollUp() throws InterruptedException {
        Thread.sleep(2000);
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
//        js.executeScript("window.scrollBy(0,1000)","");
        WebElement submit=webDriver.findElement(By.xpath("//mat-expansion-panel[1]/mat-expansion-panel-header[1]/span[1]/mat-panel-title[1]"));
        je.executeScript("arguments[0].scrollIntoView(true);",submit);
        Logger.info("Analyst Clicks to scrollup to filtericon");
    }
    @Then("Entered ConversationText {string} should be displayed on Conversation Panel")
    public void thenEnteredCommentShouldBeDisplayedInConversationPanel(String msg) throws InterruptedException{
        Thread.sleep(2000);
        String actualComment = conversationPage.getConversationComment();

        System.out.println(msg);
        System.out.println(actualComment);
        //Assert.assertEquals(msg,actualComment,"Entered message is not displayed in Conversation Panel");
        if(actualComment.contains(msg)) {
            Logger.info("Entered message appearred in Conversation Panel: " +msg);
        }else{
            Logger.error("Expected message is not displayed");
        }
    }
    @When("Analyst Clicks to scrollup to WULogo")
    public void analystClicksOnScrollupWulogo() throws InterruptedException {
        Thread.sleep(2000);
        WebDriver webDriver = BaseTestSetup.webDriver;
        webDriver.manage().window().maximize();
        JavascriptExecutor je = (JavascriptExecutor) webDriver;
//        js.executeScript("window.scrollBy(0,1000)","");
        WebElement submit=webDriver.findElement(By.xpath("//mat-card-title[contains(text(),'Ready For Work')]"));
        je.executeScript("arguments[0].scrollIntoView(true);",submit);
        Logger.info("Analyst Clicks to scrollup to WULOGO");
    }

    @And("Analyst wait for case to open in investigation screen")
    public void analystsWaitForCaseToOpeninvestigationscreen(String tstValue) throws InterruptedException{
        if (tstValue.contains("case")) {
            tstValue = getToaster().getAttribute("innerHTML");
            System.out.println(tstValue);
            Logger.info("No more case available");
        }
        else
        {
            Logger.info("Analyst wait for case to open in investigation screen");
            Thread.sleep(3000);
        }
    }
    public WebElement getToaster() {
        return browserElementLocator.findElementByXpath("//*[@id='cdk-describedby-message-container']");
    }

    @When("Analyst Captures URL of case opened")
    public void AnalystCaptureURLOfCaseOpened() {
        WebDriver webDriver = BaseTestSetup.webDriver;
        String URL = webDriver.getCurrentUrl();
        if (URL.contains("intr")) {
            Logger.info("Analyst Captures URL of case opened intr");

        } else {
            Logger.info("Analyst Captures URL of case opened sanc");

        }
    }
    @And("Analyst verifies full subjectId is displayed on Party activity Card")
    public void analystVerifiesFullSubjectIdIsDisplayed() throws InterruptedException{
        conversationPage.VerifySubjectId();
    }
}
