package com.wu.stepdefinitions.Pharos.Sanctions;

import com.wu.base.BaseTestSetup;
import com.wu.base.logger.Logger;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SANCWorkFlowSteps {


    @Then("Verify the particular role from OKTA")
    public void verifyUserRole() {
        WebDriver webDriver = BaseTestSetup.webDriver;
        JavascriptExecutor js = (JavascriptExecutor) webDriver;
        String localStorage = (String) js.executeScript(String.format("return window.localStorage.getItem('%s');", "okta-token-storage"));
        String[] VAR2 = localStorage.split("\\},");
        String Role = VAR2[2];
        String[] role = Role.split("\\],");
        Logger.info("role value:" + role[1]);
    }

    @Then("Analyst verifies the Workflow header as Readiness Check")
    public void analystVerifiesWorkflowHeader() throws  Exception{
        Thread.sleep(3000);
        WebElement arrow = BaseTestSetup.webDriver.findElement(By.xpath("//mat-expansion-panel-header[@role='button']/span[2]"));
        arrow.click();
        Thread.sleep(3000);
        WebElement workflowHeader = BaseTestSetup.webDriver.findElement(By.xpath("//p[contains(text(),' Readiness Check ')]"));

        if(workflowHeader.getText().equalsIgnoreCase("Readiness Check")){
        Logger.info("Anlayst verified the Workflow Header as - Readiness Check for Pre-tier case");
        }else{
            Logger.error("Failed to verify Workflow header as : Readiness check for Pre-tier case");
        }
    }
}
