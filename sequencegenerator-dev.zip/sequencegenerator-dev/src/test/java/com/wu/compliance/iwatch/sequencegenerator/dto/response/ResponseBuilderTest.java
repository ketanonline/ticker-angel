package com.wu.compliance.iwatch.sequencegenerator.dto.response;

import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ResponseBuilderTest {

    @InjectMocks
    ResponseBuilder responseBuilder;


    @Test
    @DisplayName("Should return bad request")
    void testResponseBuilder_shouldReturnBadRequest() {
        List<ErrorDetail> errorDetails = new ArrayList<>();
        errorDetails.add(new ErrorDetail("pId", "pId missing"));
        String uuid = UUID.randomUUID().toString();
        DefaultResponse result = responseBuilder.buildBadRequestResponse(uuid, errorDetails);
        assertEquals("WUIWXSG4000", result.getCode());
        assertEquals(uuid, result.getTraceId());
        assertEquals("Bad request", result.getMessage().getText());
    }


    @Test
    @DisplayName("Should return Internal Server Error")
    void testResponseBuilder_shouldReturnInternalServerError() {
        List<ErrorDetail> errorDetails = new ArrayList<>();
        errorDetails.add(new ErrorDetail("pId", "pId missing"));
        String uuid = UUID.randomUUID().toString();
        DefaultResponse result = responseBuilder.buildUnknownErrorResponse(uuid, "Error");
        assertEquals("WUIWXSG5000", result.getCode());
        assertEquals(uuid, result.getTraceId());
        assertEquals("Internal Server Error", result.getMessage().getText());
        assertEquals("Error", result.getDescription());
    }
}