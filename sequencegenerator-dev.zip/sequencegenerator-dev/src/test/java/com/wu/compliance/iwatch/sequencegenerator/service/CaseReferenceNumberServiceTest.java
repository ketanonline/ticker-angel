package com.wu.compliance.iwatch.sequencegenerator.service;

import com.wu.compliance.iwatch.sequencegenerator.TestUtil;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.BDDMockito.given;


@ExtendWith({MockitoExtension.class})
class CaseReferenceNumberServiceTest {

    @Mock
    SequenceCacheService sequenceCacheService;

    @Mock
    DateGeneratorService dateGeneratorService;

    CaseReferenceNumberService caseReferenceNumberService;

    @BeforeEach
    public void eachTestSetup() {
        caseReferenceNumberService = new CaseReferenceNumberService(sequenceCacheService, dateGeneratorService, "N");
        org.springframework.test.util
                .ReflectionTestUtils.setField(
                        caseReferenceNumberService,
                        "sequencePrefix",
                        "CC");
    }

    @Test
    @DisplayName("case reference number should be null if cache returns null response.")
    void testCaseReferenceNumberService_ifCacheReturnsNull() {
        Tenant pt = TestUtil.getPrimaryTenant();
        given(sequenceCacheService.next(pt)).willReturn(null);
        assertNull(caseReferenceNumberService.next(pt).getCaseRefNum());
    }

    @Test
    @DisplayName("case reference number should be null if cache returns null response.")
    void testCaseReferenceNumberService_ifCacheReturnsNonNuLL() {
        Tenant pt = TestUtil.getPrimaryTenant();
        given(sequenceCacheService.next(pt)).willReturn("ABCD");
        given(dateGeneratorService.generatePrefix()).willReturn("201021");
        assertEquals("CCN20AB1021CD", caseReferenceNumberService.next(pt).getCaseRefNum());
    }

    @Test
    @DisplayName("case reference number should be built")
    void testCaseReferenceNumberService_shouldAddSubstring() {
        String result = caseReferenceNumberService.buildSequence("210129", "ABCD");
        assertEquals("CCN21AB0129CD", result);
    }
}