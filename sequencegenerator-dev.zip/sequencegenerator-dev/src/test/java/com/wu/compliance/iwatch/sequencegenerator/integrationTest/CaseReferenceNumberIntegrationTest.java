package com.wu.compliance.iwatch.sequencegenerator.integrationTest;

import com.wu.compliance.iwatch.microtestapi.couchbase.CouchbaseIntegrationTest;
import com.wu.compliance.iwatch.microtestapi.label.SlowTest;
import com.wu.compliance.iwatch.sequencegenerator.controller.CaseReferenceNumberController;
import com.wu.compliance.iwatch.sequencegenerator.dto.CaseReferenceNumberDto;
import com.wu.compliance.iwatch.sequencegenerator.service.DateGeneratorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.TestPropertySource;
import org.springframework.util.MultiValueMap;

import static org.assertj.core.api.Assertions.assertThat;

@SlowTest
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource(properties = {"spring.config.location=classpath:application-integrationtest.yml"})
@CouchbaseIntegrationTest(resources = "/caseRefSequenceMasterDocument.json")
class CaseReferenceNumberIntegrationTest {

    @Autowired
    CaseReferenceNumberController caseReferenceNumberController;

    @Autowired
    DateGeneratorService dateGeneratorService;

    @Autowired
    TestRestTemplate restTemplate;

    @LocalServerPort
    int integrationTestPort;

    private final MultiValueMap<String, String> requestHeaderMap = new HttpHeaders();

    private String caseReferenceNumberControllerEndpointUrl;


    @BeforeEach
    void testSetup() {
        //Request Headers
        requestHeaderMap.set("x-wu-tenantpid", "WU");
        requestHeaderMap.set("x-wu-tenantsid", "CMT");
        requestHeaderMap.set("x-wu-genre", "CJ");
        requestHeaderMap.set("x-wu-bizgrp", "GSI");
        requestHeaderMap.set("x-wu-invgrp", "SANC");
        requestHeaderMap.set("x-wu-userid", "123456");
        requestHeaderMap.set("x-wu-username", "pharosuser");
        requestHeaderMap.set("x-wu-useremail", "pharosuser@wu.com");
        requestHeaderMap.set("x-wu-correlationid", "452a9ad8-37fd-4f53-b144-ad3254600d3f");

        //URL Endpoint
        caseReferenceNumberControllerEndpointUrl = "http://localhost:" + integrationTestPort + "/v1/iwx/cj/sequences/generate";
    }

    @Test
    @DisplayName("Test to get valid Case reference number")
    void testGenerateCaseReferenceNumber_withValidHeader_shouldReturnCaseReferenceNumber() {
        HttpHeaders requestHeaders = new HttpHeaders(requestHeaderMap);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(null, requestHeaders);
        String datePrefix = dateGeneratorService.generatePrefix();

        ResponseEntity<CaseReferenceNumberDto> response = restTemplate.exchange(caseReferenceNumberControllerEndpointUrl,
                HttpMethod.GET, entity, CaseReferenceNumberDto.class);
        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertResponse(datePrefix, response);
    }

    @Test
    @DisplayName("Test to get valid Case reference number and should update sequence queue after MinimumCacheSize")
    void testGenerateCaseReferenceNumber_withValidHeader_shouldReturnCaseReferenceNumberAndUpdateSequenceQueue() {
        HttpHeaders requestHeaders = new HttpHeaders(requestHeaderMap);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(null, requestHeaders);
        String datePrefix = dateGeneratorService.generatePrefix();

        ResponseEntity<CaseReferenceNumberDto> response = restTemplate.exchange(caseReferenceNumberControllerEndpointUrl,
                HttpMethod.GET, entity, CaseReferenceNumberDto.class);
        assertResponse(datePrefix, response);

        response = restTemplate.exchange(caseReferenceNumberControllerEndpointUrl,
                HttpMethod.GET, entity, CaseReferenceNumberDto.class);
        assertResponse(datePrefix, response);
    }

    private static void assertResponse(String datePrefix, ResponseEntity<CaseReferenceNumberDto> response) {
        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody().getCaseRefNum()).isNotNull()
                .startsWith("CCN" + datePrefix.substring(0, 2))
                .contains(datePrefix.substring(2))
                .hasSize(13);
    }

    @Test
    @DisplayName("Test with invalid header should return bad request")
    void testGenerateCaseReferenceNumber_withInvalidHeader_shouldReturnBadRequestException() {
        requestHeaderMap.remove("x-wu-bizgrp");
        HttpHeaders requestHeaders = new HttpHeaders(requestHeaderMap);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(null, requestHeaders);

        ResponseEntity<CaseReferenceNumberDto> response = restTemplate.exchange(caseReferenceNumberControllerEndpointUrl, HttpMethod.GET, entity, CaseReferenceNumberDto.class);

        assertThat(response.getStatusCodeValue()).isEqualTo(400);
    }

    @Test
    @DisplayName("Test with invalid TenantPid and TenantSid values should return null Case reference number")
    void testGenerateCaseReferenceNumber_withInvalidTenantPidAndSid_ShouldReturnNull() {
        requestHeaderMap.set("x-wu-tenantpid", "UW");
        requestHeaderMap.set("x-wu-tenantsid", "TMC");
        HttpHeaders requestHeaders = new HttpHeaders(requestHeaderMap);
        requestHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(null, requestHeaders);

        ResponseEntity<CaseReferenceNumberDto> response = restTemplate.exchange(caseReferenceNumberControllerEndpointUrl, HttpMethod.GET, entity, CaseReferenceNumberDto.class);

        assertThat(response.getStatusCodeValue()).isEqualTo(200);
        assertThat(response.getBody().getCaseRefNum()).isNull();
    }

}
