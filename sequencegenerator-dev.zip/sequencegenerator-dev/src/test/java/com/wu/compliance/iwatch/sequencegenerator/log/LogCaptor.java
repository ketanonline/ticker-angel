package com.wu.compliance.iwatch.sequencegenerator.log;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;

import java.util.ArrayList;
import java.util.List;

public class LogCaptor extends AbstractAppender {

    List<String> logMessages = new ArrayList<>();

    static LogCaptor logCaptor;

    public LogCaptor() {
        super(LogCaptor.class.getName(), null, null, true, null);
    }

    public static LogCaptor getInstance() {
        if (logCaptor == null)
            logCaptor = new LogCaptor();
        return logCaptor;
    }

    @Override
    public void append(LogEvent event) {
        logMessages.add(event.getMessage().getFormattedMessage());
    }

    public List<String> getLogMessages() {
        return logMessages;
    }
}
