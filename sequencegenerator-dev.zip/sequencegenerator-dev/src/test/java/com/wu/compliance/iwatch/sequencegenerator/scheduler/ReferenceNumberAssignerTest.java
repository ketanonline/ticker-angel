package com.wu.compliance.iwatch.sequencegenerator.scheduler;

import com.wu.compliance.iwatch.microcommonapi.json.JsonMapper;
import com.wu.compliance.iwatch.microtestapi.provider.FileSource;
import com.wu.compliance.iwatch.sequencegenerator.TestUtil;
import com.wu.compliance.iwatch.sequencegenerator.dto.CaseReferenceNumberDto;
import com.wu.compliance.iwatch.sequencegenerator.model.Case;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import com.wu.compliance.iwatch.sequencegenerator.repository.CaseRepository;
import com.wu.compliance.iwatch.sequencegenerator.service.CaseReferenceNumberService;
import com.wu.compliance.iwatch.sequencegenerator.service.SequenceMasterService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReferenceNumberAssignerTest {

    @Mock
    CaseReferenceNumberService caseReferenceNumberService;

    @Mock
    CaseRepository caseRepository;

    @Mock
    SequenceMasterService sequenceMasterService;

    @InjectMocks
    ReferenceNumberAssigner referenceNumberAssigner;

    @BeforeEach
    public void eachTestSetup() {

        org.springframework.test.util
                .ReflectionTestUtils.setField(
                        referenceNumberAssigner,
                        "batchSize",
                        10);
    }

    @ParameterizedTest
    @DisplayName("Should update case reference number to case with no case reference number")
    @FileSource(resources = "/casesWithNullCaseRefNumber.json")
    void testReferenceNumberAssigner_shouldAssignCaseRefNumberToCasesWithNoCaseRefNumber(String dbCases) throws Exception {

        CaseReferenceNumberDto caseRefNumber = new CaseReferenceNumberDto("201121AAAA");
        Case casedto = new JsonMapper().deserialize(dbCases, Case.class);
        List<Case> cases = new ArrayList<>();
        cases.add(casedto);
        Tenant t = new Tenant("WU", "CMT");

        when(sequenceMasterService.getCurrentSequenceIndexMaster()).thenReturn(TestUtil.caseReferenceSequenceMaster());
        when(caseRepository.fetchCaseRefUnassignedCases(anyString(), anyInt())).thenReturn(cases);
        when(caseReferenceNumberService.next(t)).thenReturn(caseRefNumber);

        referenceNumberAssigner.assign();
        verify(caseRepository, times(1)).updateCaseDocument(any(Case.class));
    }


    @ParameterizedTest
    @DisplayName("Should not update case reference number if case reference number already present")
    @FileSource(resources = "/casesWithCaseRefNumber.json")
    void testReferenceNumberAssigner_shouldNotAssignCaseRefNumberToCasesWithCaseRefNumber(String dbCases) throws Exception {
        Case casedto = new JsonMapper().deserialize(dbCases, Case.class);
        List<Case> cases = new ArrayList<>();
        cases.add(casedto);

        when(sequenceMasterService.getCurrentSequenceIndexMaster()).thenReturn(TestUtil.caseReferenceSequenceMaster());
        when(caseRepository.fetchCaseRefUnassignedCases(anyString(), anyInt())).thenReturn(cases);

        referenceNumberAssigner.assign();
        verify(caseRepository, times(0)).updateCaseDocument(any(Case.class));
    }

    @ParameterizedTest
    @DisplayName("Should throw exception if Error in updating the lastRunTimestamp")
    @FileSource(resources = "/casesWithCaseRefNumber.json")
    void testReferenceNumberAssigner_shouldThrowExceptionIfErrorInLastRunTimestamp(String dbCases) throws Exception {

        when(sequenceMasterService.getCurrentSequenceIndexMaster()).thenReturn(TestUtil.caseReferenceSequenceMaster());
        doThrow(new RuntimeException("Error in updating the lastRunTimestamp")).when(sequenceMasterService).updateSchedulerLastRunTime(anyString());
        try {
            referenceNumberAssigner.assign();
        } catch (Exception e) {
            assertEquals("Error in updating the lastRunTimestamp", e.getMessage());
        }
    }


    @ParameterizedTest
    @DisplayName("Should throw error if tenant details are not parsable")
    @FileSource(resources = "/invalidCasesWithNullCaseRefNumber.json")
    void testReferenceNumberAssigner_shouldThroeErrorIfTenantDetailsAreNotParsable(String dbCases) throws Exception {

        Case casedto = new JsonMapper().deserialize(dbCases, Case.class);
        List<Case> cases = new ArrayList<>();
        cases.add(casedto);
        when(sequenceMasterService.getCurrentSequenceIndexMaster()).thenReturn(TestUtil.caseReferenceSequenceMaster());
        when(caseRepository.fetchCaseRefUnassignedCases(anyString(), anyInt())).thenReturn(cases);

        try {
            referenceNumberAssigner.assign();
        } catch (Exception e) {
            assertEquals("Error in updating reference number for case id : GSI::d055c64e-c2b6-439e-aee3-ca9ff670e3e6", e.getMessage());
        }
    }
}