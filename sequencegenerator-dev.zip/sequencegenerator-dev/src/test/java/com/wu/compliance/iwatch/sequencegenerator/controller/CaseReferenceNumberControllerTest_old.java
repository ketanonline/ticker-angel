package com.wu.compliance.iwatch.sequencegenerator.controller;

import com.wu.compliance.iwatch.sequencegenerator.TestUtil;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Disabled
@WebMvcTest(CaseReferenceNumberController.class)
@DisplayName("Case Reference Number controller")
class CaseReferenceNumberControllerTest_old {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    CaseReferenceNumberController caseReferenceNumberController;

    @Test
    @DisplayName("Should generate and return sequence number")
    void testCaseReferenceNumberController_shouldReturnStatus200() throws Exception {

        ResultActions result = mockMvc.perform(get("/v1/iwx/cj/sequences/generate")
                .headers(TestUtil.getHeaders())
                .contentType(MediaType.APPLICATION_JSON));
        result.andExpect(status().isOk());
    }

    @Test
    @DisplayName("Should give bad response on header validation failed")
    void testCaseReferenceNumberController_shouldReturnStatus400() throws Exception {

        ResultActions result = mockMvc.perform(get("/v1/iwx/cj/sequences/generate")
                .headers(new HttpHeaders())
                .contentType(MediaType.APPLICATION_JSON));

        result.andExpect(status().isBadRequest()).
                andExpect(MockMvcResultMatchers.jsonPath("$.errorDetails.*",
                        Matchers.hasSize(9)));
    }

}