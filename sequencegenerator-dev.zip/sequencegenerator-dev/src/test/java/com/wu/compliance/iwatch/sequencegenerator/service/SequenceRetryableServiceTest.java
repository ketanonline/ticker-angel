package com.wu.compliance.iwatch.sequencegenerator.service;

import com.wu.compliance.iwatch.microcommonapi.couchbase.CasFailedException;
import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.microcommonapi.json.JsonMapper;
import com.wu.compliance.iwatch.microtestapi.provider.FileSource;
import com.wu.compliance.iwatch.sequencegenerator.log.LogCaptor;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import com.wu.compliance.iwatch.sequencegenerator.model.TenantSequence;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.context.TestPropertySource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@EnableRetry
@SpringBootTest(classes = {SequenceRetryableService.class})
@TestPropertySource(locations = {"classpath:bootstrap.properties", "classpath:application.properties"})
class SequenceRetryableServiceTest {

    @Autowired
    SequenceRetryableService sequenceRetryableService;

    @MockBean
    SequenceGeneratorService sequenceGeneratorService;

    @MockBean
    SequenceMasterService sequenceMasterService;

    LogCaptor logCaptor = LogCaptor.getInstance();
    Logger logger = (Logger) LogManager.getLogger(SequenceRetryableService.class);

    @BeforeEach
    public void eachTestSetup() {
        logger.addAppender(logCaptor);
        logger.setLevel(Level.INFO);

        org.springframework.test.util
                .ReflectionTestUtils.setField(
                        sequenceRetryableService,
                        "sequenceInitCount",
                        10);
    }

    @ParameterizedTest
    @DisplayName("Should initialize the sequence cache for all the tenant, when valid sequence document in db")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testInitializeSequenceForEachTenant_WhenValidDocumentIsPresent_ShouldInitializeSequenceForEachTenant(String dbDoc) {
        //Arrange
        List<String> sequenceCache = new ArrayList<>();
        sequenceCache.add("AAAA");
        sequenceCache.add("AAAB");
        sequenceCache.add("AAAC");
        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);
        List<TenantSequence> tenantSequences = sequenceMaster.getSequences();
        Pair<List<String>, Integer> generatedSequencesWithNextIndex = Pair.of(sequenceCache, 10);
        tenantSequences.get(0).setIndex(generatedSequencesWithNextIndex.getRight());

        //Act
        when(sequenceGeneratorService.nextBatch(anyInt(), anyInt())).thenReturn(generatedSequencesWithNextIndex);
        Map<Tenant, ConcurrentLinkedQueue<String>> queueMap = sequenceRetryableService
                .initializeSequenceForEachTenant(sequenceMaster, generatedSequencesWithNextIndex.getRight().longValue());

        //Assert
        verify(sequenceMasterService, times(1)).updateMasterDocument(any(SequenceMaster.class), anyLong());
        assertEquals(2, queueMap.size());
    }

    @ParameterizedTest
    @DisplayName("When failed to initialize the cache for all the tenant, then retry 3 times and then throw CasFailedException")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testInitializeSequenceForEachTenant_WhenFailedToInitializeSequenceCacheAndRetry_ShouldThrowCasFailedException(String dbDoc) {
        //Arrange
        List<String> sequenceCache = new ArrayList<>();
        sequenceCache.add("AAAA");
        sequenceCache.add("AAAB");
        sequenceCache.add("AAAC");
        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);
        List<TenantSequence> tenantSequences = sequenceMaster.getSequences();
        Pair<List<String>, Integer> generatedSequencesWithNextIndex = Pair.of(sequenceCache, 10);
        tenantSequences.get(0).setIndex(generatedSequencesWithNextIndex.getRight());

        //Act
        when(sequenceGeneratorService.nextBatch(anyInt(), anyInt())).thenReturn(generatedSequencesWithNextIndex);
        doThrow(CasFailedException.class).when(sequenceMasterService).updateMasterDocument(any(SequenceMaster.class), anyLong());

        //Assert
        assertThatThrownBy(() -> sequenceRetryableService.initializeSequenceForEachTenant(sequenceMaster, 5L))
                .isInstanceOf(CasFailedException.class)
                .hasMessage("Document has been concurrently modified on the server");

        verify(sequenceMasterService, times(3)).updateMasterDocument(any(SequenceMaster.class), anyLong());
        assertTrue(logCaptor.getLogMessages().contains("Failed to Initializing sequence cache for all the tenants due to cas mismatch. Retry Exhausted !"));
    }

    @ParameterizedTest
    @DisplayName("Should refill the sequence cache, when sequence index is reach till SequenceMinimumCacheSize")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testUpdateSequenceQueue_WhenSequenceIndexIsReachTillSequenceMinimumCacheSize_ShouldRefillTheSequenceCache(String dbDoc) {
        //Arrange
        List<String> sequenceCache = new ArrayList<>();
        sequenceCache.add("AAAA");
        sequenceCache.add("AAAB");
        sequenceCache.add("AAAC");
        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);
        DocumentWithMetaData<SequenceMaster> sequenceMasterResponse = new DocumentWithMetaData<>(sequenceMaster, 19103L);
        List<TenantSequence> tenantSequences = sequenceMaster.getSequences();
        Pair<List<String>, Integer> generatedSequencesWithNextIndex = Pair.of(sequenceCache, 10);
        tenantSequences.get(0).setIndex(generatedSequencesWithNextIndex.getRight());
        tenantSequences.get(1).setIndex(generatedSequencesWithNextIndex.getRight());

        //Act
        when(sequenceMasterService.getCurrentSequenceIndexMasterWithCas()).thenReturn(sequenceMasterResponse);
        when(sequenceGeneratorService.nextBatch(anyInt(), anyInt())).thenReturn(generatedSequencesWithNextIndex);
        sequenceRetryableService.updateSequenceQueue(tenantSequences.get(0).getTenant(), new ConcurrentLinkedQueue<>(generatedSequencesWithNextIndex.getLeft()));

        //Assert
        verify(sequenceMasterService, times(1)).updateMasterDocument(any(SequenceMaster.class), anyLong());
    }

    @ParameterizedTest
    @DisplayName("When failed to refill sequence cache due to cas mismatch, then retry 3 times and should throw CasFailedException")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testUpdateSequenceQueue_WhenFailedToUpdateRefillSequenceCacheAndRetry_ShouldThrowCasFailedException(String dbDoc) {
        //Arrange
        List<String> sequenceCache = new ArrayList<>();
        sequenceCache.add("AAAA");
        sequenceCache.add("AAAB");
        sequenceCache.add("AAAC");
        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);
        DocumentWithMetaData<SequenceMaster> sequenceMasterResponse = new DocumentWithMetaData<>(sequenceMaster, 19103L);
        List<TenantSequence> tenantSequences = sequenceMaster.getSequences();
        Pair<List<String>, Integer> generatedSequencesWithNextIndex = Pair.of(sequenceCache, 10);
        tenantSequences.get(0).setIndex(generatedSequencesWithNextIndex.getRight());

        //Act
        when(sequenceMasterService.getCurrentSequenceIndexMasterWithCas()).thenReturn(sequenceMasterResponse);
        when(sequenceGeneratorService.nextBatch(anyInt(), anyInt())).thenReturn(generatedSequencesWithNextIndex);
        doThrow(CasFailedException.class).when(sequenceMasterService).updateMasterDocument(any(SequenceMaster.class), anyLong());

        //Assert
        assertThatThrownBy(() -> sequenceRetryableService.updateSequenceQueue(tenantSequences.get(0).getTenant(),
                new ConcurrentLinkedQueue<>(generatedSequencesWithNextIndex.getLeft())))
                .isInstanceOf(CasFailedException.class)
                .hasMessage("Document has been concurrently modified on the server");

        verify(sequenceMasterService, times(3)).updateMasterDocument(any(SequenceMaster.class), anyLong());
        assertTrue(logCaptor.getLogMessages().contains("Failed to Refilled sequence cache due to cas mismatch. Retry Exhausted !"));
    }
}
