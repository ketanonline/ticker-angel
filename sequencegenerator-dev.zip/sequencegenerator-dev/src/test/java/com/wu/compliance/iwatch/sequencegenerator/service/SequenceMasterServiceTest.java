package com.wu.compliance.iwatch.sequencegenerator.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.microcommonapi.json.JsonMapper;
import com.wu.compliance.iwatch.microtestapi.provider.FileSource;
import com.wu.compliance.iwatch.sequencegenerator.TestUtil;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import com.wu.compliance.iwatch.sequencegenerator.repository.SequenceMasterRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SequenceMasterServiceTest {

    @Mock
    SequenceMasterRepository sequenceMasterRepository;

    @InjectMocks
    SequenceMasterService sequenceMasterService;

    JsonMapper jsonMapper = new JsonMapper();

    @ParameterizedTest
    @DisplayName("Should return proper sequence index if document is present in bucket for primary tenant")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterService_shouldReturnSequenceIndex(String sequenceIndexJson) {
        SequenceMaster sequenceMaster = jsonMapper.deserialize(sequenceIndexJson, SequenceMaster.class);

        when(sequenceMasterRepository.getSequenceIndexDocument()).thenReturn(sequenceMaster);

        int sequence = sequenceMasterService.getCurrentSequenceIndex(TestUtil.getPrimaryTenant());
        assertEquals(24802, sequence);
    }

    @ParameterizedTest
    @DisplayName("Should return proper sequence index if document is present in bucket for secondary tenant")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterService_shouldReturnSequenceIndexForOtherTenant(String sequenceIndexJson) {
        SequenceMaster sequenceMaster = jsonMapper.deserialize(sequenceIndexJson, SequenceMaster.class);
        when(sequenceMasterRepository.getSequenceIndexDocument()).thenReturn(sequenceMaster);

        int sequence = sequenceMasterService.getCurrentSequenceIndex(TestUtil.getSecondaryTenant());
        assertEquals(19040, sequence);
    }

    @Test
    @DisplayName("Should return sequence index as `0` if document is not present in bucket")
    void testSequenceMasterService_shouldReturnSequenceIndexAsZero() {
        when(sequenceMasterRepository.getSequenceIndexDocument()).thenReturn(null);

        int sequence = sequenceMasterService.getCurrentSequenceIndex(TestUtil.getPrimaryTenant());
        assertEquals(0, sequence);
    }

    @Test
    @DisplayName("Should return sequence index as `0` if getSequenceIndexDocument throw exception")
    void testSequenceMasterService_shouldReturnSequenceIndexAsZeroIfSequenceIndexDocumentIsNull() {
        when(sequenceMasterRepository.getSequenceIndexDocument()).thenThrow(new RuntimeException());
        int sequence = sequenceMasterService.getCurrentSequenceIndex(TestUtil.getPrimaryTenant());
        assertEquals(0, sequence);
    }

    @ParameterizedTest
    @DisplayName("Should return DTO of case reference sequence master")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterService_shouldReturnMasterDocInDTOFormat(String dbDoc) throws JsonProcessingException {

        SequenceMaster sequenceMasterObj = jsonMapper.deserialize(dbDoc, SequenceMaster.class);
        when(sequenceMasterRepository.getSequenceIndexDocument()).thenReturn(sequenceMasterObj);

        SequenceMaster sequenceMaster = sequenceMasterService.getCurrentSequenceIndexMaster();

        assertEquals("master::sequence", sequenceMaster.getDocType());
    }

    @ParameterizedTest
    @DisplayName("Should call update sequence master field method with sequence master object should contain an updated index only for primary tenant")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterService_shouldUpdateCaseReferenceIndexOnlyForPrimaryTenant(String dbDoc) throws Exception {
        SequenceMaster sequenceMaster = jsonMapper.deserialize(dbDoc, SequenceMaster.class);
        ArgumentCaptor<SequenceMaster> sequenceDocArgCapture = ArgumentCaptor.forClass(SequenceMaster.class);
        ArgumentCaptor<Long> casCapture = ArgumentCaptor.forClass(Long.class);

        sequenceMasterService.updateMasterDocument(sequenceMaster, 2310393L);
        verify(sequenceMasterRepository).updateSequenceMasterDocument(sequenceDocArgCapture.capture(), casCapture.capture());
        assertEquals(sequenceMaster, sequenceDocArgCapture.getValue());
        assertThat(sequenceDocArgCapture.getValue().getSequences().get(0).getIndex()).isEqualTo(24802);
        assertThat(sequenceDocArgCapture.getValue().getSequences().get(1).getIndex()).isEqualTo(19040);
        assertThat(casCapture.getValue()).isEqualTo(2310393L);
    }

    @ParameterizedTest
    @DisplayName("Should call update sequence master field method with sequence master object should contain an updated index only for secondary tenant")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterService_shouldUpdateCaseReferenceIndexOnlyForSecTenant(String dbDoc) throws Exception {
        SequenceMaster sequenceMaster = jsonMapper.deserialize(dbDoc, SequenceMaster.class);
        ArgumentCaptor<SequenceMaster> sequenceDocArgCapture = ArgumentCaptor.forClass(SequenceMaster.class);
        ArgumentCaptor<Long> casCapture = ArgumentCaptor.forClass(Long.class);

        sequenceMasterService.updateMasterDocument(sequenceMaster, 1232778L);

        verify(sequenceMasterRepository).updateSequenceMasterDocument(sequenceDocArgCapture.capture(), casCapture.capture());

        assertEquals(sequenceMaster, sequenceDocArgCapture.getValue());
        assertThat(sequenceDocArgCapture.getValue().getSequences().get(0).getIndex()).isEqualTo(24802);
        assertThat(sequenceDocArgCapture.getValue().getSequences().get(1).getIndex()).isEqualTo(19040);
        assertThat(casCapture.getValue()).isEqualTo(1232778L);
    }

    @Test
    @DisplayName("Should throw error if sequence master document is missing while updating the index")
    void testSequenceMasterService_shouldThrowErrorIfUpdateFailedDueToMissingSequenceMasterDoc() {
        doThrow(new RuntimeException("Error while updating the document"))
                .when(sequenceMasterRepository).updateSequenceMasterDocument(any(SequenceMaster.class), anyLong());
        try {
            sequenceMasterService.updateMasterDocument(TestUtil.caseReferenceSequenceMaster(), 0L);
        } catch (Exception e) {
            assertEquals("Error while updating the document", e.getMessage());
        }
    }

    @ParameterizedTest
    @DisplayName("Should call update scheduler last run time method")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterService_shouldUpdateSchedulerLastRunTime(String dbDoc) throws Exception {
        SequenceMaster sequenceMasterObj = jsonMapper.deserialize(dbDoc, SequenceMaster.class);
        ArgumentCaptor<SequenceMaster> sequenceDocArgCapture = ArgumentCaptor.forClass(SequenceMaster.class);

        when(sequenceMasterRepository.getSequenceIndexDocument()).thenReturn(sequenceMasterObj);
        sequenceMasterService.updateSchedulerLastRunTime("2020-11-18T11:31:01.317Z");
        verify(sequenceMasterRepository).updateSequenceMasterField(sequenceDocArgCapture.capture());

        assertEquals(sequenceMasterObj, sequenceDocArgCapture.getValue());
        assertEquals("2020-11-18T11:31:01.317Z", sequenceDocArgCapture.getValue().getSchedulerLastRunTimestamp());
    }

    @ParameterizedTest
    @DisplayName("When document and cas is requested, Should return document with cas from DB")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterService_WhenDocumentAndCasIsRequested_ShouldReturnDocumentWithCas(String dbDoc){
        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);
        DocumentWithMetaData<SequenceMaster> sequenceMasterResponse = new DocumentWithMetaData<>(sequenceMaster, 19103L);
        when(sequenceMasterService.getCurrentSequenceIndexMasterWithCas()).thenReturn(sequenceMasterResponse);
        DocumentWithMetaData<SequenceMaster> resultDocumentWithCas = sequenceMasterRepository.getDocumentWithCas();
        assertEquals(resultDocumentWithCas.getDocument(), sequenceMaster);
    }
}