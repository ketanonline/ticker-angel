package com.wu.compliance.iwatch.sequencegenerator.service;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.text.SimpleDateFormat;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class DateGeneratorServiceTest {

    @InjectMocks
    DateGeneratorService dateGeneratorService;

    @Test
    @DisplayName("Should always return current date in yyMMdd format")
    void generatePrefix() {
        String currentDate = new SimpleDateFormat("yyMMdd").format(new Date());
        assertEquals(currentDate, dateGeneratorService.generatePrefix());
    }
}