package com.wu.compliance.iwatch.sequencegenerator.controller;

import com.wu.compliance.iwatch.microcommonapi.CommonHeaderAccessor;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.HeaderSchemaValidator;
import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.ValidationResult;
import com.wu.compliance.iwatch.sequencegenerator.dto.CaseReferenceNumberDto;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import com.wu.compliance.iwatch.sequencegenerator.service.CaseReferenceNumberService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
@DisplayName("Case Reference Number controller")
class CaseReferenceNumberControllerTest {

    @InjectMocks
    CaseReferenceNumberController caseReferenceNumberController;

    @Mock
    HeaderSchemaValidator headerSchemaValidator;

    @Mock
    CommonHeaderAccessor commonHeaderAccessor;

    @Mock
    CaseReferenceNumberService caseReferenceNumberService;


    @Test
    @DisplayName("Should generate and return sequence number")
    void testCaseReferenceNumberController_shouldReturnStatus200() {

        List<ErrorDetail> errorDetails = new ArrayList<>();
        ValidationResult validationResult = new ValidationResult(errorDetails);

        CaseReferenceNumberDto caseReferenceNumberDto = new CaseReferenceNumberDto("CC21AA0317AA");

        given(headerSchemaValidator.validate()).willReturn(validationResult);
        given(commonHeaderAccessor.getHeader(any())).willReturn("WU");
        given(caseReferenceNumberService.next(any(Tenant.class))).willReturn(caseReferenceNumberDto);


        ResponseEntity<CaseReferenceNumberDto> result = caseReferenceNumberController.getSequence();
        assertEquals(result.getBody().getCaseRefNum(),"CC21AA0317AA");
    }

}