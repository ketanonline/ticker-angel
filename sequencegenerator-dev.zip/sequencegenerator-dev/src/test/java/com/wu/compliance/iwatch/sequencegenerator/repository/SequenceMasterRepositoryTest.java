package com.wu.compliance.iwatch.sequencegenerator.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.microcommonapi.couchbase.QueryExecutor;
import com.wu.compliance.iwatch.microcommonapi.json.JacksonObjectReader;
import com.wu.compliance.iwatch.microcommonapi.json.JsonMapper;
import com.wu.compliance.iwatch.microtestapi.provider.FileSource;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;
import java.util.function.Consumer;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


@ExtendWith({MockitoExtension.class, OutputCaptureExtension.class})
class SequenceMasterRepositoryTest {
    @Mock
    QueryExecutor queryExecutor;

    @InjectMocks
    SequenceMasterRepository sequenceMasterRepository;

    @BeforeEach
    public void eachTestSetup() {
        ReflectionTestUtils.setField(
                sequenceMasterRepository,
                "sequenceMasterDocumentId",
                "master::sequence");
        ReflectionTestUtils.setField(
                sequenceMasterRepository,
                "iWatchXCustomerJourneyBucket",
                "iWatchX");
    }

    @ParameterizedTest
    @DisplayName("Should return sequence master document")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterRepository_shouldReturnSequenceMasterDoc(String sequenceIndexJson) throws JsonProcessingException {
        JacksonObjectReader jacksonObjectReader = new JacksonObjectReader();
        SequenceMaster sequenceMaster = jacksonObjectReader.readValue(sequenceIndexJson, SequenceMaster.class);
        when(queryExecutor.findById(anyString(),anyString(), any(Class.class))).
                thenReturn(Optional.of(sequenceMaster));

        SequenceMaster sequencemasterobj = sequenceMasterRepository.getSequenceIndexDocument();
        assertEquals(sequencemasterobj, sequenceMaster);
    }

    @Test
    @DisplayName("Should return null sequence master document when findById return null")
    void testSequenceMasterRepository_getSequenceIndexReturnNull() {
        when(queryExecutor.findById(anyString(), anyString(), any(Class.class))).
                thenReturn(Optional.empty());
        SequenceMaster sequenceIndexDocument = sequenceMasterRepository.getSequenceIndexDocument();
        assertThat(sequenceIndexDocument).isNull();
    }

    @Disabled
    @ParameterizedTest
    @DisplayName("Should log error if Sequence master update fails")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterRepository_shouldLogErrorIfSequenceMasterUpdateFails(String sequenceIndexJson, CapturedOutput output) throws JsonProcessingException {

        JacksonObjectReader jacksonObjectReader = new JacksonObjectReader();
        SequenceMaster sequenceMaster = jacksonObjectReader.readValue(sequenceIndexJson, SequenceMaster.class);
        doThrow(new RuntimeException())
                .when(queryExecutor)
                .upsert(anyString(), anyString(), any(SequenceMaster.class));

        assertThrows(RuntimeException.class, () -> sequenceMasterRepository.updateSequenceMasterField(sequenceMaster));
        Assertions.assertThat(output).contains("Error while updating sequence master Document.");
    }

    @ParameterizedTest
    @DisplayName("Should update Sequence master document")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterRepository_shouldUpdateSequenceMasterDocument(String sequenceIndexJson) throws JsonProcessingException {
        JacksonObjectReader jacksonObjectReader = new JacksonObjectReader();
        SequenceMaster sequenceMaster = jacksonObjectReader.readValue(sequenceIndexJson, SequenceMaster.class);

        sequenceMasterRepository.updateSequenceMasterField(sequenceMaster);
        verify(queryExecutor, times(1))
                .upsert(anyString(),anyString(),any(SequenceMaster.class));
    }

    @ParameterizedTest
    @DisplayName("When valid document and cas value is present, Should update Sequence document with cas")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterRepository_WhenValidDocumentAndCasIsPassed_ShouldUpdateSequenceDocumentWithCas(String sequenceIndexJson) {
        SequenceMaster sequenceMaster = new JsonMapper().deserialize(sequenceIndexJson, SequenceMaster.class);
        Long casValue = 5L;
        doNothing().when(queryExecutor).replace(anyString(), anyString(), any(SequenceMaster.class), any(Consumer.class));
        sequenceMasterRepository.updateSequenceMasterDocument(sequenceMaster, casValue);
        verify(queryExecutor, times(1))
                .replace(anyString(), anyString(), any(SequenceMaster.class), any(Consumer.class));
    }

    @ParameterizedTest
    @DisplayName("When document and cas is requested, Should return document with cas")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceMasterRepository_WhenDocumentAndCasIsRequested_ShouldReturnDocumentAndCas(String sequenceIndexJson) {
        SequenceMaster sequenceMaster = new JsonMapper().deserialize(sequenceIndexJson, SequenceMaster.class);
        DocumentWithMetaData<SequenceMaster> sequenceMasterResponse = new DocumentWithMetaData<>(sequenceMaster, 19103L);
        when(queryExecutor.findByIdWithMetadata(anyString(), anyString(), any())).
                thenReturn(new DocumentWithMetaData<>(sequenceMasterResponse.getDocument(), sequenceMasterResponse.getCas()));

        DocumentWithMetaData<SequenceMaster> documentMasterResponse = sequenceMasterRepository.getDocumentWithCas();
        assertEquals(documentMasterResponse.getDocument(), sequenceMaster);
        assertEquals(documentMasterResponse.getCas(), sequenceMasterResponse.getCas());
    }
}