package com.wu.compliance.iwatch.sequencegenerator;

import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import com.wu.compliance.iwatch.sequencegenerator.model.TenantSequence;
import org.springframework.http.HttpHeaders;

import java.util.ArrayList;
import java.util.List;

public class TestUtil {

    public static Tenant getPrimaryTenant() {
        return new Tenant("WU", "CMT");
    }

    public static Tenant getSecondaryTenant() {
        return new Tenant("WU", "DIG");
    }

    public static HttpHeaders getHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(HeaderKey.TENANT_PID.getValue(), "WU");
        httpHeaders.set(HeaderKey.TENANT_SID.getValue(), "CMT");
        httpHeaders.set(HeaderKey.GENRE.getValue(), "CJ");
        httpHeaders.set(HeaderKey.BUSINESS_GROUP.getValue(), "GSI");
        httpHeaders.set(HeaderKey.INVESTIGATIVE_GROUP.getValue(), "INTR");
        httpHeaders.set(HeaderKey.USER_ID.getValue(), "System");
        httpHeaders.set(HeaderKey.USER_NAME.getValue(), "System");
        httpHeaders.set(HeaderKey.USER_EMAIL.getValue(), "donotreply@westernunion.com");
        httpHeaders.set(HeaderKey.CORRELATION_ID.getValue(), "TestCorrelationId");
        return httpHeaders;
    }

    public static SequenceMaster caseReferenceSequenceMaster() {
        List<TenantSequence> sequences = new ArrayList<>();
        TenantSequence ts1 = new TenantSequence();
        ts1.setIndex(19000);
        ts1.setTenant(getPrimaryTenant());
        sequences.add(ts1);

        TenantSequence ts2 = new TenantSequence();
        ts2.setIndex(20000);
        ts2.setTenant(getSecondaryTenant());
        sequences.add(ts2);

        SequenceMaster sequenceMaster = new SequenceMaster();
        sequenceMaster.setDocType("master::sequence");
        sequenceMaster.setSchedulerLastRunTimestamp("2020-12-01T17:59:03.070722600Z");
        sequenceMaster.setSequences(sequences);
        return sequenceMaster;
    }
}
