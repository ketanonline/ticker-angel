package com.wu.compliance.iwatch.sequencegenerator.service;

import com.wu.compliance.iwatch.microcommonapi.couchbase.CasFailedException;
import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.microcommonapi.json.JsonMapper;
import com.wu.compliance.iwatch.microtestapi.provider.FileSource;
import com.wu.compliance.iwatch.sequencegenerator.TestUtil;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SequenceCacheServiceTest {

    @Mock
    SequenceMasterService sequenceMasterService;

    @InjectMocks
    SequenceCacheService sequenceCacheService;

    @Mock
    SequenceRetryableService sequenceRetryableService;

    @BeforeEach
    public void eachTestSetup() {

        org.springframework.test.util
                .ReflectionTestUtils.setField(
                sequenceCacheService,
                "sequenceMinimumCacheSize",
                10);
    }

    @ParameterizedTest
    @DisplayName("When current sequence index and cas is present, should initialize the cache for all the tenant")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceCacheService_WhenGetCurrentSequenceIndexWithCas_ShouldInitializeTheCache(String dbDoc) {

        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);
        DocumentWithMetaData<SequenceMaster> sequenceMasterResponse = new DocumentWithMetaData<>(sequenceMaster, 19103L);

        when(sequenceMasterService.getCurrentSequenceIndexMasterWithCas()).thenReturn(sequenceMasterResponse);
        sequenceCacheService.initializeSequenceCache();
        verify(sequenceRetryableService, times(1)).initializeSequenceForEachTenant(any(SequenceMaster.class), anyLong());
    }

    @ParameterizedTest
    @DisplayName("When new sequence index with different cas is updated, should throw CasFailedException")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceCacheService_WhenPersistNewSequenceIndexWithDifferentCas_ShouldThrowCasFailedException(String dbDoc) {

        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);
        DocumentWithMetaData<SequenceMaster> sequenceMasterResponse = new DocumentWithMetaData<>(sequenceMaster, 19103L);

        when(sequenceMasterService.getCurrentSequenceIndexMasterWithCas()).thenReturn(sequenceMasterResponse);
        when(sequenceRetryableService.initializeSequenceForEachTenant(any(SequenceMaster.class), anyLong())).thenThrow(CasFailedException.class);
        assertThatThrownBy(() -> sequenceCacheService.initializeSequenceCache()).isInstanceOf(CasFailedException.class);
    }

    @ParameterizedTest
    @DisplayName("When sequence index count is reach till SequenceMinimumCacheSize, should refill the sequence cache")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceCacheService_WhenSequenceIndexCountIsReachTillSequenceMinimumCacheSize_ShouldRefillSequenceCache(String dbDoc) {
        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<String>();
        queue.add("AAAA");
        queue.add("AAAB");
        queue.add("AAAC");
        queue.add("AAAD");
        queue.add("AAAE");
        queue.add("AAAF");
        queue.add("AAAG");
        queue.add("AAAH");

        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);

        Map<Tenant, ConcurrentLinkedQueue<String>> hashMap = new HashMap<Tenant, ConcurrentLinkedQueue<String>>();
        hashMap.put(TestUtil.getPrimaryTenant(), queue);
        hashMap.put(TestUtil.getSecondaryTenant(), new ConcurrentLinkedQueue<String>());
        sequenceCacheService.hashMap = hashMap;

        sequenceCacheService.next(TestUtil.getPrimaryTenant());
        verify(sequenceRetryableService, times(1)).updateSequenceQueue(any(Tenant.class), any(ConcurrentLinkedQueue.class));
    }

    @ParameterizedTest
    @DisplayName("When sequence index count is not less than SequenceMinimumCacheSize, should not refill the sequence cache and poll next sequence")
    @FileSource(resources = "/caseRefSequenceMaster.json")
    void testSequenceCacheService_WhenSequenceIndexIsNotLessThanSequenceMinimumCacheSize_ShouldNotRefillTheCache(String dbDoc) {

        SequenceMaster sequenceMaster = new JsonMapper().deserialize(dbDoc, SequenceMaster.class);

        ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<String>();
        queue.add("AAAA");
        queue.add("AAAB");
        queue.add("AAAC");
        queue.add("AAAD");
        queue.add("AAAE");
        queue.add("AAAF");
        queue.add("AAAG");
        queue.add("AAAH");
        queue.add("AAAI");
        queue.add("AAAJ");
        queue.add("AAAK");


        Map<Tenant, ConcurrentLinkedQueue<String>> hashMap = new HashMap<Tenant, ConcurrentLinkedQueue<String>>();
        hashMap.put(TestUtil.getPrimaryTenant(), queue);
        hashMap.put(TestUtil.getSecondaryTenant(), new ConcurrentLinkedQueue<String>());
        sequenceCacheService.hashMap = hashMap;

        sequenceCacheService.next(TestUtil.getPrimaryTenant());
        verify(sequenceMasterService, never()).updateMasterDocument(any(SequenceMaster.class), anyLong());
        verify(sequenceMasterService, never()).getCurrentSequenceIndexMasterWithCas();
    }
}