package com.wu.compliance.iwatch.sequencegenerator.repository;

import com.wu.compliance.iwatch.microcommonapi.couchbase.QueryExecutor;
import com.wu.compliance.iwatch.microcommonapi.json.JsonMapper;
import com.wu.compliance.iwatch.microtestapi.provider.FileSource;
import com.wu.compliance.iwatch.sequencegenerator.model.Case;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CaseRepositoryTest {

    @Mock
    QueryExecutor queryExecutor;

    @InjectMocks
    CaseRepository caseRepository;

    private Integer batchSize = 10;

    @ParameterizedTest
    @DisplayName("Should return cases with case reference number as a null")
    @FileSource(resources = "/casesWithNullCaseRefNumber.json")
    void testCaseRepository_shouldReturnCaseRefUnassignedCases(String dbCases) {
        Case caseDoc = new JsonMapper().deserialize(dbCases, Case.class);
        when(queryExecutor.find(anyString(), anyMap(), any())).
                thenReturn(Collections.singletonList(Optional.of(caseDoc)));
        List<Case> rows = caseRepository.fetchCaseRefUnassignedCases("2020-12-01T17:59:03.070722600Z", batchSize);
        assertEquals(1, rows.size());
    }

    @Test
    @DisplayName("Should return Empty list when no cases is available")
    void testCaseRepository_shouldReturnEmptyCaseRefUnassignedCases() {
        when(queryExecutor.find(anyString(), anyMap(), any(Class.class))).
                thenReturn(Collections.emptyList());
        List<Case> listOfCases = caseRepository.fetchCaseRefUnassignedCases("2020-12-01T17:59:03.070722600Z", batchSize);
        assertEquals(true, listOfCases.isEmpty());
    }

    @Test
    @DisplayName("Should return Empty list when there is Exception")
    void testCaseRepository_shouldReturnEmptyCollectionWhenExceptionOccurred() {
        when(queryExecutor.find(anyString(), anyMap(), any(Class.class))).
                thenThrow(RuntimeException.class);
        List<Case> listOfCases = caseRepository.fetchCaseRefUnassignedCases("2020-12-01T17:59:03.070722600Z", batchSize);
        assertEquals(true, listOfCases.isEmpty());
    }

    @ParameterizedTest
    @DisplayName("Should update case document")
    @FileSource(resources = "/casesWithCaseRefNumber.json")
    void testCaseRepository_shouldUpdateCaseDocument(String dbDoc) {
        Case caseDoc = new JsonMapper().deserialize(dbDoc, Case.class);
        caseRepository.updateCaseDocument(caseDoc);
        verify(queryExecutor, times(1)).update(anyString(), anyMap());
    }
}