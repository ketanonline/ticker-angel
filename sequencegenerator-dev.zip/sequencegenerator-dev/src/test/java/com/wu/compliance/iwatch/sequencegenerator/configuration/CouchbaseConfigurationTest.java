package com.wu.compliance.iwatch.sequencegenerator.configuration;


import com.wu.compliance.iwatch.microcommonapi.couchbase.DefaultQueryExecutor;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {CouchbaseConfiguration.class})
class CouchbaseConfigurationTest {

    CouchbaseConfiguration couchbaseConfiguration = new CouchbaseConfiguration();

    @Test
    @DisplayName("queryExecutor should return instance of DefaultQueryExecutor.class")
    void test_queryExecuter() {

        Assertions.assertThat(couchbaseConfiguration.queryExecutor("10.39.213.76", "testUser", "testPassword", ""))
                .isNotNull().isInstanceOf(DefaultQueryExecutor.class);
    }
}
