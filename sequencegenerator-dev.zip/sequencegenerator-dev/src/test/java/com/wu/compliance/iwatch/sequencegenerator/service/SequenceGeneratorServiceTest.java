package com.wu.compliance.iwatch.sequencegenerator.service;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class SequenceGeneratorServiceTest {

    @InjectMocks
    SequenceGeneratorService sequenceGeneratorService;

    @Test
    @DisplayName("Should generate next batch of given count, and provide updated index")
    void testSequenceGeneratorService_generateNextBatch() {
        Pair<List<String>, Integer> pair = sequenceGeneratorService.nextBatch(18279, 10);
        assertEquals(10, pair.getLeft().size());
        assertEquals(18289, pair.getRight());
    }

    @Test
    @DisplayName("Should generate sequence number in sequence")
    void testSequenceGeneratorService_generateProperSequence() {
        Pair<List<String>, Integer> pair = sequenceGeneratorService.nextBatch(18279, 5);
        assertEquals("AAAA", pair.getLeft().get(0));
        assertEquals("AAAB", pair.getLeft().get(1));
        assertEquals("AAAC", pair.getLeft().get(2));
        assertEquals("AAAD", pair.getLeft().get(3));
        assertEquals("AAAE", pair.getLeft().get(4));
    }

    @Test
    @DisplayName("Should reset sequence number after `ZZZZ`")
    void testSequenceGeneratorService_resetSequence() {
        Pair<List<String>, Integer> pair = sequenceGeneratorService.nextBatch(475252, 5);
        assertEquals("ZZZX", pair.getLeft().get(0));
        assertEquals("ZZZY", pair.getLeft().get(1));
        assertEquals("ZZZZ", pair.getLeft().get(2));
        assertEquals("AAAA", pair.getLeft().get(3));
        assertEquals("AAAB", pair.getLeft().get(4));
    }

}