package com.wu.compliance.iwatch.sequencegenerator.events;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class Base26NumberTest {

    @ParameterizedTest
    @DisplayName("Should return Base26 representation of number")
    @CsvFileSource(resources = "/numbersToChars.csv", numLinesToSkip = 1)
    void base26Decode(String chars, int ints) {
        assertEquals(chars, Base26Number.toBase26(ints));
    }
}