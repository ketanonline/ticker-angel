package com.wu.compliance.iwatch.sequencegenerator.exception;

import com.wu.compliance.iwatch.microcommonapi.CommonHeaderAccessor;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class SequenceGeneratorExceptionHandlerTest {

    @InjectMocks
    SequenceGeneratorExceptionHandler sequenceGeneratorExceptionHandler;

    @Mock
    CommonHeaderAccessor commonHeaderAccessor;

    @Test
    @DisplayName("Should return response entity with 500 for runtime exception")
    void testResponseBuilder_shouldReturnResponseEntityWith500ForRuntimeException() {
        given(commonHeaderAccessor.getHeader(any())).willReturn("1234");

        ResponseEntity<DefaultResponse> result = sequenceGeneratorExceptionHandler.handleRuntimeException(new RuntimeException("Runtime Exception"));
        assertEquals(500, result.getStatusCode().value());
        assertTrue(result.getStatusCode().is5xxServerError());
        assertEquals("1234", result.getBody().getTraceId());
        assertEquals("Runtime Exception", result.getBody().getDescription());

    }

    @Test
    @DisplayName("Should return response entity with 400 for validation exception")
    void testResponseBuilder_shouldReturnResponseEntityForValidationException() {
        given(commonHeaderAccessor.getHeader(any())).willReturn("12345");
        List<ErrorDetail> errorDetails = new ArrayList<>();

        ResponseEntity<DefaultResponse> result = sequenceGeneratorExceptionHandler.handleCustomValidationException(new ValidationException(errorDetails ,"Validation Exception"));
        assertEquals(400, result.getStatusCode().value());
        assertTrue(result.getStatusCode().is4xxClientError());
        assertEquals("12345", result.getBody().getTraceId());

    }
}