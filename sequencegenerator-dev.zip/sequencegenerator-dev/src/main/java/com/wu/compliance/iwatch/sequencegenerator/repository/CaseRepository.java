package com.wu.compliance.iwatch.sequencegenerator.repository;


import com.wu.compliance.iwatch.microcommonapi.couchbase.QueryExecutor;
import com.wu.compliance.iwatch.sequencegenerator.model.Case;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Repository
public class CaseRepository {
    @Value("${app.couchbase.bucket.customer.journey}")
    private String iWatchXCustomerJourneyBucket;
    private final QueryExecutor queryExecutor;
    private final Logger logger = LogManager.getLogger(this.getClass());

    public CaseRepository(QueryExecutor queryExecutor) {
        this.queryExecutor = queryExecutor;
    }

    public List<Case> fetchCaseRefUnassignedCases(String schedulerLastRunTimestamp, Integer batchSize) {
        try {
            List<Case> cases = queryExecutor.find("select META().id ,iwxcj.caseRefNo ,iwxcj.modifiedTimestamp, iwxcj.tenant from " +
                            iWatchXCustomerJourneyBucket + " as iwxcj where docType =$docType " +
                            " and IFMISSINGORNULL(caseRefNo,0)=0 " +
                            " and STR_TO_MILLIS(createdTimestamp) >= STR_TO_MILLIS($schedulerLastRunTimestamp)" +
                            "order by createdTimestamp limit $batchSize",
                    Map.of("docType", "gsiCase", "schedulerLastRunTimestamp", schedulerLastRunTimestamp, "batchSize",batchSize), Case.class);
            logger.info("Total " + cases.size() + " cases found for missing case reference number criteria.");
            return cases;
        } catch (Exception exception) {
            logger.error("Error while fetching case with Unassigned reference number", exception);
        }
        return Collections.EMPTY_LIST;
    }

    public void updateCaseDocument(Case caseData) {
        try {
           queryExecutor.update("update "+ iWatchXCustomerJourneyBucket + " use keys [$docId] " +
                           " set caseRefNo = $caseRefNo , modifiedTimestamp = $modifiedTimestamp",
                    Map.of("docId", caseData.getId(),
                            "caseRefNo", caseData.getCaseRefNo(),
                            "$modifiedTimestamp", Instant.now().toString()));
        } catch (Exception e) {
            logger.error("Error while updating case document for case reference number.", e);
            throw e;
        }
    }
}
