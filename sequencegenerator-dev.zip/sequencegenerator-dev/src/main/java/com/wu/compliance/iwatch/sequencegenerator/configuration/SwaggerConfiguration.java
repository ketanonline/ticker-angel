package com.wu.compliance.iwatch.sequencegenerator.configuration;

import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.servers.Server;
import org.springdoc.core.models.GroupedOpenApi;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfiguration {

    @Bean
    public GroupedOpenApi productApi(){
        return GroupedOpenApi.
                builder().
                packagesToScan("com.wu.compliance.iwatch.sequencegenerator.controller").
                addOperationCustomizer(customizeHeaders()).
                group("sequence-generator-swagger").build();
    }

    @Bean
    public OpenAPI metaData() {
        return new OpenAPI().addServersItem(
                        new Server().url("/")
                )
                .info(new Info().title("Sequence Generator Service")
                        .description("Spring Boot REST API for requesting case reference number")
                        .version("1.0")
                        .contact(new Contact().name("Pharos Modernization").email("Pharos-Modernization@westernunion.com"))
                );
    }

    public OperationCustomizer customizeHeaders(){
        return (operation, handlerMethod) -> {

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-correlationId")
                    .description("CorrelationId Info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-tenantpid")
                    .description("Tenant Primary Id Info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-tenantsid")
                    .description("Tenant Secondary Id Info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-genre")
                    .description("Genre info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-bizgrp")
                    .description("Bizgrp Info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-invgrp")
                    .description("Invgrp Info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-userid")
                    .description("UserId Info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-username")
                    .description("Username Info")
                    .allowEmptyValue(false)
            );

            operation.addParametersItem(new Parameter()
                    .in(ParameterIn.HEADER.toString())
                    .required(true)
                    .name("x-wu-useremail")
                    .description("User Email Info")
                    .allowEmptyValue(false)
            );

            return operation;
        };
    }
}

