package com.wu.compliance.iwatch.sequencegenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SequenceGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(SequenceGeneratorApplication.class, args);
    }

}
