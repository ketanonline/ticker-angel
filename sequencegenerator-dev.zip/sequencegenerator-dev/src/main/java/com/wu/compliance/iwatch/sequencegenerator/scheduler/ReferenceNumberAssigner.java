package com.wu.compliance.iwatch.sequencegenerator.scheduler;

import com.wu.compliance.iwatch.sequencegenerator.model.Case;
import com.wu.compliance.iwatch.sequencegenerator.repository.CaseRepository;
import com.wu.compliance.iwatch.sequencegenerator.service.CaseReferenceNumberService;
import com.wu.compliance.iwatch.sequencegenerator.service.SequenceMasterService;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

@Configuration
@EnableScheduling
@ConditionalOnProperty(prefix = "app", name = "reference.number.assigner.enable")
@Component
public class ReferenceNumberAssigner {

    private final CaseRepository caseRepository;
    private final CaseReferenceNumberService caseReferenceNumberService;
    private final SequenceMasterService sequenceMasterService;
    @Value("${app.documents.batchSize}")
    private Integer batchSize;

    private final Logger logger = LogManager.getLogger(this.getClass());

    public ReferenceNumberAssigner(CaseRepository caseRepository, CaseReferenceNumberService caseReferenceNumberService, SequenceMasterService sequenceMasterService) {
        Objects.requireNonNull(caseRepository, "Case repository is null");
        Objects.requireNonNull(caseReferenceNumberService, "Case reference number service is null");
        Objects.requireNonNull(sequenceMasterService, "Sequence master service is null");
        this.caseRepository = caseRepository;
        this.caseReferenceNumberService = caseReferenceNumberService;
        this.sequenceMasterService = sequenceMasterService;
    }

    @Scheduled(initialDelayString = "${app.reference.number.assigner.initialDelay.in.milliseconds}",
            fixedDelayString = "${app.reference.number.assigner.fixedDelay.in.milliseconds}")
    @SchedulerLock(name = "SCH::assignMissingCaseRefNo")
    public void assign() {
        String schedulerStartTime = Instant.now().toString();
        logger.info(Thread.currentThread().getName()+" Scheduler execution started on : " + schedulerStartTime);
        String schedulerLastRunTimestamp = this.sequenceMasterService.getCurrentSequenceIndexMaster().getSchedulerLastRunTimestamp();

        List<Case> cases = this.caseRepository.fetchCaseRefUnassignedCases(schedulerLastRunTimestamp, batchSize);
        for (Case caseDocument : cases) {
            try {
                if (caseDocument.getCaseRefNo() != null)
                    return;

                String referenceNumber = caseReferenceNumberService.next(caseDocument.getTenant()).getCaseRefNum();

                if (referenceNumber != null) {
                    caseDocument.setCaseRefNo(referenceNumber);
                    caseRepository.updateCaseDocument(caseDocument);
                    logger.info("successfully updated reference number for case id : " + caseDocument.getId() + " new case reference number is : " + referenceNumber);
                } else {
                    logger.error("Not able to update reference number for case id : " + caseDocument.getId() + " for tenant " + caseDocument.getTenant().toString());
                }

            } catch (Exception e) {
                logger.error("Error in updating reference number for case id : " + caseDocument.getId(), e);
            }
        }

        try {
            this.sequenceMasterService.updateSchedulerLastRunTime(schedulerStartTime);
        } catch (Exception e) {
            logger.error("Error in updating the lastRunTimestamp", e);
        }
        logger.info("Scheduler execution completed on : " + Instant.now().toString());
    }
}
