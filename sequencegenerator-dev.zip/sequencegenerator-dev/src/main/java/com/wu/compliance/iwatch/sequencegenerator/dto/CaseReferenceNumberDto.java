package com.wu.compliance.iwatch.sequencegenerator.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CaseReferenceNumberDto {

    private String caseRefNum;

    @JsonCreator(
            mode = JsonCreator.Mode.PROPERTIES
    )
    public CaseReferenceNumberDto(@JsonProperty("caseRefNum") String caseRefNum){
        this.caseRefNum = caseRefNum;
    }

    public String getCaseRefNum() {
        return caseRefNum;
    }

    public void setCaseRefNum(String caseRefNum) {
        this.caseRefNum = caseRefNum;
    }
}
