package com.wu.compliance.iwatch.sequencegenerator.events;

public class Base26Number {

    private int sequenceNumber;

    public Base26Number(int value) {
        sequenceNumber = value;
    }

    public String value() {
        return toBase26(sequenceNumber);
    }

    // https://en.wikipedia.org/w/index.php?title=Hexavigesimal&oldid=578218059#Bijective_base-26
    public static String toBase26(int sequence) {
        StringBuilder ret = new StringBuilder();
        while (sequence > 0) {
            --sequence;
            ret.append((char) ('A' + sequence % 26));
            sequence /= 26;
        }
        return ret.reverse().toString();
    }
}
