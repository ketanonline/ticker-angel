package com.wu.compliance.iwatch.sequencegenerator.service;

import com.wu.compliance.iwatch.microcommonapi.couchbase.CasFailedException;
import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import com.wu.compliance.iwatch.sequencegenerator.model.TenantSequence;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

@Service
public class SequenceRetryableService {

    @Value("${app.tenant.count}")
    int numberOfTenants;

    @Value("${app.sequence.refill.count}")
    int sequenceRefillCount;

    @Value("${app.sequence.initialization.count}")
    int sequenceInitCount;

    private final SequenceGeneratorService sequenceGeneratorService;
    private final SequenceMasterService sequenceMasterService;
    Map<Tenant, ConcurrentLinkedQueue<String>> hashMap = new HashMap<>(numberOfTenants);
    private final Logger logger = LogManager.getLogger(this.getClass());

    public SequenceRetryableService(SequenceGeneratorService sequenceGeneratorService, SequenceMasterService sequenceMasterService) {
        Objects.requireNonNull(sequenceGeneratorService, "sequenceGeneratorService should not be null");
        Objects.requireNonNull(sequenceMasterService, "sequenceMasterService should not be null");
        this.sequenceGeneratorService = sequenceGeneratorService;
        this.sequenceMasterService = sequenceMasterService;
    }

    @Retryable(recover = "initializeSequenceForEachTenantRecover", value = CasFailedException.class,
            maxAttemptsExpression = "${app.maxRetryCount}",
            backoff = @Backoff(delayExpression = "${app.minRetryDelay}", maxDelayExpression = "${app.maxRetryDelay}", random = true))
    public Map<Tenant, ConcurrentLinkedQueue<String>> initializeSequenceForEachTenant(SequenceMaster sequenceMaster, Long cas) {

        List<Pair<Tenant, ConcurrentLinkedQueue<String>>> tenantSequenceList = new ArrayList<>();
        List<TenantSequence> tenantSequences = new ArrayList<>();

        logger.info("Initializing sequence cache for all the tenants.");

        // for all sequences in master document
        sequenceMaster.getSequences().forEach(sequence -> {
            // for each sequence generate sequence numbers and next index
            Pair<List<String>, Integer> generatedSequencesWithNextIndex = sequenceGeneratorService.nextBatch(sequence.getIndex(), sequenceInitCount);
            // update the new index after sequence generation
            sequence.setIndex(generatedSequencesWithNextIndex.getRight());
            // add tenant and sequence cache as a pair to a list
            tenantSequenceList.add(Pair.of(sequence.getTenant(), new ConcurrentLinkedQueue<>(generatedSequencesWithNextIndex.getLeft())));
            tenantSequences.add(sequence);
        });
        sequenceMaster.setSequences(tenantSequences);

        sequenceMasterService.updateMasterDocument(sequenceMaster, cas);
        // document is saved successfully, so dump all pairs of tenants and their corresponding sequence numbers into hashMap cache
        tenantSequenceList.parallelStream().forEach(pair -> hashMap.put(pair.getLeft(), pair.getRight()));
        logger.info("Initializing sequence cache done for all the tenants.");
        return hashMap;
    }

    @Retryable(recover = "updateSequenceQueueRecover", value = CasFailedException.class,
            maxAttemptsExpression = "${app.maxRetryCount}",
            backoff = @Backoff(delayExpression = "${app.minRetryDelay}", maxDelayExpression = "${app.maxRetryDelay}", random = true))
    public Map<Tenant, ConcurrentLinkedQueue<String>> updateSequenceQueue(Tenant tenant, ConcurrentLinkedQueue<String> sequenceQueue) {
        try {
            DocumentWithMetaData<SequenceMaster> sequenceMasterWithCas = sequenceMasterService.getCurrentSequenceIndexMasterWithCas();
            logger.info("Refilling sequence cache for the tenant with pId: " + tenant.getpId() + " sId: " + tenant.getsId());
            Pair<List<String>, Integer> listIntegerPair = sequenceGeneratorService.nextBatch(sequenceMasterWithCas.getDocument().getSequenceIndexByTenant(tenant), sequenceRefillCount);
            logger.info("Tenant pId: " + tenant.getpId() + " sId: " + tenant.getsId() + " sequence has been refilled.");

            // sets tenant and updated Sequence Number in SequenceMaster
            sequenceMasterWithCas.getDocument().setSequenceIndexByTenant(tenant, listIntegerPair.getRight());
            sequenceMasterService.updateMasterDocument(sequenceMasterWithCas.getDocument(), sequenceMasterWithCas.getCas());
            sequenceQueue.addAll(listIntegerPair.getLeft());
            hashMap.put(tenant, sequenceQueue);
        } catch (CasFailedException rfException) {
            logger.error("Cas mismatch occurred while updating document.");
            throw rfException;
        } catch (Exception e) {
            logger.error("Error while updating the latest sequence index", e);
        }
        return hashMap;
    }

    @Recover
    public Map<Tenant, ConcurrentLinkedQueue<String>> initializeSequenceForEachTenantRecover(CasFailedException rfException,
                                                                                             SequenceMaster sequenceMaster, Long cas) {
        logger.error("Failed to Initializing sequence cache for all the tenants due to cas mismatch. Retry Exhausted !");
        throw new CasFailedException(rfException);
    }

    @Recover
    public Map<Tenant, ConcurrentLinkedQueue<String>> updateSequenceQueueRecover(CasFailedException rfException, Tenant tenant,
                                                                                 ConcurrentLinkedQueue<String> sequenceQueue) {
        logger.error("Failed to Refilled sequence cache due to cas mismatch. Retry Exhausted !");
        throw new CasFailedException(rfException);
    }
}