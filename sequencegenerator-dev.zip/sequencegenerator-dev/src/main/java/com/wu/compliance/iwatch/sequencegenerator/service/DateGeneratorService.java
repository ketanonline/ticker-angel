package com.wu.compliance.iwatch.sequencegenerator.service;

import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
@Service
public class DateGeneratorService {

    public String generatePrefix() {
        return new SimpleDateFormat("yyMMdd").format(new Date());
    }
}
