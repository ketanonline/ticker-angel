package com.wu.compliance.iwatch.sequencegenerator.configuration;

import com.wu.compliance.iwatch.microcommonapi.couchbase.QueryExecutor;
import com.wu.compliance.iwatch.microcommonapi.couchbase.QueryExecutorFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Objects;

@Configuration
public class CouchbaseConfiguration   {

    @Bean
    public QueryExecutor queryExecutor(@Value("${app.couchbase.host}") String host,
                                       @Value("${secret.cmtcmpl.iwatchx.database.cjcouchbase.username}") String username,
                                       @Value("${secret.cmtcmpl.iwatchx.database.cjcouchbase.password}") String password,
                                       @Value("${app.couchbase.trustStorePath:}") String trustStorePath){
        Objects.requireNonNull(host, "host should not be null");
        Objects.requireNonNull(username, "username should not be null");
        Objects.requireNonNull(password, "password should not be null");
        Objects.requireNonNull(trustStorePath, "trustStorePath should not be null");
        return QueryExecutorFactory.create(host, username, password, trustStorePath);
    }
}
