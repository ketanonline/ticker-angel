package com.wu.compliance.iwatch.sequencegenerator.exception;

import com.wu.compliance.iwatch.microcommonapi.CommonHeaderAccessor;
import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.couchbase.CasFailedException;
import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import static com.wu.compliance.iwatch.sequencegenerator.dto.response.ResponseBuilder.buildBadRequestResponse;
import static com.wu.compliance.iwatch.sequencegenerator.dto.response.ResponseBuilder.buildUnknownErrorResponse;
import static com.wu.compliance.iwatch.sequencegenerator.dto.response.ResponseBuilder.buildCasFailedErrorResponse;

@ControllerAdvice
public class SequenceGeneratorExceptionHandler {

    @Autowired
    private CommonHeaderAccessor commonHeaderAccessor;

    private final Logger logger = LogManager.getLogger(this.getClass());

    public static final String GLOBAL_EXCEPTION_HANDLER_MESSAGE = "failed to process due to exception : %s";

    private String getCorrelationId() {
        return commonHeaderAccessor.getHeader(HeaderKey.CORRELATION_ID);
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<DefaultResponse> handleRuntimeException(final RuntimeException exception) {
        String globalExceptionMessage = String.format(GLOBAL_EXCEPTION_HANDLER_MESSAGE, exception.getMessage());
        logger.error(globalExceptionMessage, exception);

        final DefaultResponse responseMessageDto = buildUnknownErrorResponse(getCorrelationId(), exception.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseMessageDto);
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<DefaultResponse> handleCustomValidationException(final ValidationException exception) {
        logger.error(ExceptionUtils.getMessage(exception), exception);
        final DefaultResponse responseMessageDto = buildBadRequestResponse(getCorrelationId(), exception.getErrorDetails());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseMessageDto);
    }

    @ExceptionHandler(CasFailedException.class)
    public ResponseEntity<DefaultResponse> handleCasFailedException(final CasFailedException exception) {
        final DefaultResponse responseMessageDto = buildCasFailedErrorResponse(getCorrelationId(), exception.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseMessageDto);
    }
}

