package com.wu.compliance.iwatch.sequencegenerator.model;

import java.util.Objects;

public class Tenant {
    private String pId;
    private String sId;

    public Tenant() {
    }

    public Tenant(String pId, String sId) {
        this.pId = pId;
        this.sId = sId;
    }

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public String getsId() {
        return sId;
    }

    public void setsId(String sId) {
        this.sId = sId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Tenant)) return false;
        Tenant tenant = (Tenant) o;
        return getpId().equals(tenant.getpId()) &&
                getsId().equals(tenant.getsId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getpId(), getsId());
    }
}
