package com.wu.compliance.iwatch.sequencegenerator.exception;

import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;

import java.io.Serializable;
import java.util.List;

public class ValidationException extends RuntimeException implements Serializable {
    private final List<ErrorDetail> errorDetails;

    public ValidationException(List<ErrorDetail> errorDetails, String message) {
        super(message);
        this.errorDetails = errorDetails;
    }

    public List<ErrorDetail> getErrorDetails() {
        return errorDetails;
    }
}
