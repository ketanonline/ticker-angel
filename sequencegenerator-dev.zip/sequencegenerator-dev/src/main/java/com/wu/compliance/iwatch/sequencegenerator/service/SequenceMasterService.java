package com.wu.compliance.iwatch.sequencegenerator.service;


import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import com.wu.compliance.iwatch.sequencegenerator.model.TenantSequence;
import com.wu.compliance.iwatch.sequencegenerator.repository.SequenceMasterRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class SequenceMasterService {

    private final SequenceMasterRepository sequenceMasterRepository;

    private final Logger logger = LogManager.getLogger(this.getClass());

    public SequenceMasterService(SequenceMasterRepository sequenceMasterRepository) {
        Objects.requireNonNull(sequenceMasterRepository, "Sequence master repository is null");
        this.sequenceMasterRepository = sequenceMasterRepository;
    }

    public int getCurrentSequenceIndex(Tenant tenant) {
        int caseSequenceNumber = 0;
        try {
            SequenceMaster sequenceMaster = sequenceMasterRepository.getSequenceIndexDocument();

            if (sequenceMaster != null) {
                caseSequenceNumber = sequenceMaster.getSequences().stream()
                        .filter(x -> x.getTenant().getpId().equals(tenant.getpId()) && x.getTenant().getsId().equals(tenant.getsId()))
                        .findFirst()
                        .map(TenantSequence::getIndex).orElse(0);
            }

        } catch (Exception e) {
            logger.error("Error while fetching sequence index document.",e);
        }
        return caseSequenceNumber;
    }

    public SequenceMaster getCurrentSequenceIndexMaster() {
        try {
            SequenceMaster sequenceMaster = sequenceMasterRepository.getSequenceIndexDocument();
            return sequenceMaster;
        } catch (Exception e) {
            logger.error("Error while fetching sequence index document.",e);
        }
        return null;
    }

    public DocumentWithMetaData<SequenceMaster> getCurrentSequenceIndexMasterWithCas() {
        return sequenceMasterRepository.getDocumentWithCas();
    }

    public void updateSchedulerLastRunTime(String schedulerStartTime) {
        SequenceMaster sequenceMaster = sequenceMasterRepository.getSequenceIndexDocument();

        if (sequenceMaster != null) {
            sequenceMaster.setSchedulerLastRunTimestamp(schedulerStartTime);
            this.sequenceMasterRepository.updateSequenceMasterField(sequenceMaster);
        }
    }

    public void updateMasterDocument(SequenceMaster masterDocument, Long cas) {
        this.sequenceMasterRepository.updateSequenceMasterDocument(masterDocument, cas);
    }
}
