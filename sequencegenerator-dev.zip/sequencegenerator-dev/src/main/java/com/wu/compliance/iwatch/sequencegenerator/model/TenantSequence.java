package com.wu.compliance.iwatch.sequencegenerator.model;

public class TenantSequence {
    private Tenant tenant;
    private int index;

    public Tenant getTenant() {
        return tenant;
    }

    public void setTenant(Tenant tenant) {
        this.tenant = tenant;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
