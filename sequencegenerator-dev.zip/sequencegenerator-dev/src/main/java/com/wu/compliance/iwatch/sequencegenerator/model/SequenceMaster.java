package com.wu.compliance.iwatch.sequencegenerator.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

public class SequenceMaster {
    private String docType;
    private List<TenantSequence> sequences;
    private String schedulerLastRunTimestamp;

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public List<TenantSequence> getSequences() {
        return sequences;
    }

    public void setSequences(List<TenantSequence> sequences) {
        this.sequences = sequences;
    }

    public String getSchedulerLastRunTimestamp() {
        return schedulerLastRunTimestamp;
    }

    public void setSchedulerLastRunTimestamp(String schedulerLastRunTimestamp) {
        this.schedulerLastRunTimestamp = schedulerLastRunTimestamp;
    }

    @JsonIgnore
    public Integer getSequenceIndexByTenant(Tenant tenant) {
        return this.sequences.stream()
                .filter(x -> x.getTenant().getpId().equals(tenant.getpId()) && x.getTenant().getsId().equals(tenant.getsId()))
                .findFirst()
                .map(TenantSequence::getIndex).orElse(0);
    }

    @JsonIgnore
    public void setSequenceIndexByTenant(Tenant tenant, Integer nextSequenceIndex) throws Exception {
        sequences.stream()
                .filter(x -> x.getTenant().getpId().equals(tenant.getpId()) && x.getTenant().getsId().equals(tenant.getsId()))
                .findFirst()
                .orElseThrow(Exception::new)
                .setIndex(nextSequenceIndex);
    }
}
