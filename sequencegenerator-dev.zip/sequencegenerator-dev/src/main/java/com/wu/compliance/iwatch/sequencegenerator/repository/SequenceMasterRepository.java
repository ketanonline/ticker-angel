package com.wu.compliance.iwatch.sequencegenerator.repository;

import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.microcommonapi.couchbase.QueryExecutor;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public class SequenceMasterRepository {

    @Value("${app.couchbase.sequence.index.document.id}")
    private String sequenceMasterDocumentId;
    @Value("${app.couchbase.bucket.customer.journey}")
    private String iWatchXCustomerJourneyBucket;
    private final QueryExecutor queryExecutor;
    private final Logger logger = LogManager.getLogger(this.getClass());

    public SequenceMasterRepository(QueryExecutor queryExecutor) {
        this.queryExecutor = queryExecutor;
    }

    public SequenceMaster getSequenceIndexDocument() {
        Optional<SequenceMaster> sequenceMaster  = queryExecutor.findById(iWatchXCustomerJourneyBucket, sequenceMasterDocumentId, SequenceMaster.class);
        if (sequenceMaster.isEmpty())
            logger.error("No such document present in the database with id : " + sequenceMasterDocumentId);
        return sequenceMaster.orElse(null);
    }

    public DocumentWithMetaData<SequenceMaster> getDocumentWithCas() {
        return queryExecutor.findByIdWithMetadata(iWatchXCustomerJourneyBucket, sequenceMasterDocumentId, SequenceMaster.class);

    }

    public void updateSequenceMasterField(SequenceMaster sequenceMaster) {
        try {
            queryExecutor.upsert(iWatchXCustomerJourneyBucket, sequenceMasterDocumentId,sequenceMaster );
        } catch (Exception e) {
            logger.error("Error while updating sequence master Document.", e);
            throw e;
        }
    }

    public void updateSequenceMasterDocument(SequenceMaster sequenceMaster, Long cas) {
        queryExecutor.replace(iWatchXCustomerJourneyBucket, sequenceMasterDocumentId, sequenceMaster, options -> options.cas(cas));
    }
}
