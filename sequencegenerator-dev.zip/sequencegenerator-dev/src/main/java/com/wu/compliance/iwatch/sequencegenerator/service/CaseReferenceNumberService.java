package com.wu.compliance.iwatch.sequencegenerator.service;

import com.wu.compliance.iwatch.sequencegenerator.dto.CaseReferenceNumberDto;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class CaseReferenceNumberService {

    @Value("${app.sequence.prefix:CC}")
    private String sequencePrefix;


    private final SequenceCacheService sequenceCacheService;
    private final DateGeneratorService dateGeneratorService;
    private final String cloudRegion;

    private final Logger logger = LogManager.getLogger(this.getClass());

    public CaseReferenceNumberService(SequenceCacheService sequenceCacheService,
                                      DateGeneratorService dateGeneratorService,
                                      @Value("${CLOUD_REGION}")
                                      String cloudRegion) {
        Objects.requireNonNull(sequenceCacheService, "Sequence cache service should not be null");
        Objects.requireNonNull(dateGeneratorService, "Date generator service should not be null");
        Objects.requireNonNull(cloudRegion, "Cloud Region should not be null");
        if (StringUtils.isBlank(cloudRegion)) {
            throw new RuntimeException("Could Region is empty.");
        }
        this.sequenceCacheService = sequenceCacheService;
        this.dateGeneratorService = dateGeneratorService;
        this.cloudRegion = cloudRegion;
    }

    public CaseReferenceNumberDto next(Tenant tenant) {
        String sequenceNumber = sequenceCacheService.next(tenant);
        if (sequenceNumber != null) {
            sequenceNumber = this.buildSequence(dateGeneratorService.generatePrefix(), sequenceNumber);
            logger.info("A new case reference number for the tenant with pId: " + tenant.getpId() + " and sId: " + tenant.getsId() + " generated: " + sequenceNumber);
        } else
            logger.error("Error in generating new case reference number returning null");

        return new CaseReferenceNumberDto(sequenceNumber);
    }

    public String buildSequence(String date, String sequence) {
        return sequencePrefix
                + cloudRegion
                + date.substring(0, 2)
                + sequence.substring(0, 2)
                + date.substring(2)
                + sequence.substring(2, 4);
    }
}
