package com.wu.compliance.iwatch.sequencegenerator.controller;

import com.wu.compliance.iwatch.microcommonapi.CommonHeaderAccessor;
import com.wu.compliance.iwatch.microcommonapi.HeaderKey;
import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.HeaderSchemaValidator;
import com.wu.compliance.iwatch.microcommonapi.jsonschema.validation.ValidationResult;
import com.wu.compliance.iwatch.sequencegenerator.dto.CaseReferenceNumberDto;
import com.wu.compliance.iwatch.sequencegenerator.exception.ValidationException;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import com.wu.compliance.iwatch.sequencegenerator.service.CaseReferenceNumberService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
@Tag(name ="Case Reference Number Controller")
public class CaseReferenceNumberController {

    private final CaseReferenceNumberService caseReferenceNumberService;
    private final CommonHeaderAccessor headers;
    private final HeaderSchemaValidator schemaValidator;

    private final Logger logger = LogManager.getLogger(this.getClass());

    public CaseReferenceNumberController(CaseReferenceNumberService caseReferenceNumberService, HeaderSchemaValidator validator, CommonHeaderAccessor headerProvider) {
        Objects.requireNonNull(caseReferenceNumberService, "case reference number service is null");
        Objects.requireNonNull(validator, "schema validator is null");
        Objects.requireNonNull(headerProvider, "header provider is null");

        this.caseReferenceNumberService = caseReferenceNumberService;
        this.schemaValidator = validator;
        this.headers = headerProvider;
    }

    @GetMapping("/v1/iwx/cj/sequences/generate")
    public ResponseEntity<CaseReferenceNumberDto> getSequence() {
        ValidationResult headerValidationResult = schemaValidator.validate();

        if (!headerValidationResult.isValid())
            throw new ValidationException(headerValidationResult.getErrorDetails(), "Header Validation Error");
        logger.debug("Header Validation Passed");

        Tenant tenant = new Tenant(headers.getHeader(HeaderKey.TENANT_PID), headers.getHeader(HeaderKey.TENANT_SID));
        return ResponseEntity.ok(caseReferenceNumberService.next(tenant));
    }
}
