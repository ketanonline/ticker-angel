package com.wu.compliance.iwatch.sequencegenerator.service;

import com.wu.compliance.iwatch.microcommonapi.couchbase.CasFailedException;
import com.wu.compliance.iwatch.microcommonapi.couchbase.DocumentWithMetaData;
import com.wu.compliance.iwatch.sequencegenerator.model.SequenceMaster;
import com.wu.compliance.iwatch.sequencegenerator.model.Tenant;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;

@Service
public class SequenceCacheService {

    @Value("${app.sequence.minimum.cache.size}")
    int sequenceMinimumCacheSize;

    @Value("${app.tenant.count}")
    int numberOfTenants;

    private final SequenceMasterService sequenceMasterService;
    private final SequenceRetryableService sequenceRetryableService;
    Map<Tenant, ConcurrentLinkedQueue<String>> hashMap = new HashMap<>(numberOfTenants);

    private final Logger logger = LogManager.getLogger(this.getClass());

    public SequenceCacheService(SequenceMasterService sequenceMasterService, SequenceRetryableService sequenceRetryableService) {
        Objects.requireNonNull(sequenceMasterService, "sequence master service is null");
        Objects.requireNonNull(sequenceRetryableService, "retryable service is null");

        this.sequenceMasterService = sequenceMasterService;
        this.sequenceRetryableService = sequenceRetryableService;
    }

    public String next(Tenant tenant) {
        if (hashMap.containsKey(tenant)) {
            ConcurrentLinkedQueue<String> sequenceQueue = hashMap.get(tenant);
            synchronized (sequenceQueue) {
                if (sequenceQueue.size() < sequenceMinimumCacheSize) {
                    hashMap = sequenceRetryableService.updateSequenceQueue(tenant, sequenceQueue);
                }
                return sequenceQueue.poll();
            }
        }
        return null;
    }

    @PostConstruct
    public void initializeSequenceCache() {
        try {
            DocumentWithMetaData<SequenceMaster> documentWithCas = sequenceMasterService.getCurrentSequenceIndexMasterWithCas();
            hashMap = sequenceRetryableService.initializeSequenceForEachTenant(documentWithCas.getDocument(), documentWithCas.getCas());

        } catch (CasFailedException re) {
            logger.error("Cas mismatch occurred while saving document.", re);
            throw re;
        } catch (Exception e) {
            logger.error("Error while initializing sequence cache, please check case reference sequence master document.");
        }
    }
}