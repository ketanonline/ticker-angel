package com.wu.compliance.iwatch.sequencegenerator.service;

import com.wu.compliance.iwatch.sequencegenerator.events.Base26Number;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SequenceGeneratorService {

    private static final int startIndex = 18279;
    private static final int endIndex = 475254;

    private final  Logger logger = LogManager.getLogger(this.getClass());

    public Pair<List<String>, Integer> nextSequence(int sequenceNumber, int counter) {
        List<String> sequenceCache = new ArrayList<>();

        if (!isResetRequired(sequenceNumber, counter)) {
            while (counter > 0) {
                --counter;
                sequenceCache.add(Base26Number.toBase26(sequenceNumber));
                sequenceNumber++;
            }
        } else {
            while (counter > 0) {
                --counter;
                sequenceCache.add(Base26Number.toBase26(sequenceNumber));
                sequenceNumber++;
                sequenceNumber = resetIfEndIndexReached(sequenceNumber);
            }
        }
        logger.info("Generated next sequence batch of size: " + sequenceCache.size() + ", and new sequence index is: " + sequenceNumber);
        return Pair.of(sequenceCache, sequenceNumber);
    }

    public Pair<List<String>, Integer> nextBatch(int currentIndex, int counter) {
        logger.info("Requested next sequence batch with initial index: " + currentIndex + " with counter: " + counter);
        return nextSequence(currentIndex, counter);
    }

    public boolean isResetRequired(int sequenceNumber, int counter) {
        int total = sequenceNumber + counter;
        return total > endIndex;
    }

    // sequence number will be reset to the startIndex if it has consumed all the sequence numbers till ZZZZ
    // or whatever last index specified.
    public int resetIfEndIndexReached(int sequenceNumber) {
        if (sequenceNumber > endIndex)
            sequenceNumber = startIndex;

        return sequenceNumber;
    }

}
