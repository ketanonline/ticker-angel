package com.wu.compliance.iwatch.sequencegenerator.dto.response;

import com.wu.compliance.iwatch.microcommonapi.dto.DefaultResponse;
import com.wu.compliance.iwatch.microcommonapi.dto.ErrorDetail;
import com.wu.compliance.iwatch.microcommonapi.dto.Message;

import java.util.List;

public class ResponseBuilder {

    private String traceId;
    private String code;
    private String description;
    private Message messageDto;
    private List<ErrorDetail> errorDetails;

    private static String productName = "Pharos";

    private ResponseBuilder() {
    }

    public static DefaultResponse buildBadRequestResponse(String traceId, List<ErrorDetail> errorDetails) {
        return new ResponseBuilder()
                .code("WUIWXSG4000")
                .traceId(traceId)
                .errorDetails(errorDetails)
                .message(new Message(productName, "Bad request"))
                .build();
    }

    public static DefaultResponse buildUnknownErrorResponse(String traceId, String errorDescription) {
        return new ResponseBuilder()
                .code("WUIWXSG5000")
                .traceId(traceId)
                .description(errorDescription)
                .message(new Message(productName, "Internal Server Error"))
                .build();
    }

    public static DefaultResponse buildCasFailedErrorResponse(String traceId, String errorDescription) {
        return DefaultResponse.builder()
                .code("WUIWXSG4000")
                .traceId(traceId)
                .description(errorDescription)
                .message(new Message(productName, "Refilling sequence cache failed. Retry exhausted!"))
                .build();
    }

    public ResponseBuilder traceId(String traceId) {
        this.traceId = traceId;
        return this;
    }

    public ResponseBuilder code(String code) {
        this.code = code;
        return this;
    }

    public ResponseBuilder description(String description) {
        this.description = description;
        return this;
    }

    public ResponseBuilder message(Message messageDto) {
        this.messageDto = messageDto;
        return this;
    }

    public ResponseBuilder errorDetails(List<ErrorDetail> errorDetails) {
        this.errorDetails = errorDetails;
        return this;
    }

    public DefaultResponse build() {
        return new DefaultResponse(traceId, code, description,messageDto, errorDetails);
    }
}