package com.wu.compliance.iwatch.sequencegenerator.configuration;

import com.couchbase.client.core.env.SecurityConfig;
import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.ClusterOptions;
import com.couchbase.client.java.env.ClusterEnvironment;
import net.javacrumbs.shedlock.provider.couchbase.javaclient3.CouchbaseLockProvider;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.file.Paths;

@Configuration
public class ShedlockConfiguration {

    private Bucket bucket;

    @Bean
    public Cluster getConnection(@Value("${app.couchbase.host}") String host,
                                 @Value("${secret.cmtcmpl.iwatchx.database.cjcouchbase.username}") String username,
                                 @Value("${secret.cmtcmpl.iwatchx.database.cjcouchbase.password}") String password,
                                 @Value("${app.couchbase.trustStorePath:}") String trustStorePath,
                                 @Value("${app.couchbase.bucket.customer.journey}") String customerJourneyBucket) {
        Cluster cluster;
        if (StringUtils.isBlank(trustStorePath)) {
            cluster = Cluster.connect(host, username, password);
        } else {
            ClusterEnvironment env = (ClusterEnvironment.builder().securityConfig(SecurityConfig.enableTls(true).trustCertificate(Paths.get(trustStorePath)))).build();
            cluster = Cluster.connect(host, ClusterOptions.clusterOptions(username, password).environment(env));
        }
        this.bucket= cluster.bucket(customerJourneyBucket);
        return cluster;
    }

    @Bean
    public CouchbaseLockProvider lockProvider() {
        return new CouchbaseLockProvider(bucket);
    }
}