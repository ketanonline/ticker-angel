
package com.wu.compliance.iwatch.sequencegenerator.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.wu.compliance.iwatch.microcommonapi.dto.OffsetDateTimeToString;
import com.wu.compliance.iwatch.microcommonapi.dto.StringToOffsetDateTime;

import java.time.OffsetDateTime;

public class Case {
    private String caseRefNo;
    private String id;
    private Tenant tenant;
    @JsonSerialize(converter = OffsetDateTimeToString.class)
    @JsonDeserialize(converter = StringToOffsetDateTime.class)
    private OffsetDateTime modifiedTimestamp;

    public Tenant getTenant() { return tenant; }

    public String getCaseRefNo() {
        return caseRefNo;
    }

    public void setCaseRefNo(String caseRefNo) {
        this.caseRefNo = caseRefNo;
    }

    public String getId() {
        return id;
    }
}
