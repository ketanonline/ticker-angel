package com.wu.compliance.iwatch.sequencegenerator.configuration;

import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.retry.annotation.EnableRetry;

@Configuration
@ComponentScan(basePackages = "com.wu.compliance.iwatch")
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "${app.sequence.generator.atMostFor}" ,defaultLockAtLeastFor = "${app.sequence.generator.atLeastFor}")
@EnableRetry
public class SequenceGeneratorConfiguration {
}
